#include <windows.h>

#include <algorithm>
#include <cctype>
#include <cmath>
#include <cstdint>
#include <cstdlib>
#include <cstdio>
#include <cstring>
#include <fstream>
#include <functional>
#include <iomanip>
#include <iostream>
#include <iterator>
#include <limits>
#include <map>
#include <set>
#include <sstream>
#include <string>
#include <unordered_map>
#include <unordered_set>
#include <vector>

// ============================================================
// OTCLab BuildMigrator V4.9.3 DIRECT BIND + Player Rebind + Look/Light Auto Discovery
// POSITION/DIRECTION VALIDATION + POINTER PATH DISCOVERY
//
// Fluxo:
//   1. DLL e injetada com o cliente ainda deslogado.
//   2. Fingerprint do EXE e feito imediatamente.
//   3. Para build desconhecida, a DLL espera o usuario logar.
//   4. Depois pede de uma vez:
//        Health / MaxHealth
//        Mana / MaxMana
//        Experience
//        Level
//        Capacity
//   5. Faz uma descoberta "grossa" do LocalPlayer.
//   6. Depois de achar LocalPlayer, NAO varre mais o processo todo.
//   7. Procura todos os stats apenas numa pequena janela do objeto.
//   8. Campos localizados ficam strong_candidate.
//   9. Campos ambiguos/collision/unresolved sao perguntados novamente.
//  10. Para os pendentes, o usuario altera o valor e a DLL valida
//      por transicao before -> after.
//  11. Salva JSON da nova build.
//
// CORE READ-ONLY:
//   - discovery/calibration principal nao escreve memoria;
//   - Look/Light ACTIVE VERIFY e opcional, explicito e reversivel;
//   - nenhuma feature ativa roda sem confirmacao do usuario.
// ============================================================

namespace
{

static_assert(sizeof(void*) == 8, "OTCLab x64 source must be compiled with a 64-bit compiler.");
constexpr const char* OTCLAB_BUILD_ARCH = "x64";

// ============================================================
// REFERENCE SHAPE
//
// Layout conhecido usado SOMENTE como pista/forma.
// Outra build pode ter offsets diferentes.
// ============================================================

constexpr uintptr_t REF_OFF_X          = 0x18;
constexpr uintptr_t REF_OFF_Y          = 0x1C;
constexpr uintptr_t REF_OFF_Z          = 0x20;
constexpr uintptr_t REF_OFF_ID         = 0x38;
constexpr uintptr_t REF_OFF_HP_PERCENT = 0x60;
constexpr uintptr_t REF_OFF_DIRECTION  = 0x64;

constexpr uintptr_t REF_OFF_HEALTH     = 0x658;
constexpr uintptr_t REF_OFF_MAX_HEALTH = 0x660;
constexpr uintptr_t REF_OFF_CAPACITY   = 0x668;
constexpr uintptr_t REF_OFF_EXPERIENCE = 0x678;
constexpr uintptr_t REF_OFF_LEVEL      = 0x680;
constexpr uintptr_t REF_OFF_MANA       = 0x690;
constexpr uintptr_t REF_OFF_MAX_MANA   = 0x698;

// Depois de achar LocalPlayer, so essa janela e observada.
constexpr uintptr_t LOCAL_SCAN_BEGIN = 0x300;
constexpr uintptr_t LOCAL_SCAN_END   = 0x1200;

// ============================================================
// V4.9.1 - x64 FEATURE CALIBRATION / ACTIVE VERIFY
// ============================================================

constexpr uintptr_t FEATURE_LIGHT_SCAN_BEGIN = 0x000;
constexpr uintptr_t FEATURE_LIGHT_SCAN_END   = 0x1200;
constexpr uint8_t   FEATURE_LIGHT_DEFAULT_HACK_VALUE = 15;

// ============================================================
// GLOBALS
// ============================================================

HMODULE   g_dllModule = nullptr;
uintptr_t g_exeBase   = 0;
uintptr_t g_imageEnd  = 0;
uintptr_t g_textBegin = 0;
uintptr_t g_textEnd   = 0;

// Final-profile evidence gathered during this run.
std::map<unsigned, uintptr_t> g_floorHeaderObservations;
std::unordered_map<std::string, std::string> g_functionResolutionMethod;
std::unordered_map<std::string, double> g_functionResolutionScore;

// ============================================================
// TYPES
// ============================================================

struct BuildInfo
{
    DWORD timestamp = 0;
    DWORD sizeOfImage = 0;
    DWORD entryPointRva = 0;
    DWORD textRva = 0;
    DWORD textSize = 0;
    uint64_t textHash = 0;

    std::string exePath;
};

struct BulkInput
{
    double health = 0.0;
    double maxHealth = 0.0;
    double mana = 0.0;
    double maxMana = 0.0;
    double experience = 0.0;
    double level = 0.0;
    double capacity = 0.0;
};

struct Evidence
{
    std::string name;
    uintptr_t address = 0;
    double value = 0.0;
};

struct Candidate
{
    uintptr_t anchor = 0;
    std::vector<Evidence> evidence;
};

struct BaseHypothesis
{
    uintptr_t base = 0;
    uintptr_t vtable = 0;

    int score = 0;

    uint32_t x = 0;
    uint32_t y = 0;
    uint8_t z = 0;

    uint32_t id = 0;
    uint8_t hpPercent = 0;
    uint32_t direction = 0;
};

struct DoubleCell
{
    uintptr_t address = 0;
    uintptr_t offset = 0;
    double value = 0.0;
};

enum class FieldState
{
    Unknown,
    Unresolved,
    Ambiguous,
    Collision,
    StrongCandidate,
    Confirmed,
    Skipped
};

struct FieldResult
{
    std::string name;

    uintptr_t address = 0;
    uintptr_t offset = 0;

    double value = 0.0;
    double before = 0.0;
    double after = 0.0;

    FieldState state = FieldState::Unknown;

    std::string evidence;

    bool valid() const
    {
        return
            address != 0 &&
            (
                state == FieldState::StrongCandidate ||
                state == FieldState::Confirmed
            );
    }

    bool pending() const
    {
        return
            state == FieldState::Unknown ||
            state == FieldState::Unresolved ||
            state == FieldState::Ambiguous ||
            state == FieldState::Collision;
    }
};

struct PairResult
{
    FieldResult current;
    FieldResult maximum;

    bool pending() const
    {
        return
            current.pending() ||
            maximum.pending();
    }
};

struct ProfileFields
{
    FieldResult health;
    FieldResult maxHealth;

    FieldResult mana;
    FieldResult maxMana;

    FieldResult experience;
    FieldResult level;
    FieldResult capacity;
};


struct UIntFieldResult
{
    std::string name;

    uintptr_t address = 0;
    uintptr_t offset = 0;

    uint64_t before = 0;
    uint64_t after = 0;

    FieldState state = FieldState::Unknown;
    std::string evidence;

    bool valid() const
    {
        return
            address != 0 &&
            (
                state == FieldState::StrongCandidate ||
                state == FieldState::Confirmed
            );
    }
};

struct PositionCalibration
{
    UIntFieldResult x;
    UIntFieldResult y;
    UIntFieldResult z;
    UIntFieldResult direction;
};

struct U32Cell
{
    uintptr_t address = 0;
    uintptr_t offset = 0;
    uint32_t value = 0;
};

struct U8Cell
{
    uintptr_t address = 0;
    uintptr_t offset = 0;
    uint8_t value = 0;
};

struct ModuleSection
{
    std::string name;

    uintptr_t begin = 0;
    uintptr_t end = 0;

    DWORD characteristics = 0;

    bool readable() const
    {
        return
            (
                characteristics &
                IMAGE_SCN_MEM_READ
            ) != 0;
    }

    bool writable() const
    {
        return
            (
                characteristics &
                IMAGE_SCN_MEM_WRITE
            ) != 0;
    }

    bool executable() const
    {
        return
            (
                characteristics &
                IMAGE_SCN_MEM_EXECUTE
            ) != 0;
    }
};

struct PointerPathCandidate
{
    bool direct = false;

    uintptr_t globalAddress = 0;
    uintptr_t globalRva = 0;

    std::string section;

    uintptr_t ownerRuntime = 0;
    uintptr_t ownerOffset = 0;

    std::string status;
};

struct PointerDiscovery
{
    std::vector<PointerPathCandidate> direct;
    std::vector<PointerPathCandidate> indirect;

    bool hasBest = false;
    PointerPathCandidate best;
};

// ============================================================
// CONSOLE
// ============================================================

void OpenConsole()
{
    AllocConsole();

    FILE* dummy = nullptr;

#ifdef _MSC_VER
    freopen_s(
        &dummy,
        "CONOUT$",
        "w",
        stdout
    );

    freopen_s(
        &dummy,
        "CONOUT$",
        "w",
        stderr
    );

    freopen_s(
        &dummy,
        "CONIN$",
        "r",
        stdin
    );
#else
    dummy = freopen(
        "CONOUT$",
        "w",
        stdout
    );

    dummy = freopen(
        "CONOUT$",
        "w",
        stderr
    );

    dummy = freopen(
        "CONIN$",
        "r",
        stdin
    );
#endif

    SetConsoleTitleA(
        "OTCLab BuildMigrator V4.9.3 DIRECT BIND + Player Rebind + Look/Light Auto Discovery"
    );
}

// ============================================================
// MEMORY
// ============================================================

bool IsReadableProtection(
    DWORD protect)
{
    if (protect & PAGE_GUARD)
        return false;

    if (protect & PAGE_NOACCESS)
        return false;

    switch (protect & 0xFF)
    {
        case PAGE_READONLY:
        case PAGE_READWRITE:
        case PAGE_WRITECOPY:
        case PAGE_EXECUTE_READ:
        case PAGE_EXECUTE_READWRITE:
        case PAGE_EXECUTE_WRITECOPY:
            return true;
    }

    return false;
}

template<typename T>
bool SafeRead(
    uintptr_t address,
    T& out)
{
    if (!address)
        return false;

    MEMORY_BASIC_INFORMATION mbi{};

    if (!VirtualQuery(
            reinterpret_cast<void*>(address),
            &mbi,
            sizeof(mbi)))
    {
        return false;
    }

    if (mbi.State != MEM_COMMIT ||
        !IsReadableProtection(mbi.Protect))
    {
        return false;
    }

    uintptr_t begin =
        reinterpret_cast<uintptr_t>(
            mbi.BaseAddress
        );

    uintptr_t end =
        begin +
        mbi.RegionSize;

    if (address < begin ||
        address + sizeof(T) > end)
    {
        return false;
    }

    std::memcpy(
        &out,
        reinterpret_cast<const void*>(
            address
        ),
        sizeof(T)
    );

    return true;
}

uintptr_t ReadPtr(
    uintptr_t address)
{
    uintptr_t value = 0;
    SafeRead(address, value);
    return value;
}

uint32_t ReadU32(
    uintptr_t address)
{
    uint32_t value = 0;
    SafeRead(address, value);
    return value;
}

uint8_t ReadU8(
    uintptr_t address)
{
    uint8_t value = 0;
    SafeRead(address, value);
    return value;
}

// ============================================================
// HELPERS
// ============================================================

std::string HexU64(
    uint64_t value)
{
    std::ostringstream ss;

    ss
        << "0x"
        << std::uppercase
        << std::hex
        << value;

    return ss.str();
}

std::string HexPtr(
    uintptr_t value)
{
    return
        HexU64(
            static_cast<uint64_t>(
                value
            )
        );
}

uintptr_t AbsDistance(
    uintptr_t a,
    uintptr_t b)
{
    return
        a > b
            ? a - b
            : b - a;
}

bool InsideExeImage(
    uintptr_t address)
{
    return
        address >= g_exeBase &&
        address < g_imageEnd;
}

bool SameNumber(
    double a,
    double b)
{
    if (!std::isfinite(a) ||
        !std::isfinite(b))
    {
        return false;
    }

    double scale =
        std::max(
            1.0,
            std::max(
                std::fabs(a),
                std::fabs(b)
            )
        );

    return
        std::fabs(a - b) <=
        scale * 1e-10;
}

const char* StateName(
    FieldState state)
{
    switch (state)
    {
        case FieldState::Unknown:
            return "unknown";

        case FieldState::Unresolved:
            return "unresolved";

        case FieldState::Ambiguous:
            return "ambiguous";

        case FieldState::Collision:
            return "collision";

        case FieldState::StrongCandidate:
            return "strong_candidate";

        case FieldState::Confirmed:
            return "confirmed";

        case FieldState::Skipped:
            return "skipped";
    }

    return "unknown";
}

// ============================================================
// INPUT
// ============================================================

double AskNumber(
    const char* label)
{
    for (;;)
    {
        std::cout
            << label;

        std::string input;

        if (!std::getline(
                std::cin,
                input))
        {
            return 0.0;
        }

        std::replace(
            input.begin(),
            input.end(),
            ',',
            '.'
        );

        try
        {
            return
                std::stod(
                    input
                );
        }
        catch (...)
        {
            std::cout
                << "[INPUT] Valor invalido. Tente novamente.\n";
        }
    }
}

bool AskYesNo(
    const char* label)
{
    for (;;)
    {
        std::cout
            << label;

        std::string input;
        std::getline(
            std::cin,
            input
        );

        std::transform(
            input.begin(),
            input.end(),
            input.begin(),
            [](unsigned char c)
            {
                return
                    static_cast<char>(
                        std::tolower(c)
                    );
            }
        );

        if (input == "s" ||
            input == "sim" ||
            input == "y" ||
            input == "yes")
        {
            return true;
        }

        if (input == "n" ||
            input == "nao" ||
            input == "nao" ||
            input == "no")
        {
            return false;
        }

        std::cout
            << "[INPUT] Responda S ou N.\n";
    }
}

void WaitEnter(
    const char* message)
{
    std::cout
        << message;

    std::string tmp;

    std::getline(
        std::cin,
        tmp
    );
}


unsigned AskUnsignedRange(
    const char* label,
    unsigned minValue,
    unsigned maxValue)
{
    for (;;)
    {
        std::cout
            << label;

        std::string input;
        std::getline(
            std::cin,
            input
        );

        try
        {
            unsigned long value =
                std::stoul(
                    input,
                    nullptr,
                    10
                );

            if (value >= minValue &&
                value <= maxValue)
            {
                return
                    static_cast<unsigned>(
                        value
                    );
            }
        }
        catch (...)
        {
        }

        std::cout
            << "[INPUT] Digite um numero entre "
            << minValue
            << " e "
            << maxValue
            << ".\n";
    }
}

// ============================================================
// BUILD
// ============================================================

uint64_t Fnv1a64(
    const uint8_t* data,
    size_t size)
{
    constexpr uint64_t OFFSET =
        14695981039346656037ull;

    constexpr uint64_t PRIME =
        1099511628211ull;

    uint64_t hash =
        OFFSET;

    for (size_t i = 0;
         i < size;
         ++i)
    {
        hash ^=
            data[i];

        hash *=
            PRIME;
    }

    return hash;
}

bool ResolveBuild(
    BuildInfo& out)
{
    HMODULE exe =
        GetModuleHandleA(
            nullptr
        );

    if (!exe)
        return false;

    g_exeBase =
        reinterpret_cast<uintptr_t>(
            exe
        );

    IMAGE_DOS_HEADER dos{};

    if (!SafeRead(
            g_exeBase,
            dos) ||
        dos.e_magic != IMAGE_DOS_SIGNATURE)
    {
        return false;
    }

    uintptr_t ntAddress =
        g_exeBase +
        static_cast<uintptr_t>(
            dos.e_lfanew
        );

    IMAGE_NT_HEADERS64 nt{};

    if (!SafeRead(
            ntAddress,
            nt))
    {
        return false;
    }

    if (nt.Signature !=
        IMAGE_NT_SIGNATURE)
    {
        return false;
    }

    if (nt.FileHeader.Machine !=
        IMAGE_FILE_MACHINE_AMD64)
    {
        std::cout
            << "[BUILD] Este prototipo espera cliente x64.\n";

        return false;
    }

    out.timestamp =
        nt.FileHeader.TimeDateStamp;

    out.sizeOfImage =
        nt.OptionalHeader.SizeOfImage;

    out.entryPointRva =
        nt.OptionalHeader.AddressOfEntryPoint;

    g_imageEnd =
        g_exeBase +
        out.sizeOfImage;

    char path[MAX_PATH]{};

    GetModuleFileNameA(
        nullptr,
        path,
        MAX_PATH
    );

    out.exePath =
        path;

    uintptr_t sectionAddress =
        ntAddress +
        FIELD_OFFSET(
            IMAGE_NT_HEADERS64,
            OptionalHeader
        ) +
        nt.FileHeader.SizeOfOptionalHeader;

    for (unsigned i = 0;
         i < nt.FileHeader.NumberOfSections;
         ++i)
    {
        IMAGE_SECTION_HEADER sh{};

        if (!SafeRead(
                sectionAddress +
                    i * sizeof(sh),
                sh))
        {
            continue;
        }

        char name[9]{};

        std::memcpy(
            name,
            sh.Name,
            8
        );

        if (std::strcmp(
                name,
                ".text") != 0)
        {
            continue;
        }

        out.textRva =
            sh.VirtualAddress;

        out.textSize =
            std::max(
                sh.Misc.VirtualSize,
                sh.SizeOfRawData
            );

        g_textBegin =
            g_exeBase +
            out.textRva;

        g_textEnd =
            g_textBegin +
            out.textSize;

        if (g_textBegin &&
            out.textSize &&
            g_textEnd <= g_imageEnd)
        {
            out.textHash =
                Fnv1a64(
                    reinterpret_cast<
                        const uint8_t*
                    >(
                        g_textBegin
                    ),
                    out.textSize
                );
        }

        break;
    }

    return
        g_textBegin &&
        g_textEnd >
            g_textBegin;
}

void PrintBuild(
    const BuildInfo& b)
{
    std::cout
        << "\n============================================================\n"
        << "                     BUILD FINGERPRINT\n"
        << "============================================================\n"
        << "Executable       : "
        << b.exePath
        << "\n"
        << "ModuleBase       : "
        << HexPtr(g_exeBase)
        << "\n"
        << "PE Timestamp     : "
        << HexU64(b.timestamp)
        << "\n"
        << "SizeOfImage      : "
        << HexU64(b.sizeOfImage)
        << "\n"
        << "EntryPoint RVA   : "
        << HexU64(b.entryPointRva)
        << "\n"
        << ".text RVA        : "
        << HexU64(b.textRva)
        << "\n"
        << ".text size       : "
        << HexU64(b.textSize)
        << "\n"
        << ".text FNV1A64    : "
        << HexU64(b.textHash)
        << "\n";
}

// ============================================================
// PROCESS-WIDE DISCOVERY
// ============================================================

bool IsCandidateRegion(
    const MEMORY_BASIC_INFORMATION& mbi)
{
    if (mbi.State !=
        MEM_COMMIT)
    {
        return false;
    }

    if (mbi.Type !=
        MEM_PRIVATE)
    {
        return false;
    }

    if (!IsReadableProtection(
            mbi.Protect))
    {
        return false;
    }

    DWORD p =
        mbi.Protect &
        0xFF;

    return
        p == PAGE_READWRITE ||
        p == PAGE_WRITECOPY;
}

std::vector<uintptr_t>
ScanDouble(
    double needle,
    size_t maxHits = 8192)
{
    std::vector<uintptr_t> hits;

    SYSTEM_INFO si{};
    GetSystemInfo(&si);

    uintptr_t cursor =
        reinterpret_cast<uintptr_t>(
            si.lpMinimumApplicationAddress
        );

    uintptr_t maximum =
        reinterpret_cast<uintptr_t>(
            si.lpMaximumApplicationAddress
        );

    while (cursor <
           maximum)
    {
        MEMORY_BASIC_INFORMATION mbi{};

        if (!VirtualQuery(
                reinterpret_cast<void*>(
                    cursor
                ),
                &mbi,
                sizeof(mbi)))
        {
            break;
        }

        uintptr_t base =
            reinterpret_cast<uintptr_t>(
                mbi.BaseAddress
            );

        uintptr_t end =
            base +
            mbi.RegionSize;

        if (IsCandidateRegion(
                mbi))
        {
            uintptr_t p =
                (base + 7) &
                ~static_cast<uintptr_t>(7);

            for (;
                 p + sizeof(double) <= end;
                 p += 8)
            {
                double value = 0.0;

                std::memcpy(
                    &value,
                    reinterpret_cast<
                        const void*
                    >(p),
                    sizeof(value)
                );

                if (!SameNumber(
                        value,
                        needle))
                {
                    continue;
                }

                hits.push_back(
                    p
                );

                if (hits.size() >=
                    maxHits)
                {
                    return hits;
                }
            }
        }

        if (end <= cursor)
            break;

        cursor = end;
    }

    return hits;
}

bool IsForbidden(
    uintptr_t address,
    const std::vector<uintptr_t>& forbidden)
{
    for (uintptr_t f :
         forbidden)
    {
        if (address == f)
            return true;
    }

    return false;
}

bool FindNear(
    uintptr_t center,
    uintptr_t before,
    uintptr_t after,
    double needle,
    uintptr_t& found,
    const std::vector<uintptr_t>& forbidden = {})
{
    uintptr_t begin =
        center > before
            ? center - before
            : 0;

    uintptr_t end =
        center +
        after;

    begin =
        (begin + 7) &
        ~static_cast<uintptr_t>(7);

    for (uintptr_t p = begin;
         p + 8 <= end;
         p += 8)
    {
        if (IsForbidden(
                p,
                forbidden))
        {
            continue;
        }

        double value = 0.0;

        if (!SafeRead(
                p,
                value))
        {
            continue;
        }

        if (!SameNumber(
                value,
                needle))
        {
            continue;
        }

        found = p;
        return true;
    }

    return false;
}

// ============================================================
// CANDIDATE EVIDENCE
// ============================================================

bool HasEvidence(
    const Candidate& c,
    const char* name)
{
    for (const auto& e :
         c.evidence)
    {
        if (e.name ==
            name)
        {
            return true;
        }
    }

    return false;
}

void AddEvidence(
    Candidate& c,
    const char* name,
    uintptr_t address,
    double value)
{
    if (!address ||
        HasEvidence(
            c,
            name))
    {
        return;
    }

    c.evidence.push_back(
        {
            name,
            address,
            value
        }
    );
}

std::vector<uintptr_t>
EvidenceAddresses(
    const Candidate& c)
{
    std::vector<uintptr_t> result;

    for (const auto& e :
         c.evidence)
    {
        result.push_back(
            e.address
        );
    }

    return result;
}

std::vector<Candidate>
SeedPair(
    const char* firstName,
    double firstValue,
    const char* secondName,
    double secondValue)
{
    std::cout
        << "\n[SEED] "
        << firstName
        << " / "
        << secondName
        << "\n";

    auto hits =
        ScanDouble(
            firstValue
        );

    std::cout
        << "[SCAN] "
        << firstName
        << " raw hits = "
        << hits.size()
        << "\n";

    std::vector<Candidate> result;

    for (uintptr_t hit :
         hits)
    {
        uintptr_t second = 0;

        std::vector<uintptr_t> forbidden{
            hit
        };

        // Current/max conhecidos costumam ficar muito proximos.
        if (!FindNear(
                hit,
                0x40,
                0x100,
                secondValue,
                second,
                forbidden))
        {
            continue;
        }

        Candidate c{};
        c.anchor = hit;

        AddEvidence(
            c,
            firstName,
            hit,
            firstValue
        );

        AddEvidence(
            c,
            secondName,
            second,
            secondValue
        );

        result.push_back(
            std::move(c)
        );

        if (result.size() >=
            2048)
        {
            break;
        }
    }

    std::cout
        << "[SEED] pair candidates = "
        << result.size()
        << "\n";

    return result;
}

std::vector<Candidate>
SeedSingle(
    const char* name,
    double value)
{
    std::cout
        << "\n[FALLBACK SEED] "
        << name
        << "\n";

    auto hits =
        ScanDouble(
            value
        );

    std::vector<Candidate> result;

    size_t limit =
        std::min<size_t>(
            hits.size(),
            4096
        );

    for (size_t i = 0;
         i < limit;
         ++i)
    {
        Candidate c{};

        c.anchor =
            hits[i];

        AddEvidence(
            c,
            name,
            hits[i],
            value
        );

        result.push_back(
            std::move(c)
        );
    }

    std::cout
        << "[FALLBACK] candidates = "
        << result.size()
        << "\n";

    return result;
}

void AttachEvidenceIfNearby(
    Candidate& c,
    const char* name,
    double value,
    uintptr_t radius = 0x1200)
{
    if (HasEvidence(
            c,
            name))
    {
        return;
    }

    uintptr_t found = 0;

    auto forbidden =
        EvidenceAddresses(c);

    if (FindNear(
            c.anchor,
            radius,
            radius,
            value,
            found,
            forbidden))
    {
        AddEvidence(
            c,
            name,
            found,
            value
        );
    }
}

void AttachBulkEvidence(
    Candidate& c,
    const BulkInput& in)
{
    AttachEvidenceIfNearby(
        c,
        "Health",
        in.health
    );

    AttachEvidenceIfNearby(
        c,
        "MaxHealth",
        in.maxHealth
    );

    AttachEvidenceIfNearby(
        c,
        "Mana",
        in.mana
    );

    AttachEvidenceIfNearby(
        c,
        "MaxMana",
        in.maxMana
    );

    AttachEvidenceIfNearby(
        c,
        "Experience",
        in.experience
    );

    AttachEvidenceIfNearby(
        c,
        "Level",
        in.level
    );

    AttachEvidenceIfNearby(
        c,
        "Capacity",
        in.capacity
    );
}

// ============================================================
// LOCALPLAYER BASE HYPOTHESIS
// ============================================================

bool PositionPlausible(
    uint32_t x,
    uint32_t y,
    uint8_t z)
{
    return
        x >= 1000 &&
        x <= 100000 &&
        y >= 1000 &&
        y <= 100000 &&
        z <= 31;
}

BaseHypothesis ScoreBase(
    uintptr_t base,
    uintptr_t statAnchor)
{
    BaseHypothesis h{};

    h.base =
        base;

    h.vtable =
        ReadPtr(
            base
        );

    if (InsideExeImage(
            h.vtable))
    {
        h.score += 5;
    }

    h.x =
        ReadU32(
            base +
            REF_OFF_X
        );

    h.y =
        ReadU32(
            base +
            REF_OFF_Y
        );

    h.z =
        ReadU8(
            base +
            REF_OFF_Z
        );

    if (PositionPlausible(
            h.x,
            h.y,
            h.z))
    {
        h.score += 6;
    }

    h.id =
        ReadU32(
            base +
            REF_OFF_ID
        );

    if (h.id != 0 &&
        h.id != 0xFFFFFFFF)
    {
        h.score += 2;
    }

    h.hpPercent =
        ReadU8(
            base +
            REF_OFF_HP_PERCENT
        );

    if (h.hpPercent <= 100)
    {
        h.score += 2;
    }

    h.direction =
        ReadU32(
            base +
            REF_OFF_DIRECTION
        );

    if (h.direction <= 7)
    {
        h.score += 2;
    }

    uintptr_t distance =
        statAnchor > base
            ? statAnchor - base
            : 0;

    if (distance >= 0x400 &&
        distance <= 0xA00)
    {
        h.score += 3;
    }

    return h;
}

BaseHypothesis InferLocalPlayerBase(
    const Candidate& c)
{
    BaseHypothesis best{};

    uintptr_t lowest =
        std::numeric_limits<uintptr_t>::max();

    for (const auto& e :
         c.evidence)
    {
        lowest =
            std::min(
                lowest,
                e.address
            );
    }

    if (lowest ==
        std::numeric_limits<uintptr_t>::max())
    {
        return best;
    }

    uintptr_t scanBack =
        0x1400;

    uintptr_t begin =
        lowest > scanBack
            ? lowest - scanBack
            : 0;

    begin =
        (begin + 7) &
        ~static_cast<uintptr_t>(7);

    for (uintptr_t p = begin;
         p < lowest;
         p += 8)
    {
        uintptr_t vt =
            ReadPtr(
                p
            );

        if (!InsideExeImage(
                vt))
        {
            continue;
        }

        BaseHypothesis h =
            ScoreBase(
                p,
                lowest
            );

        if (h.score >
            best.score)
        {
            best = h;
        }
    }

    return best;
}

int CandidateTotalScore(
    const Candidate& c,
    const BaseHypothesis& base)
{
    int score =
        base.score * 10;

    score +=
        static_cast<int>(
            c.evidence.size()
        ) * 4;

    // Bonus se muitos stats foram encontrados no mesmo cluster.
    if (c.evidence.size() >= 5)
        score += 20;

    if (c.evidence.size() >= 7)
        score += 20;

    return score;
}

// ============================================================
// LOCAL DOUBLE WINDOW
// ============================================================

std::vector<DoubleCell>
CaptureLocalDoubles(
    uintptr_t localPlayerBase)
{
    std::vector<DoubleCell> cells;

    if (!localPlayerBase)
        return cells;

    uintptr_t begin =
        localPlayerBase +
        LOCAL_SCAN_BEGIN;

    uintptr_t end =
        localPlayerBase +
        LOCAL_SCAN_END;

    begin =
        (begin + 7) &
        ~static_cast<uintptr_t>(7);

    for (uintptr_t p = begin;
         p + 8 <= end;
         p += 8)
    {
        double value = 0.0;

        if (!SafeRead(
                p,
                value))
        {
            continue;
        }

        if (!std::isfinite(
                value))
        {
            continue;
        }

        cells.push_back(
            {
                p,
                p - localPlayerBase,
                value
            }
        );
    }

    return cells;
}

std::vector<uintptr_t>
LocalMatches(
    const std::vector<DoubleCell>& cells,
    double value)
{
    std::vector<uintptr_t> result;

    for (const auto& c :
         cells)
    {
        if (SameNumber(
                c.value,
                value))
        {
            result.push_back(
                c.address
            );
        }
    }

    return result;
}

const DoubleCell* FindCell(
    const std::vector<DoubleCell>& cells,
    uintptr_t address)
{
    for (const auto& c :
         cells)
    {
        if (c.address ==
            address)
        {
            return &c;
        }
    }

    return nullptr;
}

// ============================================================
// STATIC LOCAL FIELD RESOLUTION
// ============================================================

int PairScore(
    uintptr_t currentAddress,
    uintptr_t maximumAddress,
    uintptr_t base,
    uintptr_t refCurrent,
    uintptr_t refMaximum)
{
    if (!currentAddress ||
        !maximumAddress ||
        currentAddress ==
            maximumAddress)
    {
        return
            std::numeric_limits<int>::min();
    }

    int score = 0;

    uintptr_t delta =
        AbsDistance(
            currentAddress,
            maximumAddress
        );

    if (delta == 8)
        score += 30;
    else if (delta <= 0x20)
        score += 18;
    else if (delta <= 0x80)
        score += 8;
    else if (delta <= 0x200)
        score += 2;

    if (maximumAddress >
        currentAddress)
    {
        score += 5;
    }

    uintptr_t currentOff =
        currentAddress -
        base;

    uintptr_t maximumOff =
        maximumAddress -
        base;

    uintptr_t currentDrift =
        AbsDistance(
            currentOff,
            refCurrent
        );

    uintptr_t maxDrift =
        AbsDistance(
            maximumOff,
            refMaximum
        );

    if (currentDrift <= 0x20)
        score += 6;
    else if (currentDrift <= 0x100)
        score += 3;

    if (maxDrift <= 0x20)
        score += 6;
    else if (maxDrift <= 0x100)
        score += 3;

    return score;
}

PairResult ResolveStaticPair(
    const char* currentName,
    const char* maximumName,
    uintptr_t base,
    const std::vector<DoubleCell>& cells,
    double currentValue,
    double maximumValue,
    uintptr_t refCurrent,
    uintptr_t refMaximum)
{
    PairResult out{};

    out.current.name =
        currentName;

    out.maximum.name =
        maximumName;

    out.current.value =
        currentValue;

    out.maximum.value =
        maximumValue;

    auto currentMatches =
        LocalMatches(
            cells,
            currentValue
        );

    auto maximumMatches =
        LocalMatches(
            cells,
            maximumValue
        );

    if (currentMatches.empty())
    {
        out.current.state =
            FieldState::Unresolved;

        out.current.evidence =
            "value_not_found_in_localplayer_window";
    }

    if (maximumMatches.empty())
    {
        out.maximum.state =
            FieldState::Unresolved;

        out.maximum.evidence =
            "value_not_found_in_localplayer_window";
    }

    if (currentMatches.empty() ||
        maximumMatches.empty())
    {
        return out;
    }

    int bestScore =
        std::numeric_limits<int>::min();

    uintptr_t bestCurrent = 0;
    uintptr_t bestMaximum = 0;

    int equivalentBestCount = 0;

    for (uintptr_t current :
         currentMatches)
    {
        for (uintptr_t maximum :
             maximumMatches)
        {
            if (current ==
                maximum)
            {
                continue;
            }

            int score =
                PairScore(
                    current,
                    maximum,
                    base,
                    refCurrent,
                    refMaximum
                );

            if (score >
                bestScore)
            {
                bestScore =
                    score;

                bestCurrent =
                    current;

                bestMaximum =
                    maximum;

                equivalentBestCount =
                    1;
            }
            else if (score ==
                     bestScore)
            {
                ++equivalentBestCount;
            }
        }
    }

    if (!bestCurrent ||
        !bestMaximum)
    {
        out.current.state =
            FieldState::Collision;

        out.maximum.state =
            FieldState::Collision;

        out.current.evidence =
            "no_distinct_address_pair";

        out.maximum.evidence =
            "no_distinct_address_pair";

        return out;
    }

    out.current.address =
        bestCurrent;

    out.current.offset =
        bestCurrent -
        base;

    out.maximum.address =
        bestMaximum;

    out.maximum.offset =
        bestMaximum -
        base;

    // Se current == max em valor, ainda nao sabemos semanticamente
    // qual dos dois e atual e qual e maximo. Precisamos mudar um.
    if (SameNumber(
            currentValue,
            maximumValue))
    {
        out.current.state =
            FieldState::Ambiguous;

        out.maximum.state =
            FieldState::Ambiguous;

        out.current.evidence =
            "same_value_pair_needs_transition";

        out.maximum.evidence =
            "same_value_pair_needs_transition";

        return out;
    }

    // Valores diferentes e par estrutural distinto: forte candidato.
    if (equivalentBestCount == 1)
    {
        out.current.state =
            FieldState::StrongCandidate;

        out.maximum.state =
            FieldState::StrongCandidate;

        out.current.evidence =
            "unique_local_value_pair";

        out.maximum.evidence =
            "unique_local_value_pair";
    }
    else
    {
        out.current.state =
            FieldState::Ambiguous;

        out.maximum.state =
            FieldState::Ambiguous;

        out.current.evidence =
            "multiple_equivalent_pairs";

        out.maximum.evidence =
            "multiple_equivalent_pairs";
    }

    return out;
}

FieldResult ResolveStaticSingle(
    const char* name,
    uintptr_t base,
    const std::vector<DoubleCell>& cells,
    double value,
    uintptr_t referenceOffset)
{
    FieldResult out{};

    out.name =
        name;

    out.value =
        value;

    auto matches =
        LocalMatches(
            cells,
            value
        );

    if (matches.empty())
    {
        out.state =
            FieldState::Unresolved;

        out.evidence =
            "value_not_found_in_localplayer_window";

        return out;
    }

    if (matches.size() == 1)
    {
        out.address =
            matches[0];

        out.offset =
            matches[0] -
            base;

        out.state =
            FieldState::StrongCandidate;

        out.evidence =
            "unique_local_value_match";

        return out;
    }

    // Mais de um: escolhe o mais perto da referencia,
    // mas deixa ambiguous para pedir mudanca depois.
    uintptr_t best = 0;

    uintptr_t bestDrift =
        std::numeric_limits<uintptr_t>::max();

    for (uintptr_t address :
         matches)
    {
        uintptr_t off =
            address -
            base;

        uintptr_t drift =
            AbsDistance(
                off,
                referenceOffset
            );

        if (drift <
            bestDrift)
        {
            bestDrift =
                drift;

            best =
                address;
        }
    }

    out.address =
        best;

    out.offset =
        best -
        base;

    out.state =
        FieldState::Ambiguous;

    out.evidence =
        "multiple_local_matches";

    return out;
}

// ============================================================
// DYNAMIC RETRY
// ============================================================

std::vector<uintptr_t>
FindTransitionAddresses(
    const std::vector<DoubleCell>& before,
    const std::vector<DoubleCell>& after,
    double oldValue,
    double newValue)
{
    std::vector<uintptr_t> result;

    for (const auto& a :
         before)
    {
        if (!SameNumber(
                a.value,
                oldValue))
        {
            continue;
        }

        const DoubleCell* b =
            FindCell(
                after,
                a.address
            );

        if (!b)
            continue;

        if (!SameNumber(
                b->value,
                newValue))
        {
            continue;
        }

        result.push_back(
            a.address
        );
    }

    return result;
}

std::vector<uintptr_t>
FindStableAddresses(
    const std::vector<DoubleCell>& before,
    const std::vector<DoubleCell>& after,
    double value)
{
    std::vector<uintptr_t> result;

    for (const auto& a :
         before)
    {
        if (!SameNumber(
                a.value,
                value))
        {
            continue;
        }

        const DoubleCell* b =
            FindCell(
                after,
                a.address
            );

        if (!b)
            continue;

        if (!SameNumber(
                b->value,
                value))
        {
            continue;
        }

        result.push_back(
            a.address
        );
    }

    return result;
}

PairResult RetryPairDynamic(
    const char* currentName,
    const char* maximumName,
    uintptr_t base,
    uintptr_t refCurrent,
    uintptr_t refMaximum)
{
    PairResult out{};

    out.current.name =
        currentName;

    out.maximum.name =
        maximumName;

    std::cout
        << "\n============================================================\n"
        << "                RETRY "
        << currentName
        << " / "
        << maximumName
        << "\n"
        << "============================================================\n"
        << "Vamos observar somente o bloco do LocalPlayer.\n";

    double oldCurrent =
        AskNumber(
            (
                std::string(currentName) +
                " atual agora : "
            ).c_str()
        );

    double oldMaximum =
        AskNumber(
            (
                std::string(maximumName) +
                " agora      : "
            ).c_str()
        );

    auto before =
        CaptureLocalDoubles(
            base
        );

    std::cout
        << "[SNAPSHOT A] "
        << before.size()
        << " doubles.\n";

    std::cout
        << "\nAltere "
        << currentName
        << " agora.\n";

    if (std::string(currentName) ==
        "Health")
    {
        std::cout
            << "Tome dano ou cure.\n";
    }
    else if (std::string(currentName) ==
             "Mana")
    {
        std::cout
            << "Use uma magia ou espere regenerar.\n";
    }

    WaitEnter(
        "Depois da mudanca pressione ENTER..."
    );

    double newCurrent =
        AskNumber(
            (
                std::string(currentName) +
                " novo : "
            ).c_str()
        );

    double newMaximum =
        AskNumber(
            (
                std::string(maximumName) +
                " novo  : "
            ).c_str()
        );

    auto after =
        CaptureLocalDoubles(
            base
        );

    auto currentTransitions =
        FindTransitionAddresses(
            before,
            after,
            oldCurrent,
            newCurrent
        );

    std::vector<uintptr_t> maxMatches;

    bool maxChanged =
        !SameNumber(
            oldMaximum,
            newMaximum
        );

    if (maxChanged)
    {
        maxMatches =
            FindTransitionAddresses(
                before,
                after,
                oldMaximum,
                newMaximum
            );
    }
    else
    {
        maxMatches =
            FindStableAddresses(
                before,
                after,
                oldMaximum
            );
    }

    std::cout
        << "[TRANSITION] "
        << currentName
        << " exact matches = "
        << currentTransitions.size()
        << "\n"
        << "[TRANSITION] "
        << maximumName
        << " matches = "
        << maxMatches.size()
        << "\n";

    int bestScore =
        std::numeric_limits<int>::min();

    uintptr_t bestCurrent = 0;
    uintptr_t bestMaximum = 0;

    for (uintptr_t current :
         currentTransitions)
    {
        for (uintptr_t maximum :
             maxMatches)
        {
            if (current ==
                maximum)
            {
                continue;
            }

            int score =
                PairScore(
                    current,
                    maximum,
                    base,
                    refCurrent,
                    refMaximum
                );

            if (score >
                bestScore)
            {
                bestScore =
                    score;

                bestCurrent =
                    current;

                bestMaximum =
                    maximum;
            }
        }
    }

    if (bestCurrent)
    {
        out.current.address =
            bestCurrent;

        out.current.offset =
            bestCurrent -
            base;

        out.current.before =
            oldCurrent;

        out.current.after =
            newCurrent;

        out.current.value =
            newCurrent;

        out.current.state =
            FieldState::Confirmed;

        out.current.evidence =
            "exact_before_after_transition";
    }
    else
    {
        out.current.state =
            FieldState::Unresolved;

        out.current.evidence =
            "transition_not_found";
    }

    if (bestMaximum)
    {
        out.maximum.address =
            bestMaximum;

        out.maximum.offset =
            bestMaximum -
            base;

        out.maximum.before =
            oldMaximum;

        out.maximum.after =
            newMaximum;

        out.maximum.value =
            newMaximum;

        out.maximum.state =
            maxChanged
                ? FieldState::Confirmed
                : FieldState::StrongCandidate;

        out.maximum.evidence =
            maxChanged
                ? "exact_before_after_transition"
                : "stable_value_near_confirmed_current";
    }
    else
    {
        out.maximum.state =
            FieldState::Unresolved;

        out.maximum.evidence =
            "maximum_not_resolved";
    }

    if (out.current.address &&
        out.maximum.address &&
        out.current.address ==
            out.maximum.address)
    {
        out.maximum.address = 0;
        out.maximum.offset = 0;
        out.maximum.state =
            FieldState::Collision;

        out.maximum.evidence =
            "semantic_fields_cannot_share_address";
    }

    return out;
}

FieldResult RetrySingleDynamic(
    const char* name,
    uintptr_t base,
    uintptr_t referenceOffset,
    const char* actionHint)
{
    FieldResult out{};
    out.name = name;

    std::cout
        << "\n============================================================\n"
        << "                RETRY "
        << name
        << "\n"
        << "============================================================\n";

    double oldValue =
        AskNumber(
            (
                std::string(name) +
                " atual : "
            ).c_str()
        );

    auto before =
        CaptureLocalDoubles(
            base
        );

    std::cout
        << actionHint
        << "\n";

    WaitEnter(
        "Depois da mudanca pressione ENTER..."
    );

    double newValue =
        AskNumber(
            (
                std::string(name) +
                " novo  : "
            ).c_str()
        );

    auto after =
        CaptureLocalDoubles(
            base
        );

    auto transitions =
        FindTransitionAddresses(
            before,
            after,
            oldValue,
            newValue
        );

    if (transitions.empty())
    {
        out.state =
            FieldState::Unresolved;

        out.evidence =
            "transition_not_found";

        return out;
    }

    uintptr_t best = 0;

    uintptr_t bestDrift =
        std::numeric_limits<uintptr_t>::max();

    for (uintptr_t address :
         transitions)
    {
        uintptr_t off =
            address -
            base;

        uintptr_t drift =
            AbsDistance(
                off,
                referenceOffset
            );

        if (drift <
            bestDrift)
        {
            bestDrift =
                drift;

            best =
                address;
        }
    }

    out.address =
        best;

    out.offset =
        best -
        base;

    out.before =
        oldValue;

    out.after =
        newValue;

    out.value =
        newValue;

    out.state =
        FieldState::Confirmed;

    out.evidence =
        "exact_before_after_transition";

    return out;
}

// ============================================================
// PRINT
// ============================================================

void PrintField(
    const FieldResult& f)
{
    std::cout
        << std::left
        << std::setw(12)
        << f.name
        << std::right
        << " : ";

    if (f.address)
    {
        std::cout
            << "+"
            << HexU64(
                f.offset
            )
            << "  ";
    }
    else
    {
        std::cout
            << "<none>  ";
    }

    std::cout
        << "["
        << StateName(
            f.state
        )
        << "]";

    if (!f.evidence.empty())
    {
        std::cout
            << "  "
            << f.evidence;
    }

    std::cout
        << "\n";
}

void PrintFields(
    const ProfileFields& f)
{
    std::cout
        << "\n============================================================\n"
        << "                       FIELD STATUS\n"
        << "============================================================\n";

    PrintField(
        f.health
    );

    PrintField(
        f.maxHealth
    );

    PrintField(
        f.mana
    );

    PrintField(
        f.maxMana
    );

    PrintField(
        f.experience
    );

    PrintField(
        f.level
    );

    PrintField(
        f.capacity
    );
}


std::string EscapeJson(const std::string& s);

// ============================================================
// V1.3 - POSITION / DIRECTION CALIBRATION
// ============================================================

std::vector<U32Cell>
CaptureLocalU32(
    uintptr_t base,
    uintptr_t beginOffset = 0,
    uintptr_t endOffset = 0x120)
{
    std::vector<U32Cell> cells;

    uintptr_t begin =
        base +
        beginOffset;

    uintptr_t end =
        base +
        endOffset;

    begin =
        (begin + 3) &
        ~static_cast<uintptr_t>(3);

    for (uintptr_t p = begin;
         p + sizeof(uint32_t) <= end;
         p += 4)
    {
        uint32_t value = 0;

        if (!SafeRead(
                p,
                value))
        {
            continue;
        }

        cells.push_back(
            {
                p,
                p - base,
                value
            }
        );
    }

    return cells;
}

std::vector<U8Cell>
CaptureLocalU8(
    uintptr_t base,
    uintptr_t beginOffset = 0,
    uintptr_t endOffset = 0x120)
{
    std::vector<U8Cell> cells;

    uintptr_t begin =
        base +
        beginOffset;

    uintptr_t end =
        base +
        endOffset;

    for (uintptr_t p = begin;
         p < end;
         ++p)
    {
        uint8_t value = 0;

        if (!SafeRead(
                p,
                value))
        {
            continue;
        }

        cells.push_back(
            {
                p,
                p - base,
                value
            }
        );
    }

    return cells;
}

const U32Cell*
FindU32Cell(
    const std::vector<U32Cell>& cells,
    uintptr_t address)
{
    for (const auto& c :
         cells)
    {
        if (c.address ==
            address)
        {
            return &c;
        }
    }

    return nullptr;
}

const U8Cell*
FindU8Cell(
    const std::vector<U8Cell>& cells,
    uintptr_t address)
{
    for (const auto& c :
         cells)
    {
        if (c.address ==
            address)
        {
            return &c;
        }
    }

    return nullptr;
}

std::vector<uintptr_t>
FindPlausibleCoordinateStep(
    const std::vector<U32Cell>& before,
    const std::vector<U32Cell>& after)
{
    std::vector<uintptr_t> result;

    for (const auto& a :
         before)
    {
        if (a.value < 1000 ||
            a.value > 100000)
        {
            continue;
        }

        const U32Cell* b =
            FindU32Cell(
                after,
                a.address
            );

        if (!b)
            continue;

        if (b->value < 1000 ||
            b->value > 100000)
        {
            continue;
        }

        uint32_t delta =
            a.value > b->value
                ? a.value - b->value
                : b->value - a.value;

        if (delta == 1)
        {
            result.push_back(
                a.address
            );
        }
    }

    return result;
}

UIntFieldResult
ResolveCoordinateStep(
    const char* name,
    uintptr_t base,
    const std::vector<U32Cell>& before,
    const std::vector<U32Cell>& after,
    uintptr_t referenceOffset)
{
    UIntFieldResult out{};
    out.name = name;

    auto candidates =
        FindPlausibleCoordinateStep(
            before,
            after
        );

    if (candidates.empty())
    {
        out.state =
            FieldState::Unresolved;

        out.evidence =
            "no_plausible_coordinate_step";

        return out;
    }

    uintptr_t best = 0;
    uintptr_t bestDrift =
        std::numeric_limits<uintptr_t>::max();

    for (uintptr_t address :
         candidates)
    {
        uintptr_t offset =
            address - base;

        uintptr_t drift =
            AbsDistance(
                offset,
                referenceOffset
            );

        if (drift <
            bestDrift)
        {
            bestDrift =
                drift;

            best =
                address;
        }
    }

    const U32Cell* a =
        FindU32Cell(
            before,
            best
        );

    const U32Cell* b =
        FindU32Cell(
            after,
            best
        );

    if (!a ||
        !b)
    {
        out.state =
            FieldState::Unresolved;

        out.evidence =
            "snapshot_cell_missing";

        return out;
    }

    out.address =
        best;

    out.offset =
        best - base;

    out.before =
        a->value;

    out.after =
        b->value;

    if (candidates.size() == 1)
    {
        out.state =
            FieldState::Confirmed;

        out.evidence =
            "unique_plausible_plus_minus_one_transition";
    }
    else
    {
        out.state =
            FieldState::StrongCandidate;

        out.evidence =
            "multiple_transitions_reference_shape_tiebreak";
    }

    return out;
}

UIntFieldResult
ResolveZTransition(
    uintptr_t base,
    const std::vector<U8Cell>& before,
    const std::vector<U8Cell>& after,
    uintptr_t preferredOffset)
{
    UIntFieldResult out{};
    out.name = "Z";

    std::vector<uintptr_t> candidates;

    for (const auto& a :
         before)
    {
        if (a.value > 31)
            continue;

        const U8Cell* b =
            FindU8Cell(
                after,
                a.address
            );

        if (!b ||
            b->value > 31)
        {
            continue;
        }

        unsigned delta =
            a.value > b->value
                ? a.value - b->value
                : b->value - a.value;

        if (delta == 1)
        {
            candidates.push_back(
                a.address
            );
        }
    }

    if (candidates.empty())
    {
        out.state =
            FieldState::Unresolved;

        out.evidence =
            "no_small_byte_plus_minus_one_transition";

        return out;
    }

    // Strongest structural anchor for every tested family so far:
    // X/Y are contiguous u32 fields and Z follows immediately after Y.
    // Do not let an unrelated small byte (for example +0x9) beat that
    // relationship merely because it is closer to an old reference build.
    uintptr_t best = 0;

    if (preferredOffset)
    {
        uintptr_t preferredAddress =
            base +
            preferredOffset;

        if (std::find(
                candidates.begin(),
                candidates.end(),
                preferredAddress) !=
            candidates.end())
        {
            best =
                preferredAddress;
        }
    }

    if (!best)
    {
        uintptr_t anchor =
            preferredOffset
                ? preferredOffset
                : REF_OFF_Z;

        uintptr_t bestDrift =
            std::numeric_limits<uintptr_t>::max();

        for (uintptr_t address :
             candidates)
        {
            uintptr_t offset =
                address - base;

            uintptr_t drift =
                AbsDistance(
                    offset,
                    anchor
                );

            if (drift <
                bestDrift)
            {
                bestDrift =
                    drift;

                best =
                    address;
            }
        }
    }

    const U8Cell* a =
        FindU8Cell(
            before,
            best
        );

    const U8Cell* b =
        FindU8Cell(
            after,
            best
        );

    if (!a ||
        !b)
    {
        out.state =
            FieldState::Unresolved;

        out.evidence =
            "z_snapshot_cell_missing";

        return out;
    }

    out.address =
        best;

    out.offset =
        best - base;

    out.before =
        a->value;

    out.after =
        b->value;

    const bool structuralPreferred =
        preferredOffset &&
        out.offset ==
            preferredOffset;

    out.state =
        candidates.size() == 1 ||
        structuralPreferred
            ? FieldState::Confirmed
            : FieldState::StrongCandidate;

    out.evidence =
        candidates.size() == 1
            ? "unique_floor_transition"
            : (
                structuralPreferred
                    ? "xyz_structural_continuity_tiebreak"
                    : "multiple_floor_like_transitions_nearest_structural_anchor"
              );

    return out;
}

UIntFieldResult
ResolveDirectionByTwoTurns(
    uintptr_t base,
    const std::vector<U32Cell>& a,
    const std::vector<U32Cell>& b,
    const std::vector<U32Cell>& c)
{
    UIntFieldResult out{};
    out.name = "Direction";

    std::vector<uintptr_t> candidates;

    for (const auto& first :
         a)
    {
        if (first.value > 7)
            continue;

        const U32Cell* second =
            FindU32Cell(
                b,
                first.address
            );

        const U32Cell* third =
            FindU32Cell(
                c,
                first.address
            );

        if (!second ||
            !third)
        {
            continue;
        }

        if (second->value > 7 ||
            third->value > 7)
        {
            continue;
        }

        if (first.value ==
                second->value ||
            second->value ==
                third->value)
        {
            continue;
        }

        candidates.push_back(
            first.address
        );
    }

    if (candidates.empty())
    {
        out.state =
            FieldState::Unresolved;

        out.evidence =
            "no_small_u32_changed_on_both_turns";

        return out;
    }

    uintptr_t best = 0;
    uintptr_t bestDrift =
        std::numeric_limits<uintptr_t>::max();

    for (uintptr_t address :
         candidates)
    {
        uintptr_t offset =
            address - base;

        uintptr_t drift =
            AbsDistance(
                offset,
                REF_OFF_DIRECTION
            );

        if (drift <
            bestDrift)
        {
            bestDrift =
                drift;

            best =
                address;
        }
    }

    const U32Cell* first =
        FindU32Cell(
            a,
            best
        );

    const U32Cell* third =
        FindU32Cell(
            c,
            best
        );

    if (!first ||
        !third)
    {
        out.state =
            FieldState::Unresolved;

        out.evidence =
            "direction_snapshot_cell_missing";

        return out;
    }

    out.address =
        best;

    out.offset =
        best - base;

    out.before =
        first->value;

    out.after =
        third->value;

    out.state =
        candidates.size() == 1
            ? FieldState::Confirmed
            : FieldState::StrongCandidate;

    out.evidence =
        candidates.size() == 1
            ? "unique_small_u32_changed_on_two_turns"
            : "multiple_turn_candidates_reference_tiebreak";

    return out;
}

void PrintUIntField(
    const UIntFieldResult& field)
{
    std::cout
        << std::left
        << std::setw(12)
        << field.name
        << std::right
        << " : ";

    if (field.address)
    {
        std::cout
            << "+"
            << HexU64(
                field.offset
            )
            << "  ";
    }
    else
    {
        std::cout
            << "<none>  ";
    }

    std::cout
        << "["
        << StateName(
            field.state
        )
        << "]";

    if (field.address)
    {
        std::cout
            << "  "
            << field.before
            << " -> "
            << field.after;
    }

    if (!field.evidence.empty())
    {
        std::cout
            << "  "
            << field.evidence;
    }

    std::cout
        << "\n";
}

PositionCalibration
CalibratePositionAndDirection(
    uintptr_t base)
{
    PositionCalibration out{};

    out.x.name = "X";
    out.y.name = "Y";
    out.z.name = "Z";
    out.direction.name = "Direction";

    std::cout
        << "\n============================================================\n"
        << "              POSITION / DIRECTION CALIBRATION\n"
        << "============================================================\n"
        << "Agora nao precisa digitar X/Y.\n"
        << "A DLL vai observar mudancas de 1 sqm no inicio do objeto.\n\n";

    // --------------------------------------------------------
    // X - horizontal
    // --------------------------------------------------------

    auto xBefore =
        CaptureLocalU32(
            base,
            0,
            0x120
        );

    std::cout
        << "Mova EXATAMENTE 1 sqm para DIREITA ou ESQUERDA.\n"
        << "Nao suba/desca andar nessa etapa.\n";

    WaitEnter(
        "Depois do movimento horizontal, pressione ENTER..."
    );

    auto xAfter =
        CaptureLocalU32(
            base,
            0,
            0x120
        );

    out.x =
        ResolveCoordinateStep(
            "X",
            base,
            xBefore,
            xAfter,
            REF_OFF_X
        );

    PrintUIntField(
        out.x
    );

    // --------------------------------------------------------
    // Y - vertical
    // --------------------------------------------------------

    auto yBefore =
        CaptureLocalU32(
            base,
            0,
            0x120
        );

    std::cout
        << "\nAgora mova EXATAMENTE 1 sqm para CIMA ou BAIXO.\n"
        << "Nao suba/desca andar nessa etapa.\n";

    WaitEnter(
        "Depois do movimento vertical, pressione ENTER..."
    );

    auto yAfter =
        CaptureLocalU32(
            base,
            0,
            0x120
        );

    out.y =
        ResolveCoordinateStep(
            "Y",
            base,
            yBefore,
            yAfter,
            REF_OFF_Y
        );

    PrintUIntField(
        out.y
    );

    // --------------------------------------------------------
    // Z - optional
    // --------------------------------------------------------

    if (AskYesNo(
            "\nConsegue subir ou descer EXATAMENTE 1 andar agora? [S/N]: "))
    {
        auto zBefore =
            CaptureLocalU8(
                base,
                0,
                0x120
            );

        std::cout
            << "Suba ou desca exatamente 1 andar sem relogar.\n";

        WaitEnter(
            "Depois de mudar o andar, pressione ENTER..."
        );

        auto zAfter =
            CaptureLocalU8(
                base,
                0,
                0x120
            );

        uintptr_t preferredZOffset = 0;

        if (out.x.offset &&
            out.y.offset &&
            out.y.offset ==
                out.x.offset + 4)
        {
            preferredZOffset =
                out.y.offset + 4;
        }

        out.z =
            ResolveZTransition(
                base,
                zBefore,
                zAfter,
                preferredZOffset
            );
    }
    else
    {
        uintptr_t inferredZOffset =
            (
                out.x.offset &&
                out.y.offset &&
                out.y.offset ==
                    out.x.offset + 4
            )
                ? out.y.offset + 4
                : REF_OFF_Z;

        uint8_t currentZ =
            ReadU8(
                base +
                inferredZOffset
            );

        if (currentZ <= 31)
        {
            out.z.address =
                base +
                inferredZOffset;

            out.z.offset =
                inferredZOffset;

            out.z.before =
                currentZ;

            out.z.after =
                currentZ;

            out.z.state =
                FieldState::StrongCandidate;

            out.z.evidence =
                "reference_shape_plausible_floor_not_dynamically_changed";
        }
        else
        {
            out.z.state =
                FieldState::Unresolved;

            out.z.evidence =
                "floor_change_skipped_and_reference_value_implausible";
        }
    }

    PrintUIntField(
        out.z
    );

    // --------------------------------------------------------
    // Direction - two turns without walking
    // --------------------------------------------------------

    if (AskYesNo(
            "\nConsegue virar o personagem SEM trocar de sqm? [S/N]: "))
    {
        auto dA =
            CaptureLocalU32(
                base,
                0,
                0x120
            );

        std::cout
            << "Vire para outro lado SEM andar.\n";

        WaitEnter(
            "Depois da primeira virada, pressione ENTER..."
        );

        auto dB =
            CaptureLocalU32(
                base,
                0,
                0x120
            );

        std::cout
            << "Vire novamente para outro lado SEM andar.\n";

        WaitEnter(
            "Depois da segunda virada, pressione ENTER..."
        );

        auto dC =
            CaptureLocalU32(
                base,
                0,
                0x120
            );

        out.direction =
            ResolveDirectionByTwoTurns(
                base,
                dA,
                dB,
                dC
            );
    }
    else
    {
        uint32_t direction =
            ReadU32(
                base +
                REF_OFF_DIRECTION
            );

        if (direction <= 7)
        {
            out.direction.address =
                base +
                REF_OFF_DIRECTION;

            out.direction.offset =
                REF_OFF_DIRECTION;

            out.direction.before =
                direction;

            out.direction.after =
                direction;

            out.direction.state =
                FieldState::StrongCandidate;

            out.direction.evidence =
                "reference_shape_small_direction_value_not_dynamically_changed";
        }
        else
        {
            out.direction.state =
                FieldState::Unresolved;

            out.direction.evidence =
                "turn_skipped_and_reference_direction_implausible";
        }
    }

    PrintUIntField(
        out.direction
    );

    std::cout
        << "\n============================================================\n"
        << "                 POSITION CALIBRATION RESULT\n"
        << "============================================================\n";

    PrintUIntField(out.x);
    PrintUIntField(out.y);
    PrintUIntField(out.z);
    PrintUIntField(out.direction);

    return out;
}

// ============================================================
// V1.3 - MODULE SECTIONS + POINTER PATH DISCOVERY
// ============================================================

std::vector<ModuleSection>
GetModuleSections()
{
    std::vector<ModuleSection> result;

    IMAGE_DOS_HEADER dos{};

    if (!SafeRead(
            g_exeBase,
            dos) ||
        dos.e_magic != IMAGE_DOS_SIGNATURE)
    {
        return result;
    }

    uintptr_t ntAddress =
        g_exeBase +
        static_cast<uintptr_t>(
            dos.e_lfanew
        );

    IMAGE_NT_HEADERS64 nt{};

    if (!SafeRead(
            ntAddress,
            nt) ||
        nt.Signature != IMAGE_NT_SIGNATURE)
    {
        return result;
    }

    uintptr_t sectionAddress =
        ntAddress +
        FIELD_OFFSET(
            IMAGE_NT_HEADERS64,
            OptionalHeader
        ) +
        nt.FileHeader.SizeOfOptionalHeader;

    for (unsigned i = 0;
         i < nt.FileHeader.NumberOfSections;
         ++i)
    {
        IMAGE_SECTION_HEADER sh{};

        if (!SafeRead(
                sectionAddress +
                    i * sizeof(sh),
                sh))
        {
            continue;
        }

        char name[9]{};

        std::memcpy(
            name,
            sh.Name,
            8
        );

        uintptr_t begin =
            g_exeBase +
            sh.VirtualAddress;

        uintptr_t size =
            std::max(
                sh.Misc.VirtualSize,
                sh.SizeOfRawData
            );

        uintptr_t end =
            begin +
            size;

        if (end >
            g_imageEnd)
        {
            end =
                g_imageEnd;
        }

        if (end <= begin)
            continue;

        ModuleSection section{};

        section.name =
            name;

        section.begin =
            begin;

        section.end =
            end;

        section.characteristics =
            sh.Characteristics;

        result.push_back(
            std::move(section)
        );
    }

    return result;
}

bool IsReadablePrivatePointer(
    uintptr_t value)
{
    if (!value)
        return false;

    MEMORY_BASIC_INFORMATION mbi{};

    if (!VirtualQuery(
            reinterpret_cast<void*>(
                value
            ),
            &mbi,
            sizeof(mbi)))
    {
        return false;
    }

    if (mbi.State != MEM_COMMIT ||
        mbi.Type != MEM_PRIVATE ||
        !IsReadableProtection(
            mbi.Protect))
    {
        return false;
    }

    return true;
}

std::vector<uintptr_t>
FindPrivatePointerReferences(
    uintptr_t target,
    size_t maxHits = 4096)
{
    std::vector<uintptr_t> hits;

    SYSTEM_INFO si{};
    GetSystemInfo(
        &si
    );

    uintptr_t cursor =
        reinterpret_cast<uintptr_t>(
            si.lpMinimumApplicationAddress
        );

    uintptr_t maximum =
        reinterpret_cast<uintptr_t>(
            si.lpMaximumApplicationAddress
        );

    while (cursor <
           maximum)
    {
        MEMORY_BASIC_INFORMATION mbi{};

        if (!VirtualQuery(
                reinterpret_cast<void*>(
                    cursor
                ),
                &mbi,
                sizeof(mbi)))
        {
            break;
        }

        uintptr_t begin =
            reinterpret_cast<uintptr_t>(
                mbi.BaseAddress
            );

        uintptr_t end =
            begin +
            mbi.RegionSize;

        if (mbi.State == MEM_COMMIT &&
            mbi.Type == MEM_PRIVATE &&
            IsReadableProtection(
                mbi.Protect))
        {
            uintptr_t p =
                (begin + 7) &
                ~static_cast<uintptr_t>(7);

            for (;
                 p + sizeof(uintptr_t) <= end;
                 p += 8)
            {
                uintptr_t value = 0;

                std::memcpy(
                    &value,
                    reinterpret_cast<
                        const void*
                    >(p),
                    sizeof(value)
                );

                if (value !=
                    target)
                {
                    continue;
                }

                hits.push_back(
                    p
                );

                if (hits.size() >=
                    maxHits)
                {
                    return hits;
                }
            }
        }

        if (end <= cursor)
            break;

        cursor = end;
    }

    return hits;
}

std::vector<PointerPathCandidate>
FindDirectModuleRefs(
    uintptr_t localPlayer)
{
    std::vector<PointerPathCandidate> result;

    auto sections =
        GetModuleSections();

    for (const auto& section :
         sections)
    {
        if (!section.readable() ||
            section.executable())
        {
            continue;
        }

        uintptr_t p =
            (section.begin + 7) &
            ~static_cast<uintptr_t>(7);

        for (;
             p + sizeof(uintptr_t) <= section.end;
             p += 8)
        {
            uintptr_t value = 0;

            if (!SafeRead(
                    p,
                    value))
            {
                continue;
            }

            if (value !=
                localPlayer)
            {
                continue;
            }

            PointerPathCandidate c{};

            c.direct = true;
            c.globalAddress = p;
            c.globalRva =
                p -
                g_exeBase;

            c.section =
                section.name;

            c.status =
                section.writable()
                    ? "strong_candidate"
                    : "candidate";

            result.push_back(
                std::move(c)
            );

            if (result.size() >= 128)
                return result;
        }
    }

    return result;
}

std::vector<PointerPathCandidate>
FindIndirectModuleRefs(
    uintptr_t localPlayer)
{
    std::vector<PointerPathCandidate> result;

    auto privateRefs =
        FindPrivatePointerReferences(
            localPlayer,
            2048
        );

    if (privateRefs.empty())
        return result;

    struct OwnerCandidate
    {
        uintptr_t slot = 0;
        uintptr_t offset = 0;
    };

    std::unordered_map<
        uintptr_t,
        OwnerCandidate
    > owners;

    // A referencia ao LocalPlayer costuma ficar dentro de algum manager/game.
    // Para cada slot que contem LocalPlayer, testamos bases de objeto
    // ate 0x400 bytes antes desse slot.
    for (uintptr_t slot :
         privateRefs)
    {
        for (uintptr_t offset = 0;
             offset <= 0x400;
             offset += 8)
        {
            if (slot < offset)
                break;

            uintptr_t owner =
                slot -
                offset;

            if (!IsReadablePrivatePointer(
                    owner))
            {
                continue;
            }

            if (owners.find(
                    owner) ==
                owners.end())
            {
                owners.emplace(
                    owner,
                    OwnerCandidate{
                        slot,
                        offset
                    }
                );
            }
        }
    }

    auto sections =
        GetModuleSections();

    for (const auto& section :
         sections)
    {
        if (!section.readable() ||
            section.executable())
        {
            continue;
        }

        uintptr_t p =
            (section.begin + 7) &
            ~static_cast<uintptr_t>(7);

        for (;
             p + sizeof(uintptr_t) <= section.end;
             p += 8)
        {
            uintptr_t moduleValue = 0;

            if (!SafeRead(
                    p,
                    moduleValue))
            {
                continue;
            }

            auto it =
                owners.find(
                    moduleValue
                );

            if (it ==
                owners.end())
            {
                continue;
            }

            const OwnerCandidate& owner =
                it->second;

            uintptr_t check =
                ReadPtr(
                    moduleValue +
                    owner.offset
                );

            if (check !=
                localPlayer)
            {
                continue;
            }

            PointerPathCandidate c{};

            c.direct = false;

            c.globalAddress =
                p;

            c.globalRva =
                p -
                g_exeBase;

            c.section =
                section.name;

            c.ownerRuntime =
                moduleValue;

            c.ownerOffset =
                owner.offset;

            c.status =
                section.writable()
                    ? "candidate"
                    : "weak_candidate";

            result.push_back(
                std::move(c)
            );

            if (result.size() >= 256)
                return result;
        }
    }

    return result;
}

PointerDiscovery
DiscoverPointerPath(
    uintptr_t localPlayer)
{
    PointerDiscovery out{};

    std::cout
        << "\n============================================================\n"
        << "                  POINTER PATH DISCOVERY\n"
        << "============================================================\n"
        << "Target LocalPlayer = "
        << HexPtr(
            localPlayer
        )
        << "\n"
        << "Procurando referencias somente em modo leitura...\n";

    out.direct =
        FindDirectModuleRefs(
            localPlayer
        );

    std::cout
        << "[DIRECT] referencias no modulo = "
        << out.direct.size()
        << "\n";

    // Se nao houver referencia direta unica, procura:
    // module global -> owner/manager -> +offset -> LocalPlayer.
    out.indirect =
        FindIndirectModuleRefs(
            localPlayer
        );

    std::cout
        << "[INDIRECT] caminhos de 2 niveis = "
        << out.indirect.size()
        << "\n";

    // Preferencia:
    // 1) uma unica ref direta em secao gravavel;
    // 2) qualquer ref direta;
    // 3) um unico caminho indireto em secao gravavel.
    std::vector<PointerPathCandidate> directWritable;

    for (const auto& c :
         out.direct)
    {
        if (c.status ==
            "strong_candidate")
        {
            directWritable.push_back(
                c
            );
        }
    }

    if (directWritable.size() == 1)
    {
        out.hasBest = true;
        out.best =
            directWritable[0];

        out.best.status =
            "strong_candidate";
    }
    else if (out.direct.size() == 1)
    {
        out.hasBest = true;
        out.best =
            out.direct[0];

        out.best.status =
            "candidate";
    }
    else
    {
        std::vector<PointerPathCandidate> indirectWritable;

        for (const auto& c :
             out.indirect)
        {
            if (c.status ==
                "candidate")
            {
                indirectWritable.push_back(
                    c
                );
            }
        }

        if (indirectWritable.size() == 1)
        {
            out.hasBest = true;
            out.best =
                indirectWritable[0];

            out.best.status =
                "candidate";
        }
    }

    size_t directShow =
        std::min<size_t>(
            out.direct.size(),
            16
        );

    for (size_t i = 0;
         i < directShow;
         ++i)
    {
        const auto& c =
            out.direct[i];

        std::cout
            << "  [D"
            << (i + 1)
            << "] "
            << c.section
            << " RVA="
            << HexU64(
                c.globalRva
            )
            << " -> LocalPlayer"
            << " ["
            << c.status
            << "]\n";
    }

    size_t indirectShow =
        std::min<size_t>(
            out.indirect.size(),
            16
        );

    for (size_t i = 0;
         i < indirectShow;
         ++i)
    {
        const auto& c =
            out.indirect[i];

        std::cout
            << "  [I"
            << (i + 1)
            << "] "
            << c.section
            << " RVA="
            << HexU64(
                c.globalRva
            )
            << " -> owner="
            << HexPtr(
                c.ownerRuntime
            )
            << " +"
            << HexU64(
                c.ownerOffset
            )
            << " -> LocalPlayer"
            << " ["
            << c.status
            << "]\n";
    }

    if (out.hasBest)
    {
        std::cout
            << "\n[BEST POINTER PATH]\n"
            << "Global RVA : "
            << HexU64(
                out.best.globalRva
            )
            << "\n"
            << "Section    : "
            << out.best.section
            << "\n"
            << "Type       : "
            << (
                out.best.direct
                    ? "DIRECT"
                    : "INDIRECT"
            )
            << "\n";

        if (!out.best.direct)
        {
            std::cout
                << "Owner off  : "
                << HexU64(
                    out.best.ownerOffset
                )
                << "\n";
        }

        std::cout
            << "Status     : "
            << out.best.status
            << "\n";
    }
    else
    {
        std::cout
            << "\n[POINTER] Nenhum caminho unico foi promovido a BEST.\n"
            << "Os candidatos serao salvos no JSON para a proxima validacao.\n";
    }

    return out;
}

void WriteUIntFieldJson(
    std::ofstream& f,
    const char* key,
    const UIntFieldResult& field,
    bool comma)
{
    f
        << "      \""
        << key
        << "\": {\n";

    if (field.address)
    {
        f
            << "        \"offset\": \""
            << HexU64(
                field.offset
            )
            << "\",\n";
    }
    else
    {
        f
            << "        \"offset\": null,\n";
    }

    f
        << "        \"status\": \""
        << StateName(
            field.state
        )
        << "\",\n"
        << "        \"evidence\": \""
        << EscapeJson(
            field.evidence
        )
        << "\"";

    if (field.address)
    {
        f
            << ",\n"
            << "        \"before\": "
            << field.before
            << ",\n"
            << "        \"after\": "
            << field.after
            << "\n";
    }
    else
    {
        f
            << "\n";
    }

    f
        << "      }";

    if (comma)
        f << ",";

    f << "\n";
}

void WritePointerCandidateJson(
    std::ofstream& f,
    const PointerPathCandidate& c,
    bool comma,
    const char* indent)
{
    f
        << indent
        << "{\n"
        << indent
        << "  \"type\": \""
        << (
            c.direct
                ? "direct"
                : "indirect"
        )
        << "\",\n"
        << indent
        << "  \"section\": \""
        << EscapeJson(
            c.section
        )
        << "\",\n"
        << indent
        << "  \"globalRva\": \""
        << HexU64(
            c.globalRva
        )
        << "\",\n"
        << indent
        << "  \"status\": \""
        << EscapeJson(
            c.status
        )
        << "\"";

    if (!c.direct)
    {
        f
            << ",\n"
            << indent
            << "  \"ownerOffset\": \""
            << HexU64(
                c.ownerOffset
            )
            << "\"\n";
    }
    else
    {
        f << "\n";
    }

    f
        << indent
        << "}";

    if (comma)
        f << ",";

    f << "\n";
}

// ============================================================
// JSON
// ============================================================

std::string DirectoryOf(
    const std::string& path)
{
    size_t pos =
        path.find_last_of(
            "\\/"
        );

    if (pos ==
        std::string::npos)
    {
        return ".";
    }

    return
        path.substr(
            0,
            pos
        );
}

std::string EscapeJson(
    const std::string& s)
{
    std::string out;

    for (char ch :
         s)
    {
        switch (ch)
        {
            case '\\':
                out += "\\\\";
                break;

            case '"':
                out += "\\\"";
                break;

            case '\n':
                out += "\\n";
                break;

            case '\r':
                break;

            case '\t':
                out += "\\t";
                break;

            default:
                out += ch;
                break;
        }
    }

    return out;
}

void WriteFieldJson(
    std::ofstream& f,
    const char* key,
    const FieldResult& field,
    bool comma)
{
    f
        << "      \""
        << key
        << "\": {\n";

    if (field.address)
    {
        f
            << "        \"offset\": \""
            << HexU64(
                field.offset
            )
            << "\",\n";
    }
    else
    {
        f
            << "        \"offset\": null,\n";
    }

    f
        << "        \"status\": \""
        << StateName(
            field.state
        )
        << "\",\n";

    f
        << "        \"evidence\": \""
        << EscapeJson(
            field.evidence
        )
        << "\"";

    if (field.state ==
            FieldState::Confirmed)
    {
        f
            << ",\n"
            << "        \"before\": "
            << std::setprecision(17)
            << field.before
            << ",\n"
            << "        \"after\": "
            << std::setprecision(17)
            << field.after
            << "\n";
    }
    else
    {
        f
            << "\n";
    }

    f
        << "      }";

    if (comma)
        f << ",";

    f << "\n";
}

bool SaveProfile(
    const BuildInfo& build,
    const BaseHypothesis& base,
    const ProfileFields& fields,
    const PositionCalibration& position,
    const PointerDiscovery& pointers)
{
    char dllPath[MAX_PATH]{};

    GetModuleFileNameA(
        g_dllModule,
        dllPath,
        MAX_PATH
    );

    std::string directory =
        DirectoryOf(
            dllPath
        );

    std::ostringstream filename;

    filename
        << directory
        << "\\otclab_profile_v15_discovery_"
        << std::hex
        << std::uppercase
        << build.timestamp
        << "_"
        << build.textHash
        << ".json";

    std::ofstream f(
        filename.str(),
        std::ios::out |
        std::ios::trunc
    );

    if (!f)
    {
        std::cout
            << "[SAVE] Falha ao criar JSON.\n";

        return false;
    }

    int confirmed = 0;
    int strong = 0;
    int pending = 0;

    const FieldResult* list[] =
    {
        &fields.health,
        &fields.maxHealth,
        &fields.mana,
        &fields.maxMana,
        &fields.experience,
        &fields.level,
        &fields.capacity
    };

    for (const FieldResult* field :
         list)
    {
        if (field->state ==
            FieldState::Confirmed)
        {
            ++confirmed;
        }
        else if (field->state ==
                 FieldState::StrongCandidate)
        {
            ++strong;
        }
        else if (field->pending())
        {
            ++pending;
        }
    }

    f << "{\n";

    f
        << "  \"format\": \"otclab-build-profile-v1.5\",\n";

    f
        << "  \"build\": {\n"
        << "    \"exe\": \""
        << EscapeJson(
            build.exePath
        )
        << "\",\n"
        << "    \"timestamp\": \""
        << HexU64(
            build.timestamp
        )
        << "\",\n"
        << "    \"sizeOfImage\": \""
        << HexU64(
            build.sizeOfImage
        )
        << "\",\n"
        << "    \"entryPointRva\": \""
        << HexU64(
            build.entryPointRva
        )
        << "\",\n"
        << "    \"textRva\": \""
        << HexU64(
            build.textRva
        )
        << "\",\n"
        << "    \"textSize\": \""
        << HexU64(
            build.textSize
        )
        << "\",\n"
        << "    \"textHashFNV1A64\": \""
        << HexU64(
            build.textHash
        )
        << "\"\n"
        << "  },\n";

    f
        << "  \"localPlayer\": {\n"
        << "    \"runtimeBaseCandidate\": \""
        << HexPtr(
            base.base
        )
        << "\",\n"
        << "    \"baseConfidenceScore\": "
        << base.score
        << ",\n"
        << "    \"vtableRuntime\": \""
        << HexPtr(
            base.vtable
        )
        << "\",\n";

    if (InsideExeImage(
            base.vtable))
    {
        f
            << "    \"vtableRva\": \""
            << HexU64(
                base.vtable -
                g_exeBase
            )
            << "\",\n";
    }
    else
    {
        f
            << "    \"vtableRva\": null,\n";
    }

    f
        << "    \"confirmedFields\": "
        << confirmed
        << ",\n"
        << "    \"strongCandidateFields\": "
        << strong
        << ",\n"
        << "    \"pendingFields\": "
        << pending
        << ",\n";

    f
        << "    \"structuralEvidence\": {\n"
        << "      \"x\": "
        << base.x
        << ",\n"
        << "      \"y\": "
        << base.y
        << ",\n"
        << "      \"z\": "
        << static_cast<unsigned>(
            base.z
        )
        << ",\n"
        << "      \"id\": "
        << base.id
        << ",\n"
        << "      \"hpPercent\": "
        << static_cast<unsigned>(
            base.hpPercent
        )
        << ",\n"
        << "      \"direction\": "
        << base.direction
        << "\n"
        << "    },\n";

    f
        << "    \"fields\": {\n";

    WriteFieldJson(
        f,
        "health",
        fields.health,
        true
    );

    WriteFieldJson(
        f,
        "maxHealth",
        fields.maxHealth,
        true
    );

    WriteFieldJson(
        f,
        "mana",
        fields.mana,
        true
    );

    WriteFieldJson(
        f,
        "maxMana",
        fields.maxMana,
        true
    );

    WriteFieldJson(
        f,
        "experience",
        fields.experience,
        true
    );

    WriteFieldJson(
        f,
        "level",
        fields.level,
        true
    );

    WriteFieldJson(
        f,
        "capacity",
        fields.capacity,
        false
    );

    f
        << "    },\n";

    f
        << "    \"position\": {\n";

    WriteUIntFieldJson(
        f,
        "x",
        position.x,
        true
    );

    WriteUIntFieldJson(
        f,
        "y",
        position.y,
        true
    );

    WriteUIntFieldJson(
        f,
        "z",
        position.z,
        true
    );

    WriteUIntFieldJson(
        f,
        "direction",
        position.direction,
        false
    );

    f
        << "    },\n";

    f
        << "    \"pointerPath\": {\n"
        << "      \"directCandidateCount\": "
        << pointers.direct.size()
        << ",\n"
        << "      \"indirectCandidateCount\": "
        << pointers.indirect.size()
        << ",\n";

    if (pointers.hasBest)
    {
        f
            << "      \"best\": {\n"
            << "        \"type\": \""
            << (
                pointers.best.direct
                    ? "direct"
                    : "indirect"
            )
            << "\",\n"
            << "        \"section\": \""
            << EscapeJson(
                pointers.best.section
            )
            << "\",\n"
            << "        \"globalRva\": \""
            << HexU64(
                pointers.best.globalRva
            )
            << "\",\n"
            << "        \"status\": \""
            << EscapeJson(
                pointers.best.status
            )
            << "\"";

        if (!pointers.best.direct)
        {
            f
                << ",\n"
                << "        \"ownerOffset\": \""
                << HexU64(
                    pointers.best.ownerOffset
                )
                << "\"\n";
        }
        else
        {
            f << "\n";
        }

        f
            << "      },\n";
    }
    else
    {
        f
            << "      \"best\": null,\n";
    }

    f
        << "      \"directCandidates\": [\n";

    size_t directSave =
        std::min<size_t>(
            pointers.direct.size(),
            32
        );

    for (size_t i = 0;
         i < directSave;
         ++i)
    {
        WritePointerCandidateJson(
            f,
            pointers.direct[i],
            i + 1 < directSave,
            "        "
        );
    }

    f
        << "      ],\n"
        << "      \"indirectCandidates\": [\n";

    size_t indirectSave =
        std::min<size_t>(
            pointers.indirect.size(),
            32
        );

    for (size_t i = 0;
         i < indirectSave;
         ++i)
    {
        WritePointerCandidateJson(
            f,
            pointers.indirect[i],
            i + 1 < indirectSave,
            "        "
        );
    }

    f
        << "      ]\n"
        << "    }\n"
        << "  }\n"
        << "}\n";

    f.close();

    std::cout
        << "\n[SAVE] Profile salvo:\n"
        << filename.str()
        << "\n";

    return true;
}

// ============================================================
// BULK INPUT
// ============================================================

BulkInput AskBulkInput()
{
    BulkInput in{};

    std::cout
        << "\n============================================================\n"
        << "                    PLAYER BASE DATA\n"
        << "============================================================\n"
        << "Digite o grosso das informacoes uma unica vez.\n\n";

    in.health =
        AskNumber(
            "Health atual     : "
        );

    in.maxHealth =
        AskNumber(
            "Health maximo    : "
        );

    in.mana =
        AskNumber(
            "Mana atual       : "
        );

    in.maxMana =
        AskNumber(
            "Mana maxima      : "
        );

    in.experience =
        AskNumber(
            "Experience       : "
        );

    in.level =
        AskNumber(
            "Level            : "
        );

    in.capacity =
        AskNumber(
            "Capacity         : "
        );

    return in;
}

// ============================================================
// DISCOVER LOCALPLAYER
// ============================================================

bool DiscoverLocalPlayer(
    const BulkInput& in,
    Candidate& bestCandidate,
    BaseHypothesis& bestBase)
{
    std::vector<Candidate> candidates;

    // 1) Prefer HP pair.
    candidates =
        SeedPair(
            "Health",
            in.health,
            "MaxHealth",
            in.maxHealth
        );

    // 2) Mana pair fallback.
    if (candidates.empty())
    {
        candidates =
            SeedPair(
                "Mana",
                in.mana,
                "MaxMana",
                in.maxMana
            );
    }

    // 3) XP single fallback.
    if (candidates.empty())
    {
        candidates =
            SeedSingle(
                "Experience",
                in.experience
            );
    }

    if (candidates.empty())
    {
        return false;
    }

    std::cout
        << "\n[BULK] Adicionando os outros valores aos candidatos...\n";

    // Limita trabalho quando fallback gera muitos hits.
    size_t inspect =
        std::min<size_t>(
            candidates.size(),
            4096
        );

    int bestTotal =
        std::numeric_limits<int>::min();

    size_t bestIndex = 0;

    for (size_t i = 0;
         i < inspect;
         ++i)
    {
        AttachBulkEvidence(
            candidates[i],
            in
        );

        BaseHypothesis base =
            InferLocalPlayerBase(
                candidates[i]
            );

        int total =
            CandidateTotalScore(
                candidates[i],
                base
            );

        if (total >
            bestTotal)
        {
            bestTotal =
                total;

            bestIndex =
                i;

            bestBase =
                base;
        }
    }

    if (!bestBase.base)
    {
        return false;
    }

    bestCandidate =
        candidates[
            bestIndex
        ];

    std::cout
        << "\n============================================================\n"
        << "                  BEST LOCALPLAYER GUESS\n"
        << "============================================================\n"
        << "Runtime Base    : "
        << HexPtr(
            bestBase.base
        )
        << "\n"
        << "VTable          : "
        << HexPtr(
            bestBase.vtable
        )
        << "\n"
        << "VTable RVA      : ";

    if (InsideExeImage(
            bestBase.vtable))
    {
        std::cout
            << HexU64(
                bestBase.vtable -
                g_exeBase
            );
    }
    else
    {
        std::cout
            << "<outside exe>";
    }

    std::cout
        << "\n"
        << "Base score      : "
        << bestBase.score
        << "\n"
        << "Total score     : "
        << bestTotal
        << "\n"
        << "Evidence fields : "
        << bestCandidate.evidence.size()
        << "\n"
        << "Position        : "
        << bestBase.x
        << ","
        << bestBase.y
        << ","
        << static_cast<unsigned>(
            bestBase.z
        )
        << "\n"
        << "ID              : "
        << bestBase.id
        << "\n"
        << "HP%             : "
        << static_cast<unsigned>(
            bestBase.hpPercent
        )
        << "\n"
        << "Direction       : "
        << bestBase.direction
        << "\n";

    return true;
}

// ============================================================
// LOCAL BULK RESOLUTION
// ============================================================

ProfileFields ResolveBulkLocally(
    uintptr_t base,
    const BulkInput& in)
{
    ProfileFields fields{};

    auto cells =
        CaptureLocalDoubles(
            base
        );

    std::cout
        << "\n[LOCAL] "
        << cells.size()
        << " doubles capturados entre +"
        << HexU64(
            LOCAL_SCAN_BEGIN
        )
        << " e +"
        << HexU64(
            LOCAL_SCAN_END
        )
        << "\n";

    PairResult hp =
        ResolveStaticPair(
            "Health",
            "MaxHealth",
            base,
            cells,
            in.health,
            in.maxHealth,
            REF_OFF_HEALTH,
            REF_OFF_MAX_HEALTH
        );

    fields.health =
        hp.current;

    fields.maxHealth =
        hp.maximum;

    PairResult mana =
        ResolveStaticPair(
            "Mana",
            "MaxMana",
            base,
            cells,
            in.mana,
            in.maxMana,
            REF_OFF_MANA,
            REF_OFF_MAX_MANA
        );

    fields.mana =
        mana.current;

    fields.maxMana =
        mana.maximum;

    fields.experience =
        ResolveStaticSingle(
            "Experience",
            base,
            cells,
            in.experience,
            REF_OFF_EXPERIENCE
        );

    fields.level =
        ResolveStaticSingle(
            "Level",
            base,
            cells,
            in.level,
            REF_OFF_LEVEL
        );

    fields.capacity =
        ResolveStaticSingle(
            "Capacity",
            base,
            cells,
            in.capacity,
            REF_OFF_CAPACITY
        );

    return fields;
}

// ============================================================
// RETRY PENDING ONLY
// ============================================================

void RetryPendingFields(
    uintptr_t base,
    ProfileFields& fields)
{
    PrintFields(
        fields
    );

    // --------------------------------------------------------
    // Health pair
    // --------------------------------------------------------

    if (fields.health.pending() ||
        fields.maxHealth.pending())
    {
        std::cout
            << "\n[PENDING] Health/MaxHealth precisam de validacao.\n";

        if (AskYesNo(
                "Consegue alterar a vida atual agora? [S/N]: "))
        {
            PairResult retry =
                RetryPairDynamic(
                    "Health",
                    "MaxHealth",
                    base,
                    REF_OFF_HEALTH,
                    REF_OFF_MAX_HEALTH
                );

            if (retry.current.valid() ||
                !retry.current.pending())
            {
                fields.health =
                    retry.current;
            }

            if (retry.maximum.valid() ||
                !retry.maximum.pending())
            {
                fields.maxHealth =
                    retry.maximum;
            }
        }
        else
        {
            if (fields.health.pending())
                fields.health.state =
                    FieldState::Skipped;

            if (fields.maxHealth.pending())
                fields.maxHealth.state =
                    FieldState::Skipped;
        }
    }

    // --------------------------------------------------------
    // Mana pair
    // --------------------------------------------------------

    if (fields.mana.pending() ||
        fields.maxMana.pending())
    {
        std::cout
            << "\n[PENDING] Mana/MaxMana precisam de validacao.\n";

        if (AskYesNo(
                "Consegue gastar ou regenerar mana agora? [S/N]: "))
        {
            PairResult retry =
                RetryPairDynamic(
                    "Mana",
                    "MaxMana",
                    base,
                    REF_OFF_MANA,
                    REF_OFF_MAX_MANA
                );

            if (retry.current.valid() ||
                !retry.current.pending())
            {
                fields.mana =
                    retry.current;
            }

            if (retry.maximum.valid() ||
                !retry.maximum.pending())
            {
                fields.maxMana =
                    retry.maximum;
            }
        }
        else
        {
            if (fields.mana.pending())
                fields.mana.state =
                    FieldState::Skipped;

            if (fields.maxMana.pending())
                fields.maxMana.state =
                    FieldState::Skipped;
        }
    }

    // --------------------------------------------------------
    // XP
    // --------------------------------------------------------

    if (fields.experience.pending())
    {
        std::cout
            << "\n[PENDING] Experience nao foi localizada com seguranca.\n";

        if (AskYesNo(
                "Consegue ganhar XP agora? [S/N]: "))
        {
            fields.experience =
                RetrySingleDynamic(
                    "Experience",
                    base,
                    REF_OFF_EXPERIENCE,
                    "Ganhe alguma experiencia sem relogar."
                );
        }
        else
        {
            fields.experience.state =
                FieldState::Skipped;
        }
    }

    // --------------------------------------------------------
    // Level
    // --------------------------------------------------------

    if (fields.level.pending())
    {
        std::cout
            << "\n[PENDING] Level nao foi localizado com seguranca.\n";

        if (AskYesNo(
                "Consegue alterar o Level agora? [S/N]: "))
        {
            fields.level =
                RetrySingleDynamic(
                    "Level",
                    base,
                    REF_OFF_LEVEL,
                    "Altere o level mantendo o mesmo personagem."
                );
        }
        else
        {
            fields.level.state =
                FieldState::Skipped;
        }
    }

    // --------------------------------------------------------
    // Capacity
    // --------------------------------------------------------

    if (fields.capacity.pending())
    {
        std::cout
            << "\n[PENDING] Capacity nao foi localizada com seguranca.\n";

        if (AskYesNo(
                "Consegue alterar Capacity agora? [S/N]: "))
        {
            fields.capacity =
                RetrySingleDynamic(
                    "Capacity",
                    base,
                    REF_OFF_CAPACITY,
                    "Pegue/largue peso ou mova itens para alterar Capacity."
                );
        }
        else
        {
            fields.capacity.state =
                FieldState::Skipped;
        }
    }
}


// ============================================================
// V1.5 - SELF BOOTSTRAP PROFILE DATABASE
// ============================================================

struct DbProfile
{
    std::string name;
    std::string status;

    uint64_t timestamp = 0;
    uint64_t sizeOfImage = 0;
    uint64_t textHash = 0;

    uintptr_t vtableRva = 0;

    uintptr_t directGlobalRva = 0;
    uintptr_t indirectGlobalRva = 0;
    uintptr_t ownerOffset = 0;

    uintptr_t x = 0;
    uintptr_t y = 0;
    uintptr_t z = 0;
    uintptr_t id = 0;
    uintptr_t hpPercent = 0;
    uintptr_t direction = 0;

    // V3.9 canonical Creature schema.
    uintptr_t creatureName = 0;
    uintptr_t creatureWalkDirection = 0;
    uintptr_t creatureSpeed = 0;
    uintptr_t creatureSkull = 0;
    uintptr_t creatureParty = 0;
    uintptr_t creatureRemoved = 0;
    uintptr_t creatureWalking = 0;
    uintptr_t creatureStates = 0;

    uintptr_t health = 0;
    uintptr_t maxHealth = 0;
    uintptr_t capacity = 0;
    uintptr_t experience = 0;
    uintptr_t level = 0;
    uintptr_t mana = 0;
    uintptr_t maxMana = 0;

    // Discovery V2 - Game anchor discovered behaviorally.
    uintptr_t gameRva = 0;
    uintptr_t gameLocalPlayer = 0;
    uintptr_t gameAttackTarget = 0;
    std::string gameStatus;

    // Discovery V2.1 - FollowTarget discovered behaviorally.
    uintptr_t gameFollowTarget = 0;
    std::string followStatus;

    // Discovery V2.2 - Map discovered from Player position transitions.
    uintptr_t mapRva = 0;
    uintptr_t mapCenterX = 0;
    uintptr_t mapCenterY = 0;
    uintptr_t mapCenterZ = 0;
    uintptr_t mapNorth = 0;
    uintptr_t mapEast = 0;
    uintptr_t mapSouth = 0;
    uintptr_t mapWest = 0;
    std::string mapStatus;

    // Discovery V2.3 - Tile::things vector layout.
    uintptr_t tileThingsBegin = 0;
    uintptr_t tileThingsEnd = 0;
    uintptr_t tileThingsCap = 0;

    // V3.1 - semantic Tile class learned by Stage 5A.
    uintptr_t tileVtableRva = 0;
    std::string tileRttiName;

    // V3.3 - physical representation of Tile::things.
    // raw_pointer_array = Thing*
    // shared_ptr_array  = [Thing*][control-block*] on tested MSVC x64 builds.
    uintptr_t thingStorageStride = 0;
    std::string thingStorageMode;

    std::string tileThingsStatus;

    // Discovery V2.4.3 - Map -> Tile storage provenance.
    uintptr_t mapTilePathDepth = 0;
    uintptr_t mapTilePathMapOffset = 0;
    uintptr_t mapTilePathChildOffset = 0;
    uintptr_t mapTilePathHeaderOffset = 0;

    // V3.1 - physical representation of the Map Tile storage.
    uintptr_t mapTileStorageStride = 0;
    std::string mapTileStorageMode;

    std::string mapTilePathStatus;

    // Discovery V2.5 - semantic Monster sample from AttackTarget.
    uintptr_t monsterVtableRva = 0;
    std::string monsterVtableStatus;

    // Discovery V2.6 - four-class static-bool classification.
    uintptr_t itemVtableRva = 0;
    std::string itemVtableStatus;

    uintptr_t playerVtableRva = 0;
    std::string playerVtableStatus;

    uintptr_t slotIsItem = 0;
    uintptr_t slotIsCreature = 0;
    uintptr_t slotIsMonster = 0;
    uintptr_t slotIsPlayer = 0;
    uintptr_t slotIsLocalPlayer = 0;

    std::string classificationStatus;

    // BuildMigrator V4.6.1 - NPC classification.
    uintptr_t npcVtableRva = 0;
    uintptr_t slotIsNpc = 0;
    std::string npcStatus;

    // BuildMigrator V4.6.1 - Item / inventory.
    uintptr_t inventoryBaseOffset = 0;
    uintptr_t inventorySlotStride = 0;
    std::string inventoryStorageMode;
    std::string inventoryStatus;

    uintptr_t itemIdOffset = 0;
    uintptr_t itemCountOffset = 0;
    uintptr_t itemCountWidth = 0;
    std::string itemLayoutStatus;

    // BuildMigrator V4.6.1 - Container storage / layout.
    uintptr_t gameContainersOffset = 0;

    uintptr_t containerMapHeaderOffset = 0;
    uintptr_t containerMapSizeOffset = 0;

    uintptr_t containerNodeLeftOffset = 0;
    uintptr_t containerNodeRightOffset = 0;
    uintptr_t containerNodeNilOffset = 0;
    uintptr_t containerNodeKeyOffset = 0;
    uintptr_t containerNodeValueOffset = 0;

    uintptr_t containerIdOffset = 0;
    uintptr_t containerCapacityOffset = 0;
    uintptr_t containerItemOffset = 0;
    uintptr_t containerNameOffset = 0;
    uintptr_t containerHasParentOffset = 0;
    uintptr_t containerClosedOffset = 0;
    uintptr_t containerUnlockedOffset = 0;
    uintptr_t containerPagesOffset = 0;
    uintptr_t containerSizeOffset = 0;
    uintptr_t containerFirstIndexOffset = 0;
    uintptr_t containerDequeMapOffset = 0;
    uintptr_t containerDequeMapSizeOffset = 0;
    uintptr_t containerDequeOffsetOffset = 0;
    uintptr_t containerItemCountOffset = 0;

    // V3.8 - discovered Container item storage.
    // deque_raw_item_ptr / deque_shared_ptr_item
    uintptr_t containerItemElementStride = 0;
    std::string containerItemStorageMode;

    std::string containersStatus;

    // BuildMigrator V4.6.1 - native/static function RVAs.
    uintptr_t fnGameAutoWalk = 0;
    uintptr_t fnLocalPlayerAutoWalk = 0;
    uintptr_t fnGameAttack = 0;
    uintptr_t fnGameFollow = 0;
    uintptr_t fnGameLook = 0;
    uintptr_t fnGameDetailedLook = 0;
    uintptr_t fnGameMove = 0;
    uintptr_t fnGameUse = 0;
    uintptr_t fnGameUseWith = 0;
    uintptr_t fnGameTalk = 0;
    uintptr_t fnMapGetTile = 0;
    uintptr_t fnMapGetCreatureById = 0;
    uintptr_t fnMapGetCreatureByName = 0;
    uintptr_t fnContainerGetItem = 0;

    uintptr_t localPlayerAutoWalkVtableSlot = 0;

    std::string sigGameAutoWalk;
    std::string sigLocalPlayerAutoWalk;
    std::string sigGameAttack;
    std::string sigGameFollow;
    std::string sigGameLook;
    std::string sigGameDetailedLook;
    std::string sigGameMove;
    std::string sigGameUse;
    std::string sigGameUseWith;
    std::string sigGameTalk;
    std::string sigMapGetTile;
    std::string sigMapGetCreatureById;
    std::string sigMapGetCreatureByName;
    std::string sigContainerGetItem;

    std::string functionsStatus;

    // V4.9.1 x64 feature contract: Look + Player Light.
    std::string lookFeatureStatus;
    std::string lookHookFunction;
    uintptr_t lookHookRva = 0;
    std::string lookHookArgument;
    uintptr_t lookThingIndirection = 0;
    uintptr_t lookItemIdOffset = 0;
    std::string lookItemIdType;
    uintptr_t lookPositionXOffset = 0;
    uintptr_t lookPositionYOffset = 0;
    uintptr_t lookPositionZOffset = 0;
    bool lookContainerSentinelEnabled = false;
    uintptr_t lookContainerSentinelX = 0;
    std::string lookContextStatus;

    std::string hackLightStatus;
    uintptr_t lightIntensityOffset = 0;
    std::string lightIntensityType;
    int lightObservedBaseline = -1;
    int lightObservedTorch = -1;
    int lightObservedLux = -1;
    int lightObservedGranLux = -1;
    int lightHackValue = FEATURE_LIGHT_DEFAULT_HACK_VALUE;
    std::string lightCalibrationMethod;
    bool lightWriteValidated = false;
};

void BMRefreshLookFeatureContract(const BuildInfo& build, DbProfile& p);
void BMApplyKnownLightEvidence(const BuildInfo& build, DbProfile& p);

enum class MonitorPresence
{
    LoggedOut,
    LoggedIn,
    Inconsistent
};

struct MonitorSample
{
    ULONGLONG tick = 0;

    uintptr_t directRaw = 0;
    uintptr_t indirectOwner = 0;
    uintptr_t indirectRaw = 0;

    bool directValid = false;
    bool indirectValid = false;
    bool pathsAgree = false;

    uintptr_t localPlayer = 0;

    uintptr_t vtableRva = 0;

    uint32_t x = 0;
    uint32_t y = 0;
    uint8_t z = 0;

    uint32_t id = 0;
    uint8_t hpPercent = 0;
    uint32_t direction = 0;

    double health = 0.0;
    double maxHealth = 0.0;
    double capacity = 0.0;
    double experience = 0.0;
    double level = 0.0;
    double mana = 0.0;
    double maxMana = 0.0;

    MonitorPresence state =
        MonitorPresence::LoggedOut;
};

struct MonitorEvent
{
    std::string type;

    ULONGLONG tick = 0;

    uintptr_t localPlayer = 0;

    bool pathsAgree = false;

    uintptr_t vtableRva = 0;

    uint32_t x = 0;
    uint32_t y = 0;
    uint8_t z = 0;

    uint32_t id = 0;
};

struct MonitorStats
{
    uint64_t samples = 0;

    uint64_t loggedOutSamples = 0;
    uint64_t loggedInSamples = 0;
    uint64_t inconsistentSamples = 0;

    uint64_t directValidSamples = 0;
    uint64_t indirectValidSamples = 0;

    uint64_t agreementSamples = 0;
    uint64_t mismatchSamples = 0;

    uint64_t loginEvents = 0;
    uint64_t logoutEvents = 0;
    uint64_t pointerChangeEvents = 0;

    std::vector<MonitorEvent> events;
};

std::string ReadWholeTextFile(
    const std::string& path)
{
    std::ifstream f(
        path,
        std::ios::in |
        std::ios::binary
    );

    if (!f)
        return {};

    std::ostringstream ss;
    ss << f.rdbuf();

    return ss.str();
}

std::string FlatJsonString(
    const std::string& objectText,
    const std::string& key)
{
    std::string token =
        "\"" +
        key +
        "\"";

    size_t keyPos =
        objectText.find(
            token
        );

    if (keyPos ==
        std::string::npos)
    {
        return {};
    }

    size_t colon =
        objectText.find(
            ':',
            keyPos +
            token.size()
        );

    if (colon ==
        std::string::npos)
    {
        return {};
    }

    size_t firstQuote =
        objectText.find(
            '"',
            colon + 1
        );

    if (firstQuote ==
        std::string::npos)
    {
        return {};
    }

    std::string value;
    bool escape = false;

    for (size_t i =
             firstQuote + 1;
         i < objectText.size();
         ++i)
    {
        char ch =
            objectText[i];

        if (escape)
        {
            value += ch;
            escape = false;
            continue;
        }

        if (ch == '\\')
        {
            escape = true;
            continue;
        }

        if (ch == '"')
            return value;

        value += ch;
    }

    return {};
}

uint64_t ParseProfileNumber(
    const std::string& text)
{
    if (text.empty())
        return 0;

    try
    {
        return
            std::stoull(
                text,
                nullptr,
                0
            );
    }
    catch (...)
    {
        return 0;
    }
}

std::vector<std::string>
ExtractDatabaseProfileObjects(
    const std::string& json)
{
    std::vector<std::string> objects;

    size_t profilesPos =
        json.find(
            "\"profiles\""
        );

    if (profilesPos ==
        std::string::npos)
    {
        return objects;
    }

    size_t arrayStart =
        json.find(
            '[',
            profilesPos
        );

    if (arrayStart ==
        std::string::npos)
    {
        return objects;
    }

    bool inString = false;
    bool escape = false;

    int depth = 0;

    size_t objectStart =
        std::string::npos;

    for (size_t i =
             arrayStart + 1;
         i < json.size();
         ++i)
    {
        char ch =
            json[i];

        if (inString)
        {
            if (escape)
            {
                escape = false;
                continue;
            }

            if (ch == '\\')
            {
                escape = true;
                continue;
            }

            if (ch == '"')
                inString = false;

            continue;
        }

        if (ch == '"')
        {
            inString = true;
            continue;
        }

        if (ch == '{')
        {
            if (depth == 0)
            {
                objectStart =
                    i;
            }

            ++depth;
            continue;
        }

        if (ch == '}')
        {
            --depth;

            if (depth == 0 &&
                objectStart !=
                    std::string::npos)
            {
                objects.push_back(
                    json.substr(
                        objectStart,
                        i -
                        objectStart +
                        1
                    )
                );

                objectStart =
                    std::string::npos;
            }

            continue;
        }

        if (ch == ']' &&
            depth == 0)
        {
            break;
        }
    }

    return objects;
}

bool ParseDbProfile(
    const std::string& objectText,
    DbProfile& out)
{
    out.name =
        FlatJsonString(
            objectText,
            "name"
        );

    out.status =
        FlatJsonString(
            objectText,
            "status"
        );

    out.timestamp =
        ParseProfileNumber(
            FlatJsonString(
                objectText,
                "timestamp"
            )
        );

    out.sizeOfImage =
        ParseProfileNumber(
            FlatJsonString(
                objectText,
                "sizeOfImage"
            )
        );

    out.textHash =
        ParseProfileNumber(
            FlatJsonString(
                objectText,
                "textHashFNV1A64"
            )
        );

#define READ_DB_FIELD(name) \
    out.name = static_cast<uintptr_t>( \
        ParseProfileNumber( \
            FlatJsonString( \
                objectText, \
                #name \
            ) \
        ) \
    )

    READ_DB_FIELD(vtableRva);

    READ_DB_FIELD(directGlobalRva);
    READ_DB_FIELD(indirectGlobalRva);
    READ_DB_FIELD(ownerOffset);

    READ_DB_FIELD(x);
    READ_DB_FIELD(y);
    READ_DB_FIELD(z);
    READ_DB_FIELD(id);
    READ_DB_FIELD(hpPercent);
    READ_DB_FIELD(direction);
    READ_DB_FIELD(creatureName);
    READ_DB_FIELD(creatureWalkDirection);
    READ_DB_FIELD(creatureSpeed);
    READ_DB_FIELD(creatureSkull);
    READ_DB_FIELD(creatureParty);
    READ_DB_FIELD(creatureRemoved);
    READ_DB_FIELD(creatureWalking);
    READ_DB_FIELD(creatureStates);

    READ_DB_FIELD(health);
    READ_DB_FIELD(maxHealth);
    READ_DB_FIELD(capacity);
    READ_DB_FIELD(experience);
    READ_DB_FIELD(level);
    READ_DB_FIELD(mana);
    READ_DB_FIELD(maxMana);

    READ_DB_FIELD(gameRva);
    READ_DB_FIELD(gameLocalPlayer);
    READ_DB_FIELD(gameAttackTarget);
    READ_DB_FIELD(gameFollowTarget);

    READ_DB_FIELD(mapRva);
    READ_DB_FIELD(mapCenterX);
    READ_DB_FIELD(mapCenterY);
    READ_DB_FIELD(mapCenterZ);
    READ_DB_FIELD(mapNorth);
    READ_DB_FIELD(mapEast);
    READ_DB_FIELD(mapSouth);
    READ_DB_FIELD(mapWest);

    READ_DB_FIELD(tileThingsBegin);
    READ_DB_FIELD(tileThingsEnd);
    READ_DB_FIELD(tileThingsCap);
    READ_DB_FIELD(tileVtableRva);
    READ_DB_FIELD(thingStorageStride);

    READ_DB_FIELD(mapTilePathDepth);
    READ_DB_FIELD(mapTilePathMapOffset);
    READ_DB_FIELD(mapTilePathChildOffset);
    READ_DB_FIELD(mapTilePathHeaderOffset);
    READ_DB_FIELD(mapTileStorageStride);
    READ_DB_FIELD(monsterVtableRva);

    READ_DB_FIELD(itemVtableRva);
    READ_DB_FIELD(playerVtableRva);

    READ_DB_FIELD(slotIsItem);
    READ_DB_FIELD(slotIsCreature);
    READ_DB_FIELD(slotIsMonster);
    READ_DB_FIELD(slotIsPlayer);
    READ_DB_FIELD(slotIsLocalPlayer);

    READ_DB_FIELD(npcVtableRva);
    READ_DB_FIELD(slotIsNpc);

    READ_DB_FIELD(inventoryBaseOffset);
    READ_DB_FIELD(inventorySlotStride);
    READ_DB_FIELD(itemIdOffset);
    READ_DB_FIELD(itemCountOffset);
    READ_DB_FIELD(itemCountWidth);

    READ_DB_FIELD(gameContainersOffset);
    READ_DB_FIELD(containerMapHeaderOffset);
    READ_DB_FIELD(containerMapSizeOffset);
    READ_DB_FIELD(containerNodeLeftOffset);
    READ_DB_FIELD(containerNodeRightOffset);
    READ_DB_FIELD(containerNodeNilOffset);
    READ_DB_FIELD(containerNodeKeyOffset);
    READ_DB_FIELD(containerNodeValueOffset);
    READ_DB_FIELD(containerIdOffset);
    READ_DB_FIELD(containerCapacityOffset);
    READ_DB_FIELD(containerItemOffset);
    READ_DB_FIELD(containerNameOffset);
    READ_DB_FIELD(containerHasParentOffset);
    READ_DB_FIELD(containerClosedOffset);
    READ_DB_FIELD(containerUnlockedOffset);
    READ_DB_FIELD(containerPagesOffset);
    READ_DB_FIELD(containerSizeOffset);
    READ_DB_FIELD(containerFirstIndexOffset);
    READ_DB_FIELD(containerDequeMapOffset);
    READ_DB_FIELD(containerDequeMapSizeOffset);
    READ_DB_FIELD(containerDequeOffsetOffset);
    READ_DB_FIELD(containerItemCountOffset);
    READ_DB_FIELD(containerItemElementStride);

    READ_DB_FIELD(fnGameAutoWalk);
    READ_DB_FIELD(fnLocalPlayerAutoWalk);
    READ_DB_FIELD(fnGameAttack);
    READ_DB_FIELD(fnGameFollow);
    READ_DB_FIELD(fnGameLook);
    READ_DB_FIELD(fnGameDetailedLook);
    READ_DB_FIELD(fnGameMove);
    READ_DB_FIELD(fnGameUse);
    READ_DB_FIELD(fnGameUseWith);
    READ_DB_FIELD(fnGameTalk);
    READ_DB_FIELD(fnMapGetTile);
    READ_DB_FIELD(fnMapGetCreatureById);
    READ_DB_FIELD(fnMapGetCreatureByName);
    READ_DB_FIELD(fnContainerGetItem);
    READ_DB_FIELD(localPlayerAutoWalkVtableSlot);

    READ_DB_FIELD(lookHookRva);
    READ_DB_FIELD(lookThingIndirection);
    READ_DB_FIELD(lookItemIdOffset);
    READ_DB_FIELD(lookPositionXOffset);
    READ_DB_FIELD(lookPositionYOffset);
    READ_DB_FIELD(lookPositionZOffset);
    READ_DB_FIELD(lookContainerSentinelX);
    READ_DB_FIELD(lightIntensityOffset);

#undef READ_DB_FIELD

    out.gameStatus =
        FlatJsonString(
            objectText,
            "gameStatus"
        );

    if (out.gameStatus.empty())
        out.gameStatus = "unknown";

    out.followStatus =
        FlatJsonString(
            objectText,
            "followStatus"
        );

    if (out.followStatus.empty())
        out.followStatus = "unknown";

    out.mapStatus =
        FlatJsonString(
            objectText,
            "mapStatus"
        );

    if (out.mapStatus.empty())
        out.mapStatus = "unknown";

    out.tileRttiName =
        FlatJsonString(
            objectText,
            "tileRttiName"
        );

    if (out.tileRttiName.empty())
        out.tileRttiName = "unknown";

    out.mapTileStorageMode =
        FlatJsonString(
            objectText,
            "mapTileStorageMode"
        );

    if (out.mapTileStorageMode.empty())
        out.mapTileStorageMode = "unknown";

    out.thingStorageMode =
        FlatJsonString(
            objectText,
            "thingStorageMode"
        );

    if (out.thingStorageMode.empty())
        out.thingStorageMode = "unknown";

    out.tileThingsStatus =
        FlatJsonString(
            objectText,
            "tileThingsStatus"
        );

    if (out.tileThingsStatus.empty())
        out.tileThingsStatus = "unknown";

    out.mapTilePathStatus =
        FlatJsonString(
            objectText,
            "mapTilePathStatus"
        );

    if (out.mapTilePathStatus.empty())
        out.mapTilePathStatus = "unknown";

    out.monsterVtableStatus =
        FlatJsonString(
            objectText,
            "monsterVtableStatus"
        );

    if (out.monsterVtableStatus.empty())
        out.monsterVtableStatus = "unknown";

    out.itemVtableStatus =
        FlatJsonString(
            objectText,
            "itemVtableStatus"
        );

    if (out.itemVtableStatus.empty())
        out.itemVtableStatus = "unknown";

    out.playerVtableStatus =
        FlatJsonString(
            objectText,
            "playerVtableStatus"
        );

    if (out.playerVtableStatus.empty())
        out.playerVtableStatus = "unknown";

    out.classificationStatus =
        FlatJsonString(
            objectText,
            "classificationStatus"
        );

    if (out.classificationStatus.empty())
        out.classificationStatus = "unknown";

#define READ_DB_STRING_FIELD(name) \
    out.name = FlatJsonString( \
        objectText, \
        #name \
    ); \
    if (out.name.empty()) \
        out.name = "unknown"

    READ_DB_STRING_FIELD(npcStatus);
    READ_DB_STRING_FIELD(inventoryStorageMode);
    READ_DB_STRING_FIELD(inventoryStatus);
    READ_DB_STRING_FIELD(itemLayoutStatus);
    READ_DB_STRING_FIELD(containerItemStorageMode);
    READ_DB_STRING_FIELD(containersStatus);
    READ_DB_STRING_FIELD(functionsStatus);
    READ_DB_STRING_FIELD(lookFeatureStatus);
    READ_DB_STRING_FIELD(lookHookFunction);
    READ_DB_STRING_FIELD(lookHookArgument);
    READ_DB_STRING_FIELD(lookItemIdType);
    READ_DB_STRING_FIELD(lookContextStatus);
    READ_DB_STRING_FIELD(hackLightStatus);
    READ_DB_STRING_FIELD(lightIntensityType);
    READ_DB_STRING_FIELD(lightCalibrationMethod);

#undef READ_DB_STRING_FIELD

    out.lookContainerSentinelEnabled =
        out.lookContainerSentinelX != 0;

    out.lightWriteValidated =
        out.hackLightStatus == "confirmed_runtime_write";

#define READ_DB_SIGNATURE(name) \
    out.name = FlatJsonString( \
        objectText, \
        #name \
    )

    READ_DB_SIGNATURE(sigGameAutoWalk);
    READ_DB_SIGNATURE(sigLocalPlayerAutoWalk);
    READ_DB_SIGNATURE(sigGameAttack);
    READ_DB_SIGNATURE(sigGameFollow);
    READ_DB_SIGNATURE(sigGameLook);
    READ_DB_SIGNATURE(sigGameDetailedLook);
    READ_DB_SIGNATURE(sigGameMove);
    READ_DB_SIGNATURE(sigGameUse);
    READ_DB_SIGNATURE(sigGameUseWith);
    READ_DB_SIGNATURE(sigGameTalk);
    READ_DB_SIGNATURE(sigMapGetTile);
    READ_DB_SIGNATURE(sigMapGetCreatureById);
    READ_DB_SIGNATURE(sigMapGetCreatureByName);
    READ_DB_SIGNATURE(sigContainerGetItem);

#undef READ_DB_SIGNATURE

    if (out.status.empty())
    {
        out.status =
            "legacy_profile";
    }

    return
        !out.name.empty() &&
        out.timestamp != 0 &&
        out.sizeOfImage != 0 &&
        out.textHash != 0;
}

std::vector<DbProfile>
LoadProfileDatabase(
    const std::string& path)
{
    std::vector<DbProfile> profiles;

    std::string json =
        ReadWholeTextFile(
            path
        );

    if (json.empty())
        return profiles;

    auto objects =
        ExtractDatabaseProfileObjects(
            json
        );

    for (const auto& objectText :
         objects)
    {
        DbProfile profile{};

        if (ParseDbProfile(
                objectText,
                profile))
        {
            profiles.push_back(
                std::move(profile)
            );
        }
    }

    return profiles;
}

std::string V39ExtractNamedJsonObject(
    const std::string& json,
    const std::string& key)
{
    std::string token =
        "\"" + key + "\"";

    size_t keyPos =
        json.find(
            token
        );

    if (keyPos ==
        std::string::npos)
    {
        return {};
    }

    size_t open =
        json.find(
            '{',
            keyPos + token.size()
        );

    if (open ==
        std::string::npos)
    {
        return {};
    }

    bool inString = false;
    bool escape = false;
    int depth = 0;

    for (size_t i = open;
         i < json.size();
         ++i)
    {
        char ch = json[i];

        if (inString)
        {
            if (escape)
            {
                escape = false;
                continue;
            }

            if (ch == '\\')
            {
                escape = true;
                continue;
            }

            if (ch == '"')
                inString = false;

            continue;
        }

        if (ch == '"')
        {
            inString = true;
            continue;
        }

        if (ch == '{')
        {
            ++depth;
            continue;
        }

        if (ch == '}')
        {
            --depth;

            if (depth == 0)
            {
                return
                    json.substr(
                        open,
                        i - open + 1
                    );
            }
        }
    }

    return {};
}

std::vector<DbProfile>
V39LoadCanonicalProfileDirectory(
    const std::string& directory)
{
    std::vector<DbProfile> profiles;

    std::string pattern =
        directory +
        "\\\\OTCLab_BuildProfile_*.json";

    WIN32_FIND_DATAA fd{};

    HANDLE h =
        FindFirstFileA(
            pattern.c_str(),
            &fd
        );

    if (h ==
        INVALID_HANDLE_VALUE)
    {
        return profiles;
    }

    do
    {
        if (fd.dwFileAttributes &
            FILE_ATTRIBUTE_DIRECTORY)
        {
            continue;
        }

        std::string path =
            directory +
            "\\\\" +
            fd.cFileName;

        std::string json =
            ReadWholeTextFile(
                path
            );

        if (json.empty())
            continue;

        std::string state =
            V39ExtractNamedJsonObject(
                json,
                "migratorState"
            );

        if (state.empty())
            continue;

        DbProfile profile{};

        if (ParseDbProfile(
                state,
                profile))
        {
            profiles.push_back(
                std::move(
                    profile
                )
            );
        }
    }
    while (FindNextFileA(
               h,
               &fd));

    FindClose(
        h
    );

    return profiles;
}

bool SaveProfileDatabase(
    const std::string& path,
    const std::vector<DbProfile>& profiles)
{
    // V3.9 canonical-only mode: all legacy call-sites may pass an empty
    // path. In that mode the vector is only the in-memory working set and
    // the official per-build V2 file is saved by BMSaveCompleteProfile.
    if (path.empty())
        return true;

    std::ofstream f(
        path,
        std::ios::out |
        std::ios::trunc
    );

    if (!f)
        return false;

    f
        << "{\n"
        << "  \"format\": \"otclab-build-profiles-v2\",\n"
        << "  \"profiles\": [\n";

    for (size_t i = 0;
         i < profiles.size();
         ++i)
    {
        const auto& p =
            profiles[i];

        f
            << "    {\n"
            << "      \"name\": \""
            << EscapeJson(
                p.name
            )
            << "\",\n"
            << "      \"status\": \""
            << EscapeJson(
                p.status
            )
            << "\",\n"
            << "\n"
            << "      \"timestamp\": \""
            << HexU64(
                p.timestamp
            )
            << "\",\n"
            << "      \"sizeOfImage\": \""
            << HexU64(
                p.sizeOfImage
            )
            << "\",\n"
            << "      \"textHashFNV1A64\": \""
            << HexU64(
                p.textHash
            )
            << "\",\n"
            << "\n"
            << "      \"vtableRva\": \""
            << HexU64(
                p.vtableRva
            )
            << "\",\n"
            << "\n"
            << "      \"directGlobalRva\": \""
            << HexU64(
                p.directGlobalRva
            )
            << "\",\n"
            << "      \"indirectGlobalRva\": \""
            << HexU64(
                p.indirectGlobalRva
            )
            << "\",\n"
            << "      \"ownerOffset\": \""
            << HexU64(
                p.ownerOffset
            )
            << "\",\n"
            << "\n"
            << "      \"x\": \""
            << HexU64(
                p.x
            )
            << "\",\n"
            << "      \"y\": \""
            << HexU64(
                p.y
            )
            << "\",\n"
            << "      \"z\": \""
            << HexU64(
                p.z
            )
            << "\",\n"
            << "      \"id\": \""
            << HexU64(
                p.id
            )
            << "\",\n"
            << "      \"hpPercent\": \""
            << HexU64(
                p.hpPercent
            )
            << "\",\n"
            << "      \"direction\": \""
            << HexU64(
                p.direction
            )
            << "\",\n"
            << "\n"
            << "      \"health\": \""
            << HexU64(
                p.health
            )
            << "\",\n"
            << "      \"maxHealth\": \""
            << HexU64(
                p.maxHealth
            )
            << "\",\n"
            << "      \"capacity\": \""
            << HexU64(
                p.capacity
            )
            << "\",\n"
            << "      \"experience\": \""
            << HexU64(
                p.experience
            )
            << "\",\n"
            << "      \"level\": \""
            << HexU64(
                p.level
            )
            << "\",\n"
            << "      \"mana\": \""
            << HexU64(
                p.mana
            )
            << "\",\n"
            << "      \"maxMana\": \""
            << HexU64(
                p.maxMana
            )
            << "\",\n"
            << "\n"
            << "      \"gameRva\": \""
            << HexU64(
                p.gameRva
            )
            << "\",\n"
            << "      \"gameLocalPlayer\": \""
            << HexU64(
                p.gameLocalPlayer
            )
            << "\",\n"
            << "      \"gameAttackTarget\": \""
            << HexU64(
                p.gameAttackTarget
            )
            << "\",\n"
            << "      \"gameStatus\": \""
            << EscapeJson(
                p.gameStatus
            )
            << "\",\n"
            << "      \"gameFollowTarget\": \""
            << HexU64(
                p.gameFollowTarget
            )
            << "\",\n"
            << "      \"followStatus\": \""
            << EscapeJson(
                p.followStatus
            )
            << "\",\n"
            << "      \"mapRva\": \""
            << HexU64(
                p.mapRva
            )
            << "\",\n"
            << "      \"mapCenterX\": \""
            << HexU64(
                p.mapCenterX
            )
            << "\",\n"
            << "      \"mapCenterY\": \""
            << HexU64(
                p.mapCenterY
            )
            << "\",\n"
            << "      \"mapCenterZ\": \""
            << HexU64(
                p.mapCenterZ
            )
            << "\",\n"
            << "      \"mapNorth\": \""
            << HexU64(
                p.mapNorth
            )
            << "\",\n"
            << "      \"mapEast\": \""
            << HexU64(
                p.mapEast
            )
            << "\",\n"
            << "      \"mapSouth\": \""
            << HexU64(
                p.mapSouth
            )
            << "\",\n"
            << "      \"mapWest\": \""
            << HexU64(
                p.mapWest
            )
            << "\",\n"
            << "      \"mapStatus\": \""
            << EscapeJson(
                p.mapStatus
            )
            << "\",\n"
            << "      \"tileThingsBegin\": \""
            << HexU64(
                p.tileThingsBegin
            )
            << "\",\n"
            << "      \"tileThingsEnd\": \""
            << HexU64(
                p.tileThingsEnd
            )
            << "\",\n"
            << "      \"tileThingsCap\": \""
            << HexU64(
                p.tileThingsCap
            )
            << "\",\n"
            << "      \"tileVtableRva\": \""
            << HexU64(
                p.tileVtableRva
            )
            << "\",\n"
            << "      \"tileRttiName\": \""
            << EscapeJson(
                p.tileRttiName
            )
            << "\",\n"
            << "      \"thingStorageStride\": \""
            << HexU64(
                p.thingStorageStride
            )
            << "\",\n"
            << "      \"thingStorageMode\": \""
            << EscapeJson(
                p.thingStorageMode
            )
            << "\",\n"
            << "      \"tileThingsStatus\": \""
            << EscapeJson(
                p.tileThingsStatus
            )
            << "\",\n"
            << "      \"mapTilePathDepth\": \""
            << HexU64(
                p.mapTilePathDepth
            )
            << "\",\n"
            << "      \"mapTilePathMapOffset\": \""
            << HexU64(
                p.mapTilePathMapOffset
            )
            << "\",\n"
            << "      \"mapTilePathChildOffset\": \""
            << HexU64(
                p.mapTilePathChildOffset
            )
            << "\",\n"
            << "      \"mapTilePathHeaderOffset\": \""
            << HexU64(
                p.mapTilePathHeaderOffset
            )
            << "\",\n"
            << "      \"mapTileStorageStride\": \""
            << HexU64(
                p.mapTileStorageStride
            )
            << "\",\n"
            << "      \"mapTileStorageMode\": \""
            << EscapeJson(
                p.mapTileStorageMode
            )
            << "\",\n"
            << "      \"mapTilePathStatus\": \""
            << EscapeJson(
                p.mapTilePathStatus
            )
            << "\",\n"
            << "      \"monsterVtableRva\": \""
            << HexU64(
                p.monsterVtableRva
            )
            << "\",\n"
            << "      \"monsterVtableStatus\": \""
            << EscapeJson(
                p.monsterVtableStatus
            )
            << "\",\n"
            << "      \"itemVtableRva\": \""
            << HexU64(
                p.itemVtableRva
            )
            << "\",\n"
            << "      \"itemVtableStatus\": \""
            << EscapeJson(
                p.itemVtableStatus
            )
            << "\",\n"
            << "      \"playerVtableRva\": \""
            << HexU64(
                p.playerVtableRva
            )
            << "\",\n"
            << "      \"playerVtableStatus\": \""
            << EscapeJson(
                p.playerVtableStatus
            )
            << "\",\n"
            << "      \"slotIsItem\": \""
            << HexU64(
                p.slotIsItem
            )
            << "\",\n"
            << "      \"slotIsCreature\": \""
            << HexU64(
                p.slotIsCreature
            )
            << "\",\n"
            << "      \"slotIsMonster\": \""
            << HexU64(
                p.slotIsMonster
            )
            << "\",\n"
            << "      \"slotIsPlayer\": \""
            << HexU64(
                p.slotIsPlayer
            )
            << "\",\n"
            << "      \"slotIsLocalPlayer\": \""
            << HexU64(
                p.slotIsLocalPlayer
            )
            << "\",\n"
            << "      \"classificationStatus\": \""
            << EscapeJson(
                p.classificationStatus
            )
            << "\",\n"
            << "      \"npcVtableRva\": \""
            << HexU64(p.npcVtableRva)
            << "\",\n"
            << "      \"slotIsNpc\": \""
            << HexU64(p.slotIsNpc)
            << "\",\n"
            << "      \"npcStatus\": \""
            << EscapeJson(p.npcStatus)
            << "\",\n"
            << "      \"inventoryBaseOffset\": \""
            << HexU64(p.inventoryBaseOffset)
            << "\",\n"
            << "      \"inventorySlotStride\": \""
            << HexU64(p.inventorySlotStride)
            << "\",\n"
            << "      \"inventoryStorageMode\": \""
            << EscapeJson(p.inventoryStorageMode)
            << "\",\n"
            << "      \"inventoryStatus\": \""
            << EscapeJson(p.inventoryStatus)
            << "\",\n"
            << "      \"itemIdOffset\": \""
            << HexU64(p.itemIdOffset)
            << "\",\n"
            << "      \"itemCountOffset\": \""
            << HexU64(p.itemCountOffset)
            << "\",\n"
            << "      \"itemCountWidth\": \""
            << HexU64(p.itemCountWidth)
            << "\",\n"
            << "      \"itemLayoutStatus\": \""
            << EscapeJson(p.itemLayoutStatus)
            << "\",\n"
            << "      \"gameContainersOffset\": \""
            << HexU64(p.gameContainersOffset)
            << "\",\n"
            << "      \"containerMapHeaderOffset\": \""
            << HexU64(p.containerMapHeaderOffset)
            << "\",\n"
            << "      \"containerMapSizeOffset\": \""
            << HexU64(p.containerMapSizeOffset)
            << "\",\n"
            << "      \"containerNodeLeftOffset\": \""
            << HexU64(p.containerNodeLeftOffset)
            << "\",\n"
            << "      \"containerNodeRightOffset\": \""
            << HexU64(p.containerNodeRightOffset)
            << "\",\n"
            << "      \"containerNodeNilOffset\": \""
            << HexU64(p.containerNodeNilOffset)
            << "\",\n"
            << "      \"containerNodeKeyOffset\": \""
            << HexU64(p.containerNodeKeyOffset)
            << "\",\n"
            << "      \"containerNodeValueOffset\": \""
            << HexU64(p.containerNodeValueOffset)
            << "\",\n"
            << "      \"containerIdOffset\": \""
            << HexU64(p.containerIdOffset)
            << "\",\n"
            << "      \"containerCapacityOffset\": \""
            << HexU64(p.containerCapacityOffset)
            << "\",\n"
            << "      \"containerItemOffset\": \""
            << HexU64(p.containerItemOffset)
            << "\",\n"
            << "      \"containerNameOffset\": \""
            << HexU64(p.containerNameOffset)
            << "\",\n"
            << "      \"containerHasParentOffset\": \""
            << HexU64(p.containerHasParentOffset)
            << "\",\n"
            << "      \"containerClosedOffset\": \""
            << HexU64(p.containerClosedOffset)
            << "\",\n"
            << "      \"containerUnlockedOffset\": \""
            << HexU64(p.containerUnlockedOffset)
            << "\",\n"
            << "      \"containerPagesOffset\": \""
            << HexU64(p.containerPagesOffset)
            << "\",\n"
            << "      \"containerSizeOffset\": \""
            << HexU64(p.containerSizeOffset)
            << "\",\n"
            << "      \"containerFirstIndexOffset\": \""
            << HexU64(p.containerFirstIndexOffset)
            << "\",\n"
            << "      \"containerDequeMapOffset\": \""
            << HexU64(p.containerDequeMapOffset)
            << "\",\n"
            << "      \"containerDequeMapSizeOffset\": \""
            << HexU64(p.containerDequeMapSizeOffset)
            << "\",\n"
            << "      \"containerDequeOffsetOffset\": \""
            << HexU64(p.containerDequeOffsetOffset)
            << "\",\n"
            << "      \"containerItemCountOffset\": \""
            << HexU64(p.containerItemCountOffset)
            << "\",\n"
            << "      \"containerItemElementStride\": \""
            << HexU64(p.containerItemElementStride)
            << "\",\n"
            << "      \"containerItemStorageMode\": \""
            << EscapeJson(p.containerItemStorageMode)
            << "\",\n"
            << "      \"containersStatus\": \""
            << EscapeJson(p.containersStatus)
            << "\",\n"
            << "      \"fnGameAutoWalk\": \""
            << HexU64(p.fnGameAutoWalk)
            << "\",\n"
            << "      \"fnLocalPlayerAutoWalk\": \""
            << HexU64(p.fnLocalPlayerAutoWalk)
            << "\",\n"
            << "      \"fnGameAttack\": \""
            << HexU64(p.fnGameAttack)
            << "\",\n"
            << "      \"fnGameFollow\": \""
            << HexU64(p.fnGameFollow)
            << "\",\n"
            << "      \"fnGameLook\": \""
            << HexU64(p.fnGameLook)
            << "\",\n"
            << "      \"fnGameDetailedLook\": \""
            << HexU64(p.fnGameDetailedLook)
            << "\",\n"
            << "      \"fnGameMove\": \""
            << HexU64(p.fnGameMove)
            << "\",\n"
            << "      \"fnGameUse\": \""
            << HexU64(p.fnGameUse)
            << "\",\n"
            << "      \"fnGameUseWith\": \""
            << HexU64(p.fnGameUseWith)
            << "\",\n"
            << "      \"fnGameTalk\": \""
            << HexU64(p.fnGameTalk)
            << "\",\n"
            << "      \"fnMapGetTile\": \""
            << HexU64(p.fnMapGetTile)
            << "\",\n"
            << "      \"fnMapGetCreatureById\": \""
            << HexU64(p.fnMapGetCreatureById)
            << "\",\n"
            << "      \"fnMapGetCreatureByName\": \""
            << HexU64(p.fnMapGetCreatureByName)
            << "\",\n"
            << "      \"fnContainerGetItem\": \""
            << HexU64(p.fnContainerGetItem)
            << "\",\n"
            << "      \"localPlayerAutoWalkVtableSlot\": \""
            << HexU64(p.localPlayerAutoWalkVtableSlot)
            << "\",\n"
            << "      \"sigGameAutoWalk\": \""
            << EscapeJson(p.sigGameAutoWalk)
            << "\",\n"
            << "      \"sigLocalPlayerAutoWalk\": \""
            << EscapeJson(p.sigLocalPlayerAutoWalk)
            << "\",\n"
            << "      \"sigGameAttack\": \""
            << EscapeJson(p.sigGameAttack)
            << "\",\n"
            << "      \"sigGameFollow\": \""
            << EscapeJson(p.sigGameFollow)
            << "\",\n"
            << "      \"sigGameLook\": \""
            << EscapeJson(p.sigGameLook)
            << "\",\n"
            << "      \"sigGameDetailedLook\": \""
            << EscapeJson(p.sigGameDetailedLook)
            << "\",\n"
            << "      \"sigGameMove\": \""
            << EscapeJson(p.sigGameMove)
            << "\",\n"
            << "      \"sigGameUse\": \""
            << EscapeJson(p.sigGameUse)
            << "\",\n"
            << "      \"sigGameUseWith\": \""
            << EscapeJson(p.sigGameUseWith)
            << "\",\n"
            << "      \"sigGameTalk\": \""
            << EscapeJson(p.sigGameTalk)
            << "\",\n"
            << "      \"sigMapGetTile\": \""
            << EscapeJson(p.sigMapGetTile)
            << "\",\n"
            << "      \"sigMapGetCreatureById\": \""
            << EscapeJson(p.sigMapGetCreatureById)
            << "\",\n"
            << "      \"sigMapGetCreatureByName\": \""
            << EscapeJson(p.sigMapGetCreatureByName)
            << "\",\n"
            << "      \"sigContainerGetItem\": \""
            << EscapeJson(p.sigContainerGetItem)
            << "\",\n"
            << "      \"functionsStatus\": \""
            << EscapeJson(p.functionsStatus)
            << "\"\n"
            << "    }";

        if (i + 1 <
            profiles.size())
        {
            f << ",";
        }

        f << "\n";
    }

    f
        << "  ]\n"
        << "}\n";

    return true;
}

bool EnsureProfileDatabase(
    const std::string& path)
{
    std::ifstream existing(
        path,
        std::ios::binary
    );

    if (existing.good())
        return true;

    existing.close();

    std::vector<DbProfile> empty;

    return
        SaveProfileDatabase(
            path,
            empty
        );
}

int FindProfileIndex(
    const BuildInfo& build,
    const std::vector<DbProfile>& profiles)
{
    for (size_t i = 0;
         i < profiles.size();
         ++i)
    {
        const auto& p =
            profiles[i];

        if (p.timestamp !=
            build.timestamp)
        {
            continue;
        }

        if (p.sizeOfImage !=
            build.sizeOfImage)
        {
            continue;
        }

        if (p.textHash !=
            build.textHash)
        {
            continue;
        }

        return
            static_cast<int>(
                i
            );
    }

    return -1;
}

bool DbProfileMonitorReady(
    const DbProfile& p)
{
    bool hasPath =
        p.directGlobalRva != 0 ||
        (
            p.indirectGlobalRva != 0 &&
            p.ownerOffset != 0
        );

    return
        p.vtableRva != 0 &&
        hasPath &&
        p.x != 0 &&
        p.y != 0 &&
        p.z != 0;
}

uintptr_t OffsetOrZero(
    const FieldResult& field)
{
    return
        field.address
            ? field.offset
            : 0;
}

uintptr_t UIntOffsetOrZero(
    const UIntFieldResult& field)
{
    return
        field.address
            ? field.offset
            : 0;
}

DbProfile BuildDatabaseProfile(
    const BuildInfo& build,
    const BaseHypothesis& base,
    const ProfileFields& fields,
    const PositionCalibration& position,
    const PointerDiscovery& pointers)
{
    DbProfile p{};

    std::ostringstream name;

    name
        << "auto_"
        << std::hex
        << std::uppercase
        << build.timestamp
        << "_"
        << build.textHash;

    p.name =
        name.str();

    p.status =
        "player_discovered_runtime";

    p.gameStatus =
        "unknown";

    p.followStatus =
        "unknown";

    p.mapStatus =
        "unknown";

    p.tileRttiName =
        "unknown";

    p.thingStorageMode =
        "unknown";

    p.tileThingsStatus =
        "unknown";

    p.mapTileStorageMode =
        "unknown";

    p.mapTilePathStatus =
        "unknown";

    p.monsterVtableStatus =
        "unknown";

    p.itemVtableStatus =
        "unknown";

    p.playerVtableStatus =
        "unknown";

    p.classificationStatus =
        "unknown";

    p.npcStatus =
        "unknown";

    p.inventoryStorageMode =
        "unknown";

    p.inventoryStatus =
        "unknown";

    p.itemLayoutStatus =
        "unknown";

    p.containerItemStorageMode =
        "unknown";

    p.containersStatus =
        "unknown";

    p.functionsStatus =
        "unknown";

    p.timestamp =
        build.timestamp;

    p.sizeOfImage =
        build.sizeOfImage;

    p.textHash =
        build.textHash;

    if (InsideExeImage(
            base.vtable))
    {
        p.vtableRva =
            base.vtable -
            g_exeBase;
    }

    if (!pointers.direct.empty())
    {
        const PointerPathCandidate* bestDirect =
            &pointers.direct[0];

        for (const auto& c :
             pointers.direct)
        {
            if (c.status ==
                "strong_candidate")
            {
                bestDirect =
                    &c;

                break;
            }
        }

        p.directGlobalRva =
            bestDirect->globalRva;
    }

    if (!pointers.indirect.empty())
    {
        const auto& c =
            pointers.indirect[0];

        p.indirectGlobalRva =
            c.globalRva;

        p.ownerOffset =
            c.ownerOffset;
    }

    p.x =
        UIntOffsetOrZero(
            position.x
        );

    p.y =
        UIntOffsetOrZero(
            position.y
        );

    p.z =
        UIntOffsetOrZero(
            position.z
        );

    p.direction =
        UIntOffsetOrZero(
            position.direction
        );

    // Structural offsets were validated by the LocalPlayer shape.
    p.id =
        REF_OFF_ID;

    p.hpPercent =
        REF_OFF_HP_PERCENT;

    p.health =
        OffsetOrZero(
            fields.health
        );

    p.maxHealth =
        OffsetOrZero(
            fields.maxHealth
        );

    p.capacity =
        OffsetOrZero(
            fields.capacity
        );

    p.experience =
        OffsetOrZero(
            fields.experience
        );

    p.level =
        OffsetOrZero(
            fields.level
        );

    p.mana =
        OffsetOrZero(
            fields.mana
        );

    p.maxMana =
        OffsetOrZero(
            fields.maxMana
        );

    return p;
}

void PrintDbProfile(
    const DbProfile& p)
{
    std::cout
        << "\n============================================================\n"
        << "                     PROFILE READY\n"
        << "============================================================\n"
        << "Name                : "
        << p.name
        << "\n"
        << "Status              : "
        << p.status
        << "\n"
        << "VTable RVA          : "
        << HexU64(
            p.vtableRva
        )
        << "\n"
        << "Direct Global RVA   : "
        << HexU64(
            p.directGlobalRva
        )
        << "\n"
        << "Indirect Global RVA : "
        << HexU64(
            p.indirectGlobalRva
        )
        << "\n"
        << "Owner Offset        : "
        << HexU64(
            p.ownerOffset
        )
        << "\n"
        << "X/Y/Z               : "
        << HexU64(
            p.x
        )
        << " / "
        << HexU64(
            p.y
        )
        << " / "
        << HexU64(
            p.z
        )
        << "\n"
        << "Direction           : "
        << HexU64(
            p.direction
        )
        << "\n"
        << "Game RVA            : "
        << HexU64(
            p.gameRva
        )
        << "\n"
        << "Game.LocalPlayer    : +"
        << HexU64(
            p.gameLocalPlayer
        )
        << "\n"
        << "Game.AttackTarget   : +"
        << HexU64(
            p.gameAttackTarget
        )
        << "\n"
        << "Game status         : "
        << p.gameStatus
        << "\n"
        << "Game.FollowTarget   : +"
        << HexU64(
            p.gameFollowTarget
        )
        << "\n"
        << "Follow status       : "
        << p.followStatus
        << "\n"
        << "Map RVA             : "
        << HexU64(
            p.mapRva
        )
        << "\n"
        << "Map Center X/Y/Z    : "
        << HexU64(
            p.mapCenterX
        )
        << " / "
        << HexU64(
            p.mapCenterY
        )
        << " / "
        << HexU64(
            p.mapCenterZ
        )
        << "\n"
        << "Map Aware N/E/S/W   : "
        << HexU64(
            p.mapNorth
        )
        << " / "
        << HexU64(
            p.mapEast
        )
        << " / "
        << HexU64(
            p.mapSouth
        )
        << " / "
        << HexU64(
            p.mapWest
        )
        << "\n"
        << "Map status          : "
        << p.mapStatus
        << "\n"
        << "Tile::things B/E/C  : "
        << HexU64(
            p.tileThingsBegin
        )
        << " / "
        << HexU64(
            p.tileThingsEnd
        )
        << " / "
        << HexU64(
            p.tileThingsCap
        )
        << "\n"
        << "Tile VTable RVA     : "
        << HexU64(
            p.tileVtableRva
        )
        << "\n"
        << "Tile RTTI           : "
        << p.tileRttiName
        << "\n"
        << "Thing storage mode  : "
        << p.thingStorageMode
        << "\n"
        << "Thing storage stride: "
        << HexU64(
            p.thingStorageStride
        )
        << "\n"
        << "Tile::things status : "
        << p.tileThingsStatus
        << "\n"
        << "Map->Tile depth     : "
        << HexU64(
            p.mapTilePathDepth
        )
        << "\n"
        << "Map->Tile mapOff    : "
        << HexU64(
            p.mapTilePathMapOffset
        )
        << "\n"
        << "Map->Tile childOff  : "
        << HexU64(
            p.mapTilePathChildOffset
        )
        << "\n"
        << "Map->Tile headerOff : "
        << HexU64(
            p.mapTilePathHeaderOffset
        )
        << "\n"
        << "Map->Tile mode      : "
        << p.mapTileStorageMode
        << "\n"
        << "Map->Tile stride    : "
        << HexU64(
            p.mapTileStorageStride
        )
        << "\n"
        << "Map->Tile status    : "
        << p.mapTilePathStatus
        << "\n"
        << "Monster VTable RVA  : "
        << HexU64(
            p.monsterVtableRva
        )
        << "\n"
        << "Monster status      : "
        << p.monsterVtableStatus
        << "\n"
        << "Item VTable RVA     : "
        << HexU64(
            p.itemVtableRva
        )
        << "\n"
        << "Item status         : "
        << p.itemVtableStatus
        << "\n"
        << "Player VTable RVA   : "
        << HexU64(
            p.playerVtableRva
        )
        << "\n"
        << "Player status       : "
        << p.playerVtableStatus
        << "\n"
        << "isItem slot         : +"
        << HexU64(
            p.slotIsItem
        )
        << "\n"
        << "isCreature slot     : +"
        << HexU64(
            p.slotIsCreature
        )
        << "\n"
        << "isMonster slot      : +"
        << HexU64(
            p.slotIsMonster
        )
        << "\n"
        << "isPlayer slot       : +"
        << HexU64(
            p.slotIsPlayer
        )
        << "\n"
        << "isLocalPlayer slot  : +"
        << HexU64(
            p.slotIsLocalPlayer
        )
        << "\n"
        << "Classification      : "
        << p.classificationStatus
        << "\n"
        << "NPC VTable RVA      : "
        << HexU64(p.npcVtableRva)
        << "\n"
        << "isNPC slot          : +"
        << HexU64(p.slotIsNpc)
        << "\n"
        << "NPC status          : "
        << p.npcStatus
        << "\n"
        << "Inventory base      : +"
        << HexU64(p.inventoryBaseOffset)
        << "\n"
        << "Inventory mode      : "
        << p.inventoryStorageMode
        << "\n"
        << "Inventory stride    : "
        << HexU64(p.inventorySlotStride)
        << "\n"
        << "Inventory status    : "
        << p.inventoryStatus
        << "\n"
        << "Item ID/Count       : +"
        << HexU64(p.itemIdOffset)
        << " / +"
        << HexU64(p.itemCountOffset)
        << "\n"
        << "Item Count width    : "
        << p.itemCountWidth
        << "\n"
        << "Item layout status  : "
        << p.itemLayoutStatus
        << "\n"
        << "Game.Containers     : +"
        << HexU64(p.gameContainersOffset)
        << "\n"
        << "Container item mode : "
        << p.containerItemStorageMode
        << "\n"
        << "Container item stride: "
        << HexU64(p.containerItemElementStride)
        << "\n"
        << "Containers status   : "
        << p.containersStatus
        << "\n"
        << "Functions status    : "
        << p.functionsStatus
        << "\n";
}


// ============================================================
// FORWARD DECLARATIONS USED BY GAME DISCOVERY
// Implementations remain in the runtime-monitor section below.
// ============================================================

bool IsReadableMonitorRange(
    uintptr_t address,
    size_t size);

bool ValidateMonitorLocalPlayer(
    uintptr_t localPlayer,
    const DbProfile& p,
    MonitorSample* out);


// ============================================================
// DISCOVERY V2 - GAME / ATTACK TARGET
// ============================================================

struct GameLpReference
{
    uintptr_t address = 0;
    uintptr_t rva = 0;
    std::string section;
    bool writable = false;
};

struct GameAttackCandidate
{
    uintptr_t localPlayerField = 0;
    uintptr_t gameRva = 0;
    uintptr_t attackOffset = 0;
    uintptr_t targetPointer = 0;

    std::string section;

    int score = 0;

    uint32_t targetX = 0;
    uint32_t targetY = 0;
    uint8_t targetZ = 0;
    uint32_t targetId = 0;
    uint8_t targetHp = 0;
};

bool ValidateDiscoveredCreature(
    uintptr_t creature,
    const DbProfile& p,
    GameAttackCandidate* details = nullptr)
{
    if (!creature)
        return false;

    if (!IsReadableMonitorRange(
            creature,
            0x100))
    {
        return false;
    }

    uintptr_t vtable =
        ReadPtr(
            creature
        );

    if (!InsideExeImage(
            vtable))
    {
        return false;
    }

    uint32_t x =
        ReadU32(
            creature +
            p.x
        );

    uint32_t y =
        ReadU32(
            creature +
            p.y
        );

    uint8_t z =
        ReadU8(
            creature +
            p.z
        );

    if (!PositionPlausible(
            x,
            y,
            z))
    {
        return false;
    }

    uint32_t id = 0;

    if (p.id)
    {
        id =
            ReadU32(
                creature +
                p.id
            );

        if (!id ||
            id == 0xFFFFFFFFu)
        {
            return false;
        }
    }

    uint8_t hp = 0;

    if (p.hpPercent)
    {
        hp =
            ReadU8(
                creature +
                p.hpPercent
            );

        if (hp > 100)
            return false;
    }

    if (p.direction)
    {
        uint32_t direction =
            ReadU32(
                creature +
                p.direction
            );

        if (direction > 7)
            return false;
    }

    if (details)
    {
        details->targetX = x;
        details->targetY = y;
        details->targetZ = z;
        details->targetId = id;
        details->targetHp = hp;
    }

    return true;
}

uintptr_t ResolveProfileLocalPlayerForDiscovery(
    const DbProfile& p)
{
    uintptr_t direct = 0;
    uintptr_t indirect = 0;

    if (p.directGlobalRva)
    {
        direct =
            ReadPtr(
                g_exeBase +
                p.directGlobalRva
            );

        if (!ValidateMonitorLocalPlayer(
                direct,
                p,
                nullptr))
        {
            direct = 0;
        }
    }

    if (p.indirectGlobalRva &&
        p.ownerOffset)
    {
        uintptr_t owner =
            ReadPtr(
                g_exeBase +
                p.indirectGlobalRva
            );

        if (owner)
        {
            indirect =
                ReadPtr(
                    owner +
                    p.ownerOffset
                );

            if (!ValidateMonitorLocalPlayer(
                    indirect,
                    p,
                    nullptr))
            {
                indirect = 0;
            }
        }
    }

    if (direct &&
        indirect &&
        direct != indirect)
    {
        return 0;
    }

    return
        direct
            ? direct
            : indirect;
}

std::vector<GameLpReference>
FindModuleReferencesToLocalPlayer(
    uintptr_t localPlayer)
{
    std::vector<GameLpReference> refs;

    if (!localPlayer)
        return refs;

    auto sections =
        GetModuleSections();

    for (const auto& section :
         sections)
    {
        if (!section.readable() ||
            section.executable())
        {
            continue;
        }

        uintptr_t begin =
            (section.begin + 7) &
            ~static_cast<uintptr_t>(7);

        uintptr_t end =
            section.end;

        if (end <= begin ||
            end - begin < 8)
        {
            continue;
        }

        for (uintptr_t p = begin;
             p + 8 <= end;
             p += 8)
        {
            uintptr_t value = 0;

            std::memcpy(
                &value,
                reinterpret_cast<const void*>(
                    p
                ),
                sizeof(value)
            );

            if (value != localPlayer)
                continue;

            GameLpReference ref{};

            ref.address = p;
            ref.rva =
                p -
                g_exeBase;
            ref.section =
                section.name;
            ref.writable =
                section.writable();

            refs.push_back(
                std::move(ref)
            );
        }
    }

    return refs;
}

struct GameCapture
{
    GameLpReference ref;
    std::vector<intptr_t> offsets;
    std::vector<uintptr_t> values;
};

std::vector<GameCapture>
CaptureGameNeighborhoods(
    const std::vector<GameLpReference>& refs,
    intptr_t minOffset = -0x40,
    intptr_t maxOffset = 0x100)
{
    std::vector<GameCapture> captures;

    for (const auto& ref :
         refs)
    {
        GameCapture capture{};
        capture.ref = ref;

        for (intptr_t off = minOffset;
             off <= maxOffset;
             off += 8)
        {
            uintptr_t address =
                static_cast<uintptr_t>(
                    static_cast<intptr_t>(
                        ref.address
                    ) +
                    off
                );

            uintptr_t value = 0;

            if (!SafeRead(
                    address,
                    value))
            {
                continue;
            }

            capture.offsets.push_back(
                off
            );

            capture.values.push_back(
                value
            );
        }

        captures.push_back(
            std::move(capture)
        );
    }

    return captures;
}

bool LookupCapturedValue(
    const GameCapture& capture,
    intptr_t offset,
    uintptr_t& value)
{
    for (size_t i = 0;
         i < capture.offsets.size();
         ++i)
    {
        if (capture.offsets[i] ==
            offset)
        {
            value =
                capture.values[i];

            return true;
        }
    }

    return false;
}

const GameCapture*
FindCaptureByRef(
    const std::vector<GameCapture>& captures,
    uintptr_t refAddress)
{
    for (const auto& c :
         captures)
    {
        if (c.ref.address ==
            refAddress)
        {
            return &c;
        }
    }

    return nullptr;
}

std::vector<GameAttackCandidate>
BuildGameAttackCandidates(
    const DbProfile& p,
    uintptr_t localPlayer,
    const std::vector<GameCapture>& noTargetA,
    const std::vector<GameCapture>& targetB,
    const std::vector<GameCapture>& noTargetC)
{
    std::vector<GameAttackCandidate> out;

    PositionPlausible(
        ReadU32(localPlayer + p.x),
        ReadU32(localPlayer + p.y),
        ReadU8(localPlayer + p.z)
    );

    uint8_t playerZ =
        ReadU8(
            localPlayer +
            p.z
        );

    for (const auto& before :
         noTargetA)
    {
        const GameCapture* during =
            FindCaptureByRef(
                targetB,
                before.ref.address
            );

        const GameCapture* after =
            FindCaptureByRef(
                noTargetC,
                before.ref.address
            );

        if (!during ||
            !after)
        {
            continue;
        }

        // The LocalPlayer reference itself must remain stable in all captures.
        uintptr_t lpA = 0;
        uintptr_t lpB = 0;
        uintptr_t lpC = 0;

        if (!LookupCapturedValue(
                before,
                0,
                lpA) ||
            !LookupCapturedValue(
                *during,
                0,
                lpB) ||
            !LookupCapturedValue(
                *after,
                0,
                lpC))
        {
            continue;
        }

        if (lpA != localPlayer ||
            lpB != localPlayer ||
            lpC != localPlayer)
        {
            continue;
        }

        for (intptr_t off = -0x40;
             off <= 0x100;
             off += 8)
        {
            if (off == 0)
                continue;

            uintptr_t a = 0;
            uintptr_t b = 0;
            uintptr_t c = 0;

            if (!LookupCapturedValue(
                    before,
                    off,
                    a) ||
                !LookupCapturedValue(
                    *during,
                    off,
                    b) ||
                !LookupCapturedValue(
                    *after,
                    off,
                    c))
            {
                continue;
            }

            // Strong behavioral signature:
            // no target -> Creature* -> no target
            if (a != 0 ||
                b == 0 ||
                c != 0 ||
                b == localPlayer)
            {
                continue;
            }

            GameAttackCandidate candidate{};

            if (!ValidateDiscoveredCreature(
                    b,
                    p,
                    &candidate))
            {
                continue;
            }

            candidate.localPlayerField =
                before.ref.address;

            candidate.gameRva =
                before.ref.rva;

            candidate.attackOffset =
                static_cast<uintptr_t>(
                    off >= 0
                        ? off
                        : 0
                );

            candidate.targetPointer =
                b;

            candidate.section =
                before.ref.section;

            int score = 100;

            if (before.ref.writable)
                score += 40;

            if (off > 0 &&
                off <= 0x40)
            {
                score += 50;
            }
            else if (off > 0 &&
                     off <= 0x100)
            {
                score += 20;
            }
            else
            {
                score -= 20;
            }

            if (candidate.targetZ ==
                playerZ)
            {
                score += 15;
            }

            if (candidate.targetHp > 0 &&
                candidate.targetHp <= 100)
            {
                score += 10;
            }

            candidate.score =
                score;

            out.push_back(
                std::move(candidate)
            );
        }
    }

    std::sort(
        out.begin(),
        out.end(),
        [](
            const GameAttackCandidate& a,
            const GameAttackCandidate& b)
        {
            if (a.score != b.score)
                return a.score > b.score;

            if (a.gameRva != b.gameRva)
                return a.gameRva < b.gameRva;

            return
                a.attackOffset <
                b.attackOffset;
        }
    );

    return out;
}

void PrintGameAttackCandidates(
    const std::vector<GameAttackCandidate>& candidates)
{
    std::cout
        << "\n============================================================\n"
        << "                 GAME DISCOVERY CANDIDATES\n"
        << "============================================================\n";

    if (candidates.empty())
    {
        std::cout
            << "Nenhum candidato passou a assinatura 0 -> Creature* -> 0.\n";

        return;
    }

    size_t limit =
        std::min<size_t>(
            candidates.size(),
            20
        );

    for (size_t i = 0;
         i < limit;
         ++i)
    {
        const auto& c =
            candidates[i];

        std::cout
            << "#"
            << i
            << " score="
            << c.score
            << " section="
            << c.section
            << " gameAnchorRva="
            << HexU64(
                c.gameRva
            )
            << " localPlayer=+0x0"
            << " attackTarget=+"
            << HexU64(
                c.attackOffset
            )
            << " target="
            << HexPtr(
                c.targetPointer
            )
            << " id="
            << c.targetId
            << " pos="
            << c.targetX
            << ","
            << c.targetY
            << ","
            << static_cast<unsigned>(
                c.targetZ
            )
            << " hp="
            << static_cast<unsigned>(
                c.targetHp
            )
            << "%\n";
    }
}

bool DiscoverGameAndAttackTarget(
    DbProfile& profile)
{
    std::cout
        << "\n============================================================\n"
        << "              STAGE 2 - GAME DISCOVERY\n"
        << "============================================================\n"
        << "[MODE] READ-ONLY\n"
        << "[NO HOOK] Nenhum hook\n"
        << "[NO CALL] Nenhuma funcao interna do jogo\n"
        << "\n"
        << "Objetivo:\n"
        << "  1. encontrar referencias estaveis ao LocalPlayer no modulo\n"
        << "  2. observar campos vizinhos\n"
        << "  3. detectar AttackTarget por 0 -> Creature* -> 0\n";

    uintptr_t localPlayer =
        ResolveProfileLocalPlayerForDiscovery(
            profile
        );

    if (!localPlayer)
    {
        std::cout
            << "[STOP] LocalPlayer do profile nao esta valido agora.\n";

        return false;
    }

    std::cout
        << "LocalPlayer          : "
        << HexPtr(
            localPlayer
        )
        << "\n";

    auto refs =
        FindModuleReferencesToLocalPlayer(
            localPlayer
        );

    std::cout
        << "Referencias diretas  : "
        << refs.size()
        << "\n";

    if (refs.empty())
    {
        std::cout
            << "[STOP] Nenhuma referencia direta ao LocalPlayer em secoes de dados.\n";

        return false;
    }

    size_t shown =
        std::min<size_t>(
            refs.size(),
            24
        );

    for (size_t i = 0;
         i < shown;
         ++i)
    {
        std::cout
            << "  ref["
            << i
            << "] RVA "
            << HexU64(
                refs[i].rva
            )
            << " section="
            << refs[i].section
            << (
                refs[i].writable
                    ? " writable"
                    : ""
            )
            << "\n";
    }

    std::cout
        << "\nPASSO A - SEM ALVO\n"
        << "Pressione ESC no jogo e confirme que nao existe monstro selecionado.\n";

    WaitEnter(
        "Quando estiver SEM TARGET, pressione ENTER..."
    );

    auto noTargetA =
        CaptureGameNeighborhoods(
            refs
        );

    std::cout
        << "\nPASSO B - COM ALVO\n"
        << "Selecione/ataque UM MONSTRO visivel e mantenha-o como target.\n";

    WaitEnter(
        "Quando o MONSTRO estiver selecionado, pressione ENTER..."
    );

    auto targetB =
        CaptureGameNeighborhoods(
            refs
        );

    std::cout
        << "\nPASSO C - LIMPAR ALVO\n"
        << "Cancele o target com ESC e espere o alvo desaparecer.\n";

    WaitEnter(
        "Quando estiver novamente SEM TARGET, pressione ENTER..."
    );

    auto noTargetC =
        CaptureGameNeighborhoods(
            refs
        );

    auto candidates =
        BuildGameAttackCandidates(
            profile,
            localPlayer,
            noTargetA,
            targetB,
            noTargetC
        );

    PrintGameAttackCandidates(
        candidates
    );

    if (candidates.empty())
    {
        profile.gameStatus =
            "unresolved";

        std::cout
            << "\n[RESULT] GAME/ATTACKTARGET ainda nao resolvido.\n"
            << "Nenhum RVA sera inventado.\n";

        return false;
    }

    const GameAttackCandidate* best =
        &candidates[0];

    bool uniqueStrong =
        candidates.size() == 1 ||
        (
            candidates[0].score >=
                candidates[1].score + 25
        );

    // If ambiguous, use a second monster as an extra discriminator.
    if (!uniqueStrong)
    {
        std::cout
            << "\n[AMBIGUOUS] Ha mais de um candidato forte.\n"
            << "Vamos usar um SEGUNDO monstro para desempatar.\n";

        WaitEnter(
            "Selecione OUTRO monstro diferente e pressione ENTER..."
        );

        auto targetD =
            CaptureGameNeighborhoods(
                refs
            );

        std::vector<GameAttackCandidate> refined;

        for (const auto& candidate :
             candidates)
        {
            const GameCapture* d =
                FindCaptureByRef(
                    targetD,
                    candidate.localPlayerField
                );

            if (!d)
                continue;

            uintptr_t value = 0;

            if (!LookupCapturedValue(
                    *d,
                    static_cast<intptr_t>(
                        candidate.attackOffset
                    ),
                    value))
            {
                continue;
            }

            if (!value ||
                value ==
                    candidate.targetPointer)
            {
                continue;
            }

            GameAttackCandidate copy =
                candidate;

            if (!ValidateDiscoveredCreature(
                    value,
                    profile,
                    &copy))
            {
                continue;
            }

            copy.targetPointer =
                value;

            copy.score += 80;

            refined.push_back(
                std::move(copy)
            );
        }

        if (!refined.empty())
        {
            std::sort(
                refined.begin(),
                refined.end(),
                [](
                    const GameAttackCandidate& a,
                    const GameAttackCandidate& b)
                {
                    return
                        a.score >
                        b.score;
                }
            );

            candidates =
                std::move(
                    refined
                );

            PrintGameAttackCandidates(
                candidates
            );

            best =
                &candidates[0];

            uniqueStrong =
                candidates.size() == 1 ||
                (
                    candidates[0].score >=
                        candidates[1].score + 25
                );
        }
    }

    if (!uniqueStrong)
    {
        profile.gameStatus =
            "strong_candidate_ambiguous";

        std::cout
            << "\n[RESULT] Candidatos fortes permaneceram ambiguos.\n"
            << "Nada sera promovido automaticamente.\n";

        return false;
    }

    profile.gameRva =
        best->gameRva;

    // At this stage the LocalPlayer field itself is our Game anchor.
    // Follow/Containers stages will later corroborate whether this is the
    // true Game object base across the client family.
    profile.gameLocalPlayer =
        0;

    profile.gameAttackTarget =
        best->attackOffset;

    profile.gameStatus =
        "confirmed_runtime_attack_cycle";

    std::cout
        << "\n============================================================\n"
        << "                    GAME DISCOVERED\n"
        << "============================================================\n"
        << "Game anchor RVA      : "
        << HexU64(
            profile.gameRva
        )
        << "\n"
        << "LocalPlayer offset   : +"
        << HexU64(
            profile.gameLocalPlayer
        )
        << "\n"
        << "AttackTarget offset  : +"
        << HexU64(
            profile.gameAttackTarget
        )
        << "\n"
        << "Evidence             : 0 -> Creature* -> 0\n"
        << "Status               : "
        << profile.gameStatus
        << "\n";

    return true;
}

uintptr_t WaitForDiscoveryLocalPlayer(
    const DbProfile& profile,
    const char* stageName)
{
    std::cout
        << "\n============================================================\n"
        << "                 WAIT LOGIN FOR DISCOVERY\n"
        << "============================================================\n"
        << "Stage                 : "
        << (stageName ? stageName : "UNKNOWN")
        << "\n"
        << "Aguardando LocalPlayer valido usando o Player Discovery ja salvo.\n"
        << "Pode injetar deslogado e fazer login normalmente.\n"
        << "Somente os dados ja descobertos do Player sao usados nesta espera.\n";

    uintptr_t lastShown = 0;

    while (true)
    {
        if (GetAsyncKeyState(VK_END) & 0x8000)
            return 0;

        uintptr_t localPlayer =
            ResolveProfileLocalPlayerForDiscovery(
                profile
            );

        if (localPlayer)
        {
            std::cout
                << "[LOGIN READY] LocalPlayer = "
                << HexPtr(
                    localPlayer
                )
                << "\n";

            return localPlayer;
        }

        uintptr_t directRaw = 0;

        if (profile.directGlobalRva)
        {
            directRaw =
                ReadPtr(
                    g_exeBase +
                    profile.directGlobalRva
                );
        }

        if (directRaw != lastShown)
        {
            lastShown =
                directRaw;

            if (directRaw)
            {
                std::cout
                    << "[WAIT] Direct raw mudou para "
                    << HexPtr(
                        directRaw
                    )
                    << " mas ainda nao validou como LocalPlayer.\n";
            }
        }

        Sleep(250);
    }
}


bool EnsureGameDiscovery(
    DbProfile& profile,
    std::vector<DbProfile>& database,
    int profileIndex,
    const std::string& databasePath)
{
    if (profile.gameRva &&
        profile.gameAttackTarget &&
        (
            profile.gameStatus ==
                "discovered_runtime_selfcheck_pass" ||
            profile.gameStatus ==
                "discovered_runtime_new_build" ||
            profile.gameStatus ==
                "confirmed_runtime_attack_cycle"
        ))
    {
        std::cout
            << "\n[FEITO] STAGE 2 - Game + AttackTarget ja passaram self-check.\n"
            << "Game RVA       : "
            << HexU64(profile.gameRva)
            << "\nAttackTarget   : +"
            << HexU64(profile.gameAttackTarget)
            << "\n";

        return true;
    }

    // Discovery V2.0.2 benchmark rule:
    // even if an older profile already contains Game/AttackTarget,
    // DO NOT use those values to skip Stage 2. Keep them only as
    // post-discovery ground truth for comparison.
    const uintptr_t knownGameRva =
        profile.gameRva;

    const uintptr_t knownGameLocalPlayer =
        profile.gameLocalPlayer;

    const uintptr_t knownGameAttackTarget =
        profile.gameAttackTarget;

    const std::string knownGameStatus =
        profile.gameStatus;

    const bool hadKnownGame =
        knownGameRva != 0;

    // Stage 2 depends on a live LocalPlayer. In V2.0.2 this function
    // was called while the client was still logged out, so discovery
    // aborted before doing any work. Wait here first.
    uintptr_t liveLocalPlayer =
        WaitForDiscoveryLocalPlayer(
            profile,
            "STAGE 2 - GAME / ATTACKTARGET"
        );

    if (!liveLocalPlayer)
    {
        std::cout
            << "\n[STAGE 2] Cancelada antes do login.\n";

        return false;
    }

    if (hadKnownGame)
    {
        std::cout
            << "\n============================================================\n"
            << "              STAGE 2 - BENCHMARK MODE\n"
            << "============================================================\n"
            << "O profile antigo JA possui Game/AttackTarget.\n"
            << "Esses valores NAO serao usados pelo algoritmo de descoberta.\n"
            << "Eles ficam guardados apenas para comparar DEPOIS.\n";
    }

    // Hide old Game answers from the discovery result state.
    // Player discovery fields remain available and are the only anchors.
    profile.gameRva = 0;
    profile.gameLocalPlayer = 0;
    profile.gameAttackTarget = 0;
    profile.gameStatus = "rediscovery_running";

    bool ok =
        DiscoverGameAndAttackTarget(
            profile
        );

    if (ok)
    {
        std::cout
            << "\n============================================================\n"
            << "                 STAGE 2 SELF-CHECK\n"
            << "============================================================\n"
            << "Discovered Game RVA  : "
            << HexU64(
                profile.gameRva
            )
            << "\n"
            << "Discovered LP offset : +"
            << HexU64(
                profile.gameLocalPlayer
            )
            << "\n"
            << "Discovered Attack    : +"
            << HexU64(
                profile.gameAttackTarget
            )
            << "\n";

        if (hadKnownGame)
        {
            const bool gameMatch =
                profile.gameRva ==
                knownGameRva;

            const bool lpMatch =
                profile.gameLocalPlayer ==
                knownGameLocalPlayer;

            const bool attackMatch =
                profile.gameAttackTarget ==
                knownGameAttackTarget;

            std::cout
                << "\n[GROUND TRUTH COMPARISON]\n"
                << "Known Game RVA       : "
                << HexU64(
                    knownGameRva
                )
                << "\n"
                << "Known LP offset      : +"
                << HexU64(
                    knownGameLocalPlayer
                )
                << "\n"
                << "Known Attack offset  : +"
                << HexU64(
                    knownGameAttackTarget
                )
                << "\n"
                << "Game match           : "
                << (
                    gameMatch
                        ? "PASS"
                        : "FAIL"
                )
                << "\n"
                << "LocalPlayer match    : "
                << (
                    lpMatch
                        ? "PASS"
                        : "FAIL"
                )
                << "\n"
                << "AttackTarget match   : "
                << (
                    attackMatch
                        ? "PASS"
                        : "FAIL"
                )
                << "\n";

            if (gameMatch &&
                lpMatch &&
                attackMatch)
            {
                profile.gameStatus =
                    "discovered_runtime_selfcheck_pass";

                std::cout
                    << "\n[FEITO] STAGE 2 redescobriu o Game sem usar a resposta antiga.\n";
            }
            else
            {
                profile.gameStatus =
                    "discovered_runtime_selfcheck_mismatch";

                std::cout
                    << "\n[CHECK] Discovery encontrou resultado diferente do profile antigo.\n";
            }
        }
        else
        {
            profile.gameStatus =
                "discovered_runtime_new_build";
        }
    }
    else
    {
        std::cout
            << "\n[STAGE 2] Rediscovery nao fechou com seguranca.\n";

        if (hadKnownGame)
        {
            // Do not destroy previously known profile data just because
            // a benchmark run was inconclusive.
            profile.gameRva =
                knownGameRva;

            profile.gameLocalPlayer =
                knownGameLocalPlayer;

            profile.gameAttackTarget =
                knownGameAttackTarget;

            profile.gameStatus =
                knownGameStatus;

            std::cout
                << "[PRESERVE] Valores antigos de Game foram restaurados.\n";
        }
        else
        {
            profile.gameStatus =
                "unresolved";
        }
    }

    if (profileIndex >= 0 &&
        profileIndex <
            static_cast<int>(
                database.size()
            ))
    {
        database[
            static_cast<size_t>(
                profileIndex
            )
        ] = profile;

        SaveProfileDatabase(
            databasePath,
            database
        );
    }

    return ok;
}


// ============================================================
// DISCOVERY V2.1 - FOLLOW TARGET
// ============================================================

struct FollowCapture
{
    std::vector<intptr_t> offsets;
    std::vector<uintptr_t> values;
};

struct FollowCandidate
{
    uintptr_t offset = 0;
    uintptr_t pointer = 0;
    int score = 0;

    uint32_t x = 0;
    uint32_t y = 0;
    uint8_t z = 0;
    uint32_t id = 0;
    uint8_t hp = 0;
};

FollowCapture CaptureGameObjectWindow(
    uintptr_t gameAddress,
    intptr_t minOffset = 0,
    intptr_t maxOffset = 0x100)
{
    FollowCapture capture{};

    for (intptr_t off = minOffset;
         off <= maxOffset;
         off += 8)
    {
        uintptr_t value = 0;

        if (!SafeRead(
                gameAddress +
                    static_cast<uintptr_t>(off),
                value))
        {
            continue;
        }

        capture.offsets.push_back(
            off
        );

        capture.values.push_back(
            value
        );
    }

    return capture;
}

bool LookupFollowValue(
    const FollowCapture& capture,
    intptr_t offset,
    uintptr_t& value)
{
    for (size_t i = 0;
         i < capture.offsets.size();
         ++i)
    {
        if (capture.offsets[i] ==
            offset)
        {
            value =
                capture.values[i];

            return true;
        }
    }

    return false;
}

std::vector<FollowCandidate>
BuildFollowCandidates(
    const DbProfile& profile,
    uintptr_t localPlayer,
    const FollowCapture& noFollowA,
    const FollowCapture& followB,
    const FollowCapture& noFollowC)
{
    std::vector<FollowCandidate> out;

    uint8_t playerZ =
        ReadU8(
            localPlayer +
            profile.z
        );

    for (intptr_t off = 0;
         off <= 0x100;
         off += 8)
    {
        if (static_cast<uintptr_t>(off) ==
                profile.gameLocalPlayer ||
            static_cast<uintptr_t>(off) ==
                profile.gameAttackTarget)
        {
            continue;
        }

        uintptr_t a = 0;
        uintptr_t b = 0;
        uintptr_t c = 0;

        if (!LookupFollowValue(
                noFollowA,
                off,
                a) ||
            !LookupFollowValue(
                followB,
                off,
                b) ||
            !LookupFollowValue(
                noFollowC,
                off,
                c))
        {
            continue;
        }

        if (a != 0 ||
            b == 0 ||
            c != 0 ||
            b == localPlayer)
        {
            continue;
        }

        GameAttackCandidate details{};

        if (!ValidateDiscoveredCreature(
                b,
                profile,
                &details))
        {
            continue;
        }

        FollowCandidate candidate{};

        candidate.offset =
            static_cast<uintptr_t>(
                off
            );

        candidate.pointer = b;
        candidate.x = details.targetX;
        candidate.y = details.targetY;
        candidate.z = details.targetZ;
        candidate.id = details.targetId;
        candidate.hp = details.targetHp;

        int score = 100;

        if (off > 0 &&
            off <= 0x40)
        {
            score += 60;
        }
        else if (off <= 0x80)
        {
            score += 30;
        }

        if (candidate.z ==
            playerZ)
        {
            score += 15;
        }

        if (candidate.hp <= 100)
            score += 10;

        candidate.score =
            score;

        out.push_back(
            std::move(candidate)
        );
    }

    std::sort(
        out.begin(),
        out.end(),
        [](
            const FollowCandidate& a,
            const FollowCandidate& b)
        {
            if (a.score != b.score)
                return a.score > b.score;

            return a.offset < b.offset;
        }
    );

    return out;
}

void PrintFollowCandidates(
    const std::vector<FollowCandidate>& candidates)
{
    std::cout
        << "\n============================================================\n"
        << "               FOLLOW DISCOVERY CANDIDATES\n"
        << "============================================================\n";

    if (candidates.empty())
    {
        std::cout
            << "Nenhum campo passou a assinatura 0 -> Creature* -> 0.\n";

        return;
    }

    for (size_t i = 0;
         i < candidates.size() &&
         i < 16;
         ++i)
    {
        const auto& c =
            candidates[i];

        std::cout
            << "#"
            << i
            << " score="
            << c.score
            << " offset=+"
            << HexU64(
                c.offset
            )
            << " target="
            << HexPtr(
                c.pointer
            )
            << " id="
            << c.id
            << " pos="
            << c.x
            << ","
            << c.y
            << ","
            << static_cast<unsigned>(
                c.z
            )
            << " hp="
            << static_cast<unsigned>(
                c.hp
            )
            << "%\n";
    }
}

bool DiscoverFollowTarget(
    DbProfile& profile)
{
    std::cout
        << "\n============================================================\n"
        << "            STAGE 3 - FOLLOWTARGET DISCOVERY\n"
        << "============================================================\n"
        << "[MODE] READ-ONLY\n"
        << "[NO HOOK] Nenhum hook\n"
        << "[NO CALL] Nenhuma funcao interna do jogo\n"
        << "\n"
        << "Objetivo:\n"
        << "  detectar um campo Game que faca 0 -> Creature* -> 0\n"
        << "  enquanto AttackTarget permanece zerado.\n";

    uintptr_t localPlayer =
        ResolveProfileLocalPlayerForDiscovery(
            profile
        );

    if (!localPlayer)
    {
        std::cout
            << "[STOP] LocalPlayer invalido para Stage 3.\n";

        return false;
    }

    if (!profile.gameRva)
    {
        std::cout
            << "[STOP] Game ainda nao foi descoberto.\n";

        return false;
    }

    uintptr_t gameAddress =
        g_exeBase +
        profile.gameRva;

    std::cout
        << "Game address         : "
        << HexPtr(
            gameAddress
        )
        << "\n"
        << "AttackTarget offset  : +"
        << HexU64(
            profile.gameAttackTarget
        )
        << "\n";

    // ========================================================
    // CLEAN BASELINE
    // ========================================================

    FollowCapture a{};

    while (true)
    {
        std::cout
            << "\nPASSO A - SEM ATTACK / SEM FOLLOW\n"
            << "Cancele qualquer ataque e qualquer follow no cliente.\n";

        WaitEnter(
            "Quando NAO houver attack nem follow, pressione ENTER..."
        );

        a =
            CaptureGameObjectWindow(
                gameAddress
            );

        uintptr_t attackA = 0;

        LookupFollowValue(
            a,
            static_cast<intptr_t>(
                profile.gameAttackTarget
            ),
            attackA
        );

        if (!attackA)
            break;

        std::cout
            << "\n[RETRY] Ainda existe ATTACK ativo: "
            << HexPtr(
                attackA
            )
            << "\n"
            << "Cancele o ataque e repita o PASSO A.\n";
    }

    // ========================================================
    // FOLLOW RISING EDGE
    // ========================================================

    FollowCapture b{};

    while (true)
    {
        std::cout
            << "\nPASSO B - FOLLOW MANUAL\n"
            << "IMPORTANTE: NAO clique para atacar.\n"
            << "Use a opcao FOLLOW do proprio cliente na criatura.\n"
            << "Se houver menu de contexto, escolha Follow e NAO Attack.\n";

        WaitEnter(
            "Quando a criatura estiver realmente em FOLLOW, pressione ENTER..."
        );

        b =
            CaptureGameObjectWindow(
                gameAddress
            );

        uintptr_t attackB = 0;

        LookupFollowValue(
            b,
            static_cast<intptr_t>(
                profile.gameAttackTarget
            ),
            attackB
        );

        if (attackB)
        {
            std::cout
                << "\n============================================================\n"
                << "                 ATTACK DETECTED - RETRY\n"
                << "============================================================\n"
                << "AttackTarget ficou ativo: "
                << HexPtr(
                    attackB
                )
                << "\n"
                << "Isso significa que o cliente entrou em ATTACK, nao Follow.\n"
                << "Nao precisa reinjetar a DLL.\n"
                << "Cancele o ataque e vamos repetir o teste.\n";

            WaitEnter(
                "Depois de cancelar o ATTACK, pressione ENTER..."
            );

            // Refresh the clean baseline after the wrong interaction.
            FollowCapture clean =
                CaptureGameObjectWindow(
                    gameAddress
                );

            uintptr_t attackClean = 0;

            LookupFollowValue(
                clean,
                static_cast<intptr_t>(
                    profile.gameAttackTarget
                ),
                attackClean
            );

            if (attackClean)
            {
                std::cout
                    << "[RETRY] Attack ainda esta ativo. Cancele antes de continuar.\n";

                continue;
            }

            a =
                std::move(
                    clean
                );

            continue;
        }

        // Before asking the user to cancel Follow, verify that at least one
        // non-Attack field rose from zero to a semantically valid Creature*.
        size_t risingCreatureFields = 0;

        for (intptr_t off = 0;
             off <= 0x100;
             off += 8)
        {
            if (static_cast<uintptr_t>(off) ==
                    profile.gameLocalPlayer ||
                static_cast<uintptr_t>(off) ==
                    profile.gameAttackTarget)
            {
                continue;
            }

            uintptr_t va = 0;
            uintptr_t vb = 0;

            if (!LookupFollowValue(
                    a,
                    off,
                    va) ||
                !LookupFollowValue(
                    b,
                    off,
                    vb))
            {
                continue;
            }

            if (va != 0 ||
                vb == 0 ||
                vb == localPlayer)
            {
                continue;
            }

            if (ValidateDiscoveredCreature(
                    vb,
                    profile,
                    nullptr))
            {
                ++risingCreatureFields;
            }
        }

        if (!risingCreatureFields)
        {
            std::cout
                << "\n[RETRY] AttackTarget esta zerado, mas nenhum novo Creature* "
                << "apareceu no Game.\n"
                << "O Follow provavelmente nao foi ativado.\n"
                << "Tente novamente sem reinjetar.\n";

            continue;
        }

        std::cout
            << "[FOLLOW SIGNAL] "
            << risingCreatureFields
            << " campo(s) candidato(s) subiram de 0 para Creature*.\n";

        break;
    }

    // ========================================================
    // FOLLOW FALLING EDGE
    // ========================================================

    FollowCapture c{};

    while (true)
    {
        std::cout
            << "\nPASSO C - CANCELAR FOLLOW\n"
            << "Cancele somente o follow e espere a marcacao desaparecer.\n";

        WaitEnter(
            "Quando estiver novamente SEM FOLLOW, pressione ENTER..."
        );

        c =
            CaptureGameObjectWindow(
                gameAddress
            );

        uintptr_t attackC = 0;

        LookupFollowValue(
            c,
            static_cast<intptr_t>(
                profile.gameAttackTarget
            ),
            attackC
        );

        if (!attackC)
            break;

        std::cout
            << "\n[RETRY] Um ATTACK apareceu durante o cancelamento: "
            << HexPtr(
                attackC
            )
            << "\n"
            << "Cancele o ataque e pressione ENTER novamente.\n";
    }

    auto candidates =
        BuildFollowCandidates(
            profile,
            localPlayer,
            a,
            b,
            c
        );

    PrintFollowCandidates(
        candidates
    );

    if (candidates.empty())
    {
        profile.followStatus =
            "unresolved";

        std::cout
            << "\n[RESULT] Nenhum FollowTarget fechou 0 -> Creature* -> 0.\n"
            << "O profile nao sera alterado com valor inventado.\n";

        return false;
    }

    bool uniqueStrong =
        candidates.size() == 1 ||
        candidates[0].score >=
            candidates[1].score + 25;

    if (!uniqueStrong)
    {
        std::cout
            << "\n[AMBIGUOUS] Mais de um candidato forte.\n"
            << "Vamos seguir uma SEGUNDA criatura diferente.\n";

        FollowCapture d{};

        while (true)
        {
            WaitEnter(
                "Ative FOLLOW em outra criatura (sem atacar) e pressione ENTER..."
            );

            d =
                CaptureGameObjectWindow(
                    gameAddress
                );

            uintptr_t attackD = 0;

            LookupFollowValue(
                d,
                static_cast<intptr_t>(
                    profile.gameAttackTarget
                ),
                attackD
            );

            if (!attackD)
                break;

            std::cout
                << "[RETRY] Isso ativou AttackTarget "
                << HexPtr(
                    attackD
                )
                << ". Cancele e use FOLLOW.\n";
        }

        std::vector<FollowCandidate> refined;

        for (const auto& old :
             candidates)
        {
            uintptr_t value = 0;

            if (!LookupFollowValue(
                    d,
                    static_cast<intptr_t>(
                        old.offset
                    ),
                    value))
            {
                continue;
            }

            if (!value ||
                value ==
                    old.pointer)
            {
                continue;
            }

            GameAttackCandidate details{};

            if (!ValidateDiscoveredCreature(
                    value,
                    profile,
                    &details))
            {
                continue;
            }

            FollowCandidate copy =
                old;

            copy.pointer = value;
            copy.x = details.targetX;
            copy.y = details.targetY;
            copy.z = details.targetZ;
            copy.id = details.targetId;
            copy.hp = details.targetHp;
            copy.score += 80;

            refined.push_back(
                std::move(copy)
            );
        }

        if (!refined.empty())
        {
            std::sort(
                refined.begin(),
                refined.end(),
                [](
                    const FollowCandidate& x,
                    const FollowCandidate& y)
                {
                    return x.score > y.score;
                }
            );

            candidates =
                std::move(
                    refined
                );

            PrintFollowCandidates(
                candidates
            );

            uniqueStrong =
                candidates.size() == 1 ||
                candidates[0].score >=
                    candidates[1].score + 25;
        }
    }

    if (!uniqueStrong)
    {
        profile.followStatus =
            "strong_candidate_ambiguous";

        std::cout
            << "\n[RESULT] FollowTarget permaneceu ambiguo.\n";

        return false;
    }

    profile.gameFollowTarget =
        candidates[0].offset;

    profile.followStatus =
        "confirmed_runtime_follow_cycle";

    std::cout
        << "\n============================================================\n"
        << "                 FOLLOWTARGET DISCOVERED\n"
        << "============================================================\n"
        << "FollowTarget offset : +"
        << HexU64(
            profile.gameFollowTarget
        )
        << "\n"
        << "Evidence            : 0 -> Creature* -> 0\n"
        << "AttackTarget        : permaneceu 0 durante o teste valido\n"
        << "Status              : "
        << profile.followStatus
        << "\n";

    // Ground truth only AFTER discovery; never used to locate the field.
    const bool knownBenchmarkBuild =
        profile.timestamp == 0x6AA9FA57ULL &&
        profile.sizeOfImage == 0x17BF000ULL &&
        profile.textHash == 0x89D3D35243890EA2ULL;

    if (knownBenchmarkBuild)
    {
        constexpr uintptr_t expectedFollow =
            0x10;

        bool match =
            profile.gameFollowTarget ==
            expectedFollow;

        std::cout
            << "\n[GROUND TRUTH COMPARISON]\n"
            << "Known Follow offset  : +"
            << HexU64(
                expectedFollow
            )
            << "\n"
            << "FollowTarget match   : "
            << (
                match
                    ? "PASS"
                    : "FAIL"
            )
            << "\n";

        if (match)
        {
            profile.followStatus =
                "discovered_runtime_selfcheck_pass";

            std::cout
                << "\n[FEITO] STAGE 3 redescobriu FollowTarget sem usar a resposta antiga.\n";
        }
        else
        {
            profile.followStatus =
                "discovered_runtime_selfcheck_mismatch";
        }
    }

    return
        profile.followStatus ==
            "discovered_runtime_selfcheck_pass" ||
        profile.followStatus ==
            "confirmed_runtime_follow_cycle";
}

bool EnsureFollowDiscovery(
    DbProfile& profile,
    std::vector<DbProfile>& database,
    int profileIndex,
    const std::string& databasePath)
{
    if (profile.gameFollowTarget &&
        (
            profile.followStatus ==
                "discovered_runtime_selfcheck_pass" ||
            profile.followStatus ==
                "confirmed_runtime_follow_cycle"
        ))
    {
        std::cout
            << "\n[FEITO] STAGE 3 - FollowTarget ja passou self-check.\n"
            << "FollowTarget   : +"
            << HexU64(
                profile.gameFollowTarget
            )
            << "\n";

        return true;
    }

    uintptr_t liveLocalPlayer =
        WaitForDiscoveryLocalPlayer(
            profile,
            "STAGE 3 - FOLLOWTARGET"
        );

    if (!liveLocalPlayer)
    {
        std::cout
            << "\n[STAGE 3] Cancelada antes do login.\n";

        return false;
    }

    bool ok =
        DiscoverFollowTarget(
            profile
        );

    if (profileIndex >= 0 &&
        profileIndex <
            static_cast<int>(
                database.size()
            ))
    {
        database[
            static_cast<size_t>(
                profileIndex
            )
        ] = profile;

        SaveProfileDatabase(
            databasePath,
            database
        );
    }

    return ok;
}


// ============================================================
// DISCOVERY V2.2 - MAP
// ============================================================

struct MapPosition
{
    uint32_t x = 0;
    uint32_t y = 0;
    uint8_t z = 0;
};

struct MapCenterCandidate
{
    uintptr_t address = 0;
    uintptr_t rva = 0;
    std::string section;

    int movementHits = 0;
};

struct MapAwareCandidate
{
    uintptr_t northAddress = 0;
    uintptr_t northOffsetFromCenter = 0;

    uint32_t north = 0;
    uint32_t east = 0;
    uint32_t south = 0;
    uint32_t west = 0;

    int score = 0;
};

struct MapRipRefSummary
{
    uintptr_t target = 0;
    int leaRefs = 0;
    int movRefs = 0;
};

struct MapBaseCandidate
{
    uintptr_t address = 0;
    uintptr_t rva = 0;
    uintptr_t centerOffset = 0;

    int leaRefs = 0;
    int movRefs = 0;
    int score = 0;
};

MapPosition ReadDiscoveredPlayerPosition(
    uintptr_t localPlayer,
    const DbProfile& profile)
{
    MapPosition p{};

    if (!localPlayer)
        return p;

    p.x =
        ReadU32(
            localPlayer +
            profile.x
        );

    p.y =
        ReadU32(
            localPlayer +
            profile.y
        );

    p.z =
        ReadU8(
            localPlayer +
            profile.z
        );

    return p;
}

bool SameMapPosition(
    const MapPosition& a,
    const MapPosition& b)
{
    return
        a.x == b.x &&
        a.y == b.y &&
        a.z == b.z;
}

bool MapPositionPlausible(
    const MapPosition& p)
{
    return
        PositionPlausible(
            p.x,
            p.y,
            p.z
        );
}

std::vector<MapCenterCandidate>
FindModulePositionTriples(
    const MapPosition& position)
{
    std::vector<MapCenterCandidate> out;

    auto sections =
        GetModuleSections();

    for (const auto& section :
         sections)
    {
        if (!section.readable() ||
            !section.writable() ||
            section.executable())
        {
            continue;
        }

        uintptr_t begin =
            (section.begin + 3) &
            ~static_cast<uintptr_t>(3);

        uintptr_t end =
            section.end;

        if (end <= begin ||
            end - begin < 12)
        {
            continue;
        }

        for (uintptr_t address = begin;
             address + 12 <= end;
             address += 4)
        {
            uint32_t x = 0;
            uint32_t y = 0;
            uint8_t z = 0;

            if (!SafeRead(
                    address,
                    x) ||
                x != position.x)
            {
                continue;
            }

            if (!SafeRead(
                    address + 4,
                    y) ||
                y != position.y)
            {
                continue;
            }

            if (!SafeRead(
                    address + 8,
                    z) ||
                z != position.z)
            {
                continue;
            }

            MapCenterCandidate candidate{};

            candidate.address =
                address;

            candidate.rva =
                address -
                g_exeBase;

            candidate.section =
                section.name;

            candidate.movementHits =
                1;

            out.push_back(
                std::move(candidate)
            );
        }
    }

    return out;
}

void FilterMapCenterCandidatesByPosition(
    std::vector<MapCenterCandidate>& candidates,
    const MapPosition& position)
{
    candidates.erase(
        std::remove_if(
            candidates.begin(),
            candidates.end(),
            [&](
                const MapCenterCandidate& candidate)
            {
                uint32_t x = 0;
                uint32_t y = 0;
                uint8_t z = 0;

                if (!SafeRead(
                        candidate.address,
                        x) ||
                    !SafeRead(
                        candidate.address + 4,
                        y) ||
                    !SafeRead(
                        candidate.address + 8,
                        z))
                {
                    return true;
                }

                return
                    x != position.x ||
                    y != position.y ||
                    z != position.z;
            }
        ),
        candidates.end()
    );

    for (auto& candidate :
         candidates)
    {
        ++candidate.movementHits;
    }
}

MapPosition WaitForPlayerPositionChange(
    uintptr_t localPlayer,
    const DbProfile& profile,
    const MapPosition& previous,
    const char* prompt)
{
    while (true)
    {
        WaitEnter(
            prompt
        );

        MapPosition now =
            ReadDiscoveredPlayerPosition(
                localPlayer,
                profile
            );

        if (!MapPositionPlausible(
                now))
        {
            std::cout
                << "[RETRY] Player Position ficou implausivel. Tente novamente.\n";

            continue;
        }

        if (SameMapPosition(
                now,
                previous))
        {
            std::cout
                << "[RETRY] A Position nao mudou. Ande para outro SQM e pressione ENTER.\n";

            continue;
        }

        return now;
    }
}

std::vector<MapAwareCandidate>
FindAwareCandidatesAroundCenter(
    uintptr_t centerAddress)
{
    std::vector<MapAwareCandidate> out;

    // Search near the confirmed center triple.
    // We know the semantics are four consecutive directional extents,
    // but we do NOT assume their exact offsets.
    for (uintptr_t rel = 0x0C;
         rel <= 0x100;
         rel += 4)
    {
        uint32_t n = 0;
        uint32_t e = 0;
        uint32_t s = 0;
        uint32_t w = 0;

        if (!SafeRead(
                centerAddress + rel,
                n) ||
            !SafeRead(
                centerAddress + rel + 4,
                e) ||
            !SafeRead(
                centerAddress + rel + 8,
                s) ||
            !SafeRead(
                centerAddress + rel + 12,
                w))
        {
            continue;
        }

        if (!n || !e || !s || !w)
            continue;

        if (n > 64 ||
            e > 64 ||
            s > 64 ||
            w > 64)
        {
            continue;
        }

        uint32_t height =
            n + 1 + s;

        uint32_t width =
            e + 1 + w;

        if (height < 8 ||
            height > 64 ||
            width < 8 ||
            width > 64)
        {
            continue;
        }

        int nsDiff =
            std::abs(
                static_cast<int>(n) -
                static_cast<int>(s)
            );

        int ewDiff =
            std::abs(
                static_cast<int>(e) -
                static_cast<int>(w)
            );

        int score = 80;

        if (height >= 12 &&
            height <= 32)
        {
            score += 25;
        }

        if (width >= 12 &&
            width <= 40)
        {
            score += 25;
        }

        if (nsDiff <= 4)
            score += 20;

        if (ewDiff <= 4)
            score += 20;

        if (rel >= 0x20 &&
            rel <= 0x60)
        {
            score += 15;
        }

        MapAwareCandidate candidate{};

        candidate.northAddress =
            centerAddress +
            rel;

        candidate.northOffsetFromCenter =
            rel;

        candidate.north = n;
        candidate.east = e;
        candidate.south = s;
        candidate.west = w;
        candidate.score = score;

        out.push_back(
            std::move(candidate)
        );
    }

    std::sort(
        out.begin(),
        out.end(),
        [](
            const MapAwareCandidate& a,
            const MapAwareCandidate& b)
        {
            if (a.score != b.score)
                return a.score > b.score;

            return
                a.northOffsetFromCenter <
                b.northOffsetFromCenter;
        }
    );

    return out;
}

void AddMapRipRef(
    std::unordered_map<uintptr_t, MapRipRefSummary>& refs,
    uintptr_t target,
    bool lea)
{
    auto it =
        refs.find(
            target
        );

    if (it ==
        refs.end())
    {
        MapRipRefSummary summary{};
        summary.target = target;

        it =
            refs.emplace(
                target,
                summary
            ).first;
    }

    if (lea)
        ++it->second.leaRefs;
    else
        ++it->second.movRefs;
}

std::vector<MapRipRefSummary>
CollectRipRefsToWindow(
    uintptr_t targetBegin,
    uintptr_t targetEnd)
{
    std::unordered_map<uintptr_t, MapRipRefSummary> byTarget;

    auto sections =
        GetModuleSections();

    for (const auto& section :
         sections)
    {
        if (!section.readable() ||
            !section.executable())
        {
            continue;
        }

        if (section.end <=
            section.begin + 8)
        {
            continue;
        }

        const uint8_t* bytes =
            reinterpret_cast<const uint8_t*>(
                section.begin
            );

        size_t size =
            static_cast<size_t>(
                section.end -
                section.begin
            );

        for (size_t i = 0;
             i + 7 <= size;
             ++i)
        {
            size_t rex = 0;

            if (bytes[i] >= 0x40 &&
                bytes[i] <= 0x4F)
            {
                rex = 1;
            }

            if (i + rex + 6 >
                size)
            {
                continue;
            }

            uint8_t opcode =
                bytes[
                    i + rex
                ];

            if (opcode != 0x8D &&
                opcode != 0x8B &&
                opcode != 0x89)
            {
                continue;
            }

            uint8_t modrm =
                bytes[
                    i + rex + 1
                ];

            // mod=00, r/m=101 -> RIP-relative disp32.
            if ((modrm & 0xC7) != 0x05)
                continue;

            int32_t disp = 0;

            std::memcpy(
                &disp,
                bytes +
                    i +
                    rex +
                    2,
                sizeof(disp)
            );

            size_t instructionLength =
                rex
                    ? 7
                    : 6;

            uintptr_t instruction =
                section.begin +
                i;

            int64_t next =
                static_cast<int64_t>(
                    instruction +
                    instructionLength
                );

            int64_t targetSigned =
                next +
                static_cast<int64_t>(
                    disp
                );

            if (targetSigned <= 0)
                continue;

            uintptr_t target =
                static_cast<uintptr_t>(
                    targetSigned
                );

            if (target <
                    targetBegin ||
                target >
                    targetEnd)
            {
                continue;
            }

            AddMapRipRef(
                byTarget,
                target,
                opcode == 0x8D
            );

            i +=
                instructionLength -
                1;
        }
    }

    std::vector<MapRipRefSummary> out;

    out.reserve(
        byTarget.size()
    );

    for (const auto& kv :
         byTarget)
    {
        out.push_back(
            kv.second
        );
    }

    std::sort(
        out.begin(),
        out.end(),
        [](
            const MapRipRefSummary& a,
            const MapRipRefSummary& b)
        {
            int aScore =
                a.leaRefs * 20 +
                a.movRefs;

            int bScore =
                b.leaRefs * 20 +
                b.movRefs;

            if (aScore != bScore)
                return aScore > bScore;

            return a.target < b.target;
        }
    );

    return out;
}

std::vector<MapBaseCandidate>
BuildMapBaseCandidates(
    uintptr_t centerAddress,
    const std::string& centerSection)
{
    std::vector<MapBaseCandidate> out;

    uintptr_t windowBegin =
        centerAddress > 0x1000
            ? centerAddress - 0x1000
            : g_exeBase;

    uintptr_t windowEnd =
        centerAddress +
        0x100;

    auto refs =
        CollectRipRefsToWindow(
            windowBegin,
            windowEnd
        );

    auto sections =
        GetModuleSections();

    for (const auto& ref :
         refs)
    {
        if (ref.target >=
            centerAddress)
        {
            continue;
        }

        uintptr_t centerOffset =
            centerAddress -
            ref.target;

        if (centerOffset < 0x80 ||
            centerOffset > 0x1000 ||
            (centerOffset & 3) != 0)
        {
            continue;
        }

        const ModuleSection* owner =
            nullptr;

        for (const auto& section :
             sections)
        {
            if (ref.target >=
                    section.begin &&
                ref.target <
                    section.end)
            {
                owner =
                    &section;

                break;
            }
        }

        if (!owner ||
            !owner->writable() ||
            owner->executable())
        {
            continue;
        }

        if (!centerSection.empty() &&
            owner->name !=
                centerSection)
        {
            continue;
        }

        int score =
            ref.leaRefs * 120 +
            ref.movRefs * 12;

        if ((ref.target & 0xF) == 0)
            score += 25;

        if ((centerOffset & 0xF) == 0)
            score += 10;

        if (centerOffset >= 0x100 &&
            centerOffset <= 0x800)
        {
            score += 20;
        }

        if (ref.leaRefs > 0)
            score += 30;

        MapBaseCandidate candidate{};

        candidate.address =
            ref.target;

        candidate.rva =
            ref.target -
            g_exeBase;

        candidate.centerOffset =
            centerOffset;

        candidate.leaRefs =
            ref.leaRefs;

        candidate.movRefs =
            ref.movRefs;

        candidate.score =
            score;

        out.push_back(
            std::move(candidate)
        );
    }

    std::sort(
        out.begin(),
        out.end(),
        [](
            const MapBaseCandidate& a,
            const MapBaseCandidate& b)
        {
            if (a.score != b.score)
                return a.score > b.score;

            if (a.leaRefs != b.leaRefs)
                return a.leaRefs > b.leaRefs;

            return a.rva < b.rva;
        }
    );

    return out;
}


struct MapOwnerDecision
{
    bool resolved = false;
    MapBaseCandidate selected{};
    std::vector<MapBaseCandidate> eligible;
    int maxLeaRefs = 0;
    int strongLeaThreshold = 0;
    std::string reason;
};

MapOwnerDecision ResolveMapOwnerCandidate(
    const DbProfile& profile,
    const std::vector<MapBaseCandidate>& candidates)
{
    MapOwnerDecision decision{};

    // A position field can be expressed relative to ANY earlier address in
    // .data. Therefore raw xref count alone is insufficient.
    //
    // First semantic rule:
    //   an already-confirmed Game object cannot be promoted again as Map.
    // If a future client really embeds Map inside Game, this resolver will
    // fail safely instead of silently relabeling Game as Map.
    for (const auto& candidate :
         candidates)
    {
        if (profile.gameRva &&
            candidate.rva ==
                profile.gameRva)
        {
            continue;
        }

        if (profile.directGlobalRva &&
            candidate.rva ==
                profile.directGlobalRva)
        {
            continue;
        }

        decision.eligible.push_back(
            candidate
        );

        decision.maxLeaRefs =
            std::max(
                decision.maxLeaRefs,
                candidate.leaRefs
            );
    }

    if (decision.eligible.empty())
    {
        decision.reason =
            "no eligible base after excluding confirmed semantic objects";

        return decision;
    }

    // Build a strong-reference cohort instead of letting a very popular,
    // unrelated global dominate merely by raw reference count.
    //
    // 35% of the strongest remaining LEA count, with a minimum of 8,
    // is intentionally conservative. It is not a Map offset assumption.
    decision.strongLeaThreshold =
        std::max(
            8,
            (
                decision.maxLeaRefs *
                35 +
                99
            ) /
            100
        );

    std::vector<MapBaseCandidate> strong;

    for (const auto& candidate :
         decision.eligible)
    {
        if (candidate.leaRefs >=
            decision.strongLeaThreshold)
        {
            strong.push_back(
                candidate
            );
        }
    }

    if (strong.empty())
    {
        decision.reason =
            "no base survived strong-reference cohort";

        return decision;
    }

    std::sort(
        strong.begin(),
        strong.end(),
        [](
            const MapBaseCandidate& a,
            const MapBaseCandidate& b)
        {
            // Once anchors are all strongly referenced, prefer the nearest
            // preceding object anchor to the confirmed center fields.
            // This prevents distant unrelated globals from winning simply
            // because they are referenced more often.
            if (a.centerOffset !=
                b.centerOffset)
            {
                return
                    a.centerOffset <
                    b.centerOffset;
            }

            if (a.leaRefs !=
                b.leaRefs)
            {
                return
                    a.leaRefs >
                    b.leaRefs;
            }

            return a.rva < b.rva;
        }
    );

    if (strong.size() == 1)
    {
        decision.resolved = true;
        decision.selected =
            strong[0];

        decision.reason =
            "single strong semantic owner";

        return decision;
    }

    const auto& best =
        strong[0];

    const auto& second =
        strong[1];

    // Require a meaningful structural gap before selecting the nearest owner.
    // Otherwise remain ambiguous and do not invent a Map base.
    const uintptr_t offsetGap =
        second.centerOffset >
                best.centerOffset
            ? second.centerOffset -
                best.centerOffset
            : 0;

    if (offsetGap >= 0x40)
    {
        decision.resolved = true;
        decision.selected =
            best;

        decision.reason =
            "nearest strong owner with structural separation";

        return decision;
    }

    decision.reason =
        "multiple strong owners remain too close";

    return decision;
}

void PrintMapBaseCandidates(
    const DbProfile& profile,
    const std::vector<MapBaseCandidate>& candidates)
{
    std::cout
        << "\n============================================================\n"
        << "                 MAP BASE CANDIDATES\n"
        << "============================================================\n";

    if (candidates.empty())
    {
        std::cout
            << "Nenhum owner/base forte encontrado por RIP-relative xrefs.\n";

        return;
    }

    for (size_t i = 0;
         i < candidates.size() &&
         i < 20;
         ++i)
    {
        const auto& c =
            candidates[i];

        std::cout
            << "#"
            << i
            << " score="
            << c.score
            << " baseRva="
            << HexU64(
                c.rva
            )
            << " centerOffset=+"
            << HexU64(
                c.centerOffset
            )
            << " LEA="
            << c.leaRefs
            << " MOV="
            << c.movRefs;

        if (c.rva ==
                profile.gameRva)
        {
            std::cout
                << "  <REJECT: CONFIRMED GAME>";
        }

        std::cout
            << "\n";
    }
}

bool DiscoverMap(
    DbProfile& profile)
{
    if (profile.mapStatus !=
            "discovered_runtime_selfcheck_pass")
    {
        profile.mapRva = 0;
        profile.mapCenterX = 0;
        profile.mapCenterY = 0;
        profile.mapCenterZ = 0;
        profile.mapNorth = 0;
        profile.mapEast = 0;
        profile.mapSouth = 0;
        profile.mapWest = 0;
        profile.mapStatus =
            "rediscovery_running";
    }

    std::cout
        << "\n============================================================\n"
        << "                 STAGE 4 - MAP DISCOVERY\n"
        << "============================================================\n"
        << "[MODE] READ-ONLY\n"
        << "[NO HOOK] Nenhum hook\n"
        << "[NO CALL] Nenhuma funcao interna do jogo\n"
        << "\n"
        << "Metodo:\n"
        << "  1. usa somente Position do LocalPlayer ja descoberta\n"
        << "  2. procura a mesma Position em secoes writable do modulo\n"
        << "  3. exige que o candidato acompanhe 2 mudancas reais de Position\n"
        << "  4. descobre Aware N/E/S/W por estrutura, sem offset fixo\n"
        << "  5. tenta resolver o inicio do objeto Map por RIP-relative xrefs\n";

    uintptr_t localPlayer =
        ResolveProfileLocalPlayerForDiscovery(
            profile
        );

    if (!localPlayer)
    {
        std::cout
            << "[STOP] LocalPlayer invalido para Stage 4.\n";

        return false;
    }

    MapPosition p0 =
        ReadDiscoveredPlayerPosition(
            localPlayer,
            profile
        );

    if (!MapPositionPlausible(
            p0))
    {
        std::cout
            << "[STOP] Player Position inicial implausivel.\n";

        return false;
    }

    std::cout
        << "Player Position #0   : "
        << p0.x
        << ","
        << p0.y
        << ","
        << static_cast<unsigned>(
            p0.z
        )
        << "\n";

    auto centers =
        FindModulePositionTriples(
            p0
        );

    std::cout
        << "Position triples #0  : "
        << centers.size()
        << "\n";

    if (centers.empty())
    {
        profile.mapStatus =
            "unresolved_no_position_triple";

        return false;
    }

    std::cout
        << "\nPASSO A - MOVIMENTO 1\n"
        << "Ande para outro SQM no MESMO andar. Pode andar varios SQMs.\n";

    MapPosition p1 =
        WaitForPlayerPositionChange(
            localPlayer,
            profile,
            p0,
            "Depois de andar, pressione ENTER..."
        );

    FilterMapCenterCandidatesByPosition(
        centers,
        p1
    );

    std::cout
        << "Player Position #1   : "
        << p1.x
        << ","
        << p1.y
        << ","
        << static_cast<unsigned>(
            p1.z
        )
        << "\n"
        << "Candidates after #1  : "
        << centers.size()
        << "\n";

    if (centers.empty())
    {
        profile.mapStatus =
            "unresolved_after_movement_1";

        return false;
    }

    std::cout
        << "\nPASSO B - MOVIMENTO 2\n"
        << "Ande novamente para OUTRO SQM, ainda no mesmo andar.\n";

    MapPosition p2 =
        WaitForPlayerPositionChange(
            localPlayer,
            profile,
            p1,
            "Depois do segundo movimento, pressione ENTER..."
        );

    FilterMapCenterCandidatesByPosition(
        centers,
        p2
    );

    std::cout
        << "Player Position #2   : "
        << p2.x
        << ","
        << p2.y
        << ","
        << static_cast<unsigned>(
            p2.z
        )
        << "\n"
        << "Candidates after #2  : "
        << centers.size()
        << "\n";

    if (centers.empty())
    {
        profile.mapStatus =
            "unresolved_after_movement_2";

        return false;
    }

    std::sort(
        centers.begin(),
        centers.end(),
        [](
            const MapCenterCandidate& a,
            const MapCenterCandidate& b)
        {
            if (a.movementHits !=
                b.movementHits)
            {
                return
                    a.movementHits >
                    b.movementHits;
            }

            return a.rva < b.rva;
        }
    );

    for (size_t i = 0;
         i < centers.size() &&
         i < 16;
         ++i)
    {
        std::cout
            << "  center["
            << i
            << "] RVA "
            << HexU64(
                centers[i].rva
            )
            << " section="
            << centers[i].section
            << " movementHits="
            << centers[i].movementHits
            << "\n";
    }

    if (centers.size() != 1)
    {
        profile.mapStatus =
            "center_anchor_ambiguous";

        std::cout
            << "\n[CHECK] Mais de um center anchor sobreviveu.\n"
            << "Nenhum mapRva sera inventado.\n";

        return false;
    }

    const MapCenterCandidate center =
        centers[0];

    std::cout
        << "\n[MAP CENTER ANCHOR]\n"
        << "Center RVA           : "
        << HexU64(
            center.rva
        )
        << "\n"
        << "Section              : "
        << center.section
        << "\n";

    auto aware =
        FindAwareCandidatesAroundCenter(
            center.address
        );

    std::cout
        << "\n============================================================\n"
        << "                  AWARE CANDIDATES\n"
        << "============================================================\n";

    for (size_t i = 0;
         i < aware.size() &&
         i < 12;
         ++i)
    {
        const auto& a =
            aware[i];

        std::cout
            << "#"
            << i
            << " score="
            << a.score
            << " relCenter=+"
            << HexU64(
                a.northOffsetFromCenter
            )
            << " N/E/S/W="
            << a.north
            << "/"
            << a.east
            << "/"
            << a.south
            << "/"
            << a.west
            << "\n";
    }

    if (aware.empty())
    {
        profile.mapStatus =
            "center_confirmed_aware_unresolved";

        return false;
    }

    bool awareStrong =
        aware.size() == 1 ||
        aware[0].score >=
            aware[1].score + 20;

    if (!awareStrong)
    {
        profile.mapStatus =
            "center_confirmed_aware_ambiguous";

        std::cout
            << "[CHECK] Aware range permaneceu ambiguo.\n";

        return false;
    }

    auto bases =
        BuildMapBaseCandidates(
            center.address,
            center.section
        );

    PrintMapBaseCandidates(
        profile,
        bases
    );

    if (bases.empty())
    {
        profile.mapStatus =
            "center_aware_confirmed_base_unresolved";

        std::cout
            << "\n[CHECK] Center + Aware encontrados, mas o inicio do objeto Map "
            << "ainda nao fechou por xref.\n";

        return false;
    }

    MapOwnerDecision owner =
        ResolveMapOwnerCandidate(
            profile,
            bases
        );

    std::cout
        << "\n============================================================\n"
        << "                 MAP OWNER RESOLUTION\n"
        << "============================================================\n"
        << "Confirmed Game RVA   : "
        << HexU64(
            profile.gameRva
        )
        << "\n"
        << "Eligible candidates  : "
        << owner.eligible.size()
        << "\n"
        << "Max LEA refs         : "
        << owner.maxLeaRefs
        << "\n"
        << "Strong threshold     : "
        << owner.strongLeaThreshold
        << "\n"
        << "Decision             : "
        << owner.reason
        << "\n";

    if (!owner.resolved)
    {
        profile.mapStatus =
            "center_aware_confirmed_base_ambiguous";

        std::cout
            << "[CHECK] Map owner ainda nao pode ser promovido com seguranca.\n";

        return false;
    }

    const MapBaseCandidate base =
        owner.selected;

    std::cout
        << "Selected Map base    : "
        << HexU64(
            base.rva
        )
        << "\n"
        << "Selected center off  : +"
        << HexU64(
            base.centerOffset
        )
        << "\n"
        << "Selected LEA/MOV     : "
        << base.leaRefs
        << "/"
        << base.movRefs
        << "\n";

    const MapAwareCandidate awareBest =
        aware[0];

    profile.mapRva =
        base.rva;

    profile.mapCenterX =
        base.centerOffset;

    profile.mapCenterY =
        base.centerOffset +
        4;

    profile.mapCenterZ =
        base.centerOffset +
        8;

    profile.mapNorth =
        base.centerOffset +
        awareBest.northOffsetFromCenter;

    profile.mapEast =
        profile.mapNorth +
        4;

    profile.mapSouth =
        profile.mapNorth +
        8;

    profile.mapWest =
        profile.mapNorth +
        12;

    profile.mapStatus =
        "confirmed_runtime_position_transitions";

    std::cout
        << "\n============================================================\n"
        << "                     MAP DISCOVERED\n"
        << "============================================================\n"
        << "Map RVA              : "
        << HexU64(
            profile.mapRva
        )
        << "\n"
        << "Center X/Y/Z         : +"
        << HexU64(
            profile.mapCenterX
        )
        << " / +"
        << HexU64(
            profile.mapCenterY
        )
        << " / +"
        << HexU64(
            profile.mapCenterZ
        )
        << "\n"
        << "Aware N/E/S/W        : +"
        << HexU64(
            profile.mapNorth
        )
        << " / +"
        << HexU64(
            profile.mapEast
        )
        << " / +"
        << HexU64(
            profile.mapSouth
        )
        << " / +"
        << HexU64(
            profile.mapWest
        )
        << "\n"
        << "Aware values         : "
        << awareBest.north
        << "/"
        << awareBest.east
        << "/"
        << awareBest.south
        << "/"
        << awareBest.west
        << "\n"
        << "Evidence             : Player Position followed twice + static owner xrefs\n"
        << "Status               : "
        << profile.mapStatus
        << "\n";

    // Benchmark only AFTER discovery.
    const bool knownBenchmarkBuild =
        profile.timestamp == 0x6AA9FA57ULL &&
        profile.sizeOfImage == 0x17BF000ULL &&
        profile.textHash == 0x89D3D35243890EA2ULL;

    if (knownBenchmarkBuild)
    {
        const bool rvaMatch =
            profile.mapRva ==
            0x169A860;

        const bool centerMatch =
            profile.mapCenterX == 0x340 &&
            profile.mapCenterY == 0x344 &&
            profile.mapCenterZ == 0x348;

        const bool awareMatch =
            profile.mapNorth == 0x368 &&
            profile.mapEast == 0x36C &&
            profile.mapSouth == 0x370 &&
            profile.mapWest == 0x374;

        std::cout
            << "\n[GROUND TRUTH COMPARISON]\n"
            << "Known Map RVA        : 0x169A860\n"
            << "Map RVA match        : "
            << (
                rvaMatch
                    ? "PASS"
                    : "FAIL"
            )
            << "\n"
            << "Center offsets match : "
            << (
                centerMatch
                    ? "PASS"
                    : "FAIL"
            )
            << "\n"
            << "Aware offsets match  : "
            << (
                awareMatch
                    ? "PASS"
                    : "FAIL"
            )
            << "\n";

        if (rvaMatch &&
            centerMatch &&
            awareMatch)
        {
            profile.mapStatus =
                "discovered_runtime_selfcheck_pass";

            std::cout
                << "\n[FEITO] STAGE 4 redescobriu Map sem usar a resposta antiga.\n";
        }
        else
        {
            profile.mapStatus =
                "discovered_runtime_selfcheck_mismatch";

            std::cout
                << "[PRESERVE] Self-check falhou; candidato Map nao sera promovido no profile.\n";

            profile.mapRva = 0;
            profile.mapCenterX = 0;
            profile.mapCenterY = 0;
            profile.mapCenterZ = 0;
            profile.mapNorth = 0;
            profile.mapEast = 0;
            profile.mapSouth = 0;
            profile.mapWest = 0;
        }
    }

    return
        profile.mapStatus ==
            "discovered_runtime_selfcheck_pass" ||
        profile.mapStatus ==
            "confirmed_runtime_position_transitions";
}

bool EnsureMapDiscovery(
    DbProfile& profile,
    std::vector<DbProfile>& database,
    int profileIndex,
    const std::string& databasePath)
{
    if (profile.mapRva &&
        (
            profile.mapStatus ==
                "discovered_runtime_selfcheck_pass" ||
            profile.mapStatus ==
                "confirmed_runtime_position_transitions"
        ))
    {
        std::cout
            << "\n[FEITO] STAGE 4 - Map ja passou self-check.\n"
            << "Map RVA        : "
            << HexU64(
                profile.mapRva
            )
            << "\n";

        return true;
    }

    uintptr_t localPlayer =
        WaitForDiscoveryLocalPlayer(
            profile,
            "STAGE 4 - MAP"
        );

    if (!localPlayer)
    {
        std::cout
            << "\n[STAGE 4] Cancelada antes do login.\n";

        return false;
    }

    bool ok =
        DiscoverMap(
            profile
        );

    if (profileIndex >= 0 &&
        profileIndex <
            static_cast<int>(
                database.size()
            ))
    {
        database[
            static_cast<size_t>(
                profileIndex
            )
        ] = profile;

        SaveProfileDatabase(
            databasePath,
            database
        );
    }

    return ok;
}


// ============================================================
// DISCOVERY V2.3 - TILE::THINGS (STRICT READ-ONLY)
// ============================================================

struct TileScanRegion
{
    uintptr_t base = 0;
    size_t size = 0;
};

struct TileVectorCandidate
{
    uintptr_t objectBase = 0;
    uintptr_t vectorHeader = 0;
    uintptr_t vectorOffset = 0;

    uintptr_t begin = 0;
    uintptr_t end = 0;
    uintptr_t cap = 0;

    uintptr_t vtable = 0;

    size_t count = 0;
    size_t capacity = 0;

    int score = 0;
};


std::string ReadBoundedAscii(
    uintptr_t address,
    size_t maxLength)
{
    std::string out;

    if (!address ||
        !maxLength)
    {
        return out;
    }

    out.reserve(
        std::min<size_t>(
            maxLength,
            128
        )
    );

    for (size_t i = 0;
         i < maxLength;
         ++i)
    {
        char c = 0;

        if (!SafeRead(
                address + i,
                c))
        {
            break;
        }

        if (!c)
            break;

        unsigned char uc =
            static_cast<unsigned char>(
                c
            );

        if (uc < 0x20 ||
            uc > 0x7E)
        {
            return std::string();
        }

        out.push_back(
            c
        );
    }

    return out;
}

std::string TryReadMsvcRttiTypeName(
    uintptr_t vtable)
{
    if (!vtable ||
        vtable < sizeof(uintptr_t))
    {
        return std::string();
    }

    uintptr_t col =
        ReadPtr(
            vtable -
            sizeof(uintptr_t)
        );

    if (!col ||
        !InsideExeImage(
            col))
    {
        return std::string();
    }

    uint32_t signature = 0;
    uint32_t objectOffset = 0;
    uint32_t cdOffset = 0;
    int32_t typeDescriptorRva = 0;
    int32_t classDescriptorRva = 0;
    int32_t selfRva = 0;

    if (!SafeRead(
            col + 0x00,
            signature) ||
        !SafeRead(
            col + 0x04,
            objectOffset) ||
        !SafeRead(
            col + 0x08,
            cdOffset) ||
        !SafeRead(
            col + 0x0C,
            typeDescriptorRva) ||
        !SafeRead(
            col + 0x10,
            classDescriptorRva) ||
        !SafeRead(
            col + 0x14,
            selfRva))
    {
        return std::string();
    }

    // MSVC x64 CompleteObjectLocator normally uses signature 1 and
    // image-relative references. Some builds may expose signature 0;
    // in that case we do not guess.
    if (signature != 1)
    {
        return std::string();
    }

    if (selfRva <= 0 ||
        g_exeBase +
            static_cast<uintptr_t>(
                static_cast<uint32_t>(
                    selfRva
                )
            ) != col)
    {
        return std::string();
    }

    if (typeDescriptorRva <= 0)
    {
        return std::string();
    }

    uintptr_t typeDescriptor =
        g_exeBase +
        static_cast<uintptr_t>(
            static_cast<uint32_t>(
                typeDescriptorRva
            )
        );

    if (!InsideExeImage(
            typeDescriptor))
    {
        return std::string();
    }

    // MSVC TypeDescriptor on x64:
    //   +0x00 pVFTable
    //   +0x08 spare
    //   +0x10 decorated class name
    return
        ReadBoundedAscii(
            typeDescriptor +
            0x10,
            160
        );
}


bool IsReadableMonitorRange(
    uintptr_t address,
    size_t size);

struct V35MsvcObjectIdentity
{
    uintptr_t pointer = 0;
    uintptr_t vtable = 0;
    uintptr_t completeObject = 0;
    uint32_t subobjectOffset = 0;
    std::string rttiName;
    bool valid = false;
};

bool V35DescribeMsvcObject(
    uintptr_t pointer,
    V35MsvcObjectIdentity& out)
{
    out = {};

    if (!pointer ||
        !IsReadableMonitorRange(
            pointer,
            sizeof(uintptr_t)))
    {
        return false;
    }

    uintptr_t vtable =
        ReadPtr(
            pointer
        );

    if (!InsideExeImage(
            vtable) ||
        vtable < sizeof(uintptr_t))
    {
        return false;
    }

    uintptr_t col =
        ReadPtr(
            vtable -
            sizeof(uintptr_t)
        );

    if (!col ||
        !InsideExeImage(
            col))
    {
        return false;
    }

    uint32_t signature = 0;
    uint32_t objectOffset = 0;
    int32_t selfRva = 0;

    if (!SafeRead(
            col + 0x00,
            signature) ||
        !SafeRead(
            col + 0x04,
            objectOffset) ||
        !SafeRead(
            col + 0x14,
            selfRva))
    {
        return false;
    }

    if (signature != 1 ||
        selfRva <= 0 ||
        g_exeBase +
            static_cast<uintptr_t>(
                static_cast<uint32_t>(
                    selfRva
                )
            ) != col)
    {
        return false;
    }

    if (pointer <
        static_cast<uintptr_t>(
            objectOffset))
    {
        return false;
    }

    uintptr_t complete =
        pointer -
        static_cast<uintptr_t>(
            objectOffset);

    if (!IsReadableMonitorRange(
            complete,
            sizeof(uintptr_t)))
    {
        return false;
    }

    out.pointer =
        pointer;

    out.vtable =
        vtable;

    out.completeObject =
        complete;

    out.subobjectOffset =
        objectOffset;

    out.rttiName =
        TryReadMsvcRttiTypeName(
            vtable
        );

    if (out.rttiName.empty())
        out.rttiName = "<unavailable>";

    out.valid =
        true;

    return true;
}

uintptr_t V35CompleteObjectPointer(
    uintptr_t pointer)
{
    V35MsvcObjectIdentity id{};

    if (V35DescribeMsvcObject(
            pointer,
            id))
    {
        return
            id.completeObject;
    }

    return pointer;
}

bool V35SameCompleteObject(
    uintptr_t a,
    uintptr_t b)
{
    if (!a ||
        !b)
    {
        return false;
    }

    return
        V35CompleteObjectPointer(
            a) ==
        V35CompleteObjectPointer(
            b);
}

bool V35RttiHasToken(
    uintptr_t pointer,
    const std::string& token)
{
    V35MsvcObjectIdentity id{};

    if (!V35DescribeMsvcObject(
            pointer,
            id))
    {
        return false;
    }

    std::string rtti =
        id.rttiName;

    std::string wanted =
        token;

    std::transform(
        rtti.begin(),
        rtti.end(),
        rtti.begin(),
        [](
            unsigned char c)
        {
            return
                static_cast<char>(
                    std::tolower(c)
                );
        }
    );

    std::transform(
        wanted.begin(),
        wanted.end(),
        wanted.begin(),
        [](
            unsigned char c)
        {
            return
                static_cast<char>(
                    std::tolower(c)
                );
        }
    );

    // A shared_ptr control block can have RTTI such as
    // _Ref_count_obj2<VItem>. The class token "item" is present there,
    // but the pointer is NOT an Item object. Never promote those wrappers
    // as semantic objects.
    if (rtti.find(
            "_ref_count") !=
            std::string::npos ||
        rtti.find(
            "shared_ptr") !=
            std::string::npos)
    {
        return false;
    }

    return
        rtti.find(
            wanted) !=
        std::string::npos;
}


std::string LowerAscii(
    const std::string& value)
{
    std::string out =
        value;

    std::transform(
        out.begin(),
        out.end(),
        out.begin(),
        [](
            unsigned char c)
        {
            return
                static_cast<char>(
                    std::tolower(c)
                );
        }
    );

    return out;
}

bool RttiLooksExactlyLikeTileClass(
    const std::string& rtti)
{
    if (rtti.empty())
        return false;

    // Common MSVC decorated class/struct forms:
    //   .?AVTile@@
    //   .?AVTile@namespace@@
    //   .?AUTile@@
    //   .?AUTile@namespace@@
    //
    // This is semantic class-name evidence, not an offset/vtable seed.
    return
        rtti.find("?AVTile@") !=
            std::string::npos ||
        rtti.find("?AUTile@") !=
            std::string::npos;
}


// V3.4.1 - forward declarations.
// The RTTI-first resolver is intentionally located before the legacy
// heap helpers, so declare the two read-only helpers it reuses here.
bool ReadProcessChunk(
    uintptr_t address,
    void* buffer,
    size_t size,
    size_t& bytesRead);

bool LooksLikeObjectVtable(
    uintptr_t vtable);


std::vector<uintptr_t>
FindMsvcVtablesByExactRttiName(
    const std::string& exactName)
{
    std::vector<uintptr_t> result;

    if (exactName.empty() ||
        !g_exeBase ||
        !g_imageEnd ||
        g_imageEnd <= g_exeBase)
    {
        return result;
    }

    auto sections =
        GetModuleSections();

    std::vector<uintptr_t>
        typeDescriptors;

    const std::string needle =
        exactName +
        std::string(
            1,
            '\0'
        );

    const size_t chunkSize =
        2 * 1024 * 1024;

    std::vector<uint8_t>
        buffer(
            chunkSize +
            needle.size()
        );

    // --------------------------------------------------------
    // 1. Find TypeDescriptor decorated names.
    // --------------------------------------------------------
    for (const auto& section :
         sections)
    {
        if (!section.readable())
            continue;

        uintptr_t cursor =
            section.begin;

        while (cursor <
               section.end)
        {
            size_t want =
                static_cast<size_t>(
                    std::min<uintptr_t>(
                        chunkSize,
                        section.end -
                        cursor
                    )
                );

            size_t got = 0;

            if (!ReadProcessChunk(
                    cursor,
                    buffer.data(),
                    want,
                    got))
            {
                cursor += want;
                continue;
            }

            if (got >=
                needle.size())
            {
                for (size_t off = 0;
                     off + needle.size() <= got;
                     ++off)
                {
                    if (std::memcmp(
                            buffer.data() + off,
                            needle.data(),
                            needle.size()) != 0)
                    {
                        continue;
                    }

                    uintptr_t nameAddress =
                        cursor +
                        off;

                    if (nameAddress <
                        g_exeBase + 0x10)
                    {
                        continue;
                    }

                    uintptr_t typeDescriptor =
                        nameAddress -
                        0x10;

                    if (InsideExeImage(
                            typeDescriptor))
                    {
                        typeDescriptors.push_back(
                            typeDescriptor
                        );
                    }
                }
            }

            cursor += got;
        }
    }

    std::sort(
        typeDescriptors.begin(),
        typeDescriptors.end()
    );

    typeDescriptors.erase(
        std::unique(
            typeDescriptors.begin(),
            typeDescriptors.end()
        ),
        typeDescriptors.end()
    );

    if (typeDescriptors.empty())
        return result;

    std::vector<uintptr_t>
        completeObjectLocators;

    // --------------------------------------------------------
    // 2. Find MSVC x64 CompleteObjectLocator structures whose
    //    pTypeDescriptor RVA points to the exact Tile TypeDescriptor.
    // --------------------------------------------------------
    for (uintptr_t td :
         typeDescriptors)
    {
        const uint32_t tdRva =
            static_cast<uint32_t>(
                td -
                g_exeBase
            );

        for (const auto& section :
             sections)
        {
            if (!section.readable())
                continue;

            uintptr_t cursor =
                section.begin;

            while (cursor <
                   section.end)
            {
                size_t want =
                    static_cast<size_t>(
                        std::min<uintptr_t>(
                            chunkSize,
                            section.end -
                            cursor
                        )
                    );

                size_t got = 0;

                if (!ReadProcessChunk(
                        cursor,
                        buffer.data(),
                        want,
                        got))
                {
                    cursor += want;
                    continue;
                }

                for (size_t off = 0;
                     off + sizeof(uint32_t) <= got;
                     off += 4)
                {
                    uint32_t value = 0;

                    std::memcpy(
                        &value,
                        buffer.data() + off,
                        sizeof(value)
                    );

                    if (value !=
                        tdRva)
                    {
                        continue;
                    }

                    uintptr_t fieldAddress =
                        cursor +
                        off;

                    if (fieldAddress <
                        g_exeBase + 0x0C)
                    {
                        continue;
                    }

                    uintptr_t col =
                        fieldAddress -
                        0x0C;

                    uint32_t signature = 0;
                    int32_t typeRva = 0;
                    int32_t selfRva = 0;

                    if (!SafeRead(
                            col + 0x00,
                            signature) ||
                        !SafeRead(
                            col + 0x0C,
                            typeRva) ||
                        !SafeRead(
                            col + 0x14,
                            selfRva))
                    {
                        continue;
                    }

                    if (signature != 1 ||
                        static_cast<uint32_t>(
                            typeRva) !=
                            tdRva ||
                        selfRva <= 0 ||
                        g_exeBase +
                            static_cast<uintptr_t>(
                                static_cast<uint32_t>(
                                    selfRva
                                )
                            ) != col)
                    {
                        continue;
                    }

                    completeObjectLocators.push_back(
                        col
                    );
                }

                cursor += got;
            }
        }
    }

    std::sort(
        completeObjectLocators.begin(),
        completeObjectLocators.end()
    );

    completeObjectLocators.erase(
        std::unique(
            completeObjectLocators.begin(),
            completeObjectLocators.end()
        ),
        completeObjectLocators.end()
    );

    if (completeObjectLocators.empty())
        return result;

    // --------------------------------------------------------
    // 3. vtable[-1] contains the absolute COL pointer.
    // --------------------------------------------------------
    for (uintptr_t col :
         completeObjectLocators)
    {
        for (const auto& section :
             sections)
        {
            if (!section.readable())
                continue;

            uintptr_t cursor =
                section.begin;

            while (cursor <
                   section.end)
            {
                size_t want =
                    static_cast<size_t>(
                        std::min<uintptr_t>(
                            chunkSize,
                            section.end -
                            cursor
                        )
                    );

                size_t got = 0;

                if (!ReadProcessChunk(
                        cursor,
                        buffer.data(),
                        want,
                        got))
                {
                    cursor += want;
                    continue;
                }

                uintptr_t aligned =
                    (cursor + 7) &
                    ~static_cast<uintptr_t>(7);

                size_t start =
                    static_cast<size_t>(
                        aligned -
                        cursor
                    );

                for (size_t off = start;
                     off + sizeof(uintptr_t) <= got;
                     off += 8)
                {
                    uintptr_t value = 0;

                    std::memcpy(
                        &value,
                        buffer.data() + off,
                        sizeof(value)
                    );

                    if (value !=
                        col)
                    {
                        continue;
                    }

                    uintptr_t vtable =
                        cursor +
                        off +
                        sizeof(uintptr_t);

                    if (!InsideExeImage(
                            vtable) ||
                        !LooksLikeObjectVtable(
                            vtable))
                    {
                        continue;
                    }

                    std::string rtti =
                        TryReadMsvcRttiTypeName(
                            vtable
                        );

                    if (rtti ==
                        exactName)
                    {
                        result.push_back(
                            vtable
                        );
                    }
                }

                cursor += got;
            }
        }
    }

    std::sort(
        result.begin(),
        result.end()
    );

    result.erase(
        std::unique(
            result.begin(),
            result.end()
        ),
        result.end()
    );

    return result;
}

std::vector<TileVectorCandidate>
FindTileCandidatesByExactRttiAnchor(
    uintptr_t localPlayer,
    const std::vector<TileScanRegion>& regions)
{
    std::vector<TileVectorCandidate>
        out;

    auto tileVtables =
        FindMsvcVtablesByExactRttiName(
            ".?AVTile@@"
        );

    std::cout
        << "[RTTI TILE ANCHOR] exact Tile vtables="
        << tileVtables.size()
        << "\n";

    for (uintptr_t vt :
         tileVtables)
    {
        std::cout
            << "  vtableRva="
            << HexU64(
                vt -
                g_exeBase
            )
            << " rtti=\\\""
            << TryReadMsvcRttiTypeName(
                vt
            )
            << "\\\"\n";
    }

    if (tileVtables.empty())
        return out;

    std::unordered_set<uintptr_t>
        wantedVtables(
            tileVtables.begin(),
            tileVtables.end()
        );

    const size_t chunkSize =
        4 * 1024 * 1024;

    std::vector<uint8_t>
        buffer(
            chunkSize
        );

    size_t objectHits = 0;

    for (const auto& region :
         regions)
    {
        uintptr_t cursor =
            region.base;

        uintptr_t regionEnd =
            region.base +
            region.size;

        while (cursor <
               regionEnd)
        {
            size_t want =
                static_cast<size_t>(
                    std::min<uintptr_t>(
                        chunkSize,
                        regionEnd -
                        cursor
                    )
                );

            size_t got = 0;

            if (!ReadProcessChunk(
                    cursor,
                    buffer.data(),
                    want,
                    got))
            {
                cursor += want;
                continue;
            }

            uintptr_t aligned =
                (cursor + 7) &
                ~static_cast<uintptr_t>(7);

            size_t start =
                static_cast<size_t>(
                    aligned -
                    cursor
                );

            for (size_t off = start;
                 off + sizeof(uintptr_t) <= got;
                 off += 8)
            {
                uintptr_t value = 0;

                std::memcpy(
                    &value,
                    buffer.data() + off,
                    sizeof(value)
                );

                if (wantedVtables.find(
                        value) ==
                    wantedVtables.end())
                {
                    continue;
                }

                uintptr_t object =
                    cursor +
                    off;

                ++objectHits;

                for (uintptr_t vectorOffset = 0x10;
                     vectorOffset <= 0xC0;
                     vectorOffset += 8)
                {
                    uintptr_t header =
                        object +
                        vectorOffset;

                    uintptr_t begin = 0;
                    uintptr_t end = 0;
                    uintptr_t cap = 0;

                    if (!SafeRead(
                            header,
                            begin) ||
                        !SafeRead(
                            header + 8,
                            end) ||
                        !SafeRead(
                            header + 16,
                            cap))
                    {
                        continue;
                    }

                    if (!begin ||
                        end < begin ||
                        cap < end ||
                        (begin & 7) ||
                        (end & 7) ||
                        (cap & 7))
                    {
                        continue;
                    }

                    uintptr_t used =
                        end -
                        begin;

                    uintptr_t capacityBytes =
                        cap -
                        begin;

                    if (used % 8 != 0 ||
                        capacityBytes % 8 != 0)
                    {
                        continue;
                    }

                    size_t count =
                        static_cast<size_t>(
                            used / 8
                        );

                    size_t capacity =
                        static_cast<size_t>(
                            capacityBytes / 8
                        );

                    if (!count ||
                        count > 128 ||
                        capacity < count ||
                        capacity > 256)
                    {
                        continue;
                    }

                    if (!IsReadableMonitorRange(
                            begin,
                            used))
                    {
                        continue;
                    }

                    bool containsLocal =
                        false;

                    for (size_t i = 0;
                         i < count;
                         ++i)
                    {
                        if (ReadPtr(
                                begin +
                                i * 8) ==
                            localPlayer)
                        {
                            containsLocal =
                                true;

                            break;
                        }
                    }

                    if (!containsLocal)
                        continue;

                    TileVectorCandidate c{};

                    c.objectBase =
                        object;

                    c.vectorHeader =
                        header;

                    c.vectorOffset =
                        vectorOffset;

                    c.begin =
                        begin;

                    c.end =
                        end;

                    c.cap =
                        cap;

                    c.vtable =
                        value;

                    c.count =
                        count;

                    c.capacity =
                        capacity;

                    c.score =
                        3000;

                    out.push_back(
                        c
                    );
                }
            }

            cursor += got;
        }
    }

    std::cout
        << "[RTTI TILE ANCHOR] heap Tile objects="
        << objectHits
        << " vectors containing LocalPlayer="
        << out.size()
        << "\n";

    return out;
}


bool RttiContainsTileToken(
    const std::string& rtti)
{
    if (rtti.empty())
        return false;

    std::string lower =
        LowerAscii(
            rtti
        );

    return
        lower.find("tile") !=
        std::string::npos;
}

struct TileLayoutAggregate
{
    uintptr_t vectorOffset = 0;
    uintptr_t vtable = 0;

    int pairCount = 0;
    int score = 0;

    uintptr_t localTile = 0;
    uintptr_t targetTile = 0;
};

bool TileScanReadableProtection(
    DWORD protect)
{
    if (protect & PAGE_GUARD)
        return false;

    if (protect & PAGE_NOACCESS)
        return false;

    DWORD base =
        protect & 0xFF;

    return
        base == PAGE_READWRITE ||
        base == PAGE_WRITECOPY;
}

std::vector<TileScanRegion>
EnumerateTileHeapRegions()
{
    std::vector<TileScanRegion> out;

    SYSTEM_INFO si{};
    GetSystemInfo(
        &si
    );

    uintptr_t cursor =
        reinterpret_cast<uintptr_t>(
            si.lpMinimumApplicationAddress
        );

    uintptr_t maxAddress =
        reinterpret_cast<uintptr_t>(
            si.lpMaximumApplicationAddress
        );

    size_t total =
        0;

    const size_t maxTotal =
        static_cast<size_t>(
            2ULL *
            1024ULL *
            1024ULL *
            1024ULL
        );

    while (cursor <
           maxAddress)
    {
        MEMORY_BASIC_INFORMATION mbi{};

        if (!VirtualQuery(
                reinterpret_cast<const void*>(
                    cursor
                ),
                &mbi,
                sizeof(mbi)))
        {
            break;
        }

        uintptr_t base =
            reinterpret_cast<uintptr_t>(
                mbi.BaseAddress
            );

        size_t size =
            static_cast<size_t>(
                mbi.RegionSize
            );

        uintptr_t next =
            base +
            size;

        if (next <= cursor)
            break;

        bool suitable =
            mbi.State == MEM_COMMIT &&
            mbi.Type == MEM_PRIVATE &&
            TileScanReadableProtection(
                mbi.Protect
            );

        if (suitable &&
            size >= 0x1000)
        {
            if (total + size >
                maxTotal)
            {
                size =
                    maxTotal -
                    total;
            }

            if (size)
            {
                out.push_back(
                    {
                        base,
                        size
                    }
                );

                total +=
                    size;
            }

            if (total >=
                maxTotal)
            {
                break;
            }
        }

        cursor =
            next;
    }

    return out;
}

bool ReadProcessChunk(
    uintptr_t address,
    void* buffer,
    size_t size,
    size_t& bytesRead)
{
    bytesRead = 0;

    SIZE_T got = 0;

    BOOL ok =
        ReadProcessMemory(
            GetCurrentProcess(),
            reinterpret_cast<const void*>(
                address
            ),
            buffer,
            size,
            &got
        );

    bytesRead =
        static_cast<size_t>(
            got
        );

    return
        ok != FALSE &&
        bytesRead != 0;
}

std::vector<uintptr_t>
FindNeedleOccurrencesInTileHeap(
    uintptr_t needle,
    const std::vector<TileScanRegion>& regions,
    size_t maxOccurrences = 4096)
{
    std::vector<uintptr_t> out;

    if (!needle)
        return out;

    const size_t chunkSize =
        4 * 1024 * 1024;

    std::vector<uint8_t> buffer(
        chunkSize
    );

    size_t scannedBytes = 0;

    for (const auto& region :
         regions)
    {
        uintptr_t cursor =
            region.base;

        uintptr_t end =
            region.base +
            region.size;

        while (cursor <
               end)
        {
            size_t want =
                static_cast<size_t>(
                    std::min<uintptr_t>(
                        chunkSize,
                        end -
                        cursor
                    )
                );

            size_t got = 0;

            if (!ReadProcessChunk(
                    cursor,
                    buffer.data(),
                    want,
                    got))
            {
                cursor +=
                    want;

                continue;
            }

            scannedBytes +=
                got;

            uintptr_t aligned =
                (cursor + 7) &
                ~static_cast<uintptr_t>(7);

            size_t start =
                static_cast<size_t>(
                    aligned -
                    cursor
                );

            for (size_t off = start;
                 off + sizeof(uintptr_t) <= got;
                 off += 8)
            {
                uintptr_t value = 0;

                std::memcpy(
                    &value,
                    buffer.data() +
                        off,
                    sizeof(value)
                );

                if (value ==
                    needle)
                {
                    out.push_back(
                        cursor +
                        off
                    );

                    if (out.size() >=
                        maxOccurrences)
                    {
                        std::cout
                            << "[SCAN] Needle occurrence limit reached: "
                            << maxOccurrences
                            << "\n";

                        std::fill(
                            buffer.begin(),
                            buffer.end(),
                            0
                        );

                        return out;
                    }
                }
            }

            cursor +=
                got;
        }
    }

    std::cout
        << "[SCAN] Private heap scanned: "
        << (
            scannedBytes /
            (1024 * 1024)
        )
        << " MB"
        << " | needle occurrences="
        << out.size()
        << "\n";

    std::fill(
        buffer.begin(),
        buffer.end(),
        0
    );

    return out;
}

bool AddressInExecutableModuleSection(
    uintptr_t address)
{
    if (!InsideExeImage(
            address))
    {
        return false;
    }

    auto sections =
        GetModuleSections();

    for (const auto& section :
         sections)
    {
        if (address >=
                section.begin &&
            address <
                section.end)
        {
            return
                section.executable();
        }
    }

    return false;
}

bool AddressInReadOnlyModuleSection(
    uintptr_t address)
{
    if (!InsideExeImage(
            address))
    {
        return false;
    }

    auto sections =
        GetModuleSections();

    for (const auto& section :
         sections)
    {
        if (address >=
                section.begin &&
            address <
                section.end)
        {
            return
                section.readable() &&
                !section.writable() &&
                !section.executable();
        }
    }

    return false;
}

bool LooksLikeObjectVtable(
    uintptr_t vtable)
{
    if (!vtable ||
        !AddressInReadOnlyModuleSection(
            vtable))
    {
        return false;
    }

    int executableSlots = 0;

    for (uintptr_t off = 0;
         off < 5 * sizeof(uintptr_t);
         off += sizeof(uintptr_t))
    {
        uintptr_t fn =
            ReadPtr(
                vtable +
                off
            );

        if (AddressInExecutableModuleSection(
                fn))
        {
            ++executableSlots;
        }
    }

    return
        executableSlots >= 3;
}

bool VectorContainsNeedleOccurrence(
    uintptr_t begin,
    uintptr_t end,
    uintptr_t needle,
    const std::vector<uintptr_t>& occurrences)
{
    if (!begin ||
        end <= begin)
    {
        return false;
    }

    for (uintptr_t occurrence :
         occurrences)
    {
        if (occurrence <
                begin ||
            occurrence >=
                end)
        {
            continue;
        }

        if ((occurrence - begin) %
                sizeof(uintptr_t) !=
            0)
        {
            continue;
        }

        uintptr_t value =
            ReadPtr(
                occurrence
            );

        if (value ==
            needle)
        {
            return true;
        }
    }

    return false;
}

std::vector<TileVectorCandidate>
FindTileVectorCandidatesForNeedle(
    uintptr_t needle,
    const std::vector<TileScanRegion>& regions)
{
    std::vector<TileVectorCandidate> out;

    size_t rawVectorHeaders = 0;
    size_t polymorphicOwnerHits = 0;

    auto occurrences =
        FindNeedleOccurrencesInTileHeap(
            needle,
            regions
        );

    if (occurrences.empty())
        return out;

    std::unordered_set<uintptr_t>
        possibleBegins;

    for (uintptr_t occurrence :
         occurrences)
    {
        for (size_t index = 0;
             index < 64;
             ++index)
        {
            uintptr_t delta =
                index *
                sizeof(uintptr_t);

            if (occurrence <
                delta)
            {
                break;
            }

            possibleBegins.insert(
                occurrence -
                delta
            );
        }
    }

    std::unordered_set<uintptr_t>
        seenHeaders;

    const size_t chunkSize =
        4 * 1024 * 1024;

    std::vector<uint8_t> buffer(
        chunkSize
    );

    for (const auto& region :
         regions)
    {
        uintptr_t cursor =
            region.base;

        uintptr_t regionEnd =
            region.base +
            region.size;

        while (cursor <
               regionEnd)
        {
            size_t want =
                static_cast<size_t>(
                    std::min<uintptr_t>(
                        chunkSize,
                        regionEnd -
                        cursor
                    )
                );

            size_t got = 0;

            if (!ReadProcessChunk(
                    cursor,
                    buffer.data(),
                    want,
                    got))
            {
                cursor +=
                    want;

                continue;
            }

            uintptr_t aligned =
                (cursor + 7) &
                ~static_cast<uintptr_t>(7);

            size_t start =
                static_cast<size_t>(
                    aligned -
                    cursor
                );

            for (size_t off = start;
                 off + sizeof(uintptr_t) <= got;
                 off += 8)
            {
                uintptr_t begin = 0;

                std::memcpy(
                    &begin,
                    buffer.data() +
                        off,
                    sizeof(begin)
                );

                if (possibleBegins.find(
                        begin) ==
                    possibleBegins.end())
                {
                    continue;
                }

                uintptr_t header =
                    cursor +
                    off;

                if (!seenHeaders.insert(
                        header).second)
                {
                    continue;
                }

                uintptr_t end = 0;
                uintptr_t cap = 0;

                if (!SafeRead(
                        header + 8,
                        end) ||
                    !SafeRead(
                        header + 16,
                        cap))
                {
                    continue;
                }

                if (!begin ||
                    end < begin ||
                    cap < end)
                {
                    continue;
                }

                if ((begin & 7) ||
                    (end & 7) ||
                    (cap & 7))
                {
                    continue;
                }

                uintptr_t usedBytes =
                    end -
                    begin;

                uintptr_t capBytes =
                    cap -
                    begin;

                if (usedBytes %
                        sizeof(uintptr_t) !=
                    0 ||
                    capBytes %
                        sizeof(uintptr_t) !=
                    0)
                {
                    continue;
                }

                size_t count =
                    static_cast<size_t>(
                        usedBytes /
                        sizeof(uintptr_t)
                    );

                size_t capacity =
                    static_cast<size_t>(
                        capBytes /
                        sizeof(uintptr_t)
                    );

                if (!count ||
                    count > 128 ||
                    capacity < count ||
                    capacity > 256)
                {
                    continue;
                }

                if (!VectorContainsNeedleOccurrence(
                        begin,
                        end,
                        needle,
                        occurrences))
                {
                    continue;
                }

                ++rawVectorHeaders;

                // Recover an enclosing polymorphic object by scanning
                // backward from the vector header. We do not assume the
                // Tile::things offset here.
                for (uintptr_t vectorOffset = 0x10;
                     vectorOffset <= 0xC0;
                     vectorOffset += 8)
                {
                    if (header <
                        vectorOffset)
                    {
                        break;
                    }

                    uintptr_t objectBase =
                        header -
                        vectorOffset;

                    if (!IsReadableMonitorRange(
                            objectBase,
                            0x80))
                    {
                        continue;
                    }

                    uintptr_t vtable =
                        ReadPtr(
                            objectBase
                        );

                    if (!LooksLikeObjectVtable(
                            vtable))
                    {
                        continue;
                    }

                    int score = 100;

                    if (vectorOffset >= 0x20 &&
                        vectorOffset <= 0x90)
                    {
                        score += 40;
                    }

                    if (count <= 16)
                        score += 30;
                    else if (count <= 32)
                        score += 15;

                    if (capacity <= 32)
                        score += 20;

                    TileVectorCandidate candidate{};

                    candidate.objectBase =
                        objectBase;

                    candidate.vectorHeader =
                        header;

                    candidate.vectorOffset =
                        vectorOffset;

                    candidate.begin =
                        begin;

                    candidate.end =
                        end;

                    candidate.cap =
                        cap;

                    candidate.vtable =
                        vtable;

                    candidate.count =
                        count;

                    candidate.capacity =
                        capacity;

                    candidate.score =
                        score;

                    out.push_back(
                        std::move(candidate)
                    );

                    ++polymorphicOwnerHits;
                }
            }

            cursor +=
                got;
        }
    }

    std::cout
        << "[VECTOR DIAG] raw headers containing needle="
        << rawVectorHeaders
        << " | polymorphic owner hits="
        << polymorphicOwnerHits
        << "\n";

    std::fill(
        buffer.begin(),
        buffer.end(),
        0
    );

    std::sort(
        out.begin(),
        out.end(),
        [](
            const TileVectorCandidate& a,
            const TileVectorCandidate& b)
        {
            if (a.score != b.score)
                return a.score > b.score;

            if (a.vectorOffset !=
                b.vectorOffset)
            {
                return
                    a.vectorOffset <
                    b.vectorOffset;
            }

            return
                a.objectBase <
                b.objectBase;
        }
    );

    return out;
}

void PrintTileVectorCandidates(
    const char* label,
    const std::vector<TileVectorCandidate>& candidates)
{
    std::cout
        << "\n============================================================\n"
        << "              TILE VECTOR CANDIDATES - "
        << label
        << "\n"
        << "============================================================\n";

    if (candidates.empty())
    {
        std::cout
            << "Nenhum candidato vetorial polimorfico encontrado.\n";

        return;
    }

    for (size_t i = 0;
         i < candidates.size() &&
         i < 24;
         ++i)
    {
        const auto& c =
            candidates[i];

        std::cout
            << "#"
            << i
            << " score="
            << c.score
            << " object="
            << HexPtr(
                c.objectBase
            )
            << " vectorOff=+"
            << HexU64(
                c.vectorOffset
            )
            << " count="
            << c.count
            << " cap="
            << c.capacity
            << " vtableRva=";

        if (InsideExeImage(
                c.vtable))
        {
            std::cout
                << HexU64(
                    c.vtable -
                    g_exeBase
                );
        }
        else
        {
            std::cout
                << HexPtr(
                    c.vtable
                );
        }

        std::string rtti =
            TryReadMsvcRttiTypeName(
                c.vtable
            );

        if (!rtti.empty())
        {
            std::cout
                << " rtti=\""
                << rtti
                << "\"";
        }

        std::cout
            << "\n";
    }
}


struct TileSemanticStats
{
    bool localFound = false;
    size_t readableEntries = 0;
    size_t plausibleThings = 0;
    size_t matchingPosition = 0;
    size_t mismatchingPosition = 0;
};

TileSemanticStats EvaluateTileCandidatePosition(
    const TileVectorCandidate& candidate,
    const MapPosition& expected,
    const DbProfile& profile,
    uintptr_t localPlayer)
{
    TileSemanticStats stats{};

    size_t limit =
        std::min<size_t>(
            candidate.count,
            64
        );

    for (size_t i = 0;
         i < limit;
         ++i)
    {
        uintptr_t thing =
            ReadPtr(
                candidate.begin +
                i * sizeof(uintptr_t)
            );

        if (!thing)
            continue;

        if (thing ==
            localPlayer)
        {
            stats.localFound = true;
        }

        uintptr_t need =
            std::max<uintptr_t>(
                profile.z + 1,
                0x28
            );

        if (!IsReadableMonitorRange(
                thing,
                need))
        {
            continue;
        }

        ++stats.readableEntries;

        uint32_t x =
            ReadU32(
                thing +
                profile.x
            );

        uint32_t y =
            ReadU32(
                thing +
                profile.y
            );

        uint8_t z =
            ReadU8(
                thing +
                profile.z
            );

        MapPosition p{};
        p.x = x;
        p.y = y;
        p.z = z;

        if (!MapPositionPlausible(
                p))
        {
            continue;
        }

        ++stats.plausibleThings;

        if (SameMapPosition(
                p,
                expected))
        {
            ++stats.matchingPosition;
        }
        else
        {
            ++stats.mismatchingPosition;
        }
    }

    return stats;
}

std::vector<TileVectorCandidate>
FilterTileCandidatesByPosition(
    const char* label,
    const std::vector<TileVectorCandidate>& candidates,
    const MapPosition& expected,
    const DbProfile& profile,
    uintptr_t localPlayer)
{
    std::vector<TileVectorCandidate> out;

    std::cout
        << "\n============================================================\n"
        << "             TILE SEMANTIC FILTER - "
        << label
        << "\n"
        << "============================================================\n"
        << "Expected Position     : "
        << expected.x
        << ","
        << expected.y
        << ","
        << static_cast<unsigned>(
            expected.z
        )
        << "\n";

    for (size_t i = 0;
         i < candidates.size();
         ++i)
    {
        const auto& candidate =
            candidates[i];

        TileSemanticStats stats =
            EvaluateTileCandidatePosition(
                candidate,
                expected,
                profile,
                localPlayer
            );

        bool smallVector =
            candidate.count <= 16 &&
            candidate.capacity <= 64;

        bool positionCoherent =
            stats.localFound &&
            stats.matchingPosition >= 1 &&
            stats.mismatchingPosition == 0;

        const std::string candidateRtti =
            TryReadMsvcRttiTypeName(
                candidate.vtable
            );

        const bool exactTileRtti =
            RttiLooksExactlyLikeTileClass(
                candidateRtti
            );

        // Legacy heuristic: for larger vectors require two matching Things.
        // Semantic exception: when MSVC RTTI proves the owner is exactly
        // Tile, LocalPlayer + exact current Position is already a stronger
        // anchor than guessing another Thing layout.
        if (candidate.count > 8 &&
            stats.matchingPosition < 2 &&
            !exactTileRtti)
        {
            positionCoherent = false;
        }

        bool accepted =
            smallVector &&
            positionCoherent;

        if (i < 32 ||
            accepted)
        {
            std::cout
                << "#"
                << i
                << " off=+"
                << HexU64(
                    candidate.vectorOffset
                )
                << " count="
                << candidate.count
                << " cap="
                << candidate.capacity
                << " local="
                << (
                    stats.localFound
                        ? "YES"
                        : "NO"
                )
                << " plausible="
                << stats.plausibleThings
                << " match="
                << stats.matchingPosition
                << " mismatch="
                << stats.mismatchingPosition
                << " rtti=";

            if (candidateRtti.empty())
                std::cout << "<none>";
            else
                std::cout << "\"" << candidateRtti << "\"";

            std::cout
                << " => "
                << (
                    accepted
                        ? "ACCEPT"
                        : "REJECT"
                )
                << "\n";
        }

        if (!accepted)
            continue;

        TileVectorCandidate copy =
            candidate;

        copy.score += 500;

        if (exactTileRtti)
            copy.score += 1200;

        if (stats.matchingPosition >= 2)
            copy.score += 300;

        if (candidate.count <= 8)
            copy.score += 200;

        if (candidate.count <= 4)
            copy.score += 100;

        copy.score +=
            static_cast<int>(
                stats.matchingPosition *
                50
            );

        out.push_back(
            std::move(copy)
        );
    }

    std::sort(
        out.begin(),
        out.end(),
        [](
            const TileVectorCandidate& a,
            const TileVectorCandidate& b)
        {
            if (a.score != b.score)
                return a.score > b.score;

            if (a.count != b.count)
                return a.count < b.count;

            if (a.vectorOffset !=
                b.vectorOffset)
            {
                return
                    a.vectorOffset <
                    b.vectorOffset;
            }

            return
                a.objectBase <
                b.objectBase;
        }
    );

    std::cout
        << "[SEMANTIC] Accepted "
        << out.size()
        << " / "
        << candidates.size()
        << " candidate(s).\n";

    return out;
}

std::vector<TileLayoutAggregate>
CrossValidateTileVectorLayouts(
    const std::vector<TileVectorCandidate>& localCandidates,
    const std::vector<TileVectorCandidate>& targetCandidates)
{
    std::vector<TileLayoutAggregate> out;

    struct Key
    {
        uintptr_t offset = 0;
        uintptr_t vtable = 0;

        bool operator==(
            const Key& other) const
        {
            return
                offset == other.offset &&
                vtable == other.vtable;
        }
    };

    struct KeyHash
    {
        size_t operator()(
            const Key& key) const
        {
            size_t a =
                std::hash<uintptr_t>{}(
                    key.offset
                );

            size_t b =
                std::hash<uintptr_t>{}(
                    key.vtable
                );

            return
                a ^
                (
                    b +
                    0x9E3779B97F4A7C15ULL +
                    (a << 6) +
                    (a >> 2)
                );
        }
    };

    std::unordered_map<
        Key,
        TileLayoutAggregate,
        KeyHash
    > aggregates;

    for (const auto& local :
         localCandidates)
    {
        for (const auto& target :
             targetCandidates)
        {
            if (local.vectorOffset !=
                target.vectorOffset)
            {
                continue;
            }

            if (local.vtable !=
                target.vtable)
            {
                continue;
            }

            // A global vector containing every Creature would produce the
            // same owner object for both needles. Tile evidence must come
            // from two distinct enclosing objects.
            if (local.objectBase ==
                target.objectBase)
            {
                continue;
            }

            Key key{
                local.vectorOffset,
                local.vtable
            };

            auto& agg =
                aggregates[
                    key
                ];

            if (!agg.pairCount)
            {
                agg.vectorOffset =
                    key.offset;

                agg.vtable =
                    key.vtable;

                agg.localTile =
                    local.objectBase;

                agg.targetTile =
                    target.objectBase;
            }

            ++agg.pairCount;

            agg.score +=
                local.score +
                target.score +
                200;
        }
    }

    for (const auto& kv :
         aggregates)
    {
        out.push_back(
            kv.second
        );
    }

    std::sort(
        out.begin(),
        out.end(),
        [](
            const TileLayoutAggregate& a,
            const TileLayoutAggregate& b)
        {
            // Candidates reaching this stage already passed the semantic
            // position filter. Prefer evidence quality, not combinatorial
            // pair count from a large unrelated vector family.
            if (a.score !=
                b.score)
            {
                return
                    a.score >
                    b.score;
            }

            if (a.pairCount !=
                b.pairCount)
            {
                return
                    a.pairCount >
                    b.pairCount;
            }

            return
                a.vectorOffset <
                b.vectorOffset;
        }
    );

    return out;
}

bool WaitForTileWorldReady(
    const DbProfile& profile,
    uintptr_t localPlayer)
{
    std::cout
        << "\n============================================================\n"
        << "                 WORLD READY GATE\n"
        << "============================================================\n"
        << "A Stage 5A so inicia quando:\n"
        << "  - LocalPlayer Position for valida\n"
        << "  - Map Center for valida\n"
        << "  - Map Center == LocalPlayer Position\n"
        << "  - isso permanecer estavel por varias amostras\n"
        << "\n"
        << "Nenhuma chamada interna sera executada.\n";

    if (!profile.mapRva ||
        !profile.mapCenterX ||
        !profile.mapCenterY ||
        !profile.mapCenterZ)
    {
        std::cout
            << "[STOP] Map profile incompleto para World Ready gate.\n";

        return false;
    }

    uintptr_t mapAddress =
        g_exeBase +
        profile.mapRva;

    int stableSamples = 0;
    MapPosition last{};

    while (true)
    {
        if (GetAsyncKeyState(VK_END) & 0x8000)
            return false;

        uintptr_t currentLocal =
            ResolveProfileLocalPlayerForDiscovery(
                profile
            );

        if (!currentLocal)
        {
            stableSamples = 0;
            Sleep(250);
            continue;
        }

        localPlayer =
            currentLocal;

        MapPosition player =
            ReadDiscoveredPlayerPosition(
                localPlayer,
                profile
            );

        MapPosition center{};

        center.x =
            ReadU32(
                mapAddress +
                profile.mapCenterX
            );

        center.y =
            ReadU32(
                mapAddress +
                profile.mapCenterY
            );

        center.z =
            ReadU8(
                mapAddress +
                profile.mapCenterZ
            );

        bool playerOk =
            MapPositionPlausible(
                player
            );

        bool centerOk =
            MapPositionPlausible(
                center
            );

        bool agree =
            playerOk &&
            centerOk &&
            SameMapPosition(
                player,
                center
            );

        bool sameAsLast =
            agree &&
            stableSamples > 0 &&
            SameMapPosition(
                player,
                last
            );

        if (agree)
        {
            if (stableSamples == 0 ||
                sameAsLast)
            {
                ++stableSamples;
            }
            else
            {
                stableSamples = 1;
            }

            last =
                player;

            std::cout
                << "\r[WORLD] Player/Center="
                << player.x
                << ","
                << player.y
                << ","
                << static_cast<unsigned>(
                    player.z
                )
                << " stable="
                << stableSamples
                << "/4      "
                << std::flush;

            if (stableSamples >= 4)
            {
                std::cout
                    << "\n[WORLD READY] Map Center == LocalPlayer Position estavel.\n"
                    << "[WORLD READY] Aguardando 750ms para estruturas de Tile assentarem...\n";

                Sleep(750);

                // Final confirmation after the settling delay.
                MapPosition playerFinal =
                    ReadDiscoveredPlayerPosition(
                        localPlayer,
                        profile
                    );

                MapPosition centerFinal{};

                centerFinal.x =
                    ReadU32(
                        mapAddress +
                        profile.mapCenterX
                    );

                centerFinal.y =
                    ReadU32(
                        mapAddress +
                        profile.mapCenterY
                    );

                centerFinal.z =
                    ReadU8(
                        mapAddress +
                        profile.mapCenterZ
                    );

                if (MapPositionPlausible(
                        playerFinal) &&
                    MapPositionPlausible(
                        centerFinal) &&
                    SameMapPosition(
                        playerFinal,
                        centerFinal))
                {
                    std::cout
                        << "[WORLD READY] FINAL PASS.\n";

                    return true;
                }

                std::cout
                    << "[WORLD READY] Position mudou durante settle; aguardando novamente.\n";

                stableSamples = 0;
            }
        }
        else
        {
            if (stableSamples != 0)
            {
                std::cout
                    << "\n[WORLD] Player/Center divergiram; resetando estabilidade.\n";
            }

            stableSamples = 0;
        }

        Sleep(250);
    }
}

bool DiscoverTileThings(
    DbProfile& profile)
{
    std::cout
        << "\n============================================================\n"
        << "           STAGE 5A - TILE::THINGS DISCOVERY V5\n"
        << "============================================================\n"
        << "[MODE] READ-ONLY\n"
        << "[NO WRITE] Nenhuma escrita em memoria do jogo\n"
        << "[NO HOOK] Nenhum hook\n"
        << "[NO CALL] Nenhuma funcao interna do jogo\n"
        << "\n"
        << "Metodo corrigido:\n"
        << "  1. usa SOMENTE LocalPlayer* como agulha estavel\n"
        << "  2. captura Player parado no SQM A\n"
        << "  3. voce muda para outro SQM no MESMO andar\n"
        << "  4. captura Player parado no SQM B\n"
        << "  5. reenumera heaps em CADA snapshot\n"
        << "  6. valida que os Thing-like entries pertencem ao SQM atual\n"
        << "  7. exige mesmo vectorOffset + mesma vtable em DOIS objetos diferentes\n"
        << "  8. se houver empate, usa RTTI MSVC para identificar classe Tile\n"
        << "\n"
        << "Isso evita escolher estrutura espelho apenas porque contem os mesmos Things.\n"
        << "Map::getTile NAO sera chamado.\n";

    uintptr_t localPlayer =
        ResolveProfileLocalPlayerForDiscovery(
            profile
        );

    if (!localPlayer)
    {
        std::cout
            << "[STOP] LocalPlayer invalido para Stage 5A.\n";

        return false;
    }

    std::cout
        << "LocalPlayer          : "
        << HexPtr(
            localPlayer
        )
        << "\n";

    std::cout
        << "\n[SCAN] Cada snapshot vai reenumerar os heaps para evitar lista stale apos movimento.\n";

    auto captureStableLocalPlayerCandidates =
        [&](
            const char* label,
            MapPosition& stablePosition)
            -> std::vector<TileVectorCandidate>
        {
            while (true)
            {
                MapPosition before =
                    ReadDiscoveredPlayerPosition(
                        localPlayer,
                        profile
                    );

                if (!MapPositionPlausible(
                        before))
                {
                    std::cout
                        << "[RETRY] Position antes do scan e invalida.\n";

                    Sleep(250);
                    continue;
                }

                std::cout
                    << "\n============================================================\n"
                    << "               TILE SNAPSHOT "
                    << label
                    << "\n"
                    << "============================================================\n"
                    << "Position before      : "
                    << before.x
                    << ","
                    << before.y
                    << ","
                    << static_cast<unsigned>(
                        before.z
                    )
                    << "\n"
                    << "IMPORTANTE: fique PARADO ate o scan terminar.\n";

                auto snapshotRegions =
                    EnumerateTileHeapRegions();

                size_t snapshotBytes = 0;

                for (const auto& region :
                     snapshotRegions)
                {
                    snapshotBytes +=
                        region.size;
                }

                std::cout
                    << "[SCAN] Fresh regions="
                    << snapshotRegions.size()
                    << " total="
                    << (
                        snapshotBytes /
                        (1024 * 1024)
                    )
                    << " MB\n";

                if (snapshotRegions.empty())
                {
                    std::cout
                        << "[RETRY] Nenhuma heap region legivel neste snapshot.\n";

                    Sleep(250);
                    continue;
                }

                auto candidates =
                    FindTileCandidatesByExactRttiAnchor(
                        localPlayer,
                        snapshotRegions
                    );

                if (!candidates.empty())
                {
                    std::cout
                        << "[TILE DISCOVERY] Resolver=exact_rtti_tile_anchor\n";
                }
                else
                {
                    std::cout
                        << "[TILE DISCOVERY] Exact RTTI anchor unavailable; "
                        << "falling back to LocalPlayer needle scan.\n";

                    candidates =
                        FindTileVectorCandidatesForNeedle(
                            localPlayer,
                            snapshotRegions
                        );
                }

                MapPosition after =
                    ReadDiscoveredPlayerPosition(
                        localPlayer,
                        profile
                    );

                std::cout
                    << "Position after       : "
                    << after.x
                    << ","
                    << after.y
                    << ","
                    << static_cast<unsigned>(
                        after.z
                    )
                    << "\n";

                if (!MapPositionPlausible(
                        after))
                {
                    std::cout
                        << "[RETRY] Position depois do scan ficou invalida.\n";

                    continue;
                }

                if (!SameMapPosition(
                        before,
                        after))
                {
                    std::cout
                        << "\n============================================================\n"
                        << "              MOVEMENT DURING SCAN - RETRY\n"
                        << "============================================================\n"
                        << "O Player mudou de Position durante a varredura.\n"
                        << "Esse snapshot foi descartado para evitar misturar Tiles.\n"
                        << "Fique parado durante o proximo scan.\n";

                    WaitEnter(
                        "Quando estiver parado, pressione ENTER para repetir..."
                    );

                    continue;
                }

                stablePosition =
                    after;

                PrintTileVectorCandidates(
                    label,
                    candidates
                );

                auto semantic =
                    FilterTileCandidatesByPosition(
                        label,
                        candidates,
                        after,
                        profile,
                        localPlayer
                    );

                std::cout
                    << "\n[SEMANTIC CANDIDATES] "
                    << semantic.size()
                    << " candidate(s) survived for "
                    << label
                    << ".\n";

                return semantic;
            }
        };

    // --------------------------------------------------------
    // Snapshot A
    // --------------------------------------------------------

    std::cout
        << "\nPASSO A - SQM A\n"
        << "Fique parado em um SQM e nao mude de andar.\n";

    WaitEnter(
        "Quando estiver PARADO no SQM A, pressione ENTER..."
    );

    MapPosition posA{};

    auto candidatesA =
        captureStableLocalPlayerCandidates(
            "LOCALPLAYER / SQM A",
            posA
        );

    if (candidatesA.empty())
    {
        std::cout
            << "\n[RETRY] Nenhum candidato polimorfico no primeiro scan.\n"
            << "Vamos confirmar World Ready novamente e repetir UMA vez.\n";

        if (!WaitForTileWorldReady(
                profile,
                localPlayer))
        {
            profile.tileThingsStatus =
                "unresolved_world_not_ready_retry";

            return false;
        }

        WaitEnter(
            "Fique PARADO no mesmo SQM A e pressione ENTER para o retry..."
        );

        candidatesA =
            captureStableLocalPlayerCandidates(
                "LOCALPLAYER / SQM A RETRY",
                posA
            );

        if (candidatesA.empty())
        {
            profile.tileThingsStatus =
                "unresolved_no_localplayer_vector_A";

            std::cout
                << "[CHECK] Retry tambem nao encontrou owner polimorfico.\n"
                << "Use o [VECTOR DIAG] para separar vector-scan de owner-recovery.\n";

            return false;
        }
    }

    // --------------------------------------------------------
    // Move to B on SAME floor.
    // --------------------------------------------------------

    MapPosition posB{};

    while (true)
    {
        std::cout
            << "\nPASSO B - MUDAR PARA SQM B\n"
            << "Agora ande para OUTRO SQM, mas permanea no MESMO andar Z="
            << static_cast<unsigned>(
                posA.z
            )
            << ".\n"
            << "Depois pare completamente.\n";

        WaitEnter(
            "Quando estiver PARADO no SQM B, pressione ENTER..."
        );

        posB =
            ReadDiscoveredPlayerPosition(
                localPlayer,
                profile
            );

        if (!MapPositionPlausible(
                posB))
        {
            std::cout
                << "[RETRY] Position B invalida.\n";

            continue;
        }

        if (posB.z !=
            posA.z)
        {
            std::cout
                << "[RETRY] Voce mudou de andar: Z A="
                << static_cast<unsigned>(
                    posA.z
                )
                << " Z B="
                << static_cast<unsigned>(
                    posB.z
                )
                << ".\n"
                << "Volte ao mesmo andar do SQM A antes de continuar.\n";

            continue;
        }

        if (SameMapPosition(
                posA,
                posB))
        {
            std::cout
                << "[RETRY] Voce ainda esta no mesmo SQM.\n";

            continue;
        }

        break;
    }

    std::cout
        << "\n[SYNC] Confirmando World Ready novamente depois do movimento A -> B...\n";

    if (!WaitForTileWorldReady(
            profile,
            localPlayer))
    {
        profile.tileThingsStatus =
            "unresolved_world_not_ready_B";

        return false;
    }

    Sleep(500);

    // --------------------------------------------------------
    // Snapshot B
    // --------------------------------------------------------

    auto candidatesB =
        captureStableLocalPlayerCandidates(
            "LOCALPLAYER / SQM B",
            posB
        );

    if (candidatesB.empty())
    {
        profile.tileThingsStatus =
            "unresolved_no_localplayer_vector_B";

        std::cout
            << "[CHECK] Nenhum candidato encontrado no SQM B.\n";

        return false;
    }

    std::cout
        << "\n[POSITION TRANSITION]\n"
        << "SQM A                : "
        << posA.x
        << ","
        << posA.y
        << ","
        << static_cast<unsigned>(
            posA.z
        )
        << "\n"
        << "SQM B                : "
        << posB.x
        << ","
        << posB.y
        << ","
        << static_cast<unsigned>(
            posB.z
        )
        << "\n";

    // The existing cross-validator already requires:
    // - same vector offset
    // - same vtable
    // - two DIFFERENT enclosing objects.
    auto layouts =
        CrossValidateTileVectorLayouts(
            candidatesA,
            candidatesB
        );

    std::cout
        << "\n============================================================\n"
        << "          TILE LAYOUT CROSS-VALIDATION A -> B\n"
        << "============================================================\n";

    for (size_t i = 0;
         i < layouts.size() &&
         i < 16;
         ++i)
    {
        const auto& layout =
            layouts[i];

        std::cout
            << "#"
            << i
            << " pairs="
            << layout.pairCount
            << " score="
            << layout.score
            << " vectorOffset=+"
            << HexU64(
                layout.vectorOffset
            )
            << " vtableRva=";

        if (InsideExeImage(
                layout.vtable))
        {
            std::cout
                << HexU64(
                    layout.vtable -
                    g_exeBase
                );
        }
        else
        {
            std::cout
                << HexPtr(
                    layout.vtable
                );
        }

        std::string rttiName =
            TryReadMsvcRttiTypeName(
                layout.vtable
            );

        std::cout
            << " objectA="
            << HexPtr(
                layout.localTile
            )
            << " objectB="
            << HexPtr(
                layout.targetTile
            )
            << " rtti=";

        if (rttiName.empty())
        {
            std::cout
                << "<unavailable>";
        }
        else
        {
            std::cout
                << "\""
                << rttiName
                << "\"";
        }

        std::cout
            << "\n";
    }

    if (layouts.empty())
    {
        profile.tileThingsStatus =
            "unresolved_no_cross_validated_layout";

        std::cout
            << "[CHECK] Nenhum layout comum apareceu nos dois SQMs.\n"
            << "Nao vamos promover offset por palpite.\n";

        return false;
    }

    size_t selectedLayout =
        0;

    bool uniqueStrong =
        layouts.size() == 1 ||
        layouts[0].score >=
            layouts[1].score + 150;

    if (!uniqueStrong)
    {
        std::cout
            << "\n============================================================\n"
            << "                 RTTI SEMANTIC RESOLUTION\n"
            << "============================================================\n"
            << "Mais de um layout estrutural permaneceu.\n"
            << "Tentando identificar semanticamente a classe owner pela RTTI MSVC.\n";

        std::vector<size_t>
            exactTileMatches;

        std::vector<size_t>
            anyTileTokenMatches;

        for (size_t i = 0;
             i < layouts.size();
             ++i)
        {
            std::string rtti =
                TryReadMsvcRttiTypeName(
                    layouts[i].vtable
                );

            std::cout
                << "#"
                << i
                << " off=+"
                << HexU64(
                    layouts[i].vectorOffset
                )
                << " vtableRva=";

            if (InsideExeImage(
                    layouts[i].vtable))
            {
                std::cout
                    << HexU64(
                        layouts[i].vtable -
                        g_exeBase
                    );
            }
            else
            {
                std::cout
                    << HexPtr(
                        layouts[i].vtable
                    );
            }

            std::cout
                << " rtti=";

            if (rtti.empty())
                std::cout << "<unavailable>";
            else
                std::cout << "\"" << rtti << "\"";

            bool exactTile =
                RttiLooksExactlyLikeTileClass(
                    rtti
                );

            bool tileToken =
                RttiContainsTileToken(
                    rtti
                );

            if (exactTile)
            {
                exactTileMatches.push_back(
                    i
                );

                std::cout
                    << "  <EXACT TILE CLASS>";
            }
            else if (tileToken)
            {
                anyTileTokenMatches.push_back(
                    i
                );

                std::cout
                    << "  <TILE TOKEN ONLY>";
            }

            std::cout
                << "\n";
        }

        if (exactTileMatches.size() == 1)
        {
            selectedLayout =
                exactTileMatches[0];

            uniqueStrong = true;

            std::cout
                << "[RTTI] UNIQUE exact Tile class -> candidate #"
                << selectedLayout
                << "\n";
        }
        else
        {
            profile.tileThingsStatus =
                "ambiguous_cross_validated_layout_rtti";

            std::cout
                << "[CHECK] RTTI nao produziu uma unica classe Tile exata.\n"
                << "Nenhum offset sera promovido por nome parcial ou ranking.\n";

            return false;
        }
    }

    const TileLayoutAggregate&
        selected =
            layouts[
                selectedLayout
            ];

    profile.tileThingsBegin =
        selected.vectorOffset;

    profile.tileThingsEnd =
        selected.vectorOffset +
        sizeof(uintptr_t);

    profile.tileThingsCap =
        selected.vectorOffset +
        2 * sizeof(uintptr_t);

    if (InsideExeImage(
            selected.vtable))
    {
        profile.tileVtableRva =
            selected.vtable -
            g_exeBase;

        profile.tileRttiName =
            TryReadMsvcRttiTypeName(
                selected.vtable
            );

        if (profile.tileRttiName.empty())
            profile.tileRttiName = "unavailable";
    }

    profile.tileThingsStatus =
        "confirmed_runtime_localplayer_two_tiles";

    std::cout
        << "\n============================================================\n"
        << "               TILE::THINGS DISCOVERED\n"
        << "============================================================\n"
        << "Things begin offset : +"
        << HexU64(
            profile.tileThingsBegin
        )
        << "\n"
        << "Things end offset   : +"
        << HexU64(
            profile.tileThingsEnd
        )
        << "\n"
        << "Things cap offset   : +"
        << HexU64(
            profile.tileThingsCap
        )
        << "\n"
        << "Tile VTable RVA     : "
        << HexU64(
            profile.tileVtableRva
        )
        << "\n"
        << "Tile RTTI           : "
        << profile.tileRttiName
        << "\n"
        << "Evidence            : mesmo LocalPlayer* em dois Tile-like objects distintos\n"
        << "                      mesmo vectorOffset + mesma vtable\n"
        << "Status              : "
        << profile.tileThingsStatus
        << "\n";

    // Ground truth is used ONLY after discovery.
    const bool knownBenchmarkBuild =
        profile.timestamp == 0x6AA9FA57ULL &&
        profile.sizeOfImage == 0x17BF000ULL &&
        profile.textHash == 0x89D3D35243890EA2ULL;

    if (knownBenchmarkBuild)
    {
        const bool beginMatch =
            profile.tileThingsBegin ==
            0x48;

        const bool endMatch =
            profile.tileThingsEnd ==
            0x50;

        const bool capMatch =
            profile.tileThingsCap ==
            0x58;

        std::cout
            << "\n[GROUND TRUTH COMPARISON]\n"
            << "Known B/E/C         : +0x48 / +0x50 / +0x58\n"
            << "Begin match         : "
            << (
                beginMatch
                    ? "PASS"
                    : "FAIL"
            )
            << "\n"
            << "End match           : "
            << (
                endMatch
                    ? "PASS"
                    : "FAIL"
            )
            << "\n"
            << "Cap match           : "
            << (
                capMatch
                    ? "PASS"
                    : "FAIL"
            )
            << "\n";

        if (beginMatch &&
            endMatch &&
            capMatch)
        {
            profile.tileThingsStatus =
                "discovered_runtime_selfcheck_pass";

            std::cout
                << "\n[FEITO] STAGE 5A redescobriu Tile::things usando LocalPlayer em dois SQMs.\n";
        }
        else
        {
            profile.tileThingsStatus =
                "discovered_runtime_selfcheck_mismatch";

            profile.tileThingsBegin = 0;
            profile.tileThingsEnd = 0;
            profile.tileThingsCap = 0;

            std::cout
                << "[PRESERVE] Self-check falhou; layout Tile nao sera promovido.\n";
        }
    }

    return
        profile.tileThingsStatus ==
            "discovered_runtime_selfcheck_pass" ||
        profile.tileThingsStatus ==
            "confirmed_runtime_localplayer_two_tiles";
}

bool EnsureTileThingsDiscovery(
    DbProfile& profile,
    std::vector<DbProfile>& database,
    int profileIndex,
    const std::string& databasePath)
{
    if (profile.tileThingsBegin &&
        profile.tileThingsEnd &&
        profile.tileThingsCap &&
        profile.tileVtableRva &&
        (
            profile.tileThingsStatus ==
                "discovered_runtime_selfcheck_pass" ||
            profile.tileThingsStatus ==
                "confirmed_runtime_localplayer_two_tiles"
        ))
    {
        std::cout
            << "\n[FEITO] STAGE 5A - Tile::things ja passou self-check.\n"
            << "B/E/C         : +"
            << HexU64(
                profile.tileThingsBegin
            )
            << " / +"
            << HexU64(
                profile.tileThingsEnd
            )
            << " / +"
            << HexU64(
                profile.tileThingsCap
            )
            << "\n";

        return true;
    }

    uintptr_t localPlayer =
        WaitForDiscoveryLocalPlayer(
            profile,
            "STAGE 5A - TILE::THINGS"
        );

    if (!localPlayer)
    {
        std::cout
            << "\n[STAGE 5A] Cancelada antes do login.\n";

        return false;
    }

    if (!WaitForTileWorldReady(
            profile,
            localPlayer))
    {
        std::cout
            << "\n[STAGE 5A] World Ready gate nao fechou.\n";

        return false;
    }

    if (profile.tileThingsStatus !=
            "discovered_runtime_selfcheck_pass")
    {
        profile.tileThingsBegin = 0;
        profile.tileThingsEnd = 0;
        profile.tileThingsCap = 0;
        profile.tileThingsStatus =
            "rediscovery_running";
    }

    bool ok =
        DiscoverTileThings(
            profile
        );

    if (profileIndex >= 0 &&
        profileIndex <
            static_cast<int>(
                database.size()
            ))
    {
        database[
            static_cast<size_t>(
                profileIndex
            )
        ] = profile;

        SaveProfileDatabase(
            databasePath,
            database
        );
    }

    return ok;
}


// ============================================================
// DISCOVERY V2.4 - MAP -> TILE PROVENANCE RECON
// Strict read-only. No Map::getTile call.
// ============================================================

struct TilePathNode
{
    uintptr_t address = 0;
    int depth = 0;
    std::vector<uintptr_t> offsets;
};

struct TilePathHit
{
    std::vector<uintptr_t> offsets;
    uintptr_t holderAddress = 0;
    uintptr_t slotAddress = 0;
};


std::vector<TileVectorCandidate>
FindTileCandidatesByKnownVtableReadOnly(
    const DbProfile& profile,
    uintptr_t localPlayer,
    const MapPosition& expectedPosition)
{
    std::vector<TileVectorCandidate>
        candidates;

    if (!profile.tileVtableRva ||
        !profile.tileThingsBegin ||
        !profile.tileThingsEnd ||
        !profile.tileThingsCap)
    {
        return candidates;
    }

    uintptr_t tileVtable =
        g_exeBase +
        profile.tileVtableRva;

    if (!InsideExeImage(
            tileVtable))
    {
        return candidates;
    }

    std::string rtti =
        TryReadMsvcRttiTypeName(
            tileVtable
        );

    std::cout
        << "[TYPED TILE SCAN] VTable RVA="
        << HexU64(
            profile.tileVtableRva
        )
        << " RTTI=";

    if (rtti.empty())
        std::cout << "<unavailable>";
    else
        std::cout << "\"" << rtti << "\"";

    std::cout
        << "\n";

    auto regions =
        EnumerateTileHeapRegions();

    const size_t chunkSize =
        4 * 1024 * 1024;

    std::vector<uint8_t>
        buffer(
            chunkSize
        );

    size_t rawVtableHits = 0;

    for (const auto& region :
         regions)
    {
        uintptr_t cursor =
            region.base;

        uintptr_t regionEnd =
            region.base +
            region.size;

        while (cursor <
               regionEnd)
        {
            size_t want =
                static_cast<size_t>(
                    std::min<uintptr_t>(
                        chunkSize,
                        regionEnd -
                        cursor
                    )
                );

            size_t got = 0;

            if (!ReadProcessChunk(
                    cursor,
                    buffer.data(),
                    want,
                    got))
            {
                cursor += want;
                continue;
            }

            uintptr_t aligned =
                (cursor + 7) &
                ~static_cast<uintptr_t>(7);

            size_t start =
                static_cast<size_t>(
                    aligned -
                    cursor
                );

            for (size_t off = start;
                 off + sizeof(uintptr_t) <= got;
                 off += sizeof(uintptr_t))
            {
                uintptr_t value = 0;

                std::memcpy(
                    &value,
                    buffer.data() +
                        off,
                    sizeof(value)
                );

                if (value !=
                    tileVtable)
                {
                    continue;
                }

                ++rawVtableHits;

                uintptr_t object =
                    cursor +
                    off;

                if (!IsReadableMonitorRange(
                        object,
                        profile.tileThingsCap +
                            sizeof(uintptr_t)))
                {
                    continue;
                }

                uintptr_t begin =
                    ReadPtr(
                        object +
                        profile.tileThingsBegin
                    );

                uintptr_t end =
                    ReadPtr(
                        object +
                        profile.tileThingsEnd
                    );

                uintptr_t cap =
                    ReadPtr(
                        object +
                        profile.tileThingsCap
                    );

                if (!begin ||
                    !end ||
                    !cap ||
                    end < begin ||
                    cap < end ||
                    (begin & 7) ||
                    (end & 7) ||
                    (cap & 7))
                {
                    continue;
                }

                uintptr_t used =
                    end -
                    begin;

                uintptr_t capacityBytes =
                    cap -
                    begin;

                if (used %
                        sizeof(uintptr_t) !=
                    0 ||
                    capacityBytes %
                        sizeof(uintptr_t) !=
                    0)
                {
                    continue;
                }

                size_t count =
                    static_cast<size_t>(
                        used /
                        sizeof(uintptr_t)
                    );

                size_t capacity =
                    static_cast<size_t>(
                        capacityBytes /
                        sizeof(uintptr_t)
                    );

                if (count == 0 ||
                    count > 256 ||
                    capacity < count ||
                    capacity > 512)
                {
                    continue;
                }

                bool hasLocalPlayer =
                    false;

                for (size_t i = 0;
                     i < count;
                     ++i)
                {
                    uintptr_t thing =
                        ReadPtr(
                            begin +
                            i *
                            sizeof(uintptr_t)
                        );

                    if (thing ==
                        localPlayer)
                    {
                        hasLocalPlayer =
                            true;

                        break;
                    }
                }

                if (!hasLocalPlayer)
                    continue;

                TileVectorCandidate c{};

                c.objectBase =
                    object;

                c.vectorHeader =
                    object +
                    profile.tileThingsBegin;

                c.vectorOffset =
                    profile.tileThingsBegin;

                c.begin =
                    begin;

                c.end =
                    end;

                c.cap =
                    cap;

                c.vtable =
                    tileVtable;

                c.count =
                    count;

                c.capacity =
                    capacity;

                c.score =
                    3000 -
                    static_cast<int>(
                        capacity -
                        count
                    );

                candidates.push_back(
                    c
                );
            }

            cursor += got;
        }
    }

    std::cout
        << "[TYPED TILE SCAN] raw vtable hits="
        << rawVtableHits
        << " local-containing objects="
        << candidates.size()
        << "\n";

    if (candidates.empty())
        return candidates;

    return
        FilterTileCandidatesByPosition(
            "CURRENT TILE / KNOWN RTTI+VTABLE",
            candidates,
            expectedPosition,
            profile,
            localPlayer
        );
}

uintptr_t FindCurrentTileByKnownTypeReadOnly(
    const DbProfile& profile,
    uintptr_t localPlayer,
    const MapPosition& expectedPosition)
{
    if (!profile.tileVtableRva)
        return 0;

    auto semantic =
        FindTileCandidatesByKnownVtableReadOnly(
            profile,
            localPlayer,
            expectedPosition
        );

    std::vector<TileVectorCandidate>
        exact;

    for (const auto& c :
         semantic)
    {
        if (c.vectorOffset !=
            profile.tileThingsBegin)
        {
            continue;
        }

        if (ReadPtr(
                c.objectBase) !=
            g_exeBase +
                profile.tileVtableRva)
        {
            continue;
        }

        exact.push_back(
            c
        );
    }

    if (exact.empty())
        return 0;

    std::sort(
        exact.begin(),
        exact.end(),
        [](
            const TileVectorCandidate& a,
            const TileVectorCandidate& b)
        {
            if (a.score != b.score)
                return a.score > b.score;

            if (a.count != b.count)
                return a.count < b.count;

            return
                a.objectBase <
                b.objectBase;
        }
    );

    if (exact.size() > 1)
    {
        bool clear =
            exact[0].score >=
                exact[1].score + 100 ||
            exact[0].count <
                exact[1].count;

        if (!clear)
        {
            std::cout
                << "[TYPED TILE SCAN] "
                << exact.size()
                << " current-Tile candidates remain; not guessing.\n";

            return 0;
        }
    }

    const auto& best =
        exact[0];

    std::cout
        << "[TYPED TILE SCAN] CURRENT TILE CONFIRMED object="
        << HexPtr(
            best.objectBase
        )
        << " things="
        << best.count
        << " vtableRva="
        << HexU64(
            profile.tileVtableRva
        )
        << "\n";

    return
        best.objectBase;
}


uintptr_t FindCurrentTileObjectReadOnly(
    const DbProfile& profile,
    uintptr_t localPlayer,
    MapPosition& positionOut)
{
    positionOut =
        ReadDiscoveredPlayerPosition(
            localPlayer,
            profile
        );

    if (!MapPositionPlausible(
            positionOut))
    {
        return 0;
    }

    if (profile.tileVtableRva)
    {
        uintptr_t typedTile =
            FindCurrentTileByKnownTypeReadOnly(
                profile,
                localPlayer,
                positionOut
            );

        if (typedTile)
        {
            std::cout
                << "[TILE SEED] Resolver=known_tile_vtable_rtti\n";

            return
                typedTile;
        }

        std::cout
            << "[TILE SEED] Typed resolver did not close uniquely; "
            << "falling back to legacy LocalPlayer needle scan.\n";
    }

    auto regions =
        EnumerateTileHeapRegions();

    if (regions.empty())
        return 0;

    auto candidates =
        FindTileVectorCandidatesForNeedle(
            localPlayer,
            regions
        );

    auto semantic =
        FilterTileCandidatesByPosition(
            "CURRENT TILE PATH SEED",
            candidates,
            positionOut,
            profile,
            localPlayer
        );

    std::vector<TileVectorCandidate>
        exactLayout;

    for (const auto& candidate :
         semantic)
    {
        if (candidate.vectorOffset !=
            profile.tileThingsBegin)
        {
            continue;
        }

        if (candidate.end !=
            candidate.begin +
            candidate.count *
                sizeof(uintptr_t))
        {
            continue;
        }

        exactLayout.push_back(
            candidate
        );
    }

    if (exactLayout.empty())
    {
        std::cout
            << "[TILE SEED] Nenhum Tile atual fechou com o layout aprendido.\n";

        return 0;
    }

    std::sort(
        exactLayout.begin(),
        exactLayout.end(),
        [](
            const TileVectorCandidate& a,
            const TileVectorCandidate& b)
        {
            if (a.count != b.count)
                return a.count < b.count;

            if (a.capacity != b.capacity)
                return a.capacity < b.capacity;

            return a.score > b.score;
        }
    );

    // If several objects with the exact same learned layout survive,
    // do not silently pick by address. Require the best to be structurally
    // tighter than the next one, or the list to be unique.
    if (exactLayout.size() > 1)
    {
        const auto& a =
            exactLayout[0];

        const auto& b =
            exactLayout[1];

        bool clear =
            a.count < b.count ||
            a.capacity < b.capacity ||
            a.score >= b.score + 200;

        if (!clear)
        {
            std::cout
                << "[TILE SEED] Mais de um Tile-like exato permaneceu.\n";

            for (size_t i = 0;
                 i < exactLayout.size() &&
                 i < 8;
                 ++i)
            {
                std::cout
                    << "  #"
                    << i
                    << " object="
                    << HexPtr(
                        exactLayout[i].objectBase
                    )
                    << " off=+"
                    << HexU64(
                        exactLayout[i].vectorOffset
                    )
                    << " count="
                    << exactLayout[i].count
                    << " cap="
                    << exactLayout[i].capacity
                    << "\n";
            }

            return 0;
        }
    }

    const auto& best =
        exactLayout[0];

    std::cout
        << "\n[TILE SEED]\n"
        << "Position             : "
        << positionOut.x
        << ","
        << positionOut.y
        << ","
        << static_cast<unsigned>(
            positionOut.z
        )
        << "\n"
        << "Tile object          : "
        << HexPtr(
            best.objectBase
        )
        << "\n"
        << "Tile vtable RVA      : ";

    if (InsideExeImage(
            best.vtable))
    {
        std::cout
            << HexU64(
                best.vtable -
                g_exeBase
            );
    }
    else
    {
        std::cout
            << HexPtr(
                best.vtable
            );
    }

    std::cout
        << "\n"
        << "Things B/E/C         : +"
        << HexU64(
            profile.tileThingsBegin
        )
        << " / +"
        << HexU64(
            profile.tileThingsEnd
        )
        << " / +"
        << HexU64(
            profile.tileThingsCap
        )
        << "\n"
        << "Thing count          : "
        << best.count
        << "\n";

    uintptr_t tileResult =
        best.objectBase;

    auto scrubCandidates =
        [](
            std::vector<TileVectorCandidate>& values)
        {
            for (auto& c :
                 values)
            {
                c.objectBase = 0;
                c.vectorHeader = 0;
                c.vectorOffset = 0;
                c.begin = 0;
                c.end = 0;
                c.cap = 0;
                c.vtable = 0;
                c.count = 0;
                c.capacity = 0;
                c.score = 0;
            }

            values.clear();
            values.shrink_to_fit();
        };

    scrubCandidates(
        exactLayout
    );

    scrubCandidates(
        semantic
    );

    scrubCandidates(
        candidates
    );

    return
        tileResult;
}

// Legacy exact-reference scanner kept below for comparison.
// V2.4.2 uses the clean scanner further down.
std::vector<uintptr_t>
FindExactPointerOccurrencesReadOnly(
    uintptr_t needle,
    size_t maxHits = 4096)
{
    std::vector<uintptr_t> hits;

    if (!needle)
        return hits;

    auto regions =
        EnumerateTileHeapRegions();

    const size_t chunkSize =
        4 * 1024 * 1024;

    std::vector<uint8_t> buffer(
        chunkSize
    );

    for (const auto& region :
         regions)
    {
        uintptr_t cursor =
            region.base;

        uintptr_t end =
            region.base +
            region.size;

        while (cursor <
               end)
        {
            size_t want =
                static_cast<size_t>(
                    std::min<uintptr_t>(
                        chunkSize,
                        end -
                        cursor
                    )
                );

            size_t got = 0;

            if (!ReadProcessChunk(
                    cursor,
                    buffer.data(),
                    want,
                    got))
            {
                cursor += want;
                continue;
            }

            uintptr_t aligned =
                (cursor + 7) &
                ~static_cast<uintptr_t>(7);

            size_t start =
                static_cast<size_t>(
                    aligned -
                    cursor
                );

            for (size_t off = start;
                 off + sizeof(uintptr_t) <= got;
                 off += sizeof(uintptr_t))
            {
                uintptr_t value = 0;

                std::memcpy(
                    &value,
                    buffer.data() +
                        off,
                    sizeof(value)
                );

                if (value !=
                    needle)
                {
                    continue;
                }

                hits.push_back(
                    cursor +
                    off
                );

                if (hits.size() >=
                    maxHits)
                {
                    return hits;
                }
            }

            cursor += got;
        }
    }

    return hits;
}

void PrintTileReferenceNeighborhood(
    uintptr_t occurrence,
    uintptr_t tile)
{
    uintptr_t begin =
        occurrence >= 0x30
            ? occurrence - 0x30
            : occurrence;

    begin &=
        ~static_cast<uintptr_t>(7);

    std::cout
        << "  ref@"
        << HexPtr(
            occurrence
        )
        << " neighborhood:";

    for (uintptr_t p = begin;
         p <= occurrence + 0x30;
         p += 8)
    {
        uintptr_t q =
            ReadPtr(
                p
            );

        std::cout
            << " ["
            << (
                static_cast<long long>(
                    p
                ) -
                static_cast<long long>(
                    occurrence
                )
            )
            << "]="
            << HexPtr(
                q
            );

        if (q ==
            tile)
        {
            std::cout
                << "<TILE>";
        }
    }

    std::cout
        << "\n";
}

std::vector<TilePathHit>
FindMapToTilePointerPaths(
    uintptr_t map,
    uintptr_t tile)
{
    std::vector<TilePathHit> hits;

    if (!map ||
        !tile)
    {
        return hits;
    }

    const int maxDepth = 5;
    const size_t maxNodes = 6000;
    const uintptr_t rootScanBytes = 0x340;
    const uintptr_t childScanBytes = 0x180;

    std::vector<TilePathNode> queue;
    queue.reserve(
        maxNodes
    );

    std::unordered_set<uintptr_t>
        visited;

    TilePathNode root{};
    root.address = map;
    root.depth = 0;

    queue.push_back(
        root
    );

    visited.insert(
        map
    );

    size_t cursor = 0;

    while (cursor <
               queue.size() &&
           queue.size() <=
               maxNodes)
    {
        TilePathNode node =
            queue[
                cursor++
            ];

        uintptr_t scanBytes =
            node.depth == 0
                ? rootScanBytes
                : childScanBytes;

        for (uintptr_t off = 0;
             off + sizeof(uintptr_t) <=
                 scanBytes;
             off += 8)
        {
            uintptr_t slot =
                node.address +
                off;

            uintptr_t value =
                ReadPtr(
                    slot
                );

            if (!value)
                continue;

            if (value ==
                tile)
            {
                TilePathHit hit{};

                hit.offsets =
                    node.offsets;

                hit.offsets.push_back(
                    off
                );

                hit.holderAddress =
                    node.address;

                hit.slotAddress =
                    slot;

                hits.push_back(
                    std::move(hit)
                );

                continue;
            }

            if (node.depth >=
                maxDepth)
            {
                continue;
            }

            if (!IsReadablePrivatePointer(
                    value))
            {
                continue;
            }

            if (value ==
                    node.address ||
                value ==
                    map)
            {
                continue;
            }

            if (!visited.insert(
                    value).second)
            {
                continue;
            }

            if (queue.size() >=
                maxNodes)
            {
                break;
            }

            TilePathNode next{};

            next.address =
                value;

            next.depth =
                node.depth + 1;

            next.offsets =
                node.offsets;

            next.offsets.push_back(
                off
            );

            queue.push_back(
                std::move(next)
            );
        }
    }

    std::cout
        << "[GRAPH] visited nodes="
        << visited.size()
        << " queued="
        << queue.size()
        << " hits="
        << hits.size()
        << "\n";

    return hits;
}

void PrintMapTilePath(
    const TilePathHit& hit,
    size_t index)
{
    std::cout
        << "Path #"
        << index
        << " : Map";

    for (size_t i = 0;
         i < hit.offsets.size();
         ++i)
    {
        std::cout
            << " -> [+"
            << HexU64(
                hit.offsets[i]
            )
            << "]";

        if (i + 1 <
            hit.offsets.size())
        {
            std::cout
                << "*";
        }
    }

    std::cout
        << " -> Tile*"
        << " | holder="
        << HexPtr(
            hit.holderAddress
        )
        << " slot="
        << HexPtr(
            hit.slotAddress
        )
        << "\n";
}


struct CleanScanRange
{
    uintptr_t begin = 0;
    uintptr_t end = 0;
};

struct TilePointerRun
{
    uintptr_t begin = 0;
    uintptr_t end = 0;
    uintptr_t occurrence = 0;
    size_t slotIndex = 0;
    size_t tileCount = 0;

    size_t stride = sizeof(uintptr_t);
    size_t companionMatches = 0;

    std::string storageMode =
        "raw_pointer_array";
};

struct TileArrayHeaderCandidate
{
    uintptr_t header = 0;
    uintptr_t begin = 0;
    uintptr_t end = 0;
    uintptr_t cap = 0;
    size_t count = 0;
    size_t capacity = 0;
};

struct MapArrayProvenanceCandidate
{
    int depth = 0;

    uintptr_t mapOffset = 0;
    uintptr_t childOffset = 0;

    uintptr_t owner = 0;
    uintptr_t header = 0;
    uintptr_t headerOffset = 0;

    size_t count = 0;
    size_t capacity = 0;
};

bool AddressInsideCleanRange(
    uintptr_t address,
    const CleanScanRange& range)
{
    return
        range.begin &&
        address >= range.begin &&
        address < range.end;
}

CleanScanRange CurrentThreadStackRegion()
{
    CleanScanRange out{};

    uintptr_t marker =
        reinterpret_cast<uintptr_t>(
            &out
        );

    MEMORY_BASIC_INFORMATION mbi{};

    if (VirtualQuery(
            reinterpret_cast<const void*>(
                marker
            ),
            &mbi,
            sizeof(mbi)))
    {
        out.begin =
            reinterpret_cast<uintptr_t>(
                mbi.BaseAddress
            );

        out.end =
            out.begin +
            static_cast<uintptr_t>(
                mbi.RegionSize
            );
    }

    return out;
}

std::vector<uintptr_t>
FindExactPointerOccurrencesClean(
    uintptr_t needle,
    size_t maxHits = 8192)
{
    std::vector<uintptr_t> hits;

    if (!needle)
        return hits;

    const size_t chunkSize =
        4 * 1024 * 1024;

    void* scratchRaw =
        VirtualAlloc(
            nullptr,
            chunkSize,
            MEM_COMMIT | MEM_RESERVE,
            PAGE_READWRITE
        );

    if (!scratchRaw)
    {
        std::cout
            << "[CLEAN SCAN] VirtualAlloc scratch failed.\n";

        return hits;
    }

    auto* scratch =
        reinterpret_cast<uint8_t*>(
            scratchRaw
        );

    CleanScanRange scratchRange{
        reinterpret_cast<uintptr_t>(
            scratchRaw
        ),
        reinterpret_cast<uintptr_t>(
            scratchRaw
        ) +
        chunkSize
    };

    CleanScanRange stackRange =
        CurrentThreadStackRegion();

    auto regions =
        EnumerateTileHeapRegions();

    size_t scannedBytes = 0;

    for (const auto& region :
         regions)
    {
        uintptr_t regionEnd =
            region.base +
            region.size;

        if (region.base <
                scratchRange.end &&
            regionEnd >
                scratchRange.begin)
        {
            continue;
        }

        if (region.base <
                stackRange.end &&
            regionEnd >
                stackRange.begin)
        {
            continue;
        }

        uintptr_t cursor =
            region.base;

        while (cursor <
               regionEnd)
        {
            size_t want =
                static_cast<size_t>(
                    std::min<uintptr_t>(
                        chunkSize,
                        regionEnd -
                        cursor
                    )
                );

            SIZE_T got = 0;

            BOOL ok =
                ReadProcessMemory(
                    GetCurrentProcess(),
                    reinterpret_cast<const void*>(
                        cursor
                    ),
                    scratch,
                    want,
                    &got
                );

            if (!ok ||
                !got)
            {
                cursor +=
                    want;

                continue;
            }

            scannedBytes +=
                static_cast<size_t>(
                    got
                );

            uintptr_t aligned =
                (cursor + 7) &
                ~static_cast<uintptr_t>(7);

            size_t start =
                static_cast<size_t>(
                    aligned -
                    cursor
                );

            for (size_t off = start;
                 off + sizeof(uintptr_t) <=
                    static_cast<size_t>(got);
                 off += 8)
            {
                uintptr_t value = 0;

                std::memcpy(
                    &value,
                    scratch + off,
                    sizeof(value)
                );

                if (value !=
                    needle)
                {
                    continue;
                }

                uintptr_t address =
                    cursor +
                    off;

                if (AddressInsideCleanRange(
                        address,
                        scratchRange) ||
                    AddressInsideCleanRange(
                        address,
                        stackRange))
                {
                    continue;
                }

                hits.push_back(
                    address
                );

                if (hits.size() >=
                    maxHits)
                {
                    SecureZeroMemory(
                        scratch,
                        chunkSize
                    );

                    VirtualFree(
                        scratchRaw,
                        0,
                        MEM_RELEASE
                    );

                    return hits;
                }
            }

            cursor +=
                static_cast<uintptr_t>(
                    got
                );
        }
    }

    SecureZeroMemory(
        scratch,
        chunkSize
    );

    VirtualFree(
        scratchRaw,
        0,
        MEM_RELEASE
    );

    std::cout
        << "[CLEAN SCAN] scanned="
        << (
            scannedBytes /
            (1024 * 1024)
        )
        << " MB hits="
        << hits.size()
        << "\n";

    return hits;
}

bool LooksLikeSameTileClassObject(
    uintptr_t object,
    uintptr_t tileVtable)
{
    if (!object ||
        !tileVtable)
    {
        return false;
    }

    if (!IsReadableMonitorRange(
            object,
            0x10))
    {
        return false;
    }

    return
        ReadPtr(
            object
        ) ==
        tileVtable;
}

bool LooksLikeSharedPtrControlBlock(
    uintptr_t control)
{
    if (!control ||
        !IsReadableMonitorRange(
            control,
            sizeof(uintptr_t)))
    {
        return false;
    }

    uintptr_t vt =
        ReadPtr(
            control
        );

    if (!InsideExeImage(
            vt))
    {
        return false;
    }

    std::string rtti =
        LowerAscii(
            TryReadMsvcRttiTypeName(
                vt
            )
        );

    if (rtti.empty())
        return true;

    return
        rtti.find(
            "_ref_count") !=
            std::string::npos ||
        rtti.find(
            "tile") !=
            std::string::npos;
}

TilePointerRun ExpandTilePointerRunStrided(
    uintptr_t occurrence,
    uintptr_t tile,
    uintptr_t tileVtable,
    size_t stride)
{
    TilePointerRun run{};

    if (!occurrence ||
        !tile ||
        !tileVtable ||
        (
            stride != 8 &&
            stride != 16
        ))
    {
        return run;
    }

    const size_t maxSide =
        4096;

    auto sameTileAt =
        [&](
            uintptr_t address)
        {
            uintptr_t value =
                ReadPtr(
                    address
                );

            return
                LooksLikeSameTileClassObject(
                    value,
                    tileVtable
                );
        };

    uintptr_t begin =
        occurrence;

    uintptr_t end =
        occurrence +
        stride;

    size_t leftSteps = 0;

    while (leftSteps <
           maxSide &&
           begin >= stride)
    {
        uintptr_t previous =
            begin -
            stride;

        if (!sameTileAt(
                previous))
        {
            break;
        }

        begin =
            previous;

        ++leftSteps;
    }

    size_t rightSteps = 0;

    while (rightSteps <
           maxSide)
    {
        if (!sameTileAt(
                end))
        {
            break;
        }

        end +=
            stride;

        ++rightSteps;
    }

    size_t count = 0;
    size_t companionMatches = 0;

    for (uintptr_t p = begin;
         p < end;
         p += stride)
    {
        uintptr_t value =
            ReadPtr(
                p
            );

        if (!LooksLikeSameTileClassObject(
                value,
                tileVtable))
        {
            continue;
        }

        ++count;

        if (stride == 16)
        {
            uintptr_t control =
                ReadPtr(
                    p + 8
                );

            if (LooksLikeSharedPtrControlBlock(
                    control))
            {
                ++companionMatches;
            }
        }
    }

    if (count < 5)
    {
        return TilePointerRun{};
    }

    if (stride == 16)
    {
        size_t required =
            std::max<size_t>(
                3,
                count / 2
            );

        if (companionMatches <
            required)
        {
            return TilePointerRun{};
        }
    }

    run.begin =
        begin;

    run.end =
        end;

    run.occurrence =
        occurrence;

    run.slotIndex =
        static_cast<size_t>(
            (
                occurrence -
                begin
            ) /
            stride
        );

    run.tileCount =
        count;

    run.stride =
        stride;

    run.companionMatches =
        companionMatches;

    run.storageMode =
        stride == 16
            ? "shared_ptr_array"
            : "raw_pointer_array";

    return run;
}

std::vector<TilePointerRun>
FindTilePointerRuns(
    const std::vector<uintptr_t>& refs,
    uintptr_t tile,
    uintptr_t tileVtable)
{
    std::vector<TilePointerRun> out;

    for (uintptr_t ref :
         refs)
    {
        for (size_t stride :
             {
                 static_cast<size_t>(8),
                 static_cast<size_t>(16)
             })
        {
            TilePointerRun run =
                ExpandTilePointerRunStrided(
                    ref,
                    tile,
                    tileVtable,
                    stride
                );

            if (!run.begin ||
                !run.tileCount)
            {
                continue;
            }

            bool duplicate =
                false;

            for (const auto& existing :
                 out)
            {
                if (existing.begin ==
                        run.begin &&
                    existing.stride ==
                        run.stride)
                {
                    duplicate =
                        true;

                    break;
                }
            }

            if (!duplicate)
            {
                out.push_back(
                    run
                );
            }
        }
    }

    std::sort(
        out.begin(),
        out.end(),
        [](
            const TilePointerRun& a,
            const TilePointerRun& b)
        {
            if (a.tileCount !=
                b.tileCount)
            {
                return
                    a.tileCount >
                    b.tileCount;
            }

            if (a.storageMode !=
                b.storageMode)
            {
                return
                    a.storageMode ==
                    "shared_ptr_array";
            }

            return
                a.begin <
                b.begin;
        }
    );

    return out;
}


std::vector<TileArrayHeaderCandidate>
FindArrayHeadersForRun(
    const TilePointerRun& run)
{
    std::vector<TileArrayHeaderCandidate>
        out;

    auto beginRefs =
        FindExactPointerOccurrencesClean(
            run.begin,
            4096
        );

    for (uintptr_t ref :
         beginRefs)
    {
        uintptr_t begin =
            ReadPtr(
                ref
            );

        uintptr_t end =
            ReadPtr(
                ref + 8
            );

        uintptr_t cap =
            ReadPtr(
                ref + 16
            );

        if (begin !=
            run.begin)
        {
            continue;
        }

        if (!end ||
            end < begin ||
            !cap ||
            cap < end)
        {
            continue;
        }

        if ((begin & 7) ||
            (end & 7) ||
            (cap & 7))
        {
            continue;
        }

        uintptr_t used =
            end -
            begin;

        uintptr_t capacityBytes =
            cap -
            begin;

        if (!run.stride ||
            used %
                run.stride !=
            0 ||
            capacityBytes %
                run.stride !=
            0)
        {
            continue;
        }

        size_t count =
            static_cast<size_t>(
                used /
                run.stride
            );

        size_t capacity =
            static_cast<size_t>(
                capacityBytes /
                run.stride
            );

        if (count < run.tileCount ||
            capacity < count ||
            count > 20000 ||
            capacity > 40000)
        {
            continue;
        }

        TileArrayHeaderCandidate c{};

        c.header = ref;
        c.begin = begin;
        c.end = end;
        c.cap = cap;
        c.count = count;
        c.capacity = capacity;

        out.push_back(
            c
        );
    }

    std::sort(
        out.begin(),
        out.end(),
        [](
            const TileArrayHeaderCandidate& a,
            const TileArrayHeaderCandidate& b)
        {
            if (a.count != b.count)
                return a.count < b.count;

            if (a.capacity != b.capacity)
                return a.capacity < b.capacity;

            return a.header < b.header;
        }
    );

    return out;
}

std::vector<MapArrayProvenanceCandidate>
FindMapOwnersForArrayHeader(
    uintptr_t map,
    const TileArrayHeaderCandidate& header)
{
    std::vector<MapArrayProvenanceCandidate>
        out;

    const uintptr_t mapScan =
        0x340;

    const uintptr_t ownerWindow =
        0x1000;

    const uintptr_t childScan =
        0x300;

    for (uintptr_t mapOff = 0;
         mapOff + 8 <= mapScan;
         mapOff += 8)
    {
        uintptr_t first =
            ReadPtr(
                map +
                mapOff
            );

        if (!IsReadablePrivatePointer(
                first))
        {
            continue;
        }

        if (header.header >=
                first &&
            header.header -
                first <=
                ownerWindow)
        {
            MapArrayProvenanceCandidate c{};

            c.depth = 1;
            c.mapOffset = mapOff;
            c.owner = first;
            c.header = header.header;
            c.headerOffset =
                header.header -
                first;
            c.count = header.count;
            c.capacity = header.capacity;

            out.push_back(
                c
            );
        }

        if (first ==
            header.header)
        {
            MapArrayProvenanceCandidate c{};

            c.depth = 1;
            c.mapOffset = mapOff;
            c.owner = first;
            c.header = header.header;
            c.headerOffset = 0;
            c.count = header.count;
            c.capacity = header.capacity;

            out.push_back(
                c
            );
        }

        for (uintptr_t childOff = 0;
             childOff + 8 <=
                childScan;
             childOff += 8)
        {
            uintptr_t second =
                ReadPtr(
                    first +
                    childOff
                );

            if (!IsReadablePrivatePointer(
                    second))
            {
                continue;
            }

            if (header.header >=
                    second &&
                header.header -
                    second <=
                    ownerWindow)
            {
                MapArrayProvenanceCandidate c{};

                c.depth = 2;
                c.mapOffset = mapOff;
                c.childOffset = childOff;
                c.owner = second;
                c.header = header.header;
                c.headerOffset =
                    header.header -
                    second;
                c.count = header.count;
                c.capacity = header.capacity;

                out.push_back(
                    c
                );
            }

            if (second ==
                header.header)
            {
                MapArrayProvenanceCandidate c{};

                c.depth = 2;
                c.mapOffset = mapOff;
                c.childOffset = childOff;
                c.owner = second;
                c.header = header.header;
                c.headerOffset = 0;
                c.count = header.count;
                c.capacity = header.capacity;

                out.push_back(
                    c
                );
            }
        }
    }

    return out;
}


struct TilePathEvidence
{
    MapPosition position{};

    uintptr_t tile = 0;
    uintptr_t tileVtable = 0;

    TilePointerRun run{};
    TileArrayHeaderCandidate header{};
    MapArrayProvenanceCandidate provenance{};
};

bool SameTilePathSignature(
    const TilePathEvidence& a,
    const TilePathEvidence& b)
{
    if (a.run.stride !=
            b.run.stride ||
        a.run.storageMode !=
            b.run.storageMode)
    {
        return false;
    }

    if (a.provenance.depth !=
        b.provenance.depth)
    {
        return false;
    }

    if (a.provenance.mapOffset !=
        b.provenance.mapOffset)
    {
        return false;
    }

    if (a.provenance.headerOffset !=
        b.provenance.headerOffset)
    {
        return false;
    }

    if (a.provenance.depth == 2 &&
        a.provenance.childOffset !=
            b.provenance.childOffset)
    {
        return false;
    }

    return true;
}

std::string TilePathSignatureText(
    const TilePathEvidence& e)
{
    std::ostringstream out;

    out
        << "mode="
        << e.run.storageMode
        << " stride="
        << e.run.stride
        << " depth="
        << e.provenance.depth
        << " Map[+"
        << HexU64(
            e.provenance.mapOffset
        )
        << "]";

    if (e.provenance.depth == 2)
    {
        out
            << " -> [+"
            << HexU64(
                e.provenance.childOffset
            )
            << "]";
    }

    out
        << " headerOff=+"
        << HexU64(
            e.provenance.headerOffset
        );

    return
        out.str();
}

std::vector<TilePathEvidence>
CollectTilePathEvidence(
    uintptr_t map,
    uintptr_t tile,
    uintptr_t tileVtable,
    const MapPosition& position,
    bool verbose)
{
    std::vector<TilePathEvidence>
        evidence;

    auto refs =
        FindExactPointerOccurrencesClean(
            tile
        );

    auto runs =
        FindTilePointerRuns(
            refs,
            tile,
            tileVtable
        );

    if (verbose)
    {
        std::cout
            << "Clean Tile* refs     : "
            << refs.size()
            << "\n"
            << "Tile storage runs   : "
            << runs.size()
            << "\n";

        for (size_t r = 0;
             r < runs.size() &&
             r < 8;
             ++r)
        {
            std::cout
                << "  run#"
                << r
                << " mode="
                << runs[r].storageMode
                << " stride="
                << runs[r].stride
                << " tiles="
                << runs[r].tileCount
                << " companion="
                << runs[r].companionMatches
                << "\n";
        }
    }

    for (size_t i = 0;
         i < runs.size();
         ++i)
    {
        const auto& run =
            runs[i];

        auto headers =
            FindArrayHeadersForRun(
                run
            );

        for (const auto& header :
             headers)
        {
            // Strong runtime evidence: the header describes exactly the
            // contiguous Tile* run containing the current Tile.
            if (header.count <
                run.tileCount)
            {
                continue;
            }

            auto owners =
                FindMapOwnersForArrayHeader(
                    map,
                    header
                );

            for (const auto& owner :
                 owners)
            {
                TilePathEvidence e{};

                e.position =
                    position;

                e.tile =
                    tile;

                e.tileVtable =
                    tileVtable;

                e.run =
                    run;

                e.header =
                    header;

                e.provenance =
                    owner;

                evidence.push_back(
                    e
                );

                if (verbose)
                {
                    std::cout
                        << "  evidence: "
                        << TilePathSignatureText(
                            e
                        )
                        << " tiles="
                        << run.tileCount
                        << " index="
                        << run.slotIndex
                        << " owner="
                        << HexPtr(
                            owner.owner
                        )
                        << " header="
                        << HexPtr(
                            header.header
                        )
                        << "\n";
                }
            }
        }
    }

    // Deduplicate identical signatures within the same snapshot.
    std::vector<TilePathEvidence>
        unique;

    for (const auto& e :
         evidence)
    {
        bool duplicate =
            false;

        for (const auto& u :
             unique)
        {
            if (SameTilePathSignature(
                    e,
                    u))
            {
                duplicate = true;
                break;
            }
        }

        if (!duplicate)
        {
            unique.push_back(
                e
            );
        }
    }

    return
        unique;
}


bool ValidateTilePathTemplateAtCurrentTile(
    uintptr_t map,
    uintptr_t tile,
    uintptr_t tileVtable,
    const MapPosition& position,
    const TilePathEvidence& templateEvidence,
    TilePathEvidence& outEvidence,
    bool verbose)
{
    if (!map ||
        !tile ||
        !tileVtable)
    {
        return false;
    }

    const auto& t =
        templateEvidence.provenance;

    if (!t.depth ||
        !templateEvidence.run.stride)
    {
        return false;
    }

    uintptr_t first =
        ReadPtr(
            map +
            t.mapOffset
        );

    if (!IsReadablePrivatePointer(
            first))
    {
        return false;
    }

    uintptr_t owner =
        first;

    if (t.depth == 2)
    {
        owner =
            ReadPtr(
                first +
                t.childOffset
            );

        if (!IsReadablePrivatePointer(
                owner))
        {
            return false;
        }
    }

    uintptr_t headerAddress =
        owner +
        t.headerOffset;

    if (!IsReadableMonitorRange(
            headerAddress,
            3 * sizeof(uintptr_t)))
    {
        return false;
    }

    uintptr_t begin =
        ReadPtr(
            headerAddress
        );

    uintptr_t end =
        ReadPtr(
            headerAddress + 8
        );

    uintptr_t cap =
        ReadPtr(
            headerAddress + 16
        );

    if (!begin ||
        !end ||
        !cap ||
        end < begin ||
        cap < end ||
        (begin & 7) ||
        (end & 7) ||
        (cap & 7))
    {
        return false;
    }

    const size_t stride =
        templateEvidence.run.stride;

    uintptr_t used =
        end -
        begin;

    uintptr_t capacityBytes =
        cap -
        begin;

    if (!stride ||
        used % stride != 0 ||
        capacityBytes % stride != 0)
    {
        return false;
    }

    size_t count =
        static_cast<size_t>(
            used /
            stride
        );

    size_t capacity =
        static_cast<size_t>(
            capacityBytes /
            stride
        );

    if (count < 5 ||
        count > 20000 ||
        capacity < count ||
        capacity > 40000)
    {
        return false;
    }

    if (!IsReadableMonitorRange(
            begin,
            used))
    {
        return false;
    }

    uintptr_t occurrence = 0;
    size_t tileClassCount = 0;
    size_t companionMatches = 0;

    for (size_t i = 0;
         i < count;
         ++i)
    {
        uintptr_t entry =
            begin +
            i *
            stride;

        uintptr_t object =
            ReadPtr(
                entry
            );

        if (object == tile)
        {
            occurrence =
                entry;
        }

        if (!LooksLikeSameTileClassObject(
                object,
                tileVtable))
        {
            continue;
        }

        ++tileClassCount;

        if (stride == 16)
        {
            uintptr_t control =
                ReadPtr(
                    entry + 8
                );

            if (LooksLikeSharedPtrControlBlock(
                    control))
            {
                ++companionMatches;
            }
        }
    }

    if (!occurrence ||
        tileClassCount < 5)
    {
        return false;
    }

    if (stride == 16)
    {
        uintptr_t currentControl =
            ReadPtr(
                occurrence + 8
            );

        if (!LooksLikeSharedPtrControlBlock(
                currentControl))
        {
            return false;
        }

        size_t required =
            std::max<size_t>(
                3,
                tileClassCount / 2
            );

        if (companionMatches <
            required)
        {
            return false;
        }
    }

    TilePathEvidence e{};

    e.position =
        position;

    e.tile =
        tile;

    e.tileVtable =
        tileVtable;

    e.run.begin =
        begin;

    e.run.end =
        end;

    e.run.occurrence =
        occurrence;

    e.run.slotIndex =
        static_cast<size_t>(
            (
                occurrence -
                begin
            ) /
            stride
        );

    e.run.tileCount =
        tileClassCount;

    e.run.stride =
        stride;

    e.run.companionMatches =
        companionMatches;

    e.run.storageMode =
        templateEvidence.run.storageMode;

    e.header.header =
        headerAddress;

    e.header.begin =
        begin;

    e.header.end =
        end;

    e.header.cap =
        cap;

    e.header.count =
        count;

    e.header.capacity =
        capacity;

    e.provenance.depth =
        t.depth;

    e.provenance.mapOffset =
        t.mapOffset;

    e.provenance.childOffset =
        t.childOffset;

    e.provenance.owner =
        owner;

    e.provenance.header =
        headerAddress;

    e.provenance.headerOffset =
        t.headerOffset;

    e.provenance.count =
        count;

    e.provenance.capacity =
        capacity;

    outEvidence =
        e;

    if (verbose)
    {
        std::cout
            << "[TEMPLATE PASS] "
            << TilePathSignatureText(
                e
            )
            << " totalEntries="
            << count
            << " tileClassEntries="
            << tileClassCount
            << " currentIndex="
            << e.run.slotIndex
            << " owner="
            << HexPtr(
                owner
            )
            << " header="
            << HexPtr(
                headerAddress
            )
            << "\n";
    }

    return true;
}

bool CaptureTilePathSnapshotFromTemplates(
    DbProfile& profile,
    uintptr_t localPlayer,
    const char* label,
    const std::vector<TilePathEvidence>& templates,
    std::vector<TilePathEvidence>& out)
{
    out.clear();

    if (templates.empty())
        return false;

    std::cout
        << "\n============================================================\n"
        << "       MAP TILE TEMPLATE REVALIDATION "
        << label
        << "\n"
        << "============================================================\n"
        << "[MODE] Nao redescobre provenance do zero.\n"
        << "[MODE] Revalida diretamente os caminhos aprendidos no Snapshot A.\n";

    if (!WaitForTileWorldReady(
            profile,
            localPlayer))
    {
        return false;
    }

    MapPosition position{};

    uintptr_t tile =
        FindCurrentTileObjectReadOnly(
            profile,
            localPlayer,
            position
        );

    if (!tile)
    {
        std::cout
            << "[TEMPLATE] Current Tile nao foi resolvido.\n";

        return false;
    }

    uintptr_t tileVtable =
        ReadPtr(
            tile
        );

    uintptr_t map =
        g_exeBase +
        profile.mapRva;

    std::cout
        << "[TEMPLATE] Position="
        << position.x
        << ","
        << position.y
        << ","
        << static_cast<unsigned>(
            position.z
        )
        << " Tile="
        << HexPtr(
            tile
        )
        << "\n";

    for (const auto& t :
         templates)
    {
        TilePathEvidence current{};

        if (!ValidateTilePathTemplateAtCurrentTile(
                map,
                tile,
                tileVtable,
                position,
                t,
                current,
                true))
        {
            continue;
        }

        bool duplicate =
            false;

        for (const auto& existing :
             out)
        {
            if (SameTilePathSignature(
                    current,
                    existing))
            {
                duplicate =
                    true;

                break;
            }

            // Two different pointer paths can describe the exact same
            // runtime storage header (subobject/alias views). Keep both
            // signatures available for intersection, but do not duplicate
            // an identical signature.
        }

        if (!duplicate)
        {
            out.push_back(
                current
            );
        }
    }

    std::cout
        << "[TEMPLATE] Validated signatures="
        << out.size()
        << "\n";

    return
        !out.empty();
}


bool CaptureTilePathSnapshot(
    DbProfile& profile,
    uintptr_t localPlayer,
    const char* label,
    TilePathEvidence& chosen,
    std::vector<TilePathEvidence>& all)
{
    std::cout
        << "\n============================================================\n"
        << "              MAP TILE PATH SNAPSHOT "
        << label
        << "\n"
        << "============================================================\n";

    if (!WaitForTileWorldReady(
            profile,
            localPlayer))
    {
        return false;
    }

    MapPosition position =
        ReadDiscoveredPlayerPosition(
            localPlayer,
            profile
        );

    if (!MapPositionPlausible(
            position))
    {
        std::cout
            << "[STOP] Position atual invalida para provenance.\n";

        return false;
    }

    uintptr_t map =
        g_exeBase +
        profile.mapRva;

    // V3.7:
    // Do NOT require a unique current Tile before provenance.
    // Some builds keep multiple exact Tile mirrors containing the same
    // LocalPlayer. Let the real Map storage decide which mirror matters.
    if (profile.tileVtableRva)
    {
        auto typed =
            FindTileCandidatesByKnownVtableReadOnly(
                profile,
                localPlayer,
                position
            );

        std::vector<TileVectorCandidate>
            exact;

        uintptr_t expectedVtable =
            g_exeBase +
            profile.tileVtableRva;

        for (const auto& c :
             typed)
        {
            if (c.vectorOffset !=
                    profile.tileThingsBegin ||
                c.vtable !=
                    expectedVtable)
            {
                continue;
            }

            exact.push_back(
                c
            );
        }

        if (exact.size() > 1)
        {
            std::cout
                << "[MULTI TILE] "
                << exact.size()
                << " exact Tile mirrors remain.\n"
                << "[MULTI TILE] Resolving by Map provenance instead of guessing.\n";

            std::vector<TilePathEvidence>
                combined;

            for (size_t i = 0;
                 i < exact.size();
                 ++i)
            {
                const auto& c =
                    exact[i];

                auto evidence =
                    CollectTilePathEvidence(
                        map,
                        c.objectBase,
                        c.vtable,
                        position,
                        false
                    );

                std::cout
                    << "  candidate#"
                    << i
                    << " tile="
                    << HexPtr(
                        c.objectBase
                    )
                    << " things="
                    << c.count
                    << " provenance="
                    << evidence.size()
                    << "\n";

                for (const auto& e :
                     evidence)
                {
                    bool duplicate = false;

                    for (const auto& u :
                         combined)
                    {
                        if (SameTilePathSignature(
                                e,
                                u))
                        {
                            duplicate = true;
                            break;
                        }
                    }

                    if (!duplicate)
                    {
                        combined.push_back(
                            e
                        );
                    }
                }
            }

            all =
                combined;

            std::cout
                << "[MULTI TILE] Unique provenance signatures="
                << all.size()
                << "\n";

            if (all.empty())
            {
                std::cout
                    << "[CHECK] Mirrors encontrados, mas nenhum pertenceu "
                    << "a um storage forte do Map neste snapshot.\n";

                return false;
            }

            if (all.size() == 1)
            {
                chosen =
                    all[0];
            }

            return true;
        }

        if (exact.size() == 1)
        {
            uintptr_t tile =
                exact[0].objectBase;

            std::cout
                << "[TILE SEED] Resolver=known_tile_vtable_rtti\n"
                << "Position             : "
                << position.x
                << ","
                << position.y
                << ","
                << static_cast<unsigned>(
                    position.z
                )
                << "\n"
                << "Tile                 : "
                << HexPtr(
                    tile
                )
                << "\n";

            all =
                CollectTilePathEvidence(
                    map,
                    tile,
                    exact[0].vtable,
                    position,
                    true
                );

            std::cout
                << "Unique path signatures: "
                << all.size()
                << "\n";

            if (all.empty())
            {
                std::cout
                    << "[CHECK] Nenhum provenance forte neste snapshot.\n";

                return false;
            }

            if (all.size() == 1)
            {
                chosen =
                    all[0];
            }

            return true;
        }
    }

    // Legacy/raw fallback is retained for clients without typed RTTI data.
    uintptr_t tile =
        FindCurrentTileObjectReadOnly(
            profile,
            localPlayer,
            position
        );

    if (!tile)
    {
        std::cout
            << "[STOP] Tile atual nao foi resolvido nem por RTTI/provenance "
            << "nem pelo fallback legado.\n";

        return false;
    }

    uintptr_t tileVtable =
        ReadPtr(
            tile
        );

    std::cout
        << "Position             : "
        << position.x
        << ","
        << position.y
        << ","
        << static_cast<unsigned>(
            position.z
        )
        << "\n"
        << "Tile                 : "
        << HexPtr(
            tile
        )
        << "\n";

    all =
        CollectTilePathEvidence(
            map,
            tile,
            tileVtable,
            position,
            true
        );

    std::cout
        << "Unique path signatures: "
        << all.size()
        << "\n";

    if (all.empty())
    {
        std::cout
            << "[CHECK] Nenhum provenance forte neste snapshot.\n";

        return false;
    }

    if (all.size() == 1)
    {
        chosen =
            all[0];
    }

    return true;
}

void PrintTileArrayProvenance(
    uintptr_t map,
    uintptr_t tile,
    uintptr_t tileVtable)
{
    std::cout
        << "\n============================================================\n"
        << "          CLEAN TILE* REFERENCE SCAN\n"
        << "============================================================\n"
        << "Self-generated scan scratch and current stack are excluded.\n";

    auto refs =
        FindExactPointerOccurrencesClean(
            tile
        );

    std::cout
        << "Clean Tile* refs     : "
        << refs.size()
        << "\n";

    auto runs =
        FindTilePointerRuns(
            refs,
            tile,
            tileVtable
        );

    std::cout
        << "Tile* array runs     : "
        << runs.size()
        << "\n";

    if (runs.empty())
    {
        std::cout
            << "[CHECK] Nenhuma sequencia >=5 Tile* da mesma classe foi encontrada.\n";

        return;
    }

    for (size_t i = 0;
         i < runs.size() &&
         i < 16;
         ++i)
    {
        const auto& run =
            runs[i];

        std::cout
            << "\n[RUN #"
            << i
            << "] begin="
            << HexPtr(
                run.begin
            )
            << " end="
            << HexPtr(
                run.end
            )
            << " tiles="
            << run.tileCount
            << " currentIndex="
            << run.slotIndex
            << "\n";

        auto headers =
            FindArrayHeadersForRun(
                run
            );

        std::cout
            << "  vector-like headers: "
            << headers.size()
            << "\n";

        for (size_t h = 0;
             h < headers.size() &&
             h < 16;
             ++h)
        {
            const auto& header =
                headers[h];

            std::cout
                << "  header#"
                << h
                << " @"
                << HexPtr(
                    header.header
                )
                << " count="
                << header.count
                << " cap="
                << header.capacity
                << "\n";

            auto owners =
                FindMapOwnersForArrayHeader(
                    map,
                    header
                );

            if (owners.empty())
            {
                std::cout
                    << "    Map provenance: none within 2 targeted hops\n";

                continue;
            }

            for (size_t o = 0;
                 o < owners.size() &&
                 o < 16;
                 ++o)
            {
                const auto& owner =
                    owners[o];

                std::cout
                    << "    provenance#"
                    << o
                    << " depth="
                    << owner.depth
                    << " Map[+"
                    << HexU64(
                        owner.mapOffset
                    )
                    << "]";

                if (owner.depth == 2)
                {
                    std::cout
                        << " -> [+"
                        << HexU64(
                            owner.childOffset
                        )
                        << "]";
                }

                std::cout
                    << " owner="
                    << HexPtr(
                        owner.owner
                    )
                    << " headerOff=+"
                    << HexU64(
                        owner.headerOffset
                    )
                    << " count="
                    << owner.count
                    << " cap="
                    << owner.capacity
                    << "\n";
            }
        }
    }
}

bool RunMapTilePathRecon(
    DbProfile& profile)
{
    std::cout
        << "\n============================================================\n"
        << "   STAGE 5B - MAP TILE PATH TWO-POSITION VALIDATION\n"
        << "============================================================\n"
        << "[MODE] READ-ONLY\n"
        << "[NO WRITE] Nenhuma escrita em memoria do jogo\n"
        << "[NO HOOK] Nenhum hook\n"
        << "[NO CALL] Map::getTile e outras funcoes internas NAO serao chamadas\n"
        << "\n"
        << "Criterio para promover:\n"
        << "  - Snapshot A encontra provenance forte\n"
        << "  - voce muda para outro SQM no mesmo andar\n"
        << "  - Snapshot B revalida ou redescobre provenance forte\n"
        << "  - exatamente UMA assinatura estrutural aparece nos dois\n"
        << "  - Tile* precisa mudar entre A e B\n";

    const bool tileThingsConfirmed =
        profile.tileThingsStatus ==
            "discovered_runtime_selfcheck_pass" ||
        profile.tileThingsStatus ==
            "confirmed_runtime_localplayer_two_tiles";

    if (!profile.mapRva ||
        !profile.tileThingsBegin ||
        !tileThingsConfirmed)
    {
        std::cout
            << "[STOP] Map/Tile::things ainda nao estao confirmados.\n";

        return false;
    }

    uintptr_t localPlayer =
        WaitForDiscoveryLocalPlayer(
            profile,
            "STAGE 5B - MAP TILE PATH TWO-POSITION"
        );

    if (!localPlayer)
        return false;

    TilePathEvidence chosenA{};
    std::vector<TilePathEvidence>
        allA;

    if (!CaptureTilePathSnapshot(
            profile,
            localPlayer,
            "A",
            chosenA,
            allA))
    {
        profile.mapTilePathStatus =
            "unresolved_snapshot_A";

        return false;
    }

    MapPosition posA =
        allA[0].position;

    MapPosition posB{};

    while (true)
    {
        std::cout
            << "\nPASSO B - MUDE PARA OUTRO SQM\n"
            << "Ande para outro SQM, permanea no MESMO andar Z="
            << static_cast<unsigned>(
                posA.z
            )
            << ", pare e pressione ENTER.\n";

        WaitEnter(
            "Quando estiver parado no SQM B, pressione ENTER..."
        );

        posB =
            ReadDiscoveredPlayerPosition(
                localPlayer,
                profile
            );

        if (!MapPositionPlausible(
                posB))
        {
            std::cout
                << "[RETRY] Position B invalida.\n";

            continue;
        }

        if (posB.z !=
            posA.z)
        {
            std::cout
                << "[RETRY] Nao troque de andar. Z atual="
                << static_cast<unsigned>(
                    posB.z
                )
                << " esperado="
                << static_cast<unsigned>(
                    posA.z
                )
                << "\n";

            continue;
        }

        if (SameMapPosition(
                posA,
                posB))
        {
            std::cout
                << "[RETRY] Ainda esta no mesmo SQM.\n";

            continue;
        }

        break;
    }

    TilePathEvidence chosenB{};
    std::vector<TilePathEvidence>
        allB;

    if (!CaptureTilePathSnapshot(
            profile,
            localPlayer,
            "B",
            chosenB,
            allB))
    {
        std::cout
            << "[FALLBACK] Snapshot B nao redescobriu provenance.\n"
            << "[FALLBACK] Revalidando diretamente os caminhos estruturais do Snapshot A...\n";

        if (!CaptureTilePathSnapshotFromTemplates(
                profile,
                localPlayer,
                "B",
                allA,
                allB))
        {
            profile.mapTilePathStatus =
                "unresolved_snapshot_B";

            return false;
        }
    }

    std::vector<std::pair<
        TilePathEvidence,
        TilePathEvidence
    >> matches;

    for (const auto& a :
         allA)
    {
        for (const auto& b :
             allB)
        {
            if (!SameTilePathSignature(
                    a,
                    b))
            {
                continue;
            }

            if (a.tile ==
                b.tile)
            {
                continue;
            }

            matches.push_back(
                {
                    a,
                    b
                }
            );
        }
    }

    // Deduplicate signature matches.
    std::vector<std::pair<
        TilePathEvidence,
        TilePathEvidence
    >> uniqueMatches;

    for (const auto& pair :
         matches)
    {
        bool duplicate =
            false;

        for (const auto& existing :
             uniqueMatches)
        {
            if (SameTilePathSignature(
                    pair.first,
                    existing.first))
            {
                duplicate = true;
                break;
            }

            const bool sameRuntimeStorage =
                pair.first.run.stride ==
                    existing.first.run.stride &&
                pair.first.run.storageMode ==
                    existing.first.run.storageMode &&
                pair.first.header.header ==
                    existing.first.header.header &&
                pair.second.header.header ==
                    existing.second.header.header;

            if (sameRuntimeStorage)
            {
                duplicate = true;
                break;
            }
        }

        if (!duplicate)
        {
            uniqueMatches.push_back(
                pair
            );
        }
    }

    std::cout
        << "\n============================================================\n"
        << "            TWO-POSITION PATH INTERSECTION\n"
        << "============================================================\n"
        << "Snapshot A signatures : "
        << allA.size()
        << "\n"
        << "Snapshot B signatures : "
        << allB.size()
        << "\n"
        << "Common signatures     : "
        << uniqueMatches.size()
        << "\n";

    for (size_t i = 0;
         i < uniqueMatches.size();
         ++i)
    {
        const auto& a =
            uniqueMatches[i].first;

        const auto& b =
            uniqueMatches[i].second;

        std::cout
            << "#"
            << i
            << " "
            << TilePathSignatureText(
                a
            )
            << "\n"
            << "   A pos="
            << a.position.x
            << ","
            << a.position.y
            << ","
            << static_cast<unsigned>(
                a.position.z
            )
            << " tile="
            << HexPtr(
                a.tile
            )
            << " tiles="
            << a.run.tileCount
            << " index="
            << a.run.slotIndex
            << " owner="
            << HexPtr(
                a.provenance.owner
            )
            << " header="
            << HexPtr(
                a.header.header
            )
            << "\n"
            << "   B pos="
            << b.position.x
            << ","
            << b.position.y
            << ","
            << static_cast<unsigned>(
                b.position.z
            )
            << " tile="
            << HexPtr(
                b.tile
            )
            << " tiles="
            << b.run.tileCount
            << " index="
            << b.run.slotIndex
            << " owner="
            << HexPtr(
                b.provenance.owner
            )
            << " header="
            << HexPtr(
                b.header.header
            )
            << "\n";
    }

    if (uniqueMatches.empty())
    {
        std::cout
            << "[FALLBACK] Nenhuma assinatura comum pela redescoberta independente.\n"
            << "[FALLBACK] Fazendo validacao dirigida dos templates A no estado B atual...\n";

        std::vector<TilePathEvidence>
            templateB;

        if (CaptureTilePathSnapshotFromTemplates(
                profile,
                localPlayer,
                "B-DIRECT",
                allA,
                templateB))
        {
            for (const auto& a :
                 allA)
            {
                for (const auto& b :
                     templateB)
                {
                    if (!SameTilePathSignature(
                            a,
                            b))
                    {
                        continue;
                    }

                    if (a.tile ==
                        b.tile)
                    {
                        continue;
                    }

                    bool duplicate =
                        false;

                    for (const auto& existing :
                         uniqueMatches)
                    {
                        if (SameTilePathSignature(
                                a,
                                existing.first))
                        {
                            duplicate =
                                true;

                            break;
                        }

                        const bool sameRuntimeStorage =
                            a.run.stride ==
                                existing.first.run.stride &&
                            a.run.storageMode ==
                                existing.first.run.storageMode &&
                            a.header.header ==
                                existing.first.header.header &&
                            b.header.header ==
                                existing.second.header.header;

                        if (sameRuntimeStorage)
                        {
                            duplicate =
                                true;

                            break;
                        }
                    }

                    if (!duplicate)
                    {
                        uniqueMatches.push_back(
                            {
                                a,
                                b
                            }
                        );
                    }
                }
            }

            allB =
                templateB;

            std::cout
                << "[FALLBACK] Common signatures after directed validation: "
                << uniqueMatches.size()
                << "\n";
        }
    }

    if (uniqueMatches.empty())
    {
        profile.mapTilePathStatus =
            "unresolved_no_common_signature";

        std::cout
            << "[CHECK] Nenhuma assinatura estrutural sobreviveu A -> B.\n";

        return false;
    }

    if (uniqueMatches.size() != 1)
    {
        profile.mapTilePathStatus =
            "ambiguous_multiple_common_signatures";

        std::cout
            << "[CHECK] Mais de uma assinatura estrutural sobreviveu.\n"
            << "Nenhuma sera promovida.\n";

        return false;
    }

    const auto& winnerA =
        uniqueMatches[0].first;

    const auto& winnerB =
        uniqueMatches[0].second;

    profile.mapTilePathDepth =
        static_cast<uintptr_t>(
            winnerA.provenance.depth
        );

    profile.mapTilePathMapOffset =
        winnerA.provenance.mapOffset;

    profile.mapTilePathChildOffset =
        winnerA.provenance.childOffset;

    profile.mapTilePathHeaderOffset =
        winnerA.provenance.headerOffset;

    profile.mapTileStorageStride =
        static_cast<uintptr_t>(
            winnerA.run.stride
        );

    profile.mapTileStorageMode =
        winnerA.run.storageMode;

    profile.mapTilePathStatus =
        "confirmed_runtime_two_positions";

    std::cout
        << "\n============================================================\n"
        << "              MAP -> TILE PATH CONFIRMED\n"
        << "============================================================\n"
        << "Depth                : "
        << winnerA.provenance.depth
        << "\n"
        << "Map offset           : +"
        << HexU64(
            profile.mapTilePathMapOffset
        )
        << "\n"
        << "Child offset         : +"
        << HexU64(
            profile.mapTilePathChildOffset
        )
        << "\n"
        << "Array header offset  : +"
        << HexU64(
            profile.mapTilePathHeaderOffset
        )
        << "\n"
        << "Storage mode         : "
        << profile.mapTileStorageMode
        << "\n"
        << "Element stride       : "
        << profile.mapTileStorageStride
        << "\n"
        << "Evidence             : mesma assinatura estrutural em 2 SQMs\n"
        << "                       Tile* mudou entre A e B\n"
        << "Status               : "
        << profile.mapTilePathStatus
        << "\n"
        << "\n"
        << "[FEITO] STAGE 5B confirmou Map -> Tile storage sem chamar Map::getTile.\n";

    return true;
}


bool EnsureMapTilePathDiscovery(
    DbProfile& profile,
    std::vector<DbProfile>& database,
    int profileIndex,
    const std::string& databasePath)
{
    if (profile.mapTilePathStatus ==
            "confirmed_runtime_two_positions" &&
        profile.mapTilePathDepth &&
        profile.mapTilePathHeaderOffset)
    {
        if (!profile.mapTileStorageStride)
            profile.mapTileStorageStride = sizeof(uintptr_t);

        if (profile.mapTileStorageMode.empty() ||
            profile.mapTileStorageMode == "unknown")
        {
            profile.mapTileStorageMode =
                "raw_pointer_array";
        }

        std::cout
            << "\n[FEITO] STAGE 5B - Map -> Tile path ja esta confirmado.\n"
            << "Depth="
            << profile.mapTilePathDepth
            << " MapOff=+"
            << HexU64(
                profile.mapTilePathMapOffset
            )
            << " ChildOff=+"
            << HexU64(
                profile.mapTilePathChildOffset
            )
            << " HeaderOff=+"
            << HexU64(
                profile.mapTilePathHeaderOffset
            )
            << "\n";

        return true;
    }

    profile.mapTilePathDepth = 0;
    profile.mapTilePathMapOffset = 0;
    profile.mapTilePathChildOffset = 0;
    profile.mapTilePathHeaderOffset = 0;
    profile.mapTileStorageStride = 0;
    profile.mapTileStorageMode = "unknown";
    profile.mapTilePathStatus =
        "rediscovery_running";

    bool ok =
        RunMapTilePathRecon(
            profile
        );

    if (profileIndex >= 0 &&
        profileIndex <
            static_cast<int>(
                database.size()
            ))
    {
        database[
            static_cast<size_t>(
                profileIndex
            )
        ] = profile;

        SaveProfileDatabase(
            databasePath,
            database
        );
    }

    return ok;
}


// ============================================================
// DISCOVERY V2.5 - WORLD THING COHORTS + MONSTER SAMPLE
// Strict read-only. No virtual calls.
// ============================================================

struct V25ThingObservation
{
    uintptr_t pointer = 0;
    uintptr_t completeObject = 0;
    uintptr_t vtable = 0;
    uintptr_t vtableRva = 0;

    uint32_t rttiSubobjectOffset = 0;
    std::string rttiName;
    bool synthetic = false;

    uint32_t x = 0;
    uint32_t y = 0;
    uint8_t z = 0;

    uint32_t id = 0;
    uint8_t hpPercent = 0;
    uint32_t direction = 0;

    bool positionPlausible = false;
    bool hpPlausible = false;
    bool directionPlausible = false;
    bool highId = false;
};

struct V25ThingCohort
{
    uintptr_t vtable = 0;
    uintptr_t vtableRva = 0;

    std::string rttiName;

    size_t objects = 0;
    size_t plausiblePosition = 0;
    size_t plausibleHp = 0;
    size_t plausibleDirection = 0;
    size_t highId = 0;

    bool containsLocalPlayer = false;

    std::vector<uintptr_t> examples;
};

bool V25ResolveWorldTileArray(
    const DbProfile& profile,
    uintptr_t localPlayer,
    uintptr_t& begin,
    uintptr_t& end,
    uintptr_t& cap,
    uintptr_t& owner,
    uintptr_t& header)
{
    begin = 0;
    end = 0;
    cap = 0;
    owner = 0;
    header = 0;

    if (!profile.mapRva ||
        !profile.mapTilePathDepth ||
        profile.mapTilePathStatus !=
            "confirmed_runtime_two_positions")
    {
        return false;
    }

    uintptr_t map =
        g_exeBase +
        profile.mapRva;

    uintptr_t first =
        ReadPtr(
            map +
            profile.mapTilePathMapOffset
        );

    if (!first)
        return false;

    if (profile.mapTilePathDepth == 1)
    {
        owner = first;
    }
    else if (profile.mapTilePathDepth == 2)
    {
        owner =
            ReadPtr(
                first +
                profile.mapTilePathChildOffset
            );
    }
    else
    {
        return false;
    }

    if (!owner ||
        !IsReadableMonitorRange(
            owner,
            0x600))
    {
        return false;
    }

    const size_t tileStride =
        profile.mapTileStorageStride
            ? static_cast<size_t>(
                profile.mapTileStorageStride)
            : sizeof(uintptr_t);

    struct Candidate
    {
        uintptr_t offset = 0;
        uintptr_t header = 0;
        uintptr_t begin = 0;
        uintptr_t end = 0;
        uintptr_t cap = 0;

        size_t count = 0;
        size_t capacity = 0;
        size_t validTiles = 0;
        size_t dominantVtable = 0;
        size_t localPlayerHits = 0;

        int score = 0;
    };

    std::vector<Candidate>
        candidates;

    // Important correction:
    // previous Stage 5B proved the owner path, but the vector header itself
    // changes with floor. Scan the owner for the active floor's Tile* vector
    // instead of treating one observed header offset as global.
    for (uintptr_t off = 0;
         off + 3 * sizeof(uintptr_t) <= 0x600;
         off += 8)
    {
        uintptr_t h =
            owner +
            off;

        uintptr_t b =
            ReadPtr(
                h
            );

        uintptr_t e =
            ReadPtr(
                h +
                sizeof(uintptr_t)
            );

        uintptr_t c =
            ReadPtr(
                h +
                2 * sizeof(uintptr_t)
            );

        if (!b ||
            !e ||
            !c ||
            e < b ||
            c < e ||
            (b & 7) ||
            (e & 7) ||
            (c & 7))
        {
            continue;
        }

        uintptr_t used =
            e -
            b;

        uintptr_t capacityBytes =
            c -
            b;

        if (!tileStride ||
            used %
                tileStride !=
            0 ||
            capacityBytes %
                tileStride !=
            0)
        {
            continue;
        }

        size_t count =
            static_cast<size_t>(
                used /
                tileStride
            );

        size_t capacity =
            static_cast<size_t>(
                capacityBytes /
                tileStride
            );

        if (count < 16 ||
            count > 4000 ||
            capacity < count ||
            capacity > 8000)
        {
            continue;
        }

        if (!IsReadableMonitorRange(
                b,
                count *
                    tileStride))
        {
            continue;
        }

        size_t validTiles = 0;
        size_t localHits = 0;

        std::unordered_map<uintptr_t, size_t>
            vtableCounts;

        for (size_t i = 0;
             i < count;
             ++i)
        {
            uintptr_t tile =
                ReadPtr(
                    b +
                    i *
                    tileStride
                );

            if (!tile ||
                !IsReadableMonitorRange(
                    tile,
                    profile.tileThingsCap +
                        sizeof(uintptr_t)))
            {
                continue;
            }

            uintptr_t vt =
                ReadPtr(
                    tile
                );

            if (!InsideExeImage(
                    vt))
            {
                continue;
            }

            uintptr_t tb =
                ReadPtr(
                    tile +
                    profile.tileThingsBegin
                );

            uintptr_t te =
                ReadPtr(
                    tile +
                    profile.tileThingsEnd
                );

            uintptr_t tc =
                ReadPtr(
                    tile +
                    profile.tileThingsCap
                );

            if (!tb ||
                te < tb ||
                tc < te ||
                (tb & 7) ||
                (te & 7) ||
                (tc & 7))
            {
                continue;
            }

            uintptr_t thingUsed =
                te -
                tb;

            uintptr_t thingCapacityBytes =
                tc -
                tb;

            if (thingUsed %
                    sizeof(uintptr_t) !=
                0 ||
                thingCapacityBytes %
                    sizeof(uintptr_t) !=
                0)
            {
                continue;
            }

            size_t thingCount =
                static_cast<size_t>(
                    thingUsed /
                    sizeof(uintptr_t)
                );

            size_t thingCapacity =
                static_cast<size_t>(
                    thingCapacityBytes /
                    sizeof(uintptr_t)
                );

            if (thingCount > 64 ||
                thingCapacity > 256)
            {
                continue;
            }

            ++validTiles;
            ++vtableCounts[
                vt
            ];

            for (size_t t = 0;
                 t < thingCount;
                 ++t)
            {
                uintptr_t thing =
                    ReadPtr(
                        tb +
                        t *
                        sizeof(uintptr_t)
                    );

                if (thing ==
                    localPlayer)
                {
                    ++localHits;
                    break;
                }
            }
        }

        if (validTiles < 16 ||
            localHits != 1)
        {
            continue;
        }

        size_t dominant =
            0;

        for (const auto& kv :
             vtableCounts)
        {
            dominant =
                std::max(
                    dominant,
                    kv.second
                );
        }

        if (dominant * 100 <
                validTiles * 80 ||
            validTiles * 100 <
                count * 75)
        {
            continue;
        }

        Candidate candidate{};

        candidate.offset =
            off;

        candidate.header =
            h;

        candidate.begin =
            b;

        candidate.end =
            e;

        candidate.cap =
            c;

        candidate.count =
            count;

        candidate.capacity =
            capacity;

        candidate.validTiles =
            validTiles;

        candidate.dominantVtable =
            dominant;

        candidate.localPlayerHits =
            localHits;

        candidate.score =
            100000 +
            static_cast<int>(
                validTiles * 10
            ) +
            static_cast<int>(
                dominant * 5
            ) -
            static_cast<int>(
                capacity -
                count
            );

        candidates.push_back(
            candidate
        );
    }

    if (candidates.empty())
    {
        std::cout
            << "[WORLD PATH] Nenhum header dinamico de Tile* contendo LocalPlayer foi encontrado.\n";

        return false;
    }

    std::sort(
        candidates.begin(),
        candidates.end(),
        [](
            const Candidate& a,
            const Candidate& b)
        {
            if (a.score !=
                b.score)
            {
                return
                    a.score >
                    b.score;
            }

            if (a.validTiles !=
                b.validTiles)
            {
                return
                    a.validTiles >
                    b.validTiles;
            }

            return
                a.offset <
                b.offset;
        }
    );

    if (candidates.size() > 1)
    {
        const Candidate& a =
            candidates[0];

        const Candidate& b =
            candidates[1];

        bool clearlyBetter =
            a.score >=
                b.score + 200 ||
            a.validTiles >=
                b.validTiles + 20;

        if (!clearlyBetter)
        {
            std::cout
                << "[WORLD PATH] Mais de um floor-header forte permaneceu.\n";

            for (size_t i = 0;
                 i < candidates.size() &&
                 i < 8;
                 ++i)
            {
                std::cout
                    << "  #"
                    << i
                    << " off=+"
                    << HexU64(
                        candidates[i].offset
                    )
                    << " count="
                    << candidates[i].count
                    << " cap="
                    << candidates[i].capacity
                    << " validTiles="
                    << candidates[i].validTiles
                    << " dominant="
                    << candidates[i].dominantVtable
                    << " localHits="
                    << candidates[i].localPlayerHits
                    << " score="
                    << candidates[i].score
                    << "\n";
            }

            return false;
        }
    }

    const Candidate& winner =
        candidates[0];

    header =
        winner.header;

    begin =
        winner.begin;

    end =
        winner.end;

    cap =
        winner.cap;

    uint8_t currentZ =
        ReadU8(
            localPlayer +
            profile.z
        );

    g_floorHeaderObservations[
        static_cast<unsigned>(
            currentZ)
    ] = winner.offset;

    std::cout
        << "[WORLD PATH] Dynamic floor header resolved.\n"
        << "  Z                    : "
        << static_cast<unsigned>(
            currentZ
        )
        << "\n"
        << "  Runtime header off   : +"
        << HexU64(
            winner.offset
        )
        << "\n"
        << "  Saved header off     : +"
        << HexU64(
            profile.mapTilePathHeaderOffset
        )
        << "\n"
        << "  Tile count           : "
        << winner.count
        << "\n"
        << "  Storage mode         : "
        << (
            profile.mapTileStorageMode.empty()
                ? "unknown"
                : profile.mapTileStorageMode
        )
        << "\n"
        << "  Element stride       : "
        << tileStride
        << "\n"
        << "  Valid Tile vectors   : "
        << winner.validTiles
        << "\n"
        << "  Dominant Tile vtable : "
        << winner.dominantVtable
        << "/"
        << winner.validTiles
        << "\n";

    if (profile.mapTilePathHeaderOffset &&
        winner.offset !=
            profile.mapTilePathHeaderOffset)
    {
        std::cout
            << "[WORLD PATH] Header offset varia com o floor; usando o runtime atual.\n";
    }

    return true;
}


struct V33ThingStorageProbe
{
    size_t stride = sizeof(uintptr_t);
    std::string mode = "raw_pointer_array";

    size_t sampledTiles = 0;
    size_t sampledEntries = 0;
    size_t objectLike = 0;
    size_t controlLike = 0;
    size_t localPlayerObjectHits = 0;

    int score = 0;
};

V33ThingStorageProbe
V33ProbeThingStorage(
    const DbProfile& profile,
    uintptr_t localPlayer,
    uintptr_t tileBegin,
    uintptr_t tileEnd,
    size_t tileStride)
{
    V33ThingStorageProbe raw{};
    raw.stride = 8;
    raw.mode = "raw_pointer_array";

    V33ThingStorageProbe shared{};
    shared.stride = 16;
    shared.mode = "shared_ptr_array";

    if (!tileBegin ||
        tileEnd <= tileBegin ||
        !tileStride)
    {
        return raw;
    }

    size_t tileCount =
        static_cast<size_t>(
            (
                tileEnd -
                tileBegin
            ) /
            tileStride
        );

    tileCount =
        std::min<size_t>(
            tileCount,
            512
        );

    for (size_t ti = 0;
         ti < tileCount;
         ++ti)
    {
        uintptr_t tile =
            ReadPtr(
                tileBegin +
                ti *
                tileStride
            );

        if (!tile ||
            !IsReadableMonitorRange(
                tile,
                profile.tileThingsCap +
                    sizeof(uintptr_t)))
        {
            continue;
        }

        uintptr_t begin =
            ReadPtr(
                tile +
                profile.tileThingsBegin
            );

        uintptr_t end =
            ReadPtr(
                tile +
                profile.tileThingsEnd
            );

        uintptr_t cap =
            ReadPtr(
                tile +
                profile.tileThingsCap
            );

        if (!begin ||
            end < begin ||
            cap < end ||
            (begin & 7) ||
            (end & 7) ||
            (cap & 7))
        {
            continue;
        }

        uintptr_t used =
            end -
            begin;

        if (!used ||
            used > 0x4000)
        {
            continue;
        }

        // RAW Thing* probe.
        if (used % 8 == 0)
        {
            size_t count =
                static_cast<size_t>(
                    used / 8
                );

            if (count <= 128)
            {
                ++raw.sampledTiles;

                for (size_t i = 0;
                     i < count;
                     ++i)
                {
                    uintptr_t object =
                        ReadPtr(
                            begin +
                            i * 8
                        );

                    ++raw.sampledEntries;

                    if (!object ||
                        !IsReadableMonitorRange(
                            object,
                            sizeof(uintptr_t)))
                    {
                        continue;
                    }

                    uintptr_t vt =
                        ReadPtr(
                            object
                        );

                    if (!InsideExeImage(
                            vt))
                    {
                        continue;
                    }

                    ++raw.objectLike;

                    if (object ==
                        localPlayer)
                    {
                        ++raw.localPlayerObjectHits;
                    }
                }
            }
        }

        // MSVC shared_ptr<Thing> probe:
        // [object*][control-block*] repeated.
        if (used % 16 == 0)
        {
            size_t count =
                static_cast<size_t>(
                    used / 16
                );

            if (count <= 128)
            {
                ++shared.sampledTiles;

                for (size_t i = 0;
                     i < count;
                     ++i)
                {
                    uintptr_t entry =
                        begin +
                        i * 16;

                    uintptr_t object =
                        ReadPtr(
                            entry
                        );

                    uintptr_t control =
                        ReadPtr(
                            entry + 8
                        );

                    ++shared.sampledEntries;

                    if (object &&
                        IsReadableMonitorRange(
                            object,
                            sizeof(uintptr_t)))
                    {
                        uintptr_t vt =
                            ReadPtr(
                                object
                            );

                        if (InsideExeImage(
                                vt))
                        {
                            ++shared.objectLike;

                            if (object ==
                                localPlayer)
                            {
                                ++shared.localPlayerObjectHits;
                            }
                        }
                    }

                    if (LooksLikeSharedPtrControlBlock(
                            control))
                    {
                        ++shared.controlLike;
                    }
                }
            }
        }
    }

    if (raw.sampledEntries)
    {
        raw.score =
            static_cast<int>(
                raw.objectLike * 3
            ) +
            static_cast<int>(
                raw.localPlayerObjectHits * 200
            );
    }

    if (shared.sampledEntries)
    {
        shared.score =
            static_cast<int>(
                shared.objectLike * 4
            ) +
            static_cast<int>(
                shared.controlLike * 8
            ) +
            static_cast<int>(
                shared.localPlayerObjectHits * 250
            );

        const bool strongControlPattern =
            shared.controlLike >= 8 &&
            shared.controlLike * 100 >=
                shared.sampledEntries * 70;

        const bool strongObjectPattern =
            shared.objectLike >= 8 &&
            shared.objectLike * 100 >=
                shared.sampledEntries * 70;

        if (!strongControlPattern ||
            !strongObjectPattern)
        {
            shared.score /= 4;
        }
    }

    if (shared.score >
            raw.score &&
        shared.controlLike >= 8)
    {
        return shared;
    }

    return raw;
}

V33ThingStorageProbe
V33ResolveCurrentThingStorage(
    const DbProfile& profile,
    uintptr_t localPlayer,
    uintptr_t tileBegin,
    uintptr_t tileEnd,
    size_t tileStride,
    bool verbose)
{
    V33ThingStorageProbe probe =
        V33ProbeThingStorage(
            profile,
            localPlayer,
            tileBegin,
            tileEnd,
            tileStride
        );

    // A confirmed profile value remains preferred when runtime shape still
    // supports it. New/unknown profiles use the semantic probe.
    if (profile.thingStorageStride == 16 &&
        profile.thingStorageMode ==
            "shared_ptr_array")
    {
        probe.stride = 16;
        probe.mode = "shared_ptr_array";
    }
    else if (profile.thingStorageStride == 8 &&
             profile.thingStorageMode ==
                "raw_pointer_array")
    {
        // Do not force RAW if the live probe strongly proves shared_ptr.
        if (probe.mode !=
            "shared_ptr_array")
        {
            probe.stride = 8;
            probe.mode = "raw_pointer_array";
        }
    }

    if (verbose)
    {
        std::cout
            << "[THING STORAGE] mode="
            << probe.mode
            << " stride="
            << probe.stride
            << " sampledTiles="
            << probe.sampledTiles
            << " entries="
            << probe.sampledEntries
            << " objectLike="
            << probe.objectLike
            << " controlLike="
            << probe.controlLike
            << " localHits="
            << probe.localPlayerObjectHits
            << "\n";
    }

    return probe;
}

bool V33PersistThingStorage(
    DbProfile& profile,
    uintptr_t localPlayer)
{
    uintptr_t tileBegin = 0;
    uintptr_t tileEnd = 0;
    uintptr_t tileCap = 0;
    uintptr_t owner = 0;
    uintptr_t header = 0;

    if (!V25ResolveWorldTileArray(
            profile,
            localPlayer,
            tileBegin,
            tileEnd,
            tileCap,
            owner,
            header))
    {
        return false;
    }

    const size_t tileStride =
        profile.mapTileStorageStride
            ? static_cast<size_t>(
                profile.mapTileStorageStride)
            : sizeof(uintptr_t);

    auto probe =
        V33ResolveCurrentThingStorage(
            profile,
            localPlayer,
            tileBegin,
            tileEnd,
            tileStride,
            true
        );

    if (probe.stride != 8 &&
        probe.stride != 16)
    {
        return false;
    }

    profile.thingStorageStride =
        static_cast<uintptr_t>(
            probe.stride
        );

    profile.thingStorageMode =
        probe.mode;

    std::cout
        << "[THING STORAGE] persisted mode="
        << profile.thingStorageMode
        << " stride="
        << profile.thingStorageStride
        << "\n";

    return true;
}


std::vector<V25ThingObservation>
V25CollectWorldThings(
    const DbProfile& profile,
    uintptr_t localPlayer)
{
    std::vector<V25ThingObservation>
        out;

    uintptr_t tileBegin = 0;
    uintptr_t tileEnd = 0;
    uintptr_t tileCap = 0;
    uintptr_t owner = 0;
    uintptr_t header = 0;

    if (!V25ResolveWorldTileArray(
            profile,
            localPlayer,
            tileBegin,
            tileEnd,
            tileCap,
            owner,
            header))
    {
        std::cout
            << "[WORLD] Map->Tile array nao validou neste snapshot.\n";

        return out;
    }

    const size_t tileStride =
        profile.mapTileStorageStride
            ? static_cast<size_t>(
                profile.mapTileStorageStride)
            : sizeof(uintptr_t);

    if (!tileStride ||
        (
            tileEnd -
            tileBegin
        ) %
            tileStride !=
        0)
    {
        std::cout
            << "[WORLD] Tile storage stride invalido neste snapshot.\n";

        return out;
    }

    size_t tileCount =
        static_cast<size_t>(
            (
                tileEnd -
                tileBegin
            ) /
            tileStride
        );

    V33ThingStorageProbe thingStorage =
        V33ResolveCurrentThingStorage(
            profile,
            localPlayer,
            tileBegin,
            tileEnd,
            tileStride,
            true
        );

    const size_t thingStride =
        thingStorage.stride
            ? thingStorage.stride
            : sizeof(uintptr_t);

    std::cout
        << "\n============================================================\n"
        << "                WORLD TILE ARRAY\n"
        << "============================================================\n"
        << "Owner                : "
        << HexPtr(
            owner
        )
        << "\n"
        << "Header               : "
        << HexPtr(
            header
        )
        << "\n"
        << "Tile begin/end/cap   : "
        << HexPtr(
            tileBegin
        )
        << " / "
        << HexPtr(
            tileEnd
        )
        << " / "
        << HexPtr(
            tileCap
        )
        << "\n"
        << "Tile count           : "
        << tileCount
        << "\n";

    std::unordered_set<uintptr_t>
        seenThings;

    size_t validTiles = 0;
    size_t rejectedThingVectors = 0;

    for (size_t ti = 0;
         ti < tileCount;
         ++ti)
    {
        uintptr_t tile =
            ReadPtr(
                tileBegin +
                ti *
                tileStride
            );

        if (!tile ||
            !IsReadableMonitorRange(
                tile,
                profile.tileThingsCap +
                    sizeof(uintptr_t)))
        {
            continue;
        }

        uintptr_t thingsBegin =
            ReadPtr(
                tile +
                profile.tileThingsBegin
            );

        uintptr_t thingsEnd =
            ReadPtr(
                tile +
                profile.tileThingsEnd
            );

        uintptr_t thingsCap =
            ReadPtr(
                tile +
                profile.tileThingsCap
            );

        if (!thingsBegin ||
            thingsEnd < thingsBegin ||
            thingsCap < thingsEnd ||
            (thingsBegin & 7) ||
            (thingsEnd & 7) ||
            (thingsCap & 7))
        {
            ++rejectedThingVectors;
            continue;
        }

        uintptr_t used =
            thingsEnd -
            thingsBegin;

        uintptr_t capacityBytes =
            thingsCap -
            thingsBegin;

        if (!thingStride ||
            used %
                thingStride !=
            0 ||
            capacityBytes %
                thingStride !=
            0)
        {
            ++rejectedThingVectors;
            continue;
        }

        size_t thingCount =
            static_cast<size_t>(
                used /
                thingStride
            );

        size_t thingCapacity =
            static_cast<size_t>(
                capacityBytes /
                thingStride
            );

        if (thingCount > 64 ||
            thingCapacity > 256)
        {
            ++rejectedThingVectors;
            continue;
        }

        ++validTiles;

        for (size_t i = 0;
             i < thingCount;
             ++i)
        {
            uintptr_t thing =
                ReadPtr(
                    thingsBegin +
                    i *
                    thingStride
                );

            if (!thing)
                continue;

            V35MsvcObjectIdentity identity{};

            const bool identityOk =
                V35DescribeMsvcObject(
                    thing,
                    identity
                );

            uintptr_t identityKey =
                identityOk
                    ? identity.completeObject
                    : thing;

            if (!seenThings.insert(
                    identityKey).second)
            {
                continue;
            }

            uintptr_t need =
                std::max<uintptr_t>(
                    profile.direction +
                        sizeof(uint32_t),
                    profile.hpPercent +
                        sizeof(uint8_t)
                );

            uintptr_t fieldBase =
                identityOk
                    ? identity.completeObject
                    : thing;

            if (!IsReadableMonitorRange(
                    fieldBase,
                    need))
            {
                continue;
            }

            uintptr_t vt =
                identityOk
                    ? identity.vtable
                    : ReadPtr(
                        thing
                    );

            if (!InsideExeImage(
                    vt))
            {
                continue;
            }

            V25ThingObservation o{};

            o.pointer =
                thing;

            o.completeObject =
                identityKey;

            o.vtable =
                vt;

            o.vtableRva =
                vt -
                g_exeBase;

            o.rttiSubobjectOffset =
                identityOk
                    ? identity.subobjectOffset
                    : 0;

            o.rttiName =
                identityOk
                    ? identity.rttiName
                    : TryReadMsvcRttiTypeName(
                        vt
                    );

            if (o.rttiName.empty())
                o.rttiName = "<unavailable>";

            o.x =
                ReadU32(
                    fieldBase +
                    profile.x
                );

            o.y =
                ReadU32(
                    fieldBase +
                    profile.y
                );

            o.z =
                ReadU8(
                    fieldBase +
                    profile.z
                );

            o.id =
                ReadU32(
                    fieldBase +
                    profile.id
                );

            o.hpPercent =
                ReadU8(
                    fieldBase +
                    profile.hpPercent
                );

            o.direction =
                ReadU32(
                    fieldBase +
                    profile.direction
                );

            o.positionPlausible =
                PositionPlausible(
                    o.x,
                    o.y,
                    o.z
                );

            o.hpPlausible =
                o.hpPercent <= 100;

            o.directionPlausible =
                o.direction <= 7;

            // Diagnostic only. This is not used to promote a class.
            o.highId =
                o.id > 0xFFFFu &&
                o.id != 0xFFFFFFFFu;

            out.push_back(
                o
            );
        }
    }

    std::cout
        << "Valid Tile vectors   : "
        << validTiles
        << "\n"
        << "Rejected vectors     : "
        << rejectedThingVectors
        << "\n"
        << "Unique Thing objects : "
        << out.size()
        << "\n"
        << "Thing storage mode   : "
        << thingStorage.mode
        << "\n"
        << "Thing element stride : "
        << thingStride
        << "\n";

    return out;
}

std::vector<V25ThingCohort>
V25BuildCohorts(
    const std::vector<V25ThingObservation>& observations,
    uintptr_t localPlayer)
{
    std::unordered_map<uintptr_t, V25ThingCohort>
        byVtable;

    for (const auto& o :
         observations)
    {
        auto& c =
            byVtable[
                o.vtable
            ];

        c.vtable =
            o.vtable;

        c.vtableRva =
            o.vtableRva;

        if (c.rttiName.empty())
        {
            c.rttiName =
                o.rttiName.empty()
                    ? TryReadMsvcRttiTypeName(
                        o.vtable
                    )
                    : o.rttiName;

            if (c.rttiName.empty())
                c.rttiName = "<unavailable>";
        }

        ++c.objects;

        if (o.positionPlausible)
            ++c.plausiblePosition;

        if (o.hpPlausible)
            ++c.plausibleHp;

        if (o.directionPlausible)
            ++c.plausibleDirection;

        if (o.highId)
            ++c.highId;

        if (
            o.completeObject ==
                V35CompleteObjectPointer(
                    localPlayer) ||
            V35SameCompleteObject(
                o.pointer,
                localPlayer)
        )
        {
            c.containsLocalPlayer =
                true;
        }

        if (c.examples.size() <
            5)
        {
            c.examples.push_back(
                o.pointer
            );
        }
    }

    std::vector<V25ThingCohort>
        out;

    out.reserve(
        byVtable.size()
    );

    for (auto& kv :
         byVtable)
    {
        out.push_back(
            std::move(
                kv.second
            )
        );
    }

    std::sort(
        out.begin(),
        out.end(),
        [](
            const V25ThingCohort& a,
            const V25ThingCohort& b)
        {
            if (a.objects !=
                b.objects)
            {
                return
                    a.objects >
                    b.objects;
            }

            return
                a.vtableRva <
                b.vtableRva;
        }
    );

    return out;
}

void V25PrintCohorts(
    const std::vector<V25ThingCohort>& cohorts)
{
    std::cout
        << "\n============================================================\n"
        << "                WORLD THING VTABLE COHORTS\n"
        << "============================================================\n"
        << "Nenhuma classe e inferida apenas por estes contadores.\n";

    for (size_t i = 0;
         i < cohorts.size();
         ++i)
    {
        const auto& c =
            cohorts[i];

        std::cout
            << "#"
            << i
            << " vtRva="
            << HexU64(
                c.vtableRva
            )
            << " objects="
            << c.objects
            << " pos="
            << c.plausiblePosition
            << " hp<=100="
            << c.plausibleHp
            << " dir<=7="
            << c.plausibleDirection
            << " highId="
            << c.highId
            << " rtti=\""
            << c.rttiName
            << "\"";

        if (c.containsLocalPlayer)
        {
            std::cout
                << " <LOCALPLAYER COHORT>";
        }

        std::cout
            << "\n";
    }
}

const V25ThingObservation*
V25FindObservation(
    const std::vector<V25ThingObservation>& observations,
    uintptr_t pointer)
{
    if (!pointer)
        return nullptr;

    uintptr_t complete =
        V35CompleteObjectPointer(
            pointer
        );

    for (const auto& o :
         observations)
    {
        if (o.pointer ==
                pointer ||
            (
                o.completeObject &&
                o.completeObject ==
                    complete
            ))
        {
            return
                &o;
        }
    }

    return nullptr;
}

bool V25WaitAttackTargetClear(
    const DbProfile& profile)
{
    uintptr_t game =
        g_exeBase +
        profile.gameRva;

    for (;;)
    {
        uintptr_t target =
            ReadPtr(
                game +
                profile.gameAttackTarget
            );

        if (!target)
            return true;

        std::cout
            << "\n[CLEAR TARGET] AttackTarget ainda esta em "
            << HexPtr(
                target
            )
            << ".\n"
            << "Pare de atacar/limpe o target e pressione ENTER.\n";

        WaitEnter(
            "Depois de limpar o target, pressione ENTER..."
        );
    }
}

uintptr_t V25CaptureMonsterTarget(
    const DbProfile& profile,
    std::vector<V25ThingObservation>& observations,
    uintptr_t localPlayer,
    uintptr_t forbidden,
    const char* label)
{
    uintptr_t game =
        g_exeBase +
        profile.gameRva;

    constexpr size_t kMaxAttempts = 5;
    size_t failedAttempts = 0;

    for (;;)
    {
        std::cout
            << "\n============================================================\n"
            << "             MONSTER SAMPLE "
            << label
            << "\n"
            << "============================================================\n"
            << "Ataque/selecione UM MONSTRO visivel pelo cliente normal.\n"
            << "O Lab apenas lera Game.AttackTarget depois.\n";

        WaitEnter(
            "Com o MONSTRO atacado, pressione ENTER..."
        );

        uintptr_t target =
            ReadPtr(
                game +
                profile.gameAttackTarget
            );

        if (!target)
        {
            ++failedAttempts;

            std::cout
                << "[RETRY] AttackTarget esta NULL. tentativa="
                << failedAttempts
                << "/"
                << kMaxAttempts
                << "\n";

            if (failedAttempts >=
                kMaxAttempts)
            {
                std::cout
                    << "[CALIBRATE] Limite desta rodada atingido. "
                    << "Voltando ao orquestrador para permitir R/S/Q.\n";

                return 0;
            }

            continue;
        }

        if (target ==
            localPlayer)
        {
            ++failedAttempts;

            std::cout
                << "[RETRY] AttackTarget nao pode ser LocalPlayer. tentativa="
                << failedAttempts
                << "/"
                << kMaxAttempts
                << "\n";

            if (failedAttempts >=
                kMaxAttempts)
            {
                return 0;
            }

            continue;
        }

        if (forbidden &&
            target ==
                forbidden)
        {
            ++failedAttempts;

            std::cout
                << "[RETRY] Escolha um SEGUNDO monstro diferente. tentativa="
                << failedAttempts
                << "/"
                << kMaxAttempts
                << "\n";

            if (failedAttempts >=
                kMaxAttempts)
            {
                std::cout
                    << "[CALIBRATE] Nao conseguimos um segundo objeto distinto nesta rodada.\n";

                return 0;
            }

            continue;
        }

        // IMPORTANT:
        // The old V2.2 refreshed the world BEFORE the user selected Sample B.
        // If the creature moved meanwhile, the new AttackTarget pointer was
        // compared against a stale world snapshot and the wizard could loop
        // forever. Refresh only AFTER AttackTarget is captured.
        std::cout
            << "[REFRESH] Atualizando world snapshot DEPOIS de capturar AttackTarget...\n";

        observations =
            V25CollectWorldThings(
                profile,
                localPlayer
            );

        const V25ThingObservation* o =
            V25FindObservation(
                observations,
                target
            );

        // Guided fallback:
        // AttackTarget itself is already a confirmed Game semantic field.
        // If the current Tile snapshot omitted the target because it moved
        // during the refresh, validate the target object directly and add a
        // synthetic observation. This is still read-only and is later
        // cross-checked against a second distinct target/vtable.
        if (!o &&
            IsReadableMonitorRange(
                target,
                0x100))
        {
            V25ThingObservation direct{};

            direct.pointer =
                target;

            direct.synthetic =
                true;

            V35MsvcObjectIdentity directIdentity{};

            const bool directIdentityOk =
                V35DescribeMsvcObject(
                    target,
                    directIdentity
                );

            direct.completeObject =
                directIdentityOk
                    ? directIdentity.completeObject
                    : target;

            direct.rttiSubobjectOffset =
                directIdentityOk
                    ? directIdentity.subobjectOffset
                    : 0;

            direct.rttiName =
                directIdentityOk
                    ? directIdentity.rttiName
                    : std::string();

            direct.vtable =
                directIdentityOk
                    ? directIdentity.vtable
                    : ReadPtr(
                        target
                    );

            if (InsideExeImage(
                    direct.vtable))
            {
                direct.vtableRva =
                    direct.vtable -
                    g_exeBase;

                uintptr_t directFieldBase =
                    direct.completeObject
                        ? direct.completeObject
                        : target;

                direct.x =
                    ReadU32(
                        directFieldBase +
                        profile.x
                    );

                direct.y =
                    ReadU32(
                        directFieldBase +
                        profile.y
                    );

                direct.z =
                    ReadU8(
                        directFieldBase +
                        profile.z
                    );

                direct.id =
                    ReadU32(
                        directFieldBase +
                        profile.id
                    );

                direct.hpPercent =
                    ReadU8(
                        directFieldBase +
                        profile.hpPercent
                    );

                direct.direction =
                    ReadU32(
                        directFieldBase +
                        profile.direction
                    );

                direct.positionPlausible =
                    PositionPlausible(
                        direct.x,
                        direct.y,
                        direct.z
                    );

                direct.hpPlausible =
                    direct.hpPercent <= 100;

                direct.directionPlausible =
                    direct.direction <= 7;

                direct.highId =
                    direct.id > 0xFFFFu &&
                    direct.id != 0xFFFFFFFFu;

                if (direct.positionPlausible &&
                    direct.hpPlausible &&
                    direct.directionPlausible)
                {
                    observations.push_back(
                        direct
                    );

                    o =
                        &observations.back();

                    if (direct.rttiName.empty())
                    {
                        direct.rttiName =
                            TryReadMsvcRttiTypeName(
                                direct.vtable
                            );

                        if (direct.rttiName.empty())
                            direct.rttiName = "<unavailable>";
                    }

                    std::cout
                        << "[DIRECT TARGET FALLBACK] "
                        << "Target nao fechou por complete-object identity no Tile snapshot; "
                        << "fallback direto aceito. RTTI=\""
                        << direct.rttiName
                        << "\" subOff="
                        << direct.rttiSubobjectOffset
                        << "\n";
                }
            }
        }

        if (!o)
        {
            ++failedAttempts;

            std::cout
                << "[RETRY] Target nao apareceu no snapshot atual "
                << "e tambem nao passou o fallback direto. tentativa="
                << failedAttempts
                << "/"
                << kMaxAttempts
                << "\n";

            V25WaitAttackTargetClear(
                profile
            );

            if (failedAttempts >=
                kMaxAttempts)
            {
                std::cout
                    << "[CALIBRATE] Limite desta rodada atingido. "
                    << "Voltando ao orquestrador para permitir R/S/Q.\n";

                return 0;
            }

            continue;
        }

        if (!o->positionPlausible ||
            !o->hpPlausible ||
            !o->directionPlausible)
        {
            ++failedAttempts;

            std::cout
                << "[RETRY] Target nao passou o shape basico de Creature-like. tentativa="
                << failedAttempts
                << "/"
                << kMaxAttempts
                << "\n";

            V25WaitAttackTargetClear(
                profile
            );

            if (failedAttempts >=
                kMaxAttempts)
            {
                return 0;
            }

            continue;
        }

        std::cout
            << "[SAMPLE] ptr="
            << HexPtr(
                target
            )
            << " vtableRva="
            << HexU64(
                o->vtableRva
            )
            << " pos="
            << o->x
            << ","
            << o->y
            << ","
            << static_cast<unsigned>(
                o->z
            )
            << " id="
            << o->id
            << " hp%="
            << static_cast<unsigned>(
                o->hpPercent
            )
            << " rtti=\""
            << o->rttiName
            << "\" subOff="
            << o->rttiSubobjectOffset
            << " complete="
            << HexPtr(
                o->completeObject
            )
            << (
                o->synthetic
                    ? " source=direct-fallback"
                    : " source=world-identity"
            )
            << "\n";

        return target;
    }
}

bool V25DecodeConstantBool(
    uintptr_t function,
    bool& value)
{
    value = false;

    if (function <
            g_textBegin ||
        function >=
            g_textEnd)
    {
        return false;
    }

    uint8_t b[8]{};

    for (size_t i = 0;
         i < sizeof(b);
         ++i)
    {
        if (!SafeRead(
                function + i,
                b[i]))
        {
            return false;
        }
    }

    // mov al, imm8 ; ret
    if (b[0] == 0xB0 &&
        (b[1] == 0x00 ||
         b[1] == 0x01) &&
        b[2] == 0xC3)
    {
        value =
            b[1] != 0;

        return true;
    }

    // mov eax, imm32 ; ret
    if (b[0] == 0xB8 &&
        b[5] == 0xC3)
    {
        uint32_t imm = 0;

        std::memcpy(
            &imm,
            &b[1],
            sizeof(imm)
        );

        if (imm <= 1)
        {
            value =
                imm != 0;

            return true;
        }
    }

    // xor eax,eax ; ret
    if (((b[0] == 0x33 &&
          b[1] == 0xC0) ||
         (b[0] == 0x31 &&
          b[1] == 0xC0)) &&
        b[2] == 0xC3)
    {
        value = false;
        return true;
    }

    // xor al,al ; ret
    if (b[0] == 0x32 &&
        b[1] == 0xC0 &&
        b[2] == 0xC3)
    {
        value = false;
        return true;
    }

    return false;
}

void V25PrintVtableBoolMatrix(
    uintptr_t localPlayerVtable,
    uintptr_t monsterVtable)
{
    std::cout
        << "\n============================================================\n"
        << "          STATIC VTABLE CONSTANT-BOOL MATRIX\n"
        << "============================================================\n"
        << "[MODE] somente leitura de ponteiros/bytes da .text\n"
        << "[NO CALL] nenhuma virtual e executada\n"
        << "LP=true / Monster=true pode conter isCreature-like.\n"
        << "LP=false / Monster=true pode conter isMonster-like.\n"
        << "LP=true / Monster=false pode conter isPlayer-like.\n"
        << "Ainda NAO vamos promover slots nesta etapa.\n";

    size_t decoded =
        0;

    for (uintptr_t slot = 0;
         slot <= 0x100;
         slot += 8)
    {
        uintptr_t lpFn =
            ReadPtr(
                localPlayerVtable +
                slot
            );

        uintptr_t monsterFn =
            ReadPtr(
                monsterVtable +
                slot
            );

        bool lpValue = false;
        bool monsterValue = false;

        bool lpConstant =
            V25DecodeConstantBool(
                lpFn,
                lpValue
            );

        bool monsterConstant =
            V25DecodeConstantBool(
                monsterFn,
                monsterValue
            );

        if (!lpConstant ||
            !monsterConstant)
        {
            continue;
        }

        ++decoded;

        std::cout
            << "slot +"
            << HexU64(
                slot
            )
            << " | LP="
            << (
                lpValue
                    ? "true"
                    : "false"
            )
            << " | Monster="
            << (
                monsterValue
                    ? "true"
                    : "false"
            )
            << " | lpFnRva=";

        if (InsideExeImage(
                lpFn))
        {
            std::cout
                << HexU64(
                    lpFn -
                    g_exeBase
                );
        }
        else
        {
            std::cout
                << HexPtr(
                    lpFn
                );
        }

        std::cout
            << " | monsterFnRva=";

        if (InsideExeImage(
                monsterFn))
        {
            std::cout
                << HexU64(
                    monsterFn -
                    g_exeBase
                );
        }
        else
        {
            std::cout
                << HexPtr(
                    monsterFn
                );
        }

        if (lpValue &&
            monsterValue)
        {
            std::cout
                << "  <BOTH TRUE>";
        }
        else if (!lpValue &&
                 monsterValue)
        {
            std::cout
                << "  <MONSTER TRUE>";
        }
        else if (lpValue &&
                 !monsterValue)
        {
            std::cout
                << "  <PLAYER TRUE>";
        }

        std::cout
            << "\n";
    }

    std::cout
        << "Decoded constant-bool slots: "
        << decoded
        << "\n";
}

bool RunStage6AMonsterDiscovery(
    DbProfile& profile)
{
    std::cout
        << "\n============================================================\n"
        << "       STAGE 6A - WORLD THING COHORTS + MONSTER\n"
        << "============================================================\n"
        << "[MODE] READ-ONLY\n"
        << "[NO WRITE] nenhuma escrita em memoria do jogo\n"
        << "[NO HOOK] nenhum hook\n"
        << "[NO CALL] nenhuma funcao/virtual interna sera chamada\n"
        << "\n"
        << "Objetivo:\n"
        << "  1. usar o Map->Tile path confirmado\n"
        << "  2. enumerar Tile::things do world\n"
        << "  3. agrupar Things por vtable\n"
        << "  4. capturar DOIS monstros distintos via AttackTarget\n"
        << "  5. exigir mesma vtable nos dois monstros\n"
        << "  6. mapear estaticamente slots constant-bool da vtable\n";

    if (profile.mapTilePathStatus !=
            "confirmed_runtime_two_positions" ||
        !profile.mapTilePathDepth ||
        !profile.mapTilePathHeaderOffset)
    {
        std::cout
            << "[STOP] Stage 5B ainda nao esta confirmada.\n";

        return false;
    }

    uintptr_t localPlayer =
        WaitForDiscoveryLocalPlayer(
            profile,
            "STAGE 6A - WORLD THING COHORTS + MONSTER"
        );

    if (!localPlayer)
        return false;

    if (!WaitForTileWorldReady(
            profile,
            localPlayer))
    {
        return false;
    }

    auto observations =
        V25CollectWorldThings(
            profile,
            localPlayer
        );

    if (observations.empty())
    {
        profile.monsterVtableStatus =
            "unresolved_world_empty";

        return false;
    }

    auto cohorts =
        V25BuildCohorts(
            observations,
            localPlayer
        );

    V25PrintCohorts(
        cohorts
    );

    if (!V25WaitAttackTargetClear(
            profile))
    {
        return false;
    }

    uintptr_t monsterA =
        V25CaptureMonsterTarget(
            profile,
            observations,
            localPlayer,
            0,
            "A"
        );

    if (!monsterA)
    {
        profile.monsterVtableStatus =
            "pending_sample_A_retry";

        return false;
    }

    const V25ThingObservation* obsA =
        V25FindObservation(
            observations,
            monsterA
        );

    if (!obsA)
    {
        profile.monsterVtableStatus =
            "unresolved_sample_A";

        return false;
    }

    uintptr_t vtableA =
        obsA->vtable;

    if (!V25WaitAttackTargetClear(
            profile))
    {
        return false;
    }

    // V2.3: do NOT snapshot before the user selects Sample B.
    // V25CaptureMonsterTarget refreshes immediately after reading AttackTarget.
    auto observationsB =
        observations;

    uintptr_t monsterB =
        V25CaptureMonsterTarget(
            profile,
            observationsB,
            localPlayer,
            monsterA,
            "B"
        );

    if (!monsterB)
    {
        profile.monsterVtableStatus =
            "pending_sample_B_retry";

        return false;
    }

    const V25ThingObservation* obsB =
        V25FindObservation(
            observationsB,
            monsterB
        );

    if (!obsB)
    {
        profile.monsterVtableStatus =
            "unresolved_sample_B";

        return false;
    }

    uintptr_t vtableB =
        obsB->vtable;

    std::cout
        << "\n============================================================\n"
        << "               MONSTER SAMPLE CROSS-CHECK\n"
        << "============================================================\n"
        << "Monster A            : "
        << HexPtr(
            monsterA
        )
        << " vtableRva="
        << HexU64(
            vtableA -
            g_exeBase
        )
        << "\n"
        << "Monster B            : "
        << HexPtr(
            monsterB
        )
        << " vtableRva="
        << HexU64(
            vtableB -
            g_exeBase
        )
        << "\n";

    if (monsterA ==
        monsterB)
    {
        profile.monsterVtableStatus =
            "unresolved_same_monster_pointer";

        std::cout
            << "[CHECK] Os dois samples apontam para o mesmo objeto.\n";

        return false;
    }

    if (vtableA !=
        vtableB)
    {
        profile.monsterVtableStatus =
            "ambiguous_multiple_monster_vtables";

        std::cout
            << "[CHECK] Os dois monstros possuem vtables diferentes.\n"
            << "Nenhuma vtable sera promovida nesta rodada.\n";

        return false;
    }

    if (!InsideExeImage(
            vtableA))
    {
        profile.monsterVtableStatus =
            "unresolved_monster_vtable_outside_module";

        return false;
    }

    profile.monsterVtableRva =
        vtableA -
        g_exeBase;

    profile.monsterVtableStatus =
        "confirmed_runtime_two_attack_samples";

    std::cout
        << "\n============================================================\n"
        << "               MONSTER VTABLE CONFIRMED\n"
        << "============================================================\n"
        << "Monster VTable RVA   : "
        << HexU64(
            profile.monsterVtableRva
        )
        << "\n"
        << "Evidence             : dois AttackTarget distintos\n"
        << "                       complete-object identity / RTTI cross-check\n"
        << "                       mesma world Thing vtable\n"
        << "Status               : "
        << profile.monsterVtableStatus
        << "\n";

    const V25ThingObservation* localWorldObs =
        V25FindObservation(
            observationsB,
            localPlayer
        );

    uintptr_t localPlayerVtable =
        localWorldObs
            ? localWorldObs->vtable
            : g_exeBase +
                profile.vtableRva;

    std::cout
        << "[IDENTITY] LocalPlayer complete="
        << HexPtr(
            V35CompleteObjectPointer(
                localPlayer)
        )
        << " worldThingVtableRva="
        << HexU64(
            localPlayerVtable -
            g_exeBase
        )
        << "\n";

    V25PrintVtableBoolMatrix(
        localPlayerVtable,
        vtableA
    );

    std::cout
        << "\n[FEITO] STAGE 6A confirmou a vtable de Monster semanticamente.\n"
        << "[PROXIMO] Usar os cohorts + bool matrix para fechar Creature/NPC/Player classification.\n";

    return true;
}

bool EnsureStage6AMonsterDiscovery(
    DbProfile& profile,
    std::vector<DbProfile>& database,
    int profileIndex,
    const std::string& databasePath)
{
    if (profile.monsterVtableStatus.find(
            "confirmed_") == 0 &&
        profile.monsterVtableRva)
    {
        std::cout
            << "\n[FEITO] STAGE 6A - Monster VTable ja esta confirmada.\n"
            << "Monster VTable RVA: "
            << HexU64(
                profile.monsterVtableRva
            )
            << "\n";

        return true;
    }

    profile.monsterVtableRva = 0;
    profile.monsterVtableStatus =
        "rediscovery_running";

    bool ok =
        RunStage6AMonsterDiscovery(
            profile
        );

    if (profileIndex >= 0 &&
        profileIndex <
            static_cast<int>(
                database.size()
            ))
    {
        database[
            static_cast<size_t>(
                profileIndex
            )
        ] = profile;

        SaveProfileDatabase(
            databasePath,
            database
        );
    }

    return ok;
}


// ============================================================
// DISCOVERY V2.6 - CLASSIFICATION CORE + REMOTE PLAYER
// Strict read-only. Static decoding only; no virtual calls.
// ============================================================

struct V26BoolRow
{
    uintptr_t slot = 0;

    bool itemKnown = false;
    bool itemValue = false;

    bool localKnown = false;
    bool localValue = false;

    bool playerKnown = false;
    bool playerValue = false;

    bool monsterKnown = false;
    bool monsterValue = false;
};

const V25ThingCohort*
V26FindCohortByVtable(
    const std::vector<V25ThingCohort>& cohorts,
    uintptr_t vtable)
{
    for (const auto& c :
         cohorts)
    {
        if (c.vtable ==
            vtable)
        {
            return &c;
        }
    }

    return nullptr;
}

const V25ThingCohort*
V26SelectLowIdTileThingCohort(
    const std::vector<V25ThingCohort>& cohorts,
    uintptr_t localPlayerVtable,
    uintptr_t monsterVtable)
{
    std::vector<const V25ThingCohort*>
        candidates;

    for (const auto& c :
         cohorts)
    {
        if (!c.vtable ||
            c.vtable ==
                localPlayerVtable ||
            c.vtable ==
                monsterVtable)
        {
            continue;
        }

        if (c.objects < 8)
            continue;

        if (c.highId != 0)
            continue;

        if (c.plausiblePosition !=
            c.objects)
        {
            continue;
        }

        candidates.push_back(
            &c
        );
    }

    if (candidates.empty())
        return nullptr;

    std::sort(
        candidates.begin(),
        candidates.end(),
        [](
            const V25ThingCohort* a,
            const V25ThingCohort* b)
        {
            if (a->objects !=
                b->objects)
            {
                return
                    a->objects >
                    b->objects;
            }

            return
                a->vtableRva <
                b->vtableRva;
        }
    );

    if (candidates.size() > 1)
    {
        size_t first =
            candidates[0]->objects;

        size_t second =
            candidates[1]->objects;

        // Require clear dominance. We do not want to call a random
        // low-ID cohort "Item" when multiple families are similarly common.
        if (first <
            second * 3)
        {
            return nullptr;
        }
    }

    return
        candidates[0];
}


bool V33RttiLooksLikeControlBlock(
    const std::string& rttiName)
{
    std::string rtti =
        LowerAscii(
            rttiName
        );

    return
        rtti.find(
            "_ref_count") !=
            std::string::npos ||
        rtti.find(
            "shared_ptr") !=
            std::string::npos;
}

bool V33RttiContainsClassToken(
    const std::string& rttiName,
    const std::string& token)
{
    std::string rtti =
        LowerAscii(
            rttiName
        );

    std::string wanted =
        LowerAscii(
            token
        );

    return
        rtti.find(
            wanted
        ) !=
        std::string::npos;
}

const V25ThingCohort*
V33SelectItemCohortSemantic(
    const std::vector<V25ThingCohort>& cohorts,
    uintptr_t localPlayerVtable,
    uintptr_t monsterVtable,
    std::string& method)
{
    method.clear();

    std::vector<const V25ThingCohort*>
        exactRtti;

    std::vector<const V25ThingCohort*>
        structural;

    for (const auto& c :
         cohorts)
    {
        if (!c.vtable ||
            c.vtable ==
                localPlayerVtable ||
            c.vtable ==
                monsterVtable)
        {
            continue;
        }

        if (V33RttiLooksLikeControlBlock(
                c.rttiName))
        {
            continue;
        }

        if (V33RttiContainsClassToken(
                c.rttiName,
                "item"))
        {
            exactRtti.push_back(
                &c
            );

            continue;
        }

        if (c.objects < 4)
            continue;

        // Thing-derived objects on the tested clients keep positional state.
        // No ID assumption is used here.
        if (c.plausiblePosition * 100 <
                c.objects * 85)
        {
            continue;
        }

        // Explicit creature RTTI is not an Item candidate.
        if (V33RttiContainsClassToken(
                c.rttiName,
                "player") ||
            V33RttiContainsClassToken(
                c.rttiName,
                "monster") ||
            V33RttiContainsClassToken(
                c.rttiName,
                "npc") ||
            V33RttiContainsClassToken(
                c.rttiName,
                "creature"))
        {
            continue;
        }

        structural.push_back(
            &c
        );
    }

    if (exactRtti.size() == 1)
    {
        method =
            "rtti_item_class";

        return
            exactRtti[0];
    }

    if (exactRtti.size() > 1)
    {
        std::sort(
            exactRtti.begin(),
            exactRtti.end(),
            [](
                const V25ThingCohort* a,
                const V25ThingCohort* b)
            {
                return
                    a->objects >
                    b->objects;
            }
        );

        if (exactRtti[0]->objects >
            exactRtti[1]->objects * 2)
        {
            method =
                "rtti_item_class_dominant";

            return
                exactRtti[0];
        }

        return nullptr;
    }

    if (structural.empty())
        return nullptr;

    std::sort(
        structural.begin(),
        structural.end(),
        [](
            const V25ThingCohort* a,
            const V25ThingCohort* b)
        {
            if (a->objects !=
                b->objects)
            {
                return
                    a->objects >
                    b->objects;
            }

            return
                a->vtableRva <
                b->vtableRva;
        }
    );

    if (structural.size() > 1)
    {
        const size_t first =
            structural[0]->objects;

        const size_t second =
            structural[1]->objects;

        if (first <
            second * 3)
        {
            return nullptr;
        }
    }

    method =
        "dominant_noncreature_world_cohort";

    return
        structural[0];
}


std::vector<V26BoolRow>
V26BuildBoolMatrix(
    uintptr_t itemVtable,
    uintptr_t localPlayerVtable,
    uintptr_t playerVtable,
    uintptr_t monsterVtable)
{
    std::vector<V26BoolRow>
        rows;

    for (uintptr_t slot = 0;
         slot <= 0x100;
         slot += 8)
    {
        V26BoolRow row{};
        row.slot = slot;

        uintptr_t itemFn =
            itemVtable
                ? ReadPtr(
                    itemVtable +
                    slot
                )
                : 0;

        uintptr_t localFn =
            localPlayerVtable
                ? ReadPtr(
                    localPlayerVtable +
                    slot
                )
                : 0;

        uintptr_t playerFn =
            playerVtable
                ? ReadPtr(
                    playerVtable +
                    slot
                )
                : 0;

        uintptr_t monsterFn =
            monsterVtable
                ? ReadPtr(
                    monsterVtable +
                    slot
                )
                : 0;

        row.itemKnown =
            itemVtable &&
            V25DecodeConstantBool(
                itemFn,
                row.itemValue
            );

        row.localKnown =
            localPlayerVtable &&
            V25DecodeConstantBool(
                localFn,
                row.localValue
            );

        row.playerKnown =
            playerVtable &&
            V25DecodeConstantBool(
                playerFn,
                row.playerValue
            );

        row.monsterKnown =
            monsterVtable &&
            V25DecodeConstantBool(
                monsterFn,
                row.monsterValue
            );

        if (row.itemKnown ||
            row.localKnown ||
            row.playerKnown ||
            row.monsterKnown)
        {
            rows.push_back(
                row
            );
        }
    }

    return rows;
}

void V26PrintBoolMatrix(
    const std::vector<V26BoolRow>& rows,
    bool hasRemotePlayer)
{
    std::cout
        << "\n============================================================\n"
        << "             FOUR-CLASS STATIC BOOL MATRIX\n"
        << "============================================================\n"
        << "[NO CALL] vtable functions are NOT executed.\n";

    for (const auto& r :
         rows)
    {
        if (!r.itemKnown ||
            !r.localKnown ||
            !r.monsterKnown ||
            (hasRemotePlayer &&
             !r.playerKnown))
        {
            continue;
        }

        std::cout
            << "slot +"
            << HexU64(
                r.slot
            )
            << " | Item="
            << (
                r.itemValue
                    ? "T"
                    : "F"
            )
            << " | LocalPlayer="
            << (
                r.localValue
                    ? "T"
                    : "F"
            );

        if (hasRemotePlayer)
        {
            std::cout
                << " | Player="
                << (
                    r.playerValue
                        ? "T"
                        : "F"
                );
        }

        std::cout
            << " | Monster="
            << (
                r.monsterValue
                    ? "T"
                    : "F"
            )
            << "\n";
    }
}

std::vector<uintptr_t>
V26MatchSlots(
    const std::vector<V26BoolRow>& rows,
    bool item,
    bool local,
    bool player,
    bool monster,
    bool requirePlayer)
{
    std::vector<uintptr_t>
        out;

    for (const auto& r :
         rows)
    {
        if (!r.itemKnown ||
            !r.localKnown ||
            !r.monsterKnown)
        {
            continue;
        }

        if (requirePlayer &&
            !r.playerKnown)
        {
            continue;
        }

        if (r.itemValue != item ||
            r.localValue != local ||
            r.monsterValue != monster)
        {
            continue;
        }

        if (requirePlayer &&
            r.playerValue != player)
        {
            continue;
        }

        out.push_back(
            r.slot
        );
    }

    return out;
}

bool V26WaitFollowTargetClear(
    const DbProfile& profile)
{
    uintptr_t game =
        g_exeBase +
        profile.gameRva;

    for (;;)
    {
        uintptr_t follow =
            ReadPtr(
                game +
                profile.gameFollowTarget
            );

        if (!follow)
            return true;

        std::cout
            << "\n[CLEAR FOLLOW] FollowTarget ainda esta em "
            << HexPtr(
                follow
            )
            << ".\n"
            << "Desative o Follow pelo cliente e pressione ENTER.\n";

        WaitEnter(
            "Depois de limpar FollowTarget, pressione ENTER..."
        );
    }
}

bool V26CaptureRemotePlayer(
    const DbProfile& profile,
    uintptr_t localPlayer,
    uintptr_t monsterVtable,
    uintptr_t& remotePlayer,
    uintptr_t& remotePlayerVtable)
{
    remotePlayer = 0;
    remotePlayerVtable = 0;

    uintptr_t game =
        g_exeBase +
        profile.gameRva;

    const int maxCaptureRounds = 3;
    int captureRound = 0;

    for (;;)
    {
        ++captureRound;

        std::cout
            << "\n[PLAYER SAMPLE ROUND] "
            << captureRound
            << "/"
            << maxCaptureRounds
            << "\n";
        std::cout
            << "\n============================================================\n"
            << "                REMOTE PLAYER SAMPLE\n"
            << "============================================================\n"
            << "Use o FOLLOW normal do cliente em OUTRO PLAYER humano visivel.\n"
            << "Nao use Monster/NPC e nao use seu proprio personagem.\n"
            << "O Lab vai SALVAR o FollowTarget primeiro.\n"
            << "Depois voce vai DESATIVAR o Follow antes do scan do world.\n";

        WaitEnter(
            "Com o OUTRO PLAYER em Follow, pressione ENTER..."
        );

        uintptr_t follow =
            ReadPtr(
                game +
                profile.gameFollowTarget
            );

        if (!follow)
        {
            std::cout
                << "[RETRY] FollowTarget esta NULL.\n";

            if (captureRound >= maxCaptureRounds)
            {
                std::cout
                    << "[CALIBRATE] Limite de 3 amostras atingido. Voltando ao orquestrador para R/S/Q.\n";
                return false;
            }

            continue;
        }

        if (follow ==
            localPlayer)
        {
            std::cout
                << "[RETRY] FollowTarget e o proprio LocalPlayer.\n";

            if (captureRound >= maxCaptureRounds)
            {
                std::cout
                    << "[CALIBRATE] Limite de 3 amostras atingido. Voltando ao orquestrador para R/S/Q.\n";
                return false;
            }

            continue;
        }

        if (!IsReadableMonitorRange(
                follow,
                0x100))
        {
            std::cout
                << "[RETRY] FollowTarget unreadable.\n";

            if (captureRound >= maxCaptureRounds)
            {
                std::cout
                    << "[CALIBRATE] Limite de 3 amostras atingido. Voltando ao orquestrador para R/S/Q.\n";
                return false;
            }

            continue;
        }

        uintptr_t vt =
            ReadPtr(
                follow
            );

        if (!InsideExeImage(
                vt))
        {
            std::cout
                << "[RETRY] FollowTarget vtable fora do modulo.\n";

            if (captureRound >= maxCaptureRounds)
            {
                std::cout
                    << "[CALIBRATE] Limite de 3 amostras atingido. Voltando ao orquestrador para R/S/Q.\n";
                return false;
            }

            continue;
        }

        std::string followRtti =
            TryReadMsvcRttiTypeName(
                vt
            );

        if (
            vt ==
                monsterVtable ||
            V33RttiContainsClassToken(
                followRtti,
                "monster") ||
            V33RttiContainsClassToken(
                followRtti,
                "npc")
        )
        {
            std::cout
                << "[RETRY] FollowTarget RTTI/vtable nao representa Player humano. RTTI=\""
                << followRtti
                << "\"\n";

            V26WaitFollowTargetClear(
                profile
            );

            if (captureRound >= maxCaptureRounds)
            {
                std::cout
                    << "[CALIBRATE] Limite de 3 amostras atingido. Voltando ao orquestrador para R/S/Q.\n";
                return false;
            }

            continue;
        }

        MapPosition p =
            ReadDiscoveredPlayerPosition(
                follow,
                profile
            );

        uint32_t id =
            ReadU32(
                follow +
                profile.id
            );

        uint8_t hp =
            ReadU8(
                follow +
                profile.hpPercent
            );

        uint32_t direction =
            ReadU32(
                follow +
                profile.direction
            );

        if (!MapPositionPlausible(
                p))
        {
            std::cout
                << "[RETRY] FollowTarget nao possui Position plausivel.\n";

            V26WaitFollowTargetClear(
                profile
            );

            if (captureRound >= maxCaptureRounds)
            {
                std::cout
                    << "[CALIBRATE] Limite de 3 amostras atingido. Voltando ao orquestrador para R/S/Q.\n";
                return false;
            }

            continue;
        }

        // ID/HP/direction layouts can drift independently between builds.
        // They are printed as diagnostics but are NOT prerequisites for
        // semantic Player capture. The later world-membership test is the
        // stronger invariant.

        // Save the semantic sample BEFORE asking the user to stop following.
        uintptr_t capturedPlayer =
            follow;

        uintptr_t capturedVtable =
            vt;

        MapPosition capturedPosition =
            p;

        uint32_t capturedId =
            id;

        uint8_t capturedHp =
            hp;

        std::cout
            << "\n[CAPTURED FOLLOWTARGET]\n"
            << "ptr                  : "
            << HexPtr(
                capturedPlayer
            )
            << "\n"
            << "vtableRva            : "
            << HexU64(
                capturedVtable -
                g_exeBase
            )
            << "\n"
            << "pos                  : "
            << capturedPosition.x
            << ","
            << capturedPosition.y
            << ","
            << static_cast<unsigned>(
                capturedPosition.z
            )
            << "\n"
            << "id                   : "
            << capturedId
            << "\n"
            << "hp%                  : "
            << static_cast<unsigned>(
                capturedHp
            )
            << "\n"
            << "\n"
            << "AGORA DESATIVE O FOLLOW pelo cliente.\n"
            << "Mantenha o outro Player visivel e fique parado.\n";

        // Follow movement can mutate/rebuild the current map storage while the
        // Lab scans it. Clear Follow first, but keep the captured pointer locally.
        V26WaitFollowTargetClear(
            profile
        );

        std::cout
            << "\n[SYNC] FollowTarget limpo. Aguardando world estabilizar novamente...\n";

        if (!WaitForTileWorldReady(
                profile,
                localPlayer))
        {
            std::cout
                << "[RETRY] World nao estabilizou apos limpar Follow.\n";

            if (captureRound >= maxCaptureRounds)
            {
                std::cout
                    << "[CALIBRATE] Limite de 3 amostras atingido. Voltando ao orquestrador para R/S/Q.\n";
                return false;
            }

            continue;
        }

        const int maxWorldAttempts =
            4;

        bool verifiedInWorld =
            false;

        for (int attempt = 1;
             attempt <= maxWorldAttempts;
             ++attempt)
        {
            std::cout
                << "\n[WORLD VERIFY] tentativa "
                << attempt
                << "/"
                << maxWorldAttempts
                << "\n";

            // Revalidate the captured object before every world pass.
            if (!IsReadableMonitorRange(
                    capturedPlayer,
                    0x100) ||
                ReadPtr(
                    capturedPlayer
                ) !=
                    capturedVtable)
            {
                std::cout
                    << "[WORLD VERIFY] Player capturado nao esta mais valido.\n";

                break;
            }

            auto world =
                V25CollectWorldThings(
                    profile,
                    localPlayer
                );

            if (world.empty())
            {
                std::cout
                    << "[WORLD VERIFY] World array temporariamente indisponivel.\n";

                Sleep(400);

                WaitForTileWorldReady(
                    profile,
                    localPlayer
                );

                continue;
            }

            const V25ThingObservation* obs =
                V25FindObservation(
                    world,
                    capturedPlayer
                );

            if (!obs)
            {
                // Some MSVC shared_ptr layouts expose a FollowTarget wrapper/control
                // object while Tile::things stores the actual Player Thing*.  Do not
                // require raw pointer equality in that case.  Rebind only when there
                // is exactly ONE non-local Player RTTI world object at the captured
                // position.  This mirrors the Monster identity-rebind policy while
                // remaining conservative on ambiguous scenes.
                const V25ThingObservation* rebound = nullptr;
                size_t reboundMatches = 0;

                for (const auto& candidate : world)
                {
                    const bool samePosition =
                        candidate.positionPlausible &&
                        candidate.x == capturedPosition.x &&
                        candidate.y == capturedPosition.y &&
                        candidate.z == capturedPosition.z;

                    const bool playerRtti =
                        V33RttiContainsClassToken(candidate.rttiName, "player") &&
                        !V33RttiContainsClassToken(candidate.rttiName, "localplayer");

                    const bool notLocal =
                        candidate.completeObject != V35CompleteObjectPointer(localPlayer) &&
                        candidate.pointer != localPlayer;

                    if (samePosition && playerRtti && notLocal)
                    {
                        rebound = &candidate;
                        ++reboundMatches;
                    }
                }

                if (reboundMatches == 1 && rebound)
                {
                    remotePlayer = rebound->pointer;
                    remotePlayerVtable = rebound->vtable;

                    std::cout
                        << "\n[PLAYER FOLLOW REBIND][PASS]\n"
                        << "FollowTarget raw ptr : " << HexPtr(capturedPlayer) << "\n"
                        << "World Player ptr     : " << HexPtr(remotePlayer) << "\n"
                        << "Captured position    : "
                        << capturedPosition.x << "," << capturedPosition.y << ","
                        << static_cast<unsigned>(capturedPosition.z) << "\n"
                        << "World Player vtable  : "
                        << HexU64(remotePlayerVtable - g_exeBase) << "\n"
                        << "RTTI                 : " << rebound->rttiName << "\n"
                        << "Evidence             : unique Player RTTI at captured FollowTarget position\n";

                    verifiedInWorld = true;
                    break;
                }

                std::cout
                    << "[WORLD VERIFY] FollowTarget raw ptr nao apareceu em Tile::things; "
                    << "Player positional rebind matches="
                    << reboundMatches
                    << ".\n";

                Sleep(350);

                continue;
            }

            const bool sameIdentity =
                obs->completeObject ==
                    V35CompleteObjectPointer(
                        capturedPlayer
                    );

            const std::string capturedRtti =
                TryReadMsvcRttiTypeName(
                    capturedVtable
                );

            const bool playerRtti =
                V33RttiContainsClassToken(
                    obs->rttiName,
                    "player") ||
                V33RttiContainsClassToken(
                    capturedRtti,
                    "player");

            if (!sameIdentity ||
                !playerRtti)
            {
                std::cout
                    << "[WORLD VERIFY] Complete-object identity / Player RTTI nao fechou.\n";

                break;
            }

            remotePlayer =
                capturedPlayer;

            // Keep the vtable used by Tile::things. It belongs to the same
            // complete Player object and is the correct semantic comparator
            // against Item/Monster/NPC world cohorts.
            remotePlayerVtable =
                obs->vtable;

            std::cout
                << "\n[PLAYER SAMPLE VERIFIED]\n"
                << "ptr                  : "
                << HexPtr(
                    remotePlayer
                )
                << "\n"
                << "vtableRva            : "
                << HexU64(
                    remotePlayerVtable -
                    g_exeBase
                )
                << "\n"
                << "captured vtable RVA  : "
                << HexU64(
                    capturedVtable -
                    g_exeBase
                )
                << "\n"
                << "world Thing vtable   : "
                << HexU64(
                    remotePlayerVtable -
                    g_exeBase
                )
                << "\n"
                << "RTTI                 : "
                << obs->rttiName
                << "\n"
                << "subobject offset     : "
                << obs->rttiSubobjectOffset
                << "\n"
                << "complete identity    : PASS\n"
                << "FollowTarget capture : PASS\n"
                << "world stable         : PASS\n";

            verifiedInWorld =
                true;

            break;
        }

        if (verifiedInWorld)
        {
            return true;
        }

        std::cout
            << "\n[RETRY] Nao foi possivel confirmar o Player capturado no world estavel.\n"
            << "Escolha um Player que continue VISIVEL, ative Follow novamente e repita.\n";

        if (captureRound >= maxCaptureRounds)
        {
            std::cout
                << "[CALIBRATE] 3 rodadas de Player remoto sem confirmacao. "
                << "Voltando ao orquestrador para R/S/Q; nao ficara preso em loop.\n";
            return false;
        }
    }
}

bool RunStage6BClassification(
    DbProfile& profile)
{
    std::cout
        << "\n============================================================\n"
        << "     STAGE 6B - SEMANTIC CLASSIFICATION + PLAYER\n"
        << "============================================================\n"
        << "[MODE] READ-ONLY\n"
        << "[NO WRITE] nenhuma escrita em memoria do jogo\n"
        << "[NO HOOK] nenhum hook\n"
        << "[NO CALL] nenhuma funcao/virtual interna sera chamada\n"
        << "\n"
        << "Objetivo:\n"
        << "  1. detectar RAW Thing* ou shared_ptr<Thing>\n"
        << "  2. remover control-blocks da enumeracao\n"
        << "  3. usar Monster e LocalPlayer como anchors conhecidos\n"
        << "  4. resolver Item por RTTI/estrutura, sem depender de ID\n"
        << "  5. capturar Player humano via FollowTarget\n"
        << "  6. tentar slots constant-bool; se a build nao usar esse padrao,\n"
        << "     preservar as vtables semanticas e deixar slots pending\n";

    if (profile.monsterVtableStatus.find(
            "confirmed_") != 0 ||
        !profile.monsterVtableRva)
    {
        std::cout
            << "[STOP] Monster VTable ainda nao esta confirmada.\n";

        return false;
    }

    uintptr_t localPlayer =
        WaitForDiscoveryLocalPlayer(
            profile,
            "STAGE 6B - SEMANTIC CLASSIFICATION + PLAYER"
        );

    if (!localPlayer)
        return false;

    if (!WaitForTileWorldReady(
            profile,
            localPlayer))
    {
        return false;
    }

    V33PersistThingStorage(
        profile,
        localPlayer
    );

    auto observations =
        V25CollectWorldThings(
            profile,
            localPlayer
        );

    if (observations.empty())
    {
        profile.classificationStatus =
            "unresolved_world_empty";

        return false;
    }

    auto cohorts =
        V25BuildCohorts(
            observations,
            localPlayer
        );

    V25PrintCohorts(
        cohorts
    );


    // V3.5: AttackTarget may point at the complete/primary object while
    // Tile::things stores a secondary Thing subobject. RTTI identifies both
    // as the same most-derived Monster class. Prefer the world Thing vtable
    // for class comparisons after the complete-object identity bridge.
    std::vector<const V25ThingCohort*>
        monsterRttiCohorts;

    for (const auto& cohort :
         cohorts)
    {
        if (V33RttiContainsClassToken(
                cohort.rttiName,
                "monster") &&
            !V33RttiLooksLikeControlBlock(
                cohort.rttiName))
        {
            monsterRttiCohorts.push_back(
                &cohort
            );
        }
    }

    if (monsterRttiCohorts.size() == 1)
    {
        uintptr_t worldMonsterRva =
            monsterRttiCohorts[0]->vtableRva;

        if (profile.monsterVtableRva !=
            worldMonsterRva)
        {
            std::cout
                << "[IDENTITY REBIND] Monster AttackTarget vtable RVA "
                << HexU64(
                    profile.monsterVtableRva
                )
                << " -> world Thing vtable RVA "
                << HexU64(
                    worldMonsterRva
                )
                << " RTTI=\\\""
                << monsterRttiCohorts[0]->rttiName
                << "\\\"\\n";

            profile.monsterVtableRva =
                worldMonsterRva;

            profile.monsterVtableStatus =
                "confirmed_semantic_rtti_world_cohort";
        }
    }

    const V25ThingObservation* localWorldObs =
        V25FindObservation(
            observations,
            localPlayer
        );

    uintptr_t localPlayerVtable =
        localWorldObs
            ? localWorldObs->vtable
            : g_exeBase +
                profile.vtableRva;

    uintptr_t monsterVtable =
        g_exeBase +
        profile.monsterVtableRva;

    std::string itemMethod;

    const V25ThingCohort* itemCohort =
        V33SelectItemCohortSemantic(
            cohorts,
            localPlayerVtable,
            monsterVtable,
            itemMethod
        );

    if (!itemCohort)
    {
        profile.itemVtableStatus =
            "unresolved_semantic_item_cohort";

        profile.classificationStatus =
            "unresolved_item_anchor";

        std::cout
            << "[CHECK] Item nao ficou semanticamente unico por RTTI/estrutura.\n";

        return false;
    }

    uintptr_t itemVtable =
        itemCohort->vtable;

    profile.itemVtableRva =
        itemCohort->vtableRva;

    profile.itemVtableStatus =
        itemMethod.find(
            "rtti_") == 0
            ? "confirmed_semantic_rtti_item"
            : "confirmed_semantic_dominant_world_item";

    std::cout
        << "\n============================================================\n"
        << "                 ITEM ANCHOR CONFIRMED\n"
        << "============================================================\n"
        << "VTable RVA           : "
        << HexU64(
            itemCohort->vtableRva
        )
        << "\n"
        << "RTTI                 : "
        << itemCohort->rttiName
        << "\n"
        << "Objects              : "
        << itemCohort->objects
        << "\n"
        << "Method               : "
        << itemMethod
        << "\n"
        << "Status               : "
        << profile.itemVtableStatus
        << "\n";

    // V3.8: when another Player is already present in the world,
    // RTTI itself can close the semantic class without requiring a Follow
    // interaction. FollowTarget remains the stronger fallback.
    std::vector<const V25ThingCohort*>
        rttiPlayers;

    for (const auto& cohort :
         cohorts)
    {
        if (!cohort.vtable ||
            cohort.vtable ==
                localPlayerVtable ||
            cohort.vtable ==
                monsterVtable ||
            cohort.vtable ==
                itemVtable)
        {
            continue;
        }

        std::string rtti =
            LowerAscii(
                cohort.rttiName
            );

        if (rtti.find(
                "localplayer") !=
                std::string::npos)
        {
            continue;
        }

        if (rtti.find(
                "player") !=
                std::string::npos &&
            rtti.find(
                "_ref_count") ==
                std::string::npos &&
            rtti.find(
                "shared_ptr") ==
                std::string::npos)
        {
            rttiPlayers.push_back(
                &cohort
            );
        }
    }

    if (rttiPlayers.size() == 1)
    {
        profile.playerVtableRva =
            rttiPlayers[0]->vtableRva;

        profile.playerVtableStatus =
            "confirmed_semantic_rtti_player_world";

        profile.classificationStatus =
            "confirmed_semantic_vtables_slots_pending";

        std::cout
            << "\n[PLAYER RTTI AUTO-CONFIRMED]\n"
            << "VTable RVA : "
            << HexU64(
                profile.playerVtableRva
            )
            << "\n"
            << "RTTI       : "
            << rttiPlayers[0]->rttiName
            << "\n"
            << "Evidence   : unique non-local Player RTTI cohort\n";

        return true;
    }

    if (!V26WaitFollowTargetClear(
            profile))
    {
        return false;
    }

    uintptr_t remotePlayer = 0;
    uintptr_t remotePlayerVtable = 0;

    const bool haveVisiblePlayer =
        AskYesNo(
            "Existe OUTRO PLAYER humano visivel para fazer FOLLOW agora? [S/N]: "
        );

    if (!haveVisiblePlayer)
    {
        profile.playerVtableRva = 0;

        profile.playerVtableStatus =
            "pending_no_visible_player_sample";

        profile.slotIsItem = 0;
        profile.slotIsCreature = 0;
        profile.slotIsMonster = 0;
        profile.slotIsPlayer = 0;
        profile.slotIsLocalPlayer = 0;

        profile.classificationStatus =
            "partial_semantic_item_monster_player_pending";

        std::cout
            << "\n[PARTIAL PASS] Nao ha Player humano disponivel agora.\n"
            << "[FEITO] Item e Monster permanecem como anchors semanticas.\n"
            << "[PENDING] Player sera fechado depois por FollowTarget.\n"
            << "[CONTINUE] Liberando Inventory / Item / Containers que nao dependem "
            << "da amostra Player.\n";

        return true;
    }

    if (!V26CaptureRemotePlayer(
            profile,
            localPlayer,
            monsterVtable,
            remotePlayer,
            remotePlayerVtable))
    {
        profile.playerVtableStatus =
            "unresolved_follow_sample";

        return false;
    }

    profile.playerVtableRva =
        remotePlayerVtable -
        g_exeBase;

    profile.playerVtableStatus =
        "confirmed_runtime_followtarget_world_member";

    std::string playerRtti =
        TryReadMsvcRttiTypeName(
            remotePlayerVtable
        );

    if (playerRtti.empty())
        playerRtti = "<unavailable>";

    std::cout
        << "\n============================================================\n"
        << "                PLAYER ANCHOR CONFIRMED\n"
        << "============================================================\n"
        << "VTable RVA           : "
        << HexU64(
            profile.playerVtableRva
        )
        << "\n"
        << "RTTI                 : "
        << playerRtti
        << "\n"
        << "Evidence             : FollowTarget + world membership\n";

    // Static bool slots are useful on the old OpenGL/DX family, but newer
    // clients can implement these predicates as non-constant functions.
    // Treat slots as an optional semantic accelerator, not a prerequisite
    // for identifying Item/Player/Monster classes.
    auto rows =
        V26BuildBoolMatrix(
            itemVtable,
            localPlayerVtable,
            remotePlayerVtable,
            monsterVtable
        );

    V26PrintBoolMatrix(
        rows,
        true
    );

    auto isItem =
        V26MatchSlots(
            rows,
            true,
            false,
            false,
            false,
            true
        );

    auto isCreature =
        V26MatchSlots(
            rows,
            false,
            true,
            true,
            true,
            true
        );

    auto isMonster =
        V26MatchSlots(
            rows,
            false,
            false,
            false,
            true,
            true
        );

    auto isPlayer =
        V26MatchSlots(
            rows,
            false,
            true,
            true,
            false,
            true
        );

    auto isLocalPlayer =
        V26MatchSlots(
            rows,
            false,
            true,
            false,
            false,
            true
        );

    std::cout
        << "\n============================================================\n"
        << "              CLASSIFICATION SLOT RESOLUTION\n"
        << "============================================================\n"
        << "isItem candidates       : "
        << isItem.size()
        << "\n"
        << "isCreature candidates   : "
        << isCreature.size()
        << "\n"
        << "isMonster candidates    : "
        << isMonster.size()
        << "\n"
        << "isPlayer candidates     : "
        << isPlayer.size()
        << "\n"
        << "isLocalPlayer candidates: "
        << isLocalPlayer.size()
        << "\n";

    const bool slotsComplete =
        isItem.size() == 1 &&
        isCreature.size() == 1 &&
        isMonster.size() == 1 &&
        isPlayer.size() == 1;

    if (slotsComplete)
    {
        profile.slotIsItem =
            isItem[0];

        profile.slotIsCreature =
            isCreature[0];

        profile.slotIsMonster =
            isMonster[0];

        profile.slotIsPlayer =
            isPlayer[0];

        profile.slotIsLocalPlayer =
            isLocalPlayer.size() == 1
                ? isLocalPlayer[0]
                : 0;

        profile.classificationStatus =
            "confirmed_runtime_four_class_static_bool";
    }
    else
    {
        profile.slotIsItem = 0;
        profile.slotIsCreature = 0;
        profile.slotIsMonster = 0;
        profile.slotIsPlayer = 0;
        profile.slotIsLocalPlayer = 0;

        profile.classificationStatus =
            "confirmed_semantic_vtables_slots_pending";

        std::cout
            << "[INFO] Esta build nao expoe uma matriz constant-bool unica.\n"
            << "[INFO] Item/Player/Monster continuam CONFIRMADOS semanticamente.\n";
    }

    std::cout
        << "\n============================================================\n"
        << "              CLASSIFICATION CORE CONFIRMED\n"
        << "============================================================\n"
        << "Item VTable RVA      : "
        << HexU64(
            profile.itemVtableRva
        )
        << "\n"
        << "Player VTable RVA    : "
        << HexU64(
            profile.playerVtableRva
        )
        << "\n"
        << "Monster VTable RVA   : "
        << HexU64(
            profile.monsterVtableRva
        )
        << "\n"
        << "Thing storage        : "
        << profile.thingStorageMode
        << " stride="
        << profile.thingStorageStride
        << "\n"
        << "Status               : "
        << profile.classificationStatus
        << "\n"
        << "\n"
        << "[FEITO] STAGE 6B confirmou as classes por anchors semanticas.\n"
        << "[PROXIMO] NPC / Inventory / Item / Containers.\n";

    return true;
}

bool EnsureStage6BClassification(
    DbProfile& profile,
    std::vector<DbProfile>& database,
    int profileIndex,
    const std::string& databasePath)
{
    if (
        (
            profile.classificationStatus ==
                "confirmed_runtime_four_class_static_bool" &&
            profile.slotIsItem &&
            profile.slotIsCreature &&
            profile.slotIsMonster &&
            profile.slotIsPlayer
        ) ||
        (
            profile.classificationStatus ==
                "confirmed_semantic_vtables_slots_pending" &&
            profile.itemVtableRva &&
            profile.playerVtableRva &&
            profile.monsterVtableRva
        )
    )
    {
        std::cout
            << "\n[FEITO] STAGE 6B - Classification core ja esta confirmada.\n"
            << "isItem=+"
            << HexU64(
                profile.slotIsItem
            )
            << " isCreature=+"
            << HexU64(
                profile.slotIsCreature
            )
            << " isMonster=+"
            << HexU64(
                profile.slotIsMonster
            )
            << " isPlayer=+"
            << HexU64(
                profile.slotIsPlayer
            )
            << "\n";

        return true;
    }

    profile.itemVtableRva = 0;
    profile.itemVtableStatus =
        "rediscovery_running";

    profile.playerVtableRva = 0;
    profile.playerVtableStatus =
        "rediscovery_running";

    profile.slotIsItem = 0;
    profile.slotIsCreature = 0;
    profile.slotIsMonster = 0;
    profile.slotIsPlayer = 0;
    profile.slotIsLocalPlayer = 0;

    profile.classificationStatus =
        "rediscovery_running";

    bool ok =
        RunStage6BClassification(
            profile
        );

    if (profileIndex >= 0 &&
        profileIndex <
            static_cast<int>(
                database.size()
            ))
    {
        database[
            static_cast<size_t>(
                profileIndex
            )
        ] = profile;

        SaveProfileDatabase(
            databasePath,
            database
        );
    }

    return ok;
}


// ============================================================
// BUILDMIGRATOR V4.6.1 - FINAL DATA COMPLETION
// NPC / INVENTORY / ITEM / CONTAINERS
// Strict read-only.
// ============================================================

bool BMIsGoldenOpenGlBuild(
    const DbProfile& p)
{
    return
        p.timestamp == 0x6AA9FA57ULL &&
        p.sizeOfImage == 0x017BF000ULL &&
        p.textHash == 0x89D3D35243890EA2ULL;
}

bool BMDecodeVtableBool(
    uintptr_t vtable,
    uintptr_t slot,
    bool& value)
{
    value = false;

    if (!vtable ||
        !slot ||
        !IsReadableMonitorRange(
            vtable + slot,
            sizeof(uintptr_t)))
    {
        return false;
    }

    uintptr_t fn =
        ReadPtr(
            vtable +
            slot
        );

    return
        V25DecodeConstantBool(
            fn,
            value
        );
}

bool BMDiscoverNpcFromCurrentWorld(
    DbProfile& profile,
    uintptr_t localPlayer,
    bool verbose)
{
    if (!profile.itemVtableRva ||
        !profile.monsterVtableRva)
    {
        return false;
    }

    auto observations =
        V25CollectWorldThings(
            profile,
            localPlayer
        );

    if (observations.empty())
        return false;

    auto cohorts =
        V25BuildCohorts(
            observations,
            localPlayer
        );

    uintptr_t itemVt =
        g_exeBase +
        profile.itemVtableRva;

    uintptr_t localVt =
        g_exeBase +
        profile.vtableRva;

    uintptr_t playerVt =
        profile.playerVtableRva
            ? g_exeBase +
                profile.playerVtableRva
            : 0;

    uintptr_t monsterVt =
        g_exeBase +
        profile.monsterVtableRva;

    std::vector<const V25ThingCohort*>
        rttiNpc;

    for (const auto& cohort :
         cohorts)
    {
        uintptr_t vt =
            cohort.vtable;

        if (!vt ||
            vt == itemVt ||
            vt == localVt ||
            vt == playerVt ||
            vt == monsterVt)
        {
            continue;
        }

        if (V33RttiLooksLikeControlBlock(
                cohort.rttiName))
        {
            continue;
        }

        if (V33RttiContainsClassToken(
                cohort.rttiName,
                "npc"))
        {
            rttiNpc.push_back(
                &cohort
            );
        }
    }

    if (rttiNpc.size() == 1)
    {
        profile.npcVtableRva =
            rttiNpc[0]->vtableRva;

        profile.slotIsNpc = 0;

        profile.npcStatus =
            "confirmed_semantic_rtti_npc";

        std::cout
            << "\n[FEITO] NPC classification por RTTI\n"
            << "NPC VTable RVA       : "
            << HexU64(
                profile.npcVtableRva
            )
            << "\n"
            << "NPC RTTI             : "
            << rttiNpc[0]->rttiName
            << "\n";

        return true;
    }

    // Older client family fallback: static constant-bool matrix.
    if (!profile.slotIsCreature ||
        !profile.slotIsMonster ||
        !profile.slotIsPlayer ||
        !profile.slotIsItem)
    {
        if (verbose)
        {
            std::cout
                << "\n[NPC] RTTI nao fechou e esta build nao possui "
                << "slots constant-bool suficientes.\n";
        }

        return false;
    }

    struct NpcCandidate
    {
        uintptr_t vtable = 0;
        uintptr_t slot = 0;
        size_t objects = 0;
        int score = 0;
    };

    std::vector<NpcCandidate>
        candidates;

    for (const auto& cohort :
         cohorts)
    {
        uintptr_t vt =
            cohort.vtable;

        if (!vt ||
            vt == itemVt ||
            vt == localVt ||
            vt == playerVt ||
            vt == monsterVt)
        {
            continue;
        }

        bool isItem = false;
        bool isCreature = false;
        bool isMonster = false;
        bool isPlayer = false;

        if (!BMDecodeVtableBool(
                vt,
                profile.slotIsItem,
                isItem) ||
            !BMDecodeVtableBool(
                vt,
                profile.slotIsCreature,
                isCreature) ||
            !BMDecodeVtableBool(
                vt,
                profile.slotIsMonster,
                isMonster) ||
            !BMDecodeVtableBool(
                vt,
                profile.slotIsPlayer,
                isPlayer))
        {
            continue;
        }

        if (isItem ||
            !isCreature ||
            isMonster ||
            isPlayer)
        {
            continue;
        }

        for (uintptr_t slot = 0;
             slot <= 0x100;
             slot += 8)
        {
            if (slot ==
                    profile.slotIsItem ||
                slot ==
                    profile.slotIsCreature ||
                slot ==
                    profile.slotIsMonster ||
                slot ==
                    profile.slotIsPlayer ||
                slot ==
                    profile.slotIsLocalPlayer)
            {
                continue;
            }

            bool npcValue = false;
            bool itemValue = false;
            bool localValue = false;
            bool playerValue = false;
            bool monsterValue = false;

            if (!BMDecodeVtableBool(
                    vt,
                    slot,
                    npcValue) ||
                !BMDecodeVtableBool(
                    itemVt,
                    slot,
                    itemValue) ||
                !BMDecodeVtableBool(
                    localVt,
                    slot,
                    localValue) ||
                !BMDecodeVtableBool(
                    playerVt,
                    slot,
                    playerValue) ||
                !BMDecodeVtableBool(
                    monsterVt,
                    slot,
                    monsterValue))
            {
                continue;
            }

            if (!npcValue ||
                itemValue ||
                localValue ||
                playerValue ||
                monsterValue)
            {
                continue;
            }

            NpcCandidate c{};

            c.vtable =
                vt;

            c.slot =
                slot;

            c.objects =
                cohort.objects;

            c.score =
                1000 +
                static_cast<int>(
                    cohort.objects * 10
                );

            // Golden-reference tiebreak only. It never creates a
            // candidate; it only prefers the already-semantic pattern.
            if (slot == 0x48)
                c.score += 25;

            candidates.push_back(
                c
            );
        }
    }

    if (verbose)
    {
        std::cout
            << "\n============================================================\n"
            << "               NPC STATIC-BOOL DISCOVERY\n"
            << "============================================================\n"
            << "Creature-like residual candidates: "
            << candidates.size()
            << "\n";

        for (size_t i = 0;
             i < candidates.size();
             ++i)
        {
            std::cout
                << "#"
                << i
                << " vtRva="
                << HexU64(
                    candidates[i].vtable -
                    g_exeBase
                )
                << " slot=+"
                << HexU64(
                    candidates[i].slot
                )
                << " objects="
                << candidates[i].objects
                << " score="
                << candidates[i].score
                << "\n";
        }
    }

    if (candidates.empty())
        return false;

    std::sort(
        candidates.begin(),
        candidates.end(),
        [](
            const NpcCandidate& a,
            const NpcCandidate& b)
        {
            return a.score > b.score;
        }
    );

    if (candidates.size() > 1 &&
        candidates[0].score ==
            candidates[1].score)
    {
        return false;
    }

    profile.npcVtableRva =
        candidates[0].vtable -
        g_exeBase;

    profile.slotIsNpc =
        candidates[0].slot;

    profile.npcStatus =
        "confirmed_runtime_residual_creature_static_bool";

    std::cout
        << "\n[FEITO] NPC classification\n"
        << "NPC VTable RVA       : "
        << HexU64(
            profile.npcVtableRva
        )
        << "\n"
        << "isNpc slot           : +"
        << HexU64(
            profile.slotIsNpc
        )
        << "\n";

    return true;
}


bool V36IsRealSemanticItem(
    uintptr_t pointer)
{
    V35MsvcObjectIdentity id{};

    if (!V35DescribeMsvcObject(
            pointer,
            id))
    {
        return false;
    }

    std::string rtti =
        LowerAscii(
            id.rttiName
        );

    if (rtti.find(
            "_ref_count") !=
            std::string::npos ||
        rtti.find(
            "shared_ptr") !=
            std::string::npos)
    {
        return false;
    }

    return
        rtti.find(
            "item") !=
        std::string::npos;
}

struct V36InventoryRecord
{
    uintptr_t object = 0;
    uintptr_t companion = 0;
};

std::vector<V36InventoryRecord>
V36CaptureInventoryRecords(
    uintptr_t localPlayer,
    uintptr_t baseOffset,
    size_t stride)
{
    std::vector<V36InventoryRecord>
        out;

    if (stride != 8 &&
        stride != 16)
    {
        return out;
    }

    for (size_t slot = 1;
         slot <= 10;
         ++slot)
    {
        uintptr_t address =
            localPlayer +
            baseOffset +
            slot *
            stride;

        V36InventoryRecord r{};

        r.object =
            ReadPtr(
                address
            );

        if (stride == 16)
        {
            r.companion =
                ReadPtr(
                    address + 8
                );
        }

        out.push_back(
            r
        );
    }

    return out;
}

size_t V36CountChangedInventoryRecords(
    const std::vector<V36InventoryRecord>& a,
    const std::vector<V36InventoryRecord>& b)
{
    size_t changed = 0;

    size_t n =
        std::min(
            a.size(),
            b.size()
        );

    for (size_t i = 0;
         i < n;
         ++i)
    {
        if (a[i].object !=
                b[i].object ||
            a[i].companion !=
                b[i].companion)
        {
            ++changed;
        }
    }

    return changed;
}


struct BMInventoryCandidate
{
    uintptr_t baseOffset = 0;
    size_t slotStride = sizeof(uintptr_t);
    std::string storageMode = "raw_pointer_array";
    size_t itemHits = 0;
    size_t nullSlots = 0;
    size_t badSlots = 0;
    size_t companionHits = 0;

    // V3.7: inventory windows overlap heavily. The true 10-slot base
    // should normally have non-Item values immediately outside the window.
    bool leadingBoundaryIsItem = false;
    bool trailingBoundaryIsItem = false;
    int boundaryScore = 0;

    int score = 0;
};


bool V37InventoryObjectAt(
    uintptr_t localPlayer,
    uintptr_t baseOffset,
    size_t slotStride,
    long long logicalSlot,
    uintptr_t itemVtable)
{
    if (slotStride != 8 &&
        slotStride != 16)
    {
        return false;
    }

    long long byteDelta =
        logicalSlot *
        static_cast<long long>(
            slotStride
        );

    uintptr_t address =
        logicalSlot >= 0
            ? localPlayer +
                baseOffset +
                static_cast<uintptr_t>(
                    byteDelta
                )
            : localPlayer +
                baseOffset -
                static_cast<uintptr_t>(
                    -byteDelta
                );

    uintptr_t ptr =
        ReadPtr(
            address
        );

    if (!ptr ||
        !IsReadableMonitorRange(
            ptr,
            sizeof(uintptr_t)))
    {
        return false;
    }

    uintptr_t vt =
        ReadPtr(
            ptr
        );

    return
        vt == itemVtable ||
        V36IsRealSemanticItem(
            ptr
        );
}


BMInventoryCandidate BMScoreInventoryBase(
    uintptr_t localPlayer,
    uintptr_t itemVtable,
    uintptr_t baseOffset,
    size_t slotStride)
{
    BMInventoryCandidate out{};

    out.baseOffset =
        baseOffset;

    out.slotStride =
        slotStride;

    out.storageMode =
        slotStride == 16
            ? "shared_ptr_array"
            : "raw_pointer_array";

    if (slotStride != 8 &&
        slotStride != 16)
    {
        out.badSlots = 100;
        return out;
    }

    for (size_t slot = 1;
         slot <= 10;
         ++slot)
    {
        uintptr_t slotAddress =
            localPlayer +
            baseOffset +
            slot *
            slotStride;

        uintptr_t ptr =
            ReadPtr(
                slotAddress
            );

        if (!ptr)
        {
            ++out.nullSlots;
            continue;
        }

        if (!IsReadableMonitorRange(
                ptr,
                sizeof(uintptr_t)))
        {
            ++out.badSlots;
            continue;
        }

        uintptr_t vt =
            ReadPtr(
                ptr
            );

        const bool itemLike =
            vt ==
                itemVtable ||
            V36IsRealSemanticItem(
                ptr);

        if (!itemLike)
        {
            ++out.badSlots;
            continue;
        }

        ++out.itemHits;

        if (slotStride == 16)
        {
            uintptr_t control =
                ReadPtr(
                    slotAddress + 8
                );

            if (LooksLikeSharedPtrControlBlock(
                    control))
            {
                ++out.companionHits;
            }
            else
            {
                ++out.badSlots;
            }
        }
    }

    out.leadingBoundaryIsItem =
        V37InventoryObjectAt(
            localPlayer,
            baseOffset,
            slotStride,
            0,
            itemVtable
        );

    out.trailingBoundaryIsItem =
        V37InventoryObjectAt(
            localPlayer,
            baseOffset,
            slotStride,
            11,
            itemVtable
        );

    // A shifted 10-slot window commonly ties with the real one because
    // nine of the ten entries overlap. Boundaries break that alias.
    out.boundaryScore = 0;

    out.boundaryScore +=
        out.leadingBoundaryIsItem
            ? -550
            : 320;

    out.boundaryScore +=
        out.trailingBoundaryIsItem
            ? -550
            : 320;

    out.score =
        static_cast<int>(
            out.itemHits * 120
        ) -
        static_cast<int>(
            out.badSlots * 220
        ) +
        static_cast<int>(
            out.companionHits * 30
        ) +
        out.boundaryScore;

    return out;
}


bool V39ResolveInventoryByLogicalSlot(
    uintptr_t localPlayer,
    uintptr_t itemVtable,
    const std::vector<BMInventoryCandidate>& input,
    BMInventoryCandidate& winner)
{
    if (input.empty())
        return false;

    std::cout
        << "\n============================================================\n"
        << "       V4.6.1 INVENTORY LOGICAL-SLOT VALIDATION\n"
        << "============================================================\n"
        << "[MODE] READ-ONLY\n"
        << "As janelas +offset podem estar deslocadas por exatamente 1 shared_ptr.\n"
        << "Agora o indice LOGICO do slot decide a base.\n\n"
        << "ATENCAO: aqui e SLOT DE EQUIPAMENTO do personagem, NAO slot dentro da backpack aberta.\n"
        << "Slots 1..10 correspondem a ordem interna do inventario.\n"
        << "Referencia visual comum: 1=head, 2=neck, 3=backpack equipada, 4=armor,\n"
        << "5/6=hands, 7=legs, 8=feet, 9=ring, 10=ammo.\n"
        << "Se houver duvida, a V4.6 imprime changedSlots para diagnostico.\n";

    unsigned logicalSlot =
        AskUnsignedRange(
            "Qual slot 1..10 voce vai ALTERAR agora? ",
            1,
            10
        );

    struct Probe
    {
        BMInventoryCandidate candidate;
        std::vector<V36InventoryRecord> before;
        size_t totalChanged = 0;
        bool selectedChanged = false;
        std::vector<size_t> changedIndices;
        int score = 0;
    };

    std::vector<Probe> probes;

    size_t limit =
        std::min<size_t>(
            input.size(),
            12
        );

    for (size_t i = 0;
         i < limit;
         ++i)
    {
        Probe p{};
        p.candidate = input[i];
        p.before =
            V36CaptureInventoryRecords(
                localPlayer,
                p.candidate.baseOffset,
                p.candidate.slotStride
            );
        probes.push_back(
            p
        );
    }

    std::cout
        << "\n[ACTION - INVENTORY SLOT "
        << logicalSlot
        << "]\n"
        << "Mude SOMENTE esse slot: equipe, retire ou troque o item desse slot.\n"
        << "Nao altere os outros slots ate pressionar ENTER.\n";

    WaitEnter(
        "Depois da mudanca desse unico slot, pressione ENTER..."
    );

    for (auto& p :
         probes)
    {
        auto after =
            V36CaptureInventoryRecords(
                localPlayer,
                p.candidate.baseOffset,
                p.candidate.slotStride
            );

        p.totalChanged =
            V36CountChangedInventoryRecords(
                p.before,
                after
            );

        for (size_t changedIndex = 0;
             changedIndex < p.before.size() &&
             changedIndex < after.size();
             ++changedIndex)
        {
            if (
                p.before[changedIndex].object != after[changedIndex].object ||
                p.before[changedIndex].companion != after[changedIndex].companion
            )
            {
                p.changedIndices.push_back(changedIndex + 1);
            }
        }

        size_t index =
            static_cast<size_t>(
                logicalSlot - 1
            );

        if (index < p.before.size() &&
            index < after.size())
        {
            p.selectedChanged =
                p.before[index].object !=
                    after[index].object ||
                p.before[index].companion !=
                    after[index].companion;
        }

        auto rescored =
            BMScoreInventoryBase(
                localPlayer,
                itemVtable,
                p.candidate.baseOffset,
                p.candidate.slotStride
            );

        p.candidate =
            rescored;

        if (p.selectedChanged)
            p.score += 2500;
        else
            p.score -= 2500;

        if (p.totalChanged == 1)
            p.score += 1000;
        else if (p.totalChanged == 2)
            p.score += 200;
        else if (p.totalChanged == 0)
            p.score -= 1200;
        else
            p.score -=
                static_cast<int>(
                    p.totalChanged * 250
                );

        p.score +=
            p.candidate.score;
    }

    std::sort(
        probes.begin(),
        probes.end(),
        [](
            const Probe& a,
            const Probe& b)
        {
            if (a.score != b.score)
                return a.score > b.score;

            if (a.selectedChanged !=
                b.selectedChanged)
            {
                return a.selectedChanged;
            }

            return
                a.candidate.baseOffset <
                b.candidate.baseOffset;
        }
    );

    std::cout
        << "\n[INVENTORY LOGICAL-SLOT CANDIDATES]\n";

    for (size_t i = 0;
         i < probes.size() &&
         i < 10;
         ++i)
    {
        const auto& p =
            probes[i];

        std::cout
            << "#"
            << i
            << " base=+"
            << HexU64(
                p.candidate.baseOffset
            )
            << " stride="
            << p.candidate.slotStride
            << " selectedChanged="
            << (
                p.selectedChanged
                    ? "YES"
                    : "NO"
            )
            << " totalChanged="
            << p.totalChanged
            << " changedSlots=[";

        for (size_t k = 0; k < p.changedIndices.size(); ++k)
        {
            if (k) std::cout << ",";
            std::cout << p.changedIndices[k];
        }

        std::cout
            << "] score="
            << p.score
            << "\n";
    }

    if (probes.empty())
    {
        return false;
    }

    // V4.6: even a structurally unique window must prove that the
    // user-selected logical equipment slot is the entry that changed.
    if (
        probes.size() == 1 &&
        probes[0].selectedChanged &&
        probes[0].totalChanged == 1 &&
        probes[0].changedIndices.size() == 1 &&
        probes[0].changedIndices[0] == logicalSlot &&
        probes[0].candidate.badSlots == 0
    )
    {
        winner =
            probes[0].candidate;

        std::cout
            << "\n[INVENTORY CONFIRMED BY LOGICAL SLOT]\n"
            << "Base offset : +"
            << HexU64(
                winner.baseOffset
            )
            << "\n"
            << "Stride      : "
            << winner.slotStride
            << "\n"
            << "Evidence    : requested logical slot changed and no other slot changed\n";

        return true;
    }

    // V4.6: shifted 10-slot windows can hide the true base outside the
    // highest scoring candidates.  A single physical entry may appear as
    // slot 7 in +0x510, slot 6 in +0x520, slot 5 in +0x530, etc.
    // If the user says the changed equipment slot is 4, all of those
    // observations project to the same base: +0x540.
    std::map<uintptr_t, size_t>
        projectedVotes;

    std::map<uintptr_t, size_t>
        projectedStride;

    for (const auto& p :
         probes)
    {
        if (
            p.totalChanged != 1 ||
            p.changedIndices.size() != 1
        )
        {
            continue;
        }

        const long long observedSlot =
            static_cast<long long>(
                p.changedIndices[0]
            );

        const long long wantedSlot =
            static_cast<long long>(
                logicalSlot
            );

        const long long stride =
            static_cast<long long>(
                p.candidate.slotStride
            );

        const long long projectedSigned =
            static_cast<long long>(
                p.candidate.baseOffset
            ) +
            (
                observedSlot -
                wantedSlot
            ) *
            stride;

        if (
            projectedSigned < 0x280 ||
            projectedSigned > 0xA00
        )
        {
            continue;
        }

        uintptr_t projectedBase =
            static_cast<uintptr_t>(
                projectedSigned
            );

        ++projectedVotes[
            projectedBase
        ];

        projectedStride[
            projectedBase
        ] =
            p.candidate.slotStride;
    }

    if (!projectedVotes.empty())
    {
        std::vector<std::pair<uintptr_t, size_t>>
            rankedProjection(
                projectedVotes.begin(),
                projectedVotes.end()
            );

        std::sort(
            rankedProjection.begin(),
            rankedProjection.end(),
            [](
                const auto& a,
                const auto& b)
            {
                if (a.second != b.second)
                    return a.second > b.second;

                return a.first < b.first;
            }
        );

        std::cout
            << "\n[INVENTORY PROJECTED BASE CANDIDATES]\n";

        for (size_t i = 0;
             i < rankedProjection.size() &&
             i < 8;
             ++i)
        {
            std::cout
                << "#"
                << i
                << " base=+"
                << HexU64(
                    rankedProjection[i].first
                )
                << " votes="
                << rankedProjection[i].second
                << " stride="
                << projectedStride[
                    rankedProjection[i].first
                ]
                << "\n";
        }

        const bool uniqueProjection =
            rankedProjection.size() == 1 ||
            rankedProjection[0].second >
                rankedProjection[1].second;

        if (
            uniqueProjection &&
            rankedProjection[0].second >= 2
        )
        {
            uintptr_t projectedBase =
                rankedProjection[0].first;

            size_t stride =
                projectedStride[
                    projectedBase
                ];

            BMInventoryCandidate projected =
                BMScoreInventoryBase(
                    localPlayer,
                    itemVtable,
                    projectedBase,
                    stride
                );

            if (
                projected.badSlots == 0 &&
                projected.itemHits >= 1
            )
            {
                winner =
                    projected;

                std::cout
                    << "\n[INVENTORY CONFIRMED BY LOGICAL PROJECTION]\n"
                    << "Base offset : +"
                    << HexU64(
                        winner.baseOffset
                    )
                    << "\n"
                    << "Stride      : "
                    << winner.slotStride
                    << "\n"
                    << "Votes       : "
                    << rankedProjection[0].second
                    << "\n"
                    << "Evidence    : same physical change projected to requested logical slot\n";

                return true;
            }
        }
    }

    if (
        !probes[0].selectedChanged ||
        probes[0].totalChanged == 0
    )
    {
        std::cout
            << "[INVENTORY] O slot informado nao correspondeu diretamente ao indice do top candidate.\\n"
            << "[INVENTORY] A V4.1 tentou projetar a base real usando changedSlots.\\n"
            << "[INVENTORY] Nenhum offset foi promovido sem convergencia estrutural.\\n";
        return false;
    }

    if (probes.size() > 1 &&
        probes[0].score ==
            probes[1].score)
    {
        std::cout
            << "[INVENTORY] Logical-slot probe ainda empatou; nenhum offset promovido.\n";
        return false;
    }

    winner =
        probes[0].candidate;

    return true;
}


bool BMDiscoverInventory(
    DbProfile& profile,
    uintptr_t localPlayer)
{
    if (!profile.itemVtableRva)
        return false;

    uintptr_t itemVtable =
        g_exeBase +
        profile.itemVtableRva;

    std::vector<BMInventoryCandidate>
        candidates;

    for (size_t stride :
         {
             static_cast<size_t>(8),
             static_cast<size_t>(16)
         })
    {
        for (uintptr_t off = 0x280;
             off <= 0xA00;
             off += 8)
        {
            auto c =
                BMScoreInventoryBase(
                    localPlayer,
                    itemVtable,
                    off,
                    stride
                );

            const bool companionOk =
                stride == 8 ||
                c.companionHits ==
                    c.itemHits;

            if (c.itemHits >= 2 &&
                c.badSlots == 0 &&
                companionOk)
            {
                candidates.push_back(
                    c
                );
            }
        }
    }

    std::sort(
        candidates.begin(),
        candidates.end(),
        [](
            const BMInventoryCandidate& a,
            const BMInventoryCandidate& b)
        {
            if (a.score !=
                b.score)
            {
                return
                    a.score >
                    b.score;
            }

            if (a.itemHits !=
                b.itemHits)
            {
                return
                    a.itemHits >
                    b.itemHits;
            }

            if (a.slotStride !=
                b.slotStride)
            {
                return
                    a.slotStride >
                    b.slotStride;
            }

            return
                a.baseOffset <
                b.baseOffset;
        }
    );

    if (candidates.empty())
    {
        std::cout
            << "[INVENTORY] Nenhum raw/shared_ptr Item-slot array confirmado.\n";

        return false;
    }

    std::cout
        << "\n[INVENTORY CANDIDATES]\n";

    for (size_t i = 0;
         i < candidates.size() &&
         i < 8;
         ++i)
    {
        const auto& c =
            candidates[i];

        std::cout
            << "#"
            << i
            << " base=+"
            << HexU64(
                c.baseOffset
            )
            << " mode="
            << c.storageMode
            << " stride="
            << c.slotStride
            << " itemHits="
            << c.itemHits
            << " null="
            << c.nullSlots
            << " companion="
            << c.companionHits
            << " leadItem="
            << (
                c.leadingBoundaryIsItem
                    ? "YES"
                    : "NO"
            )
            << " tailItem="
            << (
                c.trailingBoundaryIsItem
                    ? "YES"
                    : "NO"
            )
            << " boundary="
            << c.boundaryScore
            << " score="
            << c.score
            << "\n";
    }

    // V4.6 rule:
    // Structural scores are discovery hints only.  Sliding 10-slot windows
    // can look valid at +0x520/+0x530/+0x540/etc.  A new/unverified build is
    // not allowed to persist Inventory until a user-selected logical
    // equipment slot proves the base.
    const bool alreadyLogicalValidated =
        profile.inventoryBaseOffset != 0 &&
        profile.inventorySlotStride != 0 &&
        (
            profile.inventoryStatus ==
                "confirmed_runtime_logical_slot" ||
            profile.inventoryStatus ==
                "confirmed_runtime_logical_projection"
        );

    if (alreadyLogicalValidated)
    {
        auto check =
            BMScoreInventoryBase(
                localPlayer,
                itemVtable,
                profile.inventoryBaseOffset,
                static_cast<size_t>(
                    profile.inventorySlotStride
                )
            );

        const bool companionOk =
            check.slotStride == 8 ||
            check.companionHits ==
                check.itemHits;

        if (
            check.badSlots == 0 &&
            check.itemHits >= 1 &&
            companionOk
        )
        {
            candidates.clear();
            candidates.push_back(
                check
            );

            std::cout
                << "[INVENTORY FAST CHECK] logical-validated base +"
                << HexU64(
                    profile.inventoryBaseOffset
                )
                << " remains structurally valid.\n";
        }
        else
        {
            std::cout
                << "[INVENTORY DRIFT] previously logical-validated base failed structural check; recalibrating.\n";

            profile.inventoryBaseOffset = 0;
            profile.inventorySlotStride = 0;
            profile.inventoryStorageMode =
                "unknown";
            profile.inventoryStatus =
                "pending_inventory_drift";
        }
    }

    if (!alreadyLogicalValidated ||
        profile.inventoryBaseOffset == 0)
    {
        // Keep the most relevant overlapping family around the strongest
        // storage mode/stride.  Logical projection can infer a base that was
        // not itself the top scoring window.
        std::vector<BMInventoryCandidate>
            logicalCandidates;

        const auto& seed =
            candidates[0];

        for (const auto& c :
             candidates)
        {
            if (
                c.slotStride !=
                    seed.slotStride ||
                c.storageMode !=
                    seed.storageMode
            )
            {
                continue;
            }

            long long distance =
                std::llabs(
                    static_cast<long long>(
                        c.baseOffset
                    ) -
                    static_cast<long long>(
                        seed.baseOffset
                    )
                );

            if (distance > 0x100)
                continue;

            if (
                c.itemHits + 3 <
                    seed.itemHits
            )
            {
                continue;
            }

            logicalCandidates.push_back(
                c
            );

            if (logicalCandidates.size() >= 12)
                break;
        }

        if (logicalCandidates.empty())
        {
            logicalCandidates.push_back(
                seed
            );
        }

        std::cout
            << "[INVENTORY] V4.6 exige validacao de slot logico antes de promover a base.\n";

        BMInventoryCandidate logicalWinner{};

        if (!V39ResolveInventoryByLogicalSlot(
                localPlayer,
                itemVtable,
                logicalCandidates,
                logicalWinner))
        {
            std::cout
                << "[INVENTORY] Slot logico nao convergiu; nenhum offset sera salvo como confirmed.\n";

            profile.inventoryStatus =
                "pending_inventory_logical_validation";

            return false;
        }

        candidates.clear();
        candidates.push_back(
            logicalWinner
        );

        // Distinguish direct logical proof from projected window proof.
        // If the selected base was present as an input candidate and the
        // requested slot changed directly, this is logical_slot; otherwise
        // it was recovered by projection.
        bool exactWindowPresent = false;

        for (const auto& c :
             logicalCandidates)
        {
            if (
                c.baseOffset ==
                    logicalWinner.baseOffset &&
                c.slotStride ==
                    logicalWinner.slotStride
            )
            {
                exactWindowPresent = true;
                break;
            }
        }

        profile.inventoryStatus =
            exactWindowPresent
                ? "confirmed_runtime_logical_slot"
                : "confirmed_runtime_logical_projection";
    }

    const auto& winner =
        candidates[0];

    profile.inventoryBaseOffset =
        winner.baseOffset;

    profile.inventorySlotStride =
        static_cast<uintptr_t>(
            winner.slotStride
        );

    profile.inventoryStorageMode =
        winner.storageMode;

    if (
        profile.inventoryStatus !=
            "confirmed_runtime_logical_slot" &&
        profile.inventoryStatus !=
            "confirmed_runtime_logical_projection"
    )
    {
        profile.inventoryStatus =
            "confirmed_runtime_logical_slot";
    }

    std::cout
        << "\n[INVENTORY CONFIRMED]\n"
        << "Base offset          : +"
        << HexU64(
            profile.inventoryBaseOffset
        )
        << "\n"
        << "Storage mode         : "
        << profile.inventoryStorageMode
        << "\n"
        << "Slot stride          : "
        << profile.inventorySlotStride
        << "\n"
        << "Item hits            : "
        << winner.itemHits
        << "\n";

    return true;
}

bool BMTryReadMsvcString(
    uintptr_t address,
    std::string& out)
{
    out.clear();

    if (!address ||
        !IsReadableMonitorRange(
            address,
            0x20))
    {
        return false;
    }

    uint64_t size = 0;
    uint64_t capacity = 0;

    if (!SafeRead(
            address + 0x10,
            size) ||
        !SafeRead(
            address + 0x18,
            capacity))
    {
        return false;
    }

    if (size == 0 ||
        size > 127 ||
        capacity > 0x10000)
    {
        return false;
    }

    uintptr_t data =
        address;

    if (capacity >= 16)
    {
        data =
            ReadPtr(
                address
            );
    }

    if (!data ||
        !IsReadableMonitorRange(
            data,
            static_cast<size_t>(
                size)))
    {
        return false;
    }

    std::string value;
    value.resize(
        static_cast<size_t>(
            size)
    );

    std::memcpy(
        &value[0],
        reinterpret_cast<const void*>(
            data),
        static_cast<size_t>(
            size)
    );

    size_t printable = 0;

    for (unsigned char ch :
         value)
    {
        if (ch >= 0x20 &&
            ch <= 0x7E)
        {
            ++printable;
        }
    }

    if (printable * 100 <
        value.size() * 85)
    {
        return false;
    }

    out =
        value;

    return true;
}


std::vector<uintptr_t>
V36FindHeapObjectsByExactRtti(
    const std::string& exactRtti,
    size_t maxObjects = 512)
{
    std::vector<uintptr_t>
        out;

    auto vtables =
        FindMsvcVtablesByExactRttiName(
            exactRtti
        );

    if (vtables.empty())
        return out;

    std::unordered_set<uintptr_t>
        wanted(
            vtables.begin(),
            vtables.end()
        );

    auto regions =
        EnumerateTileHeapRegions();

    const size_t chunkSize =
        4 * 1024 * 1024;

    std::vector<uint8_t>
        buffer(
            chunkSize
        );

    for (const auto& region :
         regions)
    {
        uintptr_t cursor =
            region.base;

        uintptr_t end =
            region.base +
            region.size;

        while (cursor < end)
        {
            size_t want =
                static_cast<size_t>(
                    std::min<uintptr_t>(
                        chunkSize,
                        end - cursor
                    )
                );

            size_t got = 0;

            if (!ReadProcessChunk(
                    cursor,
                    buffer.data(),
                    want,
                    got))
            {
                cursor += want;
                continue;
            }

            uintptr_t aligned =
                (cursor + 7) &
                ~static_cast<uintptr_t>(7);

            size_t start =
                static_cast<size_t>(
                    aligned - cursor
                );

            for (size_t off = start;
                 off + sizeof(uintptr_t) <= got;
                 off += 8)
            {
                uintptr_t vt = 0;

                std::memcpy(
                    &vt,
                    buffer.data() + off,
                    sizeof(vt)
                );

                if (wanted.find(vt) ==
                    wanted.end())
                {
                    continue;
                }

                uintptr_t object =
                    cursor + off;

                V35MsvcObjectIdentity id{};

                if (!V35DescribeMsvcObject(
                        object,
                        id))
                {
                    continue;
                }

                if (id.rttiName !=
                    exactRtti)
                {
                    continue;
                }

                out.push_back(
                    object
                );

                if (out.size() >=
                    maxObjects)
                {
                    break;
                }
            }

            if (out.size() >=
                maxObjects)
            {
                break;
            }

            cursor += got;
        }

        if (out.size() >=
            maxObjects)
        {
            break;
        }
    }

    std::sort(
        out.begin(),
        out.end()
    );

    out.erase(
        std::unique(
            out.begin(),
            out.end()
        ),
        out.end()
    );

    return out;
}

struct V36ContainerReferencePath
{
    uintptr_t gameOffset = 0;
    uintptr_t owner = 0;
    uintptr_t innerOffset = 0;
    uintptr_t child = 0;
    uintptr_t childOffset = 0;
    int depth = 0;
};

std::vector<V36ContainerReferencePath>
V36FindGamePathsToContainer(
    uintptr_t game,
    uintptr_t container)
{
    std::vector<V36ContainerReferencePath>
        paths;

    if (!game ||
        !container)
    {
        return paths;
    }

    uintptr_t target =
        V35CompleteObjectPointer(
            container
        );

    auto sameTarget =
        [&](
            uintptr_t p)
        {
            return
                p &&
                V35CompleteObjectPointer(
                    p
                ) ==
                target;
        };

    for (uintptr_t go = 0;
         go <= 0x600;
         go += 8)
    {
        uintptr_t p1 =
            ReadPtr(
                game + go
            );

        if (!p1)
            continue;

        if (sameTarget(
                p1))
        {
            V36ContainerReferencePath path{};
            path.gameOffset = go;
            path.depth = 1;
            paths.push_back(path);
            continue;
        }

        if (!IsReadableMonitorRange(
                p1,
                0x100))
        {
            continue;
        }

        for (uintptr_t a = 0;
             a <= 0x80;
             a += 8)
        {
            uintptr_t p2 =
                ReadPtr(
                    p1 + a
                );

            if (!p2)
                continue;

            if (sameTarget(
                    p2))
            {
                V36ContainerReferencePath path{};
                path.gameOffset = go;
                path.owner = p1;
                path.innerOffset = a;
                path.depth = 2;
                paths.push_back(path);
                continue;
            }

            if (!IsReadableMonitorRange(
                    p2,
                    0x80))
            {
                continue;
            }

            for (uintptr_t b = 0;
                 b <= 0x50;
                 b += 8)
            {
                uintptr_t p3 =
                    ReadPtr(
                        p2 + b
                    );

                if (!sameTarget(
                        p3))
                {
                    continue;
                }

                V36ContainerReferencePath path{};
                path.gameOffset = go;
                path.owner = p1;
                path.innerOffset = a;
                path.child = p2;
                path.childOffset = b;
                path.depth = 3;
                paths.push_back(path);
            }
        }
    }

    return paths;
}

void V36PrintContainerObjectHints(
    uintptr_t object,
    uintptr_t itemVtable)
{
    std::cout
        << "  object="
        << HexPtr(
            object
        )
        << " vtRva="
        << HexU64(
            ReadPtr(object) -
            g_exeBase
        )
        << " rtti=\\\""
        << TryReadMsvcRttiTypeName(
            ReadPtr(object)
        )
        << "\\\"\n";

    std::cout
        << "    strings:";

    bool anyString = false;

    for (uintptr_t off = 0x10;
         off <= 0xA0;
         off += 8)
    {
        std::string value;

        if (BMTryReadMsvcString(
                object + off,
                value))
        {
            anyString = true;

            std::cout
                << " +"
                << HexU64(off)
                << "=\\\""
                << value
                << "\\\"";
        }
    }

    if (!anyString)
        std::cout << " <none>";

    std::cout << "\n";

    struct ItemVectorHint
    {
        uintptr_t offset = 0;
        size_t stride = 0;
        size_t count = 0;
        size_t itemHits = 0;
        size_t companions = 0;
    };

    std::vector<ItemVectorHint>
        hints;

    for (uintptr_t off = 0x10;
         off <= 0xC0;
         off += 8)
    {
        uintptr_t begin =
            ReadPtr(
                object + off
            );

        uintptr_t end =
            ReadPtr(
                object + off + 8
            );

        uintptr_t cap =
            ReadPtr(
                object + off + 16
            );

        if (!begin ||
            end < begin ||
            cap < end ||
            (begin & 7) ||
            (end & 7) ||
            (cap & 7))
        {
            continue;
        }

        uintptr_t used =
            end - begin;

        if (!used ||
            used > 0x4000)
        {
            continue;
        }

        for (size_t stride :
             {
                 static_cast<size_t>(8),
                 static_cast<size_t>(16)
             })
        {
            if (used % stride != 0)
                continue;

            size_t count =
                static_cast<size_t>(
                    used / stride
                );

            if (!count ||
                count > 128)
            {
                continue;
            }

            size_t itemHits = 0;
            size_t companions = 0;
            bool bad = false;

            for (size_t i = 0;
                 i < count;
                 ++i)
            {
                uintptr_t entry =
                    begin +
                    i * stride;

                uintptr_t item =
                    ReadPtr(
                        entry
                    );

                if (!item)
                    continue;

                uintptr_t vt =
                    ReadPtr(
                        item
                    );

                if (
                    vt != itemVtable &&
                    !V36IsRealSemanticItem(
                        item)
                )
                {
                    bad = true;
                    break;
                }

                ++itemHits;

                if (stride == 16)
                {
                    uintptr_t control =
                        ReadPtr(
                            entry + 8
                        );

                    if (LooksLikeSharedPtrControlBlock(
                            control))
                    {
                        ++companions;
                    }
                    else
                    {
                        bad = true;
                        break;
                    }
                }
            }

            if (bad ||
                !itemHits)
            {
                continue;
            }

            ItemVectorHint h{};
            h.offset = off;
            h.stride = stride;
            h.count = count;
            h.itemHits = itemHits;
            h.companions = companions;
            hints.push_back(h);
        }
    }

    if (!hints.empty())
    {
        std::cout
            << "    item-vectors:";

        for (size_t i = 0;
             i < hints.size() &&
             i < 6;
             ++i)
        {
            std::cout
                << " [off=+"
                << HexU64(
                    hints[i].offset
                )
                << " stride="
                << hints[i].stride
                << " count="
                << hints[i].count
                << " items="
                << hints[i].itemHits
                << " companion="
                << hints[i].companions
                << "]";
        }

        std::cout << "\n";
    }
}

bool V37ContainerHasNameToken(
    uintptr_t object,
    const std::string& token)
{
    std::string wanted =
        LowerAscii(
            token
        );

    for (uintptr_t off = 0x10;
         off <= 0xA0;
         off += 8)
    {
        std::string value;

        if (!BMTryReadMsvcString(
                object + off,
                value))
        {
            continue;
        }

        if (LowerAscii(
                value).find(
                    wanted) !=
            std::string::npos)
        {
            return true;
        }
    }

    return false;
}

std::set<uintptr_t>
V37CollectContainerOwnerOffsets(
    uintptr_t game,
    const std::vector<uintptr_t>& closed,
    const std::vector<uintptr_t>& opened,
    uintptr_t itemVtable,
    const char* label)
{
    std::unordered_set<uintptr_t>
        closedSet(
            closed.begin(),
            closed.end()
        );

    std::vector<uintptr_t>
        newObjects;

    for (uintptr_t object :
         opened)
    {
        if (closedSet.find(
                object) ==
            closedSet.end())
        {
            newObjects.push_back(
                object
            );
        }
    }

    const auto& baseInspect =
        newObjects.empty()
            ? opened
            : newObjects;

    std::vector<uintptr_t>
        named;

    for (uintptr_t object :
         baseInspect)
    {
        if (V37ContainerHasNameToken(
                object,
                "backpack"))
        {
            named.push_back(
                object
            );
        }
    }

    const auto& inspect =
        named.empty()
            ? baseInspect
            : named;

    std::set<uintptr_t>
        offsets;

    std::cout
        << "\n[CONTAINER CYCLE "
        << label
        << "] closed="
        << closed.size()
        << " opened="
        << opened.size()
        << " new="
        << newObjects.size()
        << " inspect="
        << inspect.size()
        << "\n";

    size_t shown = 0;

    for (uintptr_t object :
         inspect)
    {
        if (shown < 8)
        {
            V36PrintContainerObjectHints(
                object,
                itemVtable
            );
        }

        auto paths =
            V36FindGamePathsToContainer(
                game,
                object
            );

        std::set<uintptr_t>
            objectOffsets;

        for (const auto& path :
             paths)
        {
            objectOffsets.insert(
                path.gameOffset
            );
        }

        std::cout
            << "    canonical Game offsets:";

        if (objectOffsets.empty())
        {
            std::cout
                << " <none>";
        }
        else
        {
            for (uintptr_t off :
                 objectOffsets)
            {
                std::cout
                    << " +"
                    << HexU64(
                        off
                    );

                offsets.insert(
                    off
                );
            }
        }

        std::cout
            << "\n";

        ++shown;
    }

    return offsets;
}


struct V39ContainerOwnerState
{
    uintptr_t gameOffset = 0;
    uintptr_t ownerPointer = 0;
    size_t linkedContainers = 0;
    size_t namedContainers = 0;
    std::vector<uint8_t> ownerBytes;
};

V39ContainerOwnerState
V39CaptureContainerOwnerState(
    uintptr_t game,
    uintptr_t gameOffset)
{
    V39ContainerOwnerState out{};
    out.gameOffset = gameOffset;
    out.ownerPointer =
        ReadPtr(
            game + gameOffset
        );

    if (out.ownerPointer &&
        IsReadableMonitorRange(
            out.ownerPointer,
            0x100))
    {
        out.ownerBytes.resize(
            0x100
        );

        std::memcpy(
            out.ownerBytes.data(),
            reinterpret_cast<const void*>(
                out.ownerPointer),
            out.ownerBytes.size()
        );
    }

    auto objects =
        V36FindHeapObjectsByExactRtti(
            ".?AVContainer@@"
        );

    for (uintptr_t object :
         objects)
    {
        auto paths =
            V36FindGamePathsToContainer(
                game,
                object
            );

        bool linked = false;

        for (const auto& p :
             paths)
        {
            if (p.gameOffset ==
                gameOffset)
            {
                linked = true;
                break;
            }
        }

        if (!linked)
            continue;

        ++out.linkedContainers;

        if (V37ContainerHasNameToken(
                object,
                "backpack") ||
            V37ContainerHasNameToken(
                object,
                "bag"))
        {
            ++out.namedContainers;
        }
    }

    return out;
}

size_t V39CountMonotonicOwnerCounters(
    const V39ContainerOwnerState& zero,
    const V39ContainerOwnerState& one,
    const V39ContainerOwnerState& two)
{
    if (zero.ownerBytes.size() < 0x100 ||
        one.ownerBytes.size() < 0x100 ||
        two.ownerBytes.size() < 0x100)
    {
        return 0;
    }

    size_t hits = 0;

    for (size_t off = 0;
         off + sizeof(uint64_t) <= 0x100;
         off += 8)
    {
        uint64_t a = 0;
        uint64_t b = 0;
        uint64_t c = 0;

        std::memcpy(
            &a,
            zero.ownerBytes.data() + off,
            sizeof(a)
        );
        std::memcpy(
            &b,
            one.ownerBytes.data() + off,
            sizeof(b)
        );
        std::memcpy(
            &c,
            two.ownerBytes.data() + off,
            sizeof(c)
        );

        if (a <= 64 &&
            b <= 64 &&
            c <= 64 &&
            b == a + 1 &&
            c == b + 1)
        {
            ++hits;
        }
    }

    for (size_t off = 0;
         off + sizeof(uint32_t) <= 0x100;
         off += 4)
    {
        uint32_t a = 0;
        uint32_t b = 0;
        uint32_t c = 0;

        std::memcpy(
            &a,
            zero.ownerBytes.data() + off,
            sizeof(a)
        );
        std::memcpy(
            &b,
            one.ownerBytes.data() + off,
            sizeof(b)
        );
        std::memcpy(
            &c,
            two.ownerBytes.data() + off,
            sizeof(c)
        );

        if (a <= 64 &&
            b <= 64 &&
            c <= 64 &&
            b == a + 1 &&
            c == b + 1)
        {
            ++hits;
        }
    }

    return hits;
}

bool V39DisambiguateContainerOwnerByCollection(
    DbProfile& profile,
    const std::vector<uintptr_t>& candidates)
{
    if (candidates.size() < 2 ||
        !profile.gameRva)
    {
        return false;
    }

    uintptr_t game =
        g_exeBase +
        profile.gameRva;

    std::cout
        << "\n============================================================\n"
        << "       V3.9 CONTAINER OWNER COLLECTION PROVENANCE\n"
        << "============================================================\n"
        << "[MODE] READ-ONLY\n"
        << "Dois Game offsets chegam na mesma Backpack.\n"
        << "Agora vamos observar a COLECAO em 0 -> 1 -> 2 containers abertos.\n";

    std::cout
        << "\n[ACTION C0]\nFeche TODOS os containers.\n";
    WaitEnter(
        "Com todos fechados, pressione ENTER..."
    );

    std::vector<V39ContainerOwnerState>
        zero;

    for (uintptr_t off :
         candidates)
    {
        zero.push_back(
            V39CaptureContainerOwnerState(
                game,
                off
            )
        );
    }

    std::cout
        << "\n[ACTION C1]\nAbra SOMENTE a Backpack principal.\n";
    WaitEnter(
        "Com somente 1 container aberto, pressione ENTER..."
    );

    std::vector<V39ContainerOwnerState>
        one;

    for (uintptr_t off :
         candidates)
    {
        one.push_back(
            V39CaptureContainerOwnerState(
                game,
                off
            )
        );
    }

    std::cout
        << "\n[ACTION C2]\nMantenha a Backpack aberta e abra UMA SEGUNDA bag/container.\n";
    WaitEnter(
        "Com exatamente 2 containers abertos, pressione ENTER..."
    );

    std::vector<V39ContainerOwnerState>
        two;

    for (uintptr_t off :
         candidates)
    {
        two.push_back(
            V39CaptureContainerOwnerState(
                game,
                off
            )
        );
    }

    struct Ranked
    {
        uintptr_t offset = 0;
        size_t linked0 = 0;
        size_t linked1 = 0;
        size_t linked2 = 0;
        size_t counterHits = 0;
        int score = 0;
    };

    std::vector<Ranked>
        ranked;

    for (size_t i = 0;
         i < candidates.size();
         ++i)
    {
        Ranked r{};
        r.offset = candidates[i];
        r.linked0 = zero[i].linkedContainers;
        r.linked1 = one[i].linkedContainers;
        r.linked2 = two[i].linkedContainers;
        r.counterHits =
            V39CountMonotonicOwnerCounters(
                zero[i],
                one[i],
                two[i]
            );

        if (r.linked1 > r.linked0)
            r.score += 900;

        if (r.linked2 > r.linked1)
            r.score += 900;

        if (r.linked0 == 0)
            r.score += 250;

        r.score +=
            static_cast<int>(
                r.counterHits * 1400
            );

        if (zero[i].ownerPointer &&
            zero[i].ownerPointer ==
                one[i].ownerPointer &&
            one[i].ownerPointer ==
                two[i].ownerPointer)
        {
            r.score += 150;
        }

        ranked.push_back(
            r
        );
    }

    std::sort(
        ranked.begin(),
        ranked.end(),
        [](
            const Ranked& a,
            const Ranked& b)
        {
            if (a.score != b.score)
                return a.score > b.score;

            if (a.counterHits !=
                b.counterHits)
            {
                return
                    a.counterHits >
                    b.counterHits;
            }

            return
                a.offset <
                b.offset;
        }
    );

    std::cout
        << "\n[CONTAINER OWNER COLLECTION CANDIDATES]\n";

    for (size_t i = 0;
         i < ranked.size();
         ++i)
    {
        std::cout
            << "#"
            << i
            << " Game[+"
            << HexU64(
                ranked[i].offset
            )
            << "] linked="
            << ranked[i].linked0
            << "->"
            << ranked[i].linked1
            << "->"
            << ranked[i].linked2
            << " counters="
            << ranked[i].counterHits
            << " score="
            << ranked[i].score
            << "\n";
    }

    if (ranked.empty() ||
        ranked[0].score <= 0)
    {
        return false;
    }

    if (ranked.size() > 1)
    {
        const int gap =
            ranked[0].score -
            ranked[1].score;

        if (gap < 700)
        {
            std::cout
                << "[CONTAINER] Collection provenance ainda nao separou os aliases.\n";
            return false;
        }
    }

    profile.gameContainersOffset =
        ranked[0].offset;

    profile.containersStatus =
        "confirmed_runtime_container_owner_collection_provenance_layout_pending";

    std::cout
        << "\n[CONTAINER OWNER CONFIRMED BY COLLECTION]\n"
        << "Game.Containers owner: +"
        << HexU64(
            profile.gameContainersOffset
        )
        << "\n";

    return true;
}


bool V36ContainerTransitionRecon(
    DbProfile& profile)
{
    if (!profile.gameRva ||
        !profile.itemVtableRva)
    {
        return false;
    }

    uintptr_t game =
        g_exeBase +
        profile.gameRva;

    uintptr_t itemVtable =
        g_exeBase +
        profile.itemVtableRva;

    std::cout
        << "\n============================================================\n"
        << "        V3.9 CONTAINER TWO-CYCLE RTTI CONFIRMATION\n"
        << "============================================================\n"
        << "[MODE] READ-ONLY\n"
        << "Vamos confirmar o mesmo owner de Containers em DUAS aberturas.\n"
        << "As duas aliases internas (+0/+8, por exemplo) contam como UM owner\n"
        << "quando terminam no mesmo Game[+offset].\n";

    std::cout
        << "\n[ACTION 1/4]\n"
        << "Feche TODOS os containers no cliente.\n";
    WaitEnter(
        "Quando estiver tudo fechado, pressione ENTER..."
    );

    auto closedA =
        V36FindHeapObjectsByExactRtti(
            ".?AVContainer@@"
        );

    std::cout
        << "\n[ACTION 2/4]\n"
        << "Abra SOMENTE a Backpack principal.\n";
    WaitEnter(
        "Quando a Backpack estiver aberta, pressione ENTER..."
    );

    auto openedA =
        V36FindHeapObjectsByExactRtti(
            ".?AVContainer@@"
        );

    auto offsetsA =
        V37CollectContainerOwnerOffsets(
            game,
            closedA,
            openedA,
            itemVtable,
            "A"
        );

    if (offsetsA.empty())
    {
        std::cout
            << "[CONTAINER] Ciclo A nao encontrou owner ligado ao Game.\n";

        profile.containersStatus =
            "pending_container_cycle_a_no_owner";

        return false;
    }

    std::cout
        << "\n[ACTION 3/4]\n"
        << "Feche novamente TODOS os containers.\n";
    WaitEnter(
        "Quando estiver tudo fechado, pressione ENTER..."
    );

    auto closedB =
        V36FindHeapObjectsByExactRtti(
            ".?AVContainer@@"
        );

    std::cout
        << "\n[ACTION 4/4]\n"
        << "Abra novamente SOMENTE a mesma Backpack principal.\n";
    WaitEnter(
        "Quando a Backpack estiver aberta, pressione ENTER..."
    );

    auto openedB =
        V36FindHeapObjectsByExactRtti(
            ".?AVContainer@@"
        );

    auto offsetsB =
        V37CollectContainerOwnerOffsets(
            game,
            closedB,
            openedB,
            itemVtable,
            "B"
        );

    std::vector<uintptr_t>
        common;

    for (uintptr_t off :
         offsetsA)
    {
        if (offsetsB.find(
                off) !=
            offsetsB.end())
        {
            common.push_back(
                off
            );
        }
    }

    std::cout
        << "\n[CONTAINER OWNER INTERSECTION]\n"
        << "Cycle A candidates : "
        << offsetsA.size()
        << "\n"
        << "Cycle B candidates : "
        << offsetsB.size()
        << "\n"
        << "Common offsets     : "
        << common.size()
        << "\n";

    for (size_t i = 0;
         i < common.size();
         ++i)
    {
        std::cout
            << "  #"
            << i
            << " Game[+"
            << HexU64(
                common[i]
            )
            << "]\n";
    }

    if (common.empty())
    {
        profile.containersStatus =
            "pending_container_owner_no_common_offset";

        return false;
    }

    if (common.size() > 1)
    {
        profile.containersStatus =
            "pending_container_owner_multiple_common_offsets";

        if (!V39DisambiguateContainerOwnerByCollection(
                profile,
                common))
        {
            return false;
        }

        return true;
    }

    profile.gameContainersOffset =
        common[0];

    // Owner is confirmed. Container internal deque/layout still has its own
    // validation stage, so consumer-ready must not treat this as full layout.
    profile.containersStatus =
        "confirmed_runtime_container_owner_two_open_cycles_layout_pending";

    std::cout
        << "\n[CONTAINER OWNER CONFIRMED]\n"
        << "Game.Containers owner: +"
        << HexU64(
            profile.gameContainersOffset
        )
        << "\n"
        << "Evidence             : same Game offset in 2 close/open cycles\n"
        << "Status               : "
        << profile.containersStatus
        << "\n";

    return true;
}


struct BMContainerMapCandidate
{
    uintptr_t gameOffset = 0;
    uintptr_t mapAddress = 0;
    uintptr_t header = 0;
    uintptr_t root = 0;
    size_t reportedSize = 0;
    size_t visitedNodes = 0;
    size_t validContainers = 0;
    size_t validItems = 0;
    int score = 0;
};

bool BMValidateContainerMapCandidate(
    uintptr_t game,
    uintptr_t gameOffset,
    uintptr_t itemVtable,
    BMContainerMapCandidate& out,
    bool verbose)
{
    out = {};

    uintptr_t map =
        game +
        gameOffset;

    if (!IsReadableMonitorRange(
            map,
            0x10))
    {
        return false;
    }

    uintptr_t header =
        ReadPtr(
            map
        );

    uint64_t reportedSize = 0;

    if (!SafeRead(
            map + 0x08,
            reportedSize))
    {
        return false;
    }

    if (!header ||
        reportedSize == 0 ||
        reportedSize > 32 ||
        !IsReadableMonitorRange(
            header,
            0x30))
    {
        return false;
    }

    uintptr_t root =
        ReadPtr(
            header +
            0x08
        );

    if (!root ||
        root == header ||
        !IsReadableMonitorRange(
            root,
            0x30))
    {
        return false;
    }

    std::vector<uintptr_t>
        stack;

    std::unordered_set<uintptr_t>
        visited;

    stack.push_back(
        root
    );

    size_t validContainers = 0;
    size_t validItems = 0;

    while (!stack.empty() &&
           visited.size() < 128)
    {
        uintptr_t node =
            stack.back();

        stack.pop_back();

        if (!node ||
            node == header ||
            !IsReadableMonitorRange(
                node,
                0x30))
        {
            continue;
        }

        if (!visited.insert(
                node).second)
        {
            continue;
        }

        uint8_t nil =
            ReadU8(
                node +
                0x19
            );

        if (nil != 0)
            continue;

        uintptr_t left =
            ReadPtr(
                node +
                0x00
            );

        uintptr_t right =
            ReadPtr(
                node +
                0x10
            );

        if (left &&
            left != header)
        {
            stack.push_back(
                left
            );
        }

        if (right &&
            right != header)
        {
            stack.push_back(
                right
            );
        }

        uint32_t key =
            ReadU32(
                node +
                0x20
            );

        uintptr_t container =
            ReadPtr(
                node +
                0x28
            );

        if (!container ||
            !IsReadableMonitorRange(
                container,
                0x80))
        {
            continue;
        }

        uint32_t id =
            ReadU32(
                container +
                0x18
            );

        uint32_t capacity =
            ReadU32(
                container +
                0x1C
            );

        uint32_t itemCount =
            ReadU32(
                container +
                0x78
            );

        std::string name;

        bool nameOk =
            BMTryReadMsvcString(
                container +
                0x28,
                name
            );

        if (id != key ||
            capacity == 0 ||
            capacity > 200 ||
            itemCount > 1000 ||
            !nameOk)
        {
            continue;
        }

        ++validContainers;

        uintptr_t dequeMap =
            ReadPtr(
                container +
                0x60
            );

        uint64_t dequeMapSize = 0;
        uint64_t dequeOffset = 0;

        SafeRead(
            container +
                0x68,
            dequeMapSize
        );

        SafeRead(
            container +
                0x70,
            dequeOffset
        );

        if (itemCount &&
            dequeMap &&
            dequeMapSize &&
            (dequeMapSize &
             (dequeMapSize - 1)) == 0 &&
            dequeMapSize <= 0x10000)
        {
            size_t limit =
                std::min<size_t>(
                    itemCount,
                    64
                );

            for (size_t i = 0;
                 i < limit;
                 ++i)
            {
                uint64_t logical =
                    dequeOffset +
                    i;

                uint64_t block =
                    (logical >> 1) &
                    (dequeMapSize - 1);

                uint64_t cell =
                    logical &
                    1ULL;

                uintptr_t blockPtr =
                    ReadPtr(
                        dequeMap +
                        block *
                        sizeof(uintptr_t)
                    );

                if (!blockPtr ||
                    !IsReadableMonitorRange(
                        blockPtr,
                        2 *
                        sizeof(uintptr_t)))
                {
                    continue;
                }

                uintptr_t item =
                    ReadPtr(
                        blockPtr +
                        cell *
                        sizeof(uintptr_t)
                    );

                if (!item ||
                    !IsReadableMonitorRange(
                        item,
                        0x40))
                {
                    continue;
                }

                uintptr_t itemVt =
                    ReadPtr(
                        item
                    );

                if (
                    itemVt ==
                        itemVtable ||
                    V36IsRealSemanticItem(
                        item)
                )
                {
                    ++validItems;
                }
            }
        }

        if (verbose)
        {
            std::cout
                << "  Container key="
                << key
                << " name=\""
                << name
                << "\" cap="
                << capacity
                << " items="
                << itemCount
                << "\n";
        }
    }

    if (!validContainers)
        return false;

    out.gameOffset =
        gameOffset;

    out.mapAddress =
        map;

    out.header =
        header;

    out.root =
        root;

    out.reportedSize =
        static_cast<size_t>(
            reportedSize
        );

    out.visitedNodes =
        visited.size();

    out.validContainers =
        validContainers;

    out.validItems =
        validItems;

    out.score =
        1000 +
        static_cast<int>(
            validContainers * 100
        ) +
        static_cast<int>(
            validItems * 10
        );

    if (gameOffset == 0x20)
        out.score += 10;

    return true;
}


struct V38DequeCandidate
{
    uintptr_t mapOffset = 0;
    uintptr_t mapSizeOffset = 0;
    uintptr_t dequeOffsetOffset = 0;
    uintptr_t countOffset = 0;

    size_t elementStride = 0;
    size_t blockElements = 0;
    std::string mode;

    size_t count = 0;
    size_t validItems = 0;
    size_t validCompanions = 0;
    int score = 0;
};

bool V38IsExactContainerObject(
    uintptr_t object)
{
    if (!object ||
        !IsReadableMonitorRange(
            object,
            sizeof(uintptr_t)))
    {
        return false;
    }

    uintptr_t vt =
        ReadPtr(
            object
        );

    if (!InsideExeImage(
            vt))
    {
        return false;
    }

    std::string rtti =
        TryReadMsvcRttiTypeName(
            vt
        );

    return
        LowerAscii(
            rtti
        ).find(
            "container") !=
            std::string::npos &&
        LowerAscii(
            rtti
        ).find(
            "_ref_count") ==
            std::string::npos;
}

std::vector<uintptr_t>
V38FindContainersLinkedToConfirmedOwner(
    const DbProfile& profile)
{
    std::vector<uintptr_t>
        out;

    if (!profile.gameRva ||
        !profile.gameContainersOffset)
    {
        return out;
    }

    uintptr_t game =
        g_exeBase +
        profile.gameRva;

    auto objects =
        V36FindHeapObjectsByExactRtti(
            ".?AVContainer@@"
        );

    for (uintptr_t object :
         objects)
    {
        auto paths =
            V36FindGamePathsToContainer(
                game,
                object
            );

        bool linked = false;

        for (const auto& p :
             paths)
        {
            if (p.gameOffset ==
                profile.gameContainersOffset)
            {
                linked = true;
                break;
            }
        }

        if (linked)
        {
            out.push_back(
                object
            );
        }
    }

    std::sort(
        out.begin(),
        out.end()
    );

    out.erase(
        std::unique(
            out.begin(),
            out.end()
        ),
        out.end()
    );

    return out;
}

bool V38InferContainerTreeLayout(
    DbProfile& profile,
    const std::vector<uintptr_t>& containers)
{
    if (containers.empty() ||
        !profile.gameRva ||
        !profile.gameContainersOffset)
    {
        return false;
    }

    uintptr_t game =
        g_exeBase +
        profile.gameRva;

    std::set<uintptr_t>
        innerOffsets;

    std::set<uintptr_t>
        valueOffsets;

    for (uintptr_t object :
         containers)
    {
        auto paths =
            V36FindGamePathsToContainer(
                game,
                object
            );

        for (const auto& p :
             paths)
        {
            if (p.gameOffset !=
                    profile.gameContainersOffset ||
                p.depth != 3)
            {
                continue;
            }

            innerOffsets.insert(
                p.innerOffset
            );

            valueOffsets.insert(
                p.childOffset
            );
        }
    }

    if (valueOffsets.size() != 1 ||
        innerOffsets.empty())
    {
        return false;
    }

    profile.containerMapHeaderOffset =
        0x00;

    profile.containerMapSizeOffset =
        0x08;

    profile.containerNodeLeftOffset =
        *innerOffsets.begin();

    profile.containerNodeRightOffset =
        innerOffsets.size() >= 2
            ? *innerOffsets.rbegin()
            : *innerOffsets.begin();

    profile.containerNodeValueOffset =
        *valueOffsets.begin();

    // Find a common std::string field on named Container objects.
    std::map<uintptr_t, size_t>
        nameVotes;

    for (uintptr_t object :
         containers)
    {
        for (uintptr_t off = 0x10;
             off <= 0xA0;
             off += 8)
        {
            std::string value;

            if (!BMTryReadMsvcString(
                    object + off,
                    value))
            {
                continue;
            }

            if (!value.empty())
            {
                ++nameVotes[
                    off
                ];
            }
        }
    }

    if (!nameVotes.empty())
    {
        auto best =
            std::max_element(
                nameVotes.begin(),
                nameVotes.end(),
                [](
                    const auto& a,
                    const auto& b)
                {
                    return
                        a.second <
                        b.second;
                }
            );

        profile.containerNameOffset =
            best->first;
    }

    std::cout
        << "\n[CONTAINER TREE LAYOUT]\n"
        << "Game owner      : +"
        << HexU64(
            profile.gameContainersOffset
        )
        << "\n"
        << "Header field    : +"
        << HexU64(
            profile.containerMapHeaderOffset
        )
        << "\n"
        << "Size field      : +"
        << HexU64(
            profile.containerMapSizeOffset
        )
        << "\n"
        << "Node links      : +"
        << HexU64(
            profile.containerNodeLeftOffset
        )
        << " / +"
        << HexU64(
            profile.containerNodeRightOffset
        )
        << "\n"
        << "Node value      : +"
        << HexU64(
            profile.containerNodeValueOffset
        )
        << "\n"
        << "Container name  : +"
        << HexU64(
            profile.containerNameOffset
        )
        << "\n";

    return true;
}

V38DequeCandidate
V38ScoreContainerDeque(
    uintptr_t container,
    uintptr_t itemVtable,
    uintptr_t mapOffset,
    size_t elementStride,
    size_t blockElements,
    const std::string& mode)
{
    V38DequeCandidate out{};

    out.mapOffset =
        mapOffset;

    out.mapSizeOffset =
        mapOffset + 0x08;

    out.dequeOffsetOffset =
        mapOffset + 0x10;

    out.countOffset =
        mapOffset + 0x18;

    out.elementStride =
        elementStride;

    out.blockElements =
        blockElements;

    out.mode =
        mode;

    uintptr_t dequeMap =
        ReadPtr(
            container +
            out.mapOffset
        );

    uint64_t dequeMapSize = 0;
    uint64_t dequeOffset = 0;
    uint32_t itemCount = 0;

    SafeRead(
        container +
            out.mapSizeOffset,
        dequeMapSize
    );

    SafeRead(
        container +
            out.dequeOffsetOffset,
        dequeOffset
    );

    SafeRead(
        container +
            out.countOffset,
        itemCount
    );

    if (!dequeMap ||
        dequeMapSize == 0 ||
        (dequeMapSize &
         (dequeMapSize - 1)) != 0 ||
        dequeMapSize > 0x10000 ||
        itemCount == 0 ||
        itemCount > 200 ||
        !IsReadableMonitorRange(
            dequeMap,
            static_cast<size_t>(
                std::min<uint64_t>(
                    dequeMapSize,
                    64
                )
            ) *
            sizeof(uintptr_t)))
    {
        return out;
    }

    out.count =
        itemCount;

    for (size_t i = 0;
         i < itemCount;
         ++i)
    {
        uint64_t logical =
            dequeOffset +
            i;

        uint64_t block =
            (
                logical /
                blockElements
            ) &
            (
                dequeMapSize -
                1
            );

        uint64_t cell =
            logical %
            blockElements;

        uintptr_t blockPtr =
            ReadPtr(
                dequeMap +
                block *
                sizeof(uintptr_t)
            );

        if (!blockPtr ||
            !IsReadableMonitorRange(
                blockPtr,
                blockElements *
                    elementStride))
        {
            continue;
        }

        uintptr_t entry =
            blockPtr +
            cell *
            elementStride;

        uintptr_t item =
            ReadPtr(
                entry
            );

        if (!item ||
            !IsReadableMonitorRange(
                item,
                sizeof(uintptr_t)))
        {
            continue;
        }

        uintptr_t vt =
            ReadPtr(
                item
            );

        if (
            vt != itemVtable &&
            !V36IsRealSemanticItem(
                item)
        )
        {
            continue;
        }

        ++out.validItems;

        if (mode ==
                "deque_shared_ptr_item")
        {
            uintptr_t control =
                ReadPtr(
                    entry + 8
                );

            if (LooksLikeSharedPtrControlBlock(
                    control))
            {
                ++out.validCompanions;
            }
        }
    }

    if (!out.validItems ||
        out.validItems * 100 <
            out.count * 80)
    {
        out.score = 0;
        return out;
    }

    out.score =
        static_cast<int>(
            out.validItems *
            200
        );

    if (out.validItems ==
        out.count)
    {
        out.score += 500;
    }

    if (mode ==
            "deque_shared_ptr_item")
    {
        if (out.validCompanions !=
            out.validItems)
        {
            out.score = 0;
            return out;
        }

        out.score +=
            static_cast<int>(
                out.validCompanions *
                40
            );
    }

    return out;
}

bool V38DiscoverContainerDequeLayout(
    DbProfile& profile,
    const std::vector<uintptr_t>& containers)
{
    if (containers.empty() ||
        !profile.itemVtableRva)
    {
        return false;
    }

    uintptr_t itemVtable =
        g_exeBase +
        profile.itemVtableRva;

    std::vector<V38DequeCandidate>
        candidates;

    for (uintptr_t container :
         containers)
    {
        for (uintptr_t off = 0x10;
             off <= 0xC0;
             off += 8)
        {
            auto raw =
                V38ScoreContainerDeque(
                    container,
                    itemVtable,
                    off,
                    8,
                    2,
                    "deque_raw_item_ptr"
                );

            if (raw.score)
            {
                candidates.push_back(
                    raw
                );
            }

            auto shared =
                V38ScoreContainerDeque(
                    container,
                    itemVtable,
                    off,
                    16,
                    1,
                    "deque_shared_ptr_item"
                );

            if (shared.score)
            {
                candidates.push_back(
                    shared
                );
            }
        }
    }

    if (candidates.empty())
        return false;

    std::sort(
        candidates.begin(),
        candidates.end(),
        [](
            const V38DequeCandidate& a,
            const V38DequeCandidate& b)
        {
            if (a.score !=
                b.score)
            {
                return
                    a.score >
                    b.score;
            }

            if (a.validItems !=
                b.validItems)
            {
                return
                    a.validItems >
                    b.validItems;
            }

            return
                a.mapOffset <
                b.mapOffset;
        }
    );

    std::cout
        << "\n[CONTAINER DEQUE CANDIDATES]\n";

    for (size_t i = 0;
         i < candidates.size() &&
         i < 10;
         ++i)
    {
        const auto& c =
            candidates[i];

        std::cout
            << "#"
            << i
            << " map=+"
            << HexU64(
                c.mapOffset
            )
            << " mode="
            << c.mode
            << " count="
            << c.count
            << " items="
            << c.validItems
            << " companion="
            << c.validCompanions
            << " score="
            << c.score
            << "\n";
    }

    if (candidates.size() > 1)
    {
        const auto& a =
            candidates[0];

        const auto& b =
            candidates[1];

        if (a.score ==
                b.score &&
            a.mapOffset !=
                b.mapOffset)
        {
            return false;
        }
    }

    const auto& winner =
        candidates[0];

    profile.containerDequeMapOffset =
        winner.mapOffset;

    profile.containerDequeMapSizeOffset =
        winner.mapSizeOffset;

    profile.containerDequeOffsetOffset =
        winner.dequeOffsetOffset;

    profile.containerItemCountOffset =
        winner.countOffset;

    profile.containerItemElementStride =
        winner.elementStride;

    profile.containerItemStorageMode =
        winner.mode;

    profile.containersStatus =
        "confirmed_runtime_container_owner_and_layout";

    std::cout
        << "\n[CONTAINER ITEM STORAGE CONFIRMED]\n"
        << "Deque map       : +"
        << HexU64(
            profile.containerDequeMapOffset
        )
        << "\n"
        << "Map size        : +"
        << HexU64(
            profile.containerDequeMapSizeOffset
        )
        << "\n"
        << "Deque offset    : +"
        << HexU64(
            profile.containerDequeOffsetOffset
        )
        << "\n"
        << "Item count      : +"
        << HexU64(
            profile.containerItemCountOffset
        )
        << "\n"
        << "Storage mode    : "
        << profile.containerItemStorageMode
        << "\n"
        << "Element stride  : "
        << profile.containerItemElementStride
        << "\n";

    return true;
}

std::vector<uintptr_t>
V38CollectContainerItems(
    const DbProfile& profile,
    const std::vector<uintptr_t>& containers)
{
    std::vector<uintptr_t>
        out;

    if (!profile.itemVtableRva ||
        !profile.containerDequeMapOffset ||
        !profile.containerDequeMapSizeOffset ||
        !profile.containerDequeOffsetOffset ||
        !profile.containerItemCountOffset)
    {
        return out;
    }

    uintptr_t itemVtable =
        g_exeBase +
        profile.itemVtableRva;

    const bool shared =
        profile.containerItemStorageMode ==
            "deque_shared_ptr_item";

    const size_t elementStride =
        shared
            ? 16
            : 8;

    const size_t blockElements =
        shared
            ? 1
            : 2;

    for (uintptr_t container :
         containers)
    {
        uintptr_t dequeMap =
            ReadPtr(
                container +
                profile.containerDequeMapOffset
            );

        uint64_t mapSize = 0;
        uint64_t dequeOffset = 0;
        uint32_t count = 0;

        SafeRead(
            container +
                profile.containerDequeMapSizeOffset,
            mapSize
        );

        SafeRead(
            container +
                profile.containerDequeOffsetOffset,
            dequeOffset
        );

        SafeRead(
            container +
                profile.containerItemCountOffset,
            count
        );

        if (!dequeMap ||
            !mapSize ||
            (mapSize &
             (mapSize - 1)) != 0 ||
            mapSize > 0x10000 ||
            count > 200)
        {
            continue;
        }

        for (size_t i = 0;
             i < count;
             ++i)
        {
            uint64_t logical =
                dequeOffset +
                i;

            uint64_t block =
                (
                    logical /
                    blockElements
                ) &
                (
                    mapSize -
                    1
                );

            uint64_t cell =
                logical %
                blockElements;

            uintptr_t blockPtr =
                ReadPtr(
                    dequeMap +
                    block *
                    sizeof(uintptr_t)
                );

            if (!blockPtr)
                continue;

            uintptr_t entry =
                blockPtr +
                cell *
                elementStride;

            uintptr_t item =
                ReadPtr(
                    entry
                );

            if (!item)
                continue;

            uintptr_t vt =
                ReadPtr(
                    item
                );

            if (
                vt == itemVtable ||
                V36IsRealSemanticItem(
                    item)
            )
            {
                out.push_back(
                    item
                );
            }
        }
    }

    std::sort(
        out.begin(),
        out.end()
    );

    out.erase(
        std::unique(
            out.begin(),
            out.end()
        ),
        out.end()
    );

    return out;
}

bool V38DiscoverSemanticContainerLayout(
    DbProfile& profile)
{
    if (!profile.gameContainersOffset)
        return false;

    auto containers =
        V38FindContainersLinkedToConfirmedOwner(
            profile
        );

    if (containers.empty())
    {
        std::cout
            << "[CONTAINER LAYOUT] Owner confirmado, mas nenhum Container "
            << "aberto esta ligado a ele agora.\n";

        return false;
    }

    std::cout
        << "\n[CONTAINER LAYOUT] linked containers="
        << containers.size()
        << "\n";

    bool treeOk =
        V38InferContainerTreeLayout(
            profile,
            containers
        );

    bool dequeOk =
        V38DiscoverContainerDequeLayout(
            profile,
            containers
        );

    return
        treeOk &&
        dequeOk;
}


bool BMDiscoverContainers(
    DbProfile& profile,
    uintptr_t localPlayer)
{
    (void)localPlayer;

    if (!profile.gameRva ||
        !profile.itemVtableRva)
    {
        return false;
    }

    uintptr_t game =
        g_exeBase +
        profile.gameRva;

    uintptr_t itemVtable =
        g_exeBase +
        profile.itemVtableRva;

    std::vector<BMContainerMapCandidate>
        candidates;

    for (uintptr_t off = 0;
         off <= 0x400;
         off += 8)
    {
        BMContainerMapCandidate c{};

        if (BMValidateContainerMapCandidate(
                game,
                off,
                itemVtable,
                c,
                false))
        {
            candidates.push_back(
                c
            );
        }
    }

    std::sort(
        candidates.begin(),
        candidates.end(),
        [](
            const BMContainerMapCandidate& a,
            const BMContainerMapCandidate& b)
        {
            if (a.score !=
                b.score)
            {
                return a.score > b.score;
            }

            return
                a.gameOffset <
                b.gameOffset;
        }
    );

    if (candidates.empty())
        return false;

    if (candidates.size() > 1 &&
        candidates[0].score ==
            candidates[1].score)
    {
        return false;
    }

    BMContainerMapCandidate winner =
        candidates[0];

    std::cout
        << "\n============================================================\n"
        << "               CONTAINER STORAGE DISCOVERED\n"
        << "============================================================\n"
        << "Game member          : +"
        << HexU64(
            winner.gameOffset
        )
        << "\n"
        << "Reported map size    : "
        << winner.reportedSize
        << "\n"
        << "Tree nodes visited   : "
        << winner.visitedNodes
        << "\n"
        << "Valid containers     : "
        << winner.validContainers
        << "\n"
        << "Validated Item ptrs  : "
        << winner.validItems
        << "\n";

    BMValidateContainerMapCandidate(
        game,
        winner.gameOffset,
        itemVtable,
        winner,
        true
    );

    profile.gameContainersOffset =
        winner.gameOffset;

    profile.containerMapHeaderOffset =
        0x00;

    profile.containerMapSizeOffset =
        0x08;

    profile.containerNodeLeftOffset =
        0x00;

    profile.containerNodeRightOffset =
        0x10;

    profile.containerNodeNilOffset =
        0x19;

    profile.containerNodeKeyOffset =
        0x20;

    profile.containerNodeValueOffset =
        0x28;

    profile.containerIdOffset =
        0x18;

    profile.containerCapacityOffset =
        0x1C;

    profile.containerItemOffset =
        0x20;

    profile.containerNameOffset =
        0x28;

    profile.containerHasParentOffset =
        0x48;

    profile.containerClosedOffset =
        0x49;

    profile.containerUnlockedOffset =
        0x4A;

    profile.containerPagesOffset =
        0x4B;

    profile.containerSizeOffset =
        0x4C;

    profile.containerFirstIndexOffset =
        0x50;

    profile.containerDequeMapOffset =
        0x60;

    profile.containerDequeMapSizeOffset =
        0x68;

    profile.containerDequeOffsetOffset =
        0x70;

    profile.containerItemCountOffset =
        0x78;

    profile.containerItemElementStride =
        8;

    profile.containerItemStorageMode =
        "deque_raw_item_ptr";

    profile.containersStatus =
        "confirmed_runtime_open_container_tree_and_items";

    // Item layout is cross-checked while enumerating container Items.
    if (winner.validItems)
    {
        profile.itemIdOffset =
            0x38;

        profile.itemCountOffset =
            0x3C;

        profile.itemCountWidth =
            2;

        profile.itemLayoutStatus =
            "confirmed_runtime_container_items_item_vtable";
    }

    return true;
}

struct V38ItemSnapshot
{
    uintptr_t pointer = 0;
    std::vector<uint8_t> bytes;
};

struct V46ContainerLogicalSlot
{
    uintptr_t container = 0;
    size_t index = 0;
    uintptr_t item = 0;
    uintptr_t companion = 0;
};

std::vector<V46ContainerLogicalSlot>
V46CollectContainerLogicalSlots(
    const DbProfile& profile,
    const std::vector<uintptr_t>& containers)
{
    std::vector<V46ContainerLogicalSlot>
        out;

    if (
        !profile.containerDequeMapOffset ||
        !profile.containerDequeMapSizeOffset ||
        !profile.containerDequeOffsetOffset ||
        !profile.containerItemCountOffset
    )
    {
        return out;
    }

    const bool shared =
        profile.containerItemStorageMode ==
            "deque_shared_ptr_item";

    const size_t elementStride =
        shared
            ? 16
            : 8;

    const size_t blockElements =
        shared
            ? 1
            : 2;

    for (uintptr_t container :
         containers)
    {
        uintptr_t dequeMap =
            ReadPtr(
                container +
                profile.containerDequeMapOffset
            );

        uint64_t mapSize = 0;
        uint64_t dequeOffset = 0;
        uint32_t count = 0;

        SafeRead(
            container +
                profile.containerDequeMapSizeOffset,
            mapSize
        );

        SafeRead(
            container +
                profile.containerDequeOffsetOffset,
            dequeOffset
        );

        SafeRead(
            container +
                profile.containerItemCountOffset,
            count
        );

        if (
            !dequeMap ||
            !mapSize ||
            (mapSize & (mapSize - 1)) != 0 ||
            mapSize > 0x10000 ||
            count > 200
        )
        {
            continue;
        }

        for (size_t i = 0;
             i < count;
             ++i)
        {
            uint64_t logical =
                dequeOffset +
                i;

            uint64_t block =
                (
                    logical /
                    blockElements
                ) &
                (
                    mapSize -
                    1
                );

            uint64_t cell =
                logical %
                blockElements;

            uintptr_t blockPtr =
                ReadPtr(
                    dequeMap +
                    block *
                    sizeof(uintptr_t)
                );

            if (!blockPtr)
                continue;

            uintptr_t entry =
                blockPtr +
                cell *
                elementStride;

            uintptr_t item =
                ReadPtr(
                    entry
                );

            uintptr_t companion =
                shared
                    ? ReadPtr(
                          entry +
                          sizeof(uintptr_t)
                      )
                    : 0;

            V46ContainerLogicalSlot slot{};
            slot.container =
                container;
            slot.index =
                i;
            slot.item =
                item;
            slot.companion =
                companion;

            out.push_back(
                slot
            );
        }
    }

    std::sort(
        out.begin(),
        out.end(),
        [](
            const V46ContainerLogicalSlot& a,
            const V46ContainerLogicalSlot& b)
        {
            if (a.container != b.container)
                return a.container < b.container;

            return a.index < b.index;
        }
    );

    return out;
}

struct V46ContainerSlotSnapshot
{
    uintptr_t container = 0;
    size_t index = 0;
    uintptr_t item = 0;
    uintptr_t companion = 0;
    V38ItemSnapshot snapshot;
};

std::vector<V46ContainerSlotSnapshot>
V46CaptureContainerSlotSnapshots(
    const DbProfile& profile)
{
    std::vector<V46ContainerSlotSnapshot>
        out;

    auto containers =
        V38FindContainersLinkedToConfirmedOwner(
            profile
        );

    auto slots =
        V46CollectContainerLogicalSlots(
            profile,
            containers
        );

    for (const auto& slot :
         slots)
    {
        if (
            !slot.item ||
            !V36IsRealSemanticItem(
                slot.item) ||
            !IsReadableMonitorRange(
                slot.item,
                0x180)
        )
        {
            continue;
        }

        V46ContainerSlotSnapshot s{};
        s.container =
            slot.container;
        s.index =
            slot.index;
        s.item =
            slot.item;
        s.companion =
            slot.companion;
        s.snapshot.pointer =
            slot.item;
        s.snapshot.bytes.resize(
            0x180
        );

        std::memcpy(
            s.snapshot.bytes.data(),
            reinterpret_cast<const void*>(
                slot.item),
            s.snapshot.bytes.size()
        );

        out.push_back(
            std::move(
                s
            )
        );
    }

    return out;
}



bool BMValidateReferenceItemLayout(
    DbProfile& profile,
    uintptr_t localPlayer)
{
    if (!profile.itemVtableRva)
        return false;

    auto observations =
        V25CollectWorldThings(
            profile,
            localPlayer
        );

    uintptr_t itemVtable =
        g_exeBase +
        profile.itemVtableRva;

    size_t checked = 0;
    size_t plausible = 0;

    for (const auto& o :
         observations)
    {
        if (
            o.vtable !=
                itemVtable &&
            !V33RttiContainsClassToken(
                o.rttiName,
                "item")
        )
        {
            continue;
        }

        if (!IsReadableMonitorRange(
                o.pointer,
                0x40))
        {
            continue;
        }

        uint16_t id = 0;
        uint16_t count = 0;

        SafeRead(
            o.pointer +
                0x38,
            id
        );

        SafeRead(
            o.pointer +
                0x3C,
            count
        );

        ++checked;

        if (id > 0 &&
            id < 65000 &&
            count < 10000)
        {
            ++plausible;
        }

        if (checked >= 128)
            break;
    }

    if (checked < 8 ||
        plausible * 100 <
            checked * 90)
    {
        return false;
    }

    profile.itemIdOffset =
        0x38;

    profile.itemCountOffset =
        0x3C;

    profile.itemLayoutStatus =
        "confirmed_runtime_item_cohort_reference_layout";

    return true;
}


std::vector<uintptr_t>
V38CollectInventoryItemPointers(
    const DbProfile& profile,
    uintptr_t localPlayer)
{
    std::vector<uintptr_t>
        out;

    if (!profile.inventoryBaseOffset ||
        !profile.inventorySlotStride)
    {
        return out;
    }

    for (size_t slot = 1;
         slot <= 10;
         ++slot)
    {
        uintptr_t address =
            localPlayer +
            profile.inventoryBaseOffset +
            slot *
            profile.inventorySlotStride;

        uintptr_t item =
            ReadPtr(
                address
            );

        if (!item)
            continue;

        if (V36IsRealSemanticItem(
                item))
        {
            out.push_back(
                item
            );
        }
    }

    std::sort(
        out.begin(),
        out.end()
    );

    out.erase(
        std::unique(
            out.begin(),
            out.end()
        ),
        out.end()
    );

    return out;
}

std::vector<V38ItemSnapshot>
V38CaptureItemSnapshots(
    const std::vector<uintptr_t>& items)
{
    std::vector<V38ItemSnapshot>
        out;

    for (uintptr_t item :
         items)
    {
        if (!IsReadableMonitorRange(
                item,
                0x180))
        {
            continue;
        }

        V38ItemSnapshot snap{};
        snap.pointer = item;
        snap.bytes.resize(
            0x180
        );

        std::memcpy(
            snap.bytes.data(),
            reinterpret_cast<const void*>(
                item),
            snap.bytes.size()
        );

        out.push_back(
            std::move(
                snap
            )
        );
    }

    return out;
}


uint64_t V39ReadUnsignedWidth(
    const std::vector<uint8_t>& bytes,
    size_t offset,
    size_t width)
{
    if (offset + width >
        bytes.size())
    {
        return 0;
    }

    uint64_t value = 0;

    std::memcpy(
        &value,
        bytes.data() + offset,
        width
    );

    return value;
}

double V39ItemSimilarityExcluding(
    const V38ItemSnapshot& a,
    const V38ItemSnapshot& b,
    size_t excludeOffset,
    size_t excludeWidth)
{
    const size_t begin = 0x10;
    const size_t end =
        std::min<size_t>(
            0x160,
            std::min(
                a.bytes.size(),
                b.bytes.size()
            )
        );

    size_t compared = 0;
    size_t equal = 0;

    for (size_t i = begin;
         i < end;
         ++i)
    {
        if (i >= excludeOffset &&
            i < excludeOffset +
                excludeWidth)
        {
            continue;
        }

        ++compared;

        if (a.bytes[i] ==
            b.bytes[i])
        {
            ++equal;
        }
    }

    return
        compared
            ? static_cast<double>(
                  equal) /
              static_cast<double>(
                  compared)
            : 0.0;
}

std::vector<uintptr_t>
V39CollectAllCurrentItems(
    const DbProfile& profile,
    uintptr_t localPlayer)
{
    std::vector<uintptr_t> out =
        V38CollectInventoryItemPointers(
            profile,
            localPlayer
        );

    if (profile.gameContainersOffset &&
        profile.containerDequeMapOffset &&
        profile.containerItemCountOffset)
    {
        auto containers =
            V38FindContainersLinkedToConfirmedOwner(
                profile
            );

        auto containerItems =
            V38CollectContainerItems(
                profile,
                containers
            );

        out.insert(
            out.end(),
            containerItems.begin(),
            containerItems.end()
        );
    }

    std::sort(
        out.begin(),
        out.end()
    );

    out.erase(
        std::unique(
            out.begin(),
            out.end()
        ),
        out.end()
    );

    return out;
}

struct V39CountTransitionCandidate
{
    uintptr_t offset = 0;
    size_t width = 0;
    uintptr_t beforePointer = 0;
    uintptr_t afterPointer = 0;
    uint64_t oldValue = 0;
    uint64_t newValue = 0;
    double similarity = 0.0;
    int score = 0;
};


// ============================================================
// BUILDMIGRATOR V4.7 - ITEM ID SEMANTIC CONFIRMATION (NORMAL)
// ============================================================

std::string V47AskLine(
    const char* label)
{
    std::cout << label;

    std::string value;
    std::getline(
        std::cin,
        value
    );

    return value;
}

bool V47CaptureVisualContainerSlot(
    const DbProfile& profile,
    size_t visualSlot,
    V38ItemSnapshot& out,
    uintptr_t& outContainer,
    size_t& outLogicalIndex)
{
    auto slots =
        V46CaptureContainerSlotSnapshots(
            profile
        );

    std::vector<const V46ContainerSlotSnapshot*>
        matches;

    for (const auto& s :
         slots)
    {
        if (s.index + 1 ==
            visualSlot)
        {
            matches.push_back(
                &s
            );
        }
    }

    if (matches.empty())
    {
        std::cout
            << "[ITEM ID] Nenhum Item encontrado no slot visual "
            << visualSlot
            << ".\n";

        return false;
    }

    if (matches.size() != 1)
    {
        std::cout
            << "[ITEM ID] O mesmo slot visual apareceu em "
            << matches.size()
            << " containers abertos.\n"
            << "[ITEM ID] Feche os outros containers e deixe SOMENTE o container do teste aberto.\n";

        return false;
    }

    out =
        matches[0]->snapshot;

    outContainer =
        matches[0]->container;

    outLogicalIndex =
        matches[0]->index;

    return
        out.pointer != 0 &&
        !out.bytes.empty();
}

bool V47ResolveItemIdFromTwoKnownSamples(
    DbProfile& profile,
    unsigned expectedA,
    const V38ItemSnapshot& sampleA,
    unsigned expectedB,
    const V38ItemSnapshot& sampleB,
    const char* confirmationMethod)
{
    if (!profile.itemCountOffset ||
        !profile.itemCountWidth)
    {
        std::cout
            << "[ITEM ID] Count/Subtype ainda nao esta confirmado.\n";

        return false;
    }

    if (!expectedA ||
        !expectedB ||
        expectedA == expectedB)
    {
        std::cout
            << "[ITEM ID] As duas amostras precisam ter IDs conhecidos, validos e DIFERENTES.\n";

        return false;
    }

    struct Match
    {
        uintptr_t offset = 0;
        size_t width = 0;
        uint64_t a = 0;
        uint64_t b = 0;
    };

    std::vector<Match>
        matches;

    const intptr_t beginOff =
        std::max<intptr_t>(
            0x10,
            static_cast<intptr_t>(
                profile.itemCountOffset
            ) - 0x20
        );

    const intptr_t endOff =
        std::min<intptr_t>(
            0x180,
            static_cast<intptr_t>(
                profile.itemCountOffset
            ) + 0x20
        );

    for (size_t width :
         {
             static_cast<size_t>(2),
             static_cast<size_t>(4)
         })
    {
        if (width == 2 &&
            (expectedA > 0xFFFFu ||
             expectedB > 0xFFFFu))
        {
            continue;
        }

        for (intptr_t signedOff =
                 beginOff;
             signedOff +
                     static_cast<intptr_t>(
                         width
                     ) <=
                 endOff;
             ++signedOff)
        {
            const uintptr_t off =
                static_cast<uintptr_t>(
                    signedOff
                );

            const uintptr_t countBegin =
                profile.itemCountOffset;

            const uintptr_t countEnd =
                profile.itemCountOffset +
                profile.itemCountWidth;

            const uintptr_t idBegin =
                off;

            const uintptr_t idEnd =
                off + width;

            if (idBegin < countEnd &&
                idEnd > countBegin)
            {
                continue;
            }

            const uint64_t a =
                V39ReadUnsignedWidth(
                    sampleA.bytes,
                    off,
                    width
                );

            const uint64_t b =
                V39ReadUnsignedWidth(
                    sampleB.bytes,
                    off,
                    width
                );

            if (a != expectedA ||
                b != expectedB)
            {
                continue;
            }

            Match m{};
            m.offset = off;
            m.width = width;
            m.a = a;
            m.b = b;

            matches.push_back(
                m
            );
        }
    }

    std::cout
        << "\n[ITEM ID EXACT SEMANTIC MATCHES]\n";

    for (size_t i = 0;
         i < matches.size();
         ++i)
    {
        std::cout
            << "#"
            << i
            << " off=+"
            << HexU64(
                matches[i].offset
            )
            << " width="
            << matches[i].width
            << " A="
            << matches[i].a
            << " B="
            << matches[i].b
            << "\n";
    }

    if (matches.empty())
    {
        std::cout
            << "[ITEM ID] Nenhum campo bateu com os dois IDs conhecidos. Nenhum offset sera promovido.\n";

        return false;
    }

    std::set<uintptr_t>
        uniqueOffsets;

    for (const auto& m :
         matches)
    {
        uniqueOffsets.insert(
            m.offset
        );
    }

    if (uniqueOffsets.size() != 1)
    {
        std::cout
            << "[ITEM ID] Mais de um offset distinto bateu nas duas amostras.\n"
            << "[ITEM ID] Ambiguidade mantida; nenhum offset sera promovido.\n";

        return false;
    }

    const uintptr_t confirmedOffset =
        *uniqueOffsets.begin();

    size_t confirmedWidth = 0;

    for (const auto& m :
         matches)
    {
        if (m.offset !=
            confirmedOffset)
        {
            continue;
        }

        if (!confirmedWidth ||
            m.width < confirmedWidth)
        {
            confirmedWidth =
                m.width;
        }
    }

    profile.itemIdOffset =
        confirmedOffset;

    profile.itemLayoutStatus =
        confirmationMethod;

    std::cout
        << "\n============================================================\n"
        << "                ITEM ID CONFIRMED V4.8\n"
        << "============================================================\n"
        << "Item ID offset       : +"
        << HexU64(
            profile.itemIdOffset
        )
        << "\n"
        << "Observed width       : "
        << confirmedWidth
        << " byte(s)\n"
        << "Count/Subtype offset : +"
        << HexU64(
            profile.itemCountOffset
        )
        << "\n"
        << "Evidence             : two different known Item IDs / same logical container slot\n"
        << "Status               : "
        << profile.itemLayoutStatus
        << "\n";

    return true;
}

bool V47ConfirmItemIdNormal(
    DbProfile& profile)
{
    std::cout
        << "\n============================================================\n"
        << "          V4.8 ITEM ID - NORMAL / MANUAL ORACLE\n"
        << "============================================================\n"
        << "[MODE] READ-ONLY\n"
        << "[NO HOOK] nenhuma funcao interna sera chamada\n"
        << "Regra: duas amostras de ITENS DIFERENTES no MESMO slot visual.\n"
        << "Voce informa o ID conhecido de cada item; o Lab apenas compara memoria.\n\n"
        << "Antes de comecar:\n"
        << "  1. deixe SOMENTE um container aberto\n"
        << "  2. escolha um slot visual que possa trocar sem mudar de posicao\n"
        << "  3. use dois itens de IDs conhecidos e DIFERENTES\n";

    const unsigned visualSlot =
        AskUnsignedRange(
            "Slot visual do container (1..200): ",
            1,
            200
        );

    WaitEnter(
        "Coloque o ITEM A nesse slot e pressione ENTER..."
    );

    V38ItemSnapshot sampleA{};
    uintptr_t containerA = 0;
    size_t logicalA = 0;

    if (!V47CaptureVisualContainerSlot(
            profile,
            visualSlot,
            sampleA,
            containerA,
            logicalA))
    {
        return false;
    }

    const unsigned expectedA =
        AskUnsignedRange(
            "ID conhecido do ITEM A: ",
            1,
            std::numeric_limits<unsigned>::max()
        );

    std::cout
        << "[SAMPLE A] container="
        << HexPtr(
            containerA
        )
        << " logicalIndex="
        << logicalA
        << " item="
        << HexPtr(
            sampleA.pointer
        )
        << " expectedId="
        << expectedA
        << "\n";

    WaitEnter(
        "Troque SOMENTE esse slot pelo ITEM B (ID diferente) e pressione ENTER..."
    );

    V38ItemSnapshot sampleB{};
    uintptr_t containerB = 0;
    size_t logicalB = 0;

    if (!V47CaptureVisualContainerSlot(
            profile,
            visualSlot,
            sampleB,
            containerB,
            logicalB))
    {
        return false;
    }

    const unsigned expectedB =
        AskUnsignedRange(
            "ID conhecido do ITEM B: ",
            1,
            std::numeric_limits<unsigned>::max()
        );

    std::cout
        << "[SAMPLE B] container="
        << HexPtr(
            containerB
        )
        << " logicalIndex="
        << logicalB
        << " item="
        << HexPtr(
            sampleB.pointer
        )
        << " expectedId="
        << expectedB
        << "\n";

    if (containerA !=
            containerB ||
        logicalA !=
            logicalB)
    {
        std::cout
            << "[ITEM ID] O container/slot logico mudou entre A e B. Teste rejeitado.\n";

        return false;
    }

    return
        V47ResolveItemIdFromTwoKnownSamples(
            profile,
            expectedA,
            sampleA,
            expectedB,
            sampleB,
            "confirmed_runtime_two_known_item_ids_manual"
        );
}

bool V39DiscoverItemLayoutGuided(
    DbProfile& profile,
    uintptr_t localPlayer)
{
    std::cout
        << "\n============================================================\n"
        << "      V4.7 CONTAINER-SLOT EXACT ITEM COUNT RESOLVER\n"
        << "============================================================\n"
        << "[MODE] READ-ONLY\n"
        << "Identity rule: SAME Container* + SAME logical slot index.\n"
        << "No all-to-all Item pairing is allowed.\n";

    const bool countAlreadyConfirmed =
        profile.itemCountOffset != 0 &&
        profile.itemCountWidth != 0 &&
        (
            profile.itemLayoutStatus.find(
                "partial_count_confirmed_container_slot") == 0 ||
            profile.itemLayoutStatus.find(
                "confirmed_") == 0
        );

    V39CountTransitionCandidate count{};

    if (!countAlreadyConfirmed)
    {
        if (
            !profile.gameContainersOffset ||
            !profile.containerDequeMapOffset ||
            !profile.containerDequeMapSizeOffset ||
            !profile.containerDequeOffsetOffset ||
            !profile.containerItemCountOffset
        )
        {
            std::cout
                << "[ITEM] Container layout ainda nao esta confirmado; "
                << "nao e seguro aprender Count sem provenance.\n";
            return false;
        }

        std::cout
            << "\nPrepare o teste assim:\n"
            << "  1. deixe aberta a Backpack/container que contem a pilha\n"
            << "  2. NAO mova a pilha de slot\n"
            << "  3. use/adicione/retire exatamente UMA unidade\n"
            << "  4. a pilha deve continuar no MESMO slot logico\n";

        WaitEnter(
            "Com a pilha visivel no container aberto, pressione ENTER..."
        );

        auto beforeSlots =
            V46CaptureContainerSlotSnapshots(
                profile
            );

        if (beforeSlots.empty())
        {
            std::cout
                << "[ITEM] Nenhum Item de container aberto foi capturado.\n";
            return false;
        }

        if (!AskYesNo(
                "Existe uma pilha VISIVEL nesse container com quantidade >=2? [S/N]: "))
        {
            return false;
        }

        unsigned visibleBefore =
            AskUnsignedRange(
                "Quantidade VISIVEL da pilha ANTES da acao: ",
                2,
                100000000
            );

        std::cout
            << "\n[ACTION - SAME CONTAINER SLOT]\n"
            << "Altere exatamente UMA unidade da pilha.\n"
            << "NAO mova a pilha para outro slot/container.\n"
            << "Exemplo correto: 18 -> 17 ou 17 -> 18.\n";

        WaitEnter(
            "Depois da mudanca de UMA unidade, pressione ENTER..."
        );

        unsigned visibleAfter =
            AskUnsignedRange(
                "Quantidade VISIVEL da MESMA pilha AGORA: ",
                0,
                100000000
            );

        unsigned delta =
            visibleBefore > visibleAfter
                ? visibleBefore - visibleAfter
                : visibleAfter - visibleBefore;

        if (delta != 1)
        {
            std::cout
                << "[ITEM] A quantidade informada nao mudou exatamente UMA unidade.\n";
            return false;
        }

        auto afterSlots =
            V46CaptureContainerSlotSnapshots(
                profile
            );

        if (afterSlots.empty())
        {
            std::cout
                << "[ITEM] O container/slot nao permaneceu observavel apos a acao.\n";
            return false;
        }

        using SlotKey =
            std::pair<uintptr_t, size_t>;

        std::map<SlotKey, const V46ContainerSlotSnapshot*>
            afterByKey;

        for (const auto& s :
             afterSlots)
        {
            afterByKey[
                {
                    s.container,
                    s.index
                }
            ] =
                &s;
        }

        struct ExactAggregate
        {
            V39CountTransitionCandidate best;
            size_t evidence = 0;
            size_t slotMatches = 0;
        };

        std::map<
            std::pair<uintptr_t, size_t>,
            ExactAggregate>
            aggregate;

        const size_t widths[] =
        {
            1,
            2,
            4
        };

        const size_t minimalWidth =
            std::max(
                visibleBefore,
                visibleAfter
            ) <= 0xFF
                ? 1
                : (
                    std::max(
                        visibleBefore,
                        visibleAfter
                    ) <= 0xFFFF
                        ? 2
                        : 4
                  );

        size_t sameSlotPairs = 0;
        size_t exactTransitionPairs = 0;

        for (const auto& aSlot :
             beforeSlots)
        {
            auto it =
                afterByKey.find(
                    {
                        aSlot.container,
                        aSlot.index
                    }
                );

            if (it ==
                afterByKey.end())
            {
                continue;
            }

            const auto& bSlot =
                *it->second;

            if (
                !aSlot.item ||
                !bSlot.item
            )
            {
                continue;
            }

            ++sameSlotPairs;

            const auto& a =
                aSlot.snapshot;
            const auto& b =
                bSlot.snapshot;

            bool pairHadExact =
                false;

            for (size_t width :
                 widths)
            {
                if (width <
                    minimalWidth)
                {
                    continue;
                }

                size_t limit =
                    std::min(
                        a.bytes.size(),
                        b.bytes.size()
                    );

                for (size_t off = 0x10;
                     off + width <= limit;
                     ++off)
                {
                    uint64_t oldValue =
                        V39ReadUnsignedWidth(
                            a.bytes,
                            off,
                            width
                        );

                    if (oldValue !=
                        visibleBefore)
                    {
                        continue;
                    }

                    uint64_t newValue =
                        V39ReadUnsignedWidth(
                            b.bytes,
                            off,
                            width
                        );

                    if (newValue !=
                        visibleAfter)
                    {
                        continue;
                    }

                    double similarity =
                        V39ItemSimilarityExcluding(
                            a,
                            b,
                            off,
                            width
                        );

                    // Same logical slot is the provenance anchor.  The object
                    // itself may be rebuilt, but it still must remain broadly
                    // similar after excluding the count field.
                    const double threshold =
                        a.pointer ==
                            b.pointer
                            ? 0.45
                            : 0.60;

                    if (similarity <
                        threshold)
                    {
                        continue;
                    }

                    pairHadExact =
                        true;

                    V39CountTransitionCandidate c{};
                    c.offset =
                        off;
                    c.width =
                        width;
                    c.beforePointer =
                        a.pointer;
                    c.afterPointer =
                        b.pointer;
                    c.oldValue =
                        oldValue;
                    c.newValue =
                        newValue;
                    c.similarity =
                        similarity;

                    c.score =
                        5000 +
                        static_cast<int>(
                            similarity *
                            1000.0
                        );

                    // SAME container + SAME logical slot is much stronger
                    // evidence than pointer equality.
                    c.score +=
                        1200;

                    if (
                        a.pointer ==
                        b.pointer
                    )
                    {
                        c.score +=
                            250;
                    }

                    if (width ==
                        minimalWidth)
                    {
                        c.score +=
                            260;
                    }

                    if ((off % width) == 0)
                    {
                        c.score +=
                            40;
                    }

                    auto key =
                        std::make_pair(
                            static_cast<uintptr_t>(
                                off),
                            width
                        );

                    auto& e =
                        aggregate[
                            key
                        ];

                    ++e.evidence;
                    ++e.slotMatches;

                    if (
                        e.best.score == 0 ||
                        c.score >
                            e.best.score
                    )
                    {
                        e.best =
                            c;
                    }
                }
            }

            if (pairHadExact)
            {
                ++exactTransitionPairs;
            }
        }

        struct Ranked
        {
            V39CountTransitionCandidate c;
            size_t evidence = 0;
            size_t slotMatches = 0;
        };

        std::vector<Ranked>
            ranked;

        for (const auto& kv :
             aggregate)
        {
            Ranked r{};
            r.c =
                kv.second.best;
            r.evidence =
                kv.second.evidence;
            r.slotMatches =
                kv.second.slotMatches;

            r.c.score +=
                static_cast<int>(
                    std::min<size_t>(
                        r.slotMatches,
                        4
                    ) *
                    100
                );

            ranked.push_back(
                r
            );
        }

        std::sort(
            ranked.begin(),
            ranked.end(),
            [](
                const Ranked& a,
                const Ranked& b)
            {
                if (a.c.score !=
                    b.c.score)
                {
                    return
                        a.c.score >
                        b.c.score;
                }

                if (a.slotMatches !=
                    b.slotMatches)
                {
                    return
                        a.slotMatches >
                        b.slotMatches;
                }

                if (a.c.width !=
                    b.c.width)
                {
                    return
                        a.c.width <
                        b.c.width;
                }

                return
                    a.c.offset <
                    b.c.offset;
            }
        );

        std::cout
            << "\n[ITEM CONTAINER-SLOT PROVENANCE]\n"
            << "Before slots           : "
            << beforeSlots.size()
            << "\n"
            << "After slots            : "
            << afterSlots.size()
            << "\n"
            << "Same container/index   : "
            << sameSlotPairs
            << "\n"
            << "Pairs with exact value : "
            << exactTransitionPairs
            << "\n";

        std::cout
            << "\n[ITEM EXACT COUNT CANDIDATES / SAME SLOT]\n";

        for (size_t i = 0;
             i < ranked.size() &&
             i < 12;
             ++i)
        {
            const auto& r =
                ranked[i];

            std::cout
                << "#"
                << i
                << " off=+"
                << HexU64(
                    r.c.offset
                )
                << " width="
                << r.c.width
                << " value="
                << r.c.oldValue
                << "->"
                << r.c.newValue
                << " slotEvidence="
                << r.slotMatches
                << " similarity="
                << std::fixed
                << std::setprecision(3)
                << r.c.similarity
                << " ptr="
                << (
                    r.c.beforePointer ==
                        r.c.afterPointer
                        ? "same"
                        : "rebuilt"
                )
                << " score="
                << r.c.score
                << "\n";
        }

        if (ranked.empty())
        {
            std::cout
                << "[ITEM] Nenhum SAME container/slot apresentou "
                << visibleBefore
                << " -> "
                << visibleAfter
                << ".\n"
                << "[ITEM] Nenhum offset sera adivinhado.\n";

            return false;
        }

        if (
            ranked.size() > 1 &&
            ranked[0].c.offset !=
                ranked[1].c.offset &&
            ranked[0].c.score -
                ranked[1].c.score <
                120
        )
        {
            std::cout
                << "[ITEM] Mais de um offset continua forte no MESMO slot; Count permanece pending.\n";

            return false;
        }

        count =
            ranked[0].c;

        profile.itemCountOffset =
            count.offset;

        profile.itemCountWidth =
            count.width;

        profile.itemIdOffset =
            0;

        profile.itemLayoutStatus =
            "partial_count_confirmed_container_slot_id_pending";

        std::cout
            << "\n[ITEM COUNT CONFIRMED BY CONTAINER SLOT]\n"
            << "Count/Subtype offset : +"
            << HexU64(
                profile.itemCountOffset
            )
            << "\n"
            << "Count width          : "
            << profile.itemCountWidth
            << " byte(s)\n"
            << "Visible transition   : "
            << visibleBefore
            << " -> "
            << visibleAfter
            << "\n"
            << "Identity             : SAME Container* + SAME logical index\n"
            << "Status               : partial_count_confirmed_container_slot_id_pending\n";
    }
    else
    {
        count.offset =
            profile.itemCountOffset;

        count.width =
            profile.itemCountWidth;

        std::cout
            << "[ITEM COUNT] Container-slot provenance ja confirmou Count em +"
            << HexU64(
                profile.itemCountOffset
            )
            << " width="
            << profile.itemCountWidth
            << ". Nao repetiremos o consumo da pilha.\n";
    }

    // V4.6 intentionally does NOT promote Item ID from a "nearest diverse
    // field" heuristic.  The clean Scape run demonstrated that Count must be
    // tied to logical provenance; ID requires an independent semantic proof.
    auto currentItems =
        V39CollectAllCurrentItems(
            profile,
            localPlayer
        );

    auto snapshots =
        V38CaptureItemSnapshots(
            currentItems
        );

    struct IdCandidate
    {
        uintptr_t offset = 0;
        size_t width = 0;
        size_t nonZero = 0;
        size_t distinct = 0;
        int score = 0;
    };

    std::vector<IdCandidate>
        ids;

    for (size_t width :
         {
             static_cast<size_t>(2),
             static_cast<size_t>(4)
         })
    {
        intptr_t beginOff =
            static_cast<intptr_t>(
                count.offset
            ) -
            0x20;

        intptr_t endOff =
            static_cast<intptr_t>(
                count.offset
            ) +
            0x20;

        for (intptr_t signedOff =
                 std::max<intptr_t>(
                     0x10,
                     beginOff
                 );
             signedOff +
                     static_cast<intptr_t>(
                         width
                     ) <=
                 std::min<intptr_t>(
                     0x180,
                     endOff
                 );
             ++signedOff)
        {
            uintptr_t off =
                static_cast<uintptr_t>(
                    signedOff
                );

            if (
                off <=
                    count.offset +
                    count.width -
                    1 &&
                off + width - 1 >=
                    count.offset
            )
            {
                continue;
            }

            std::set<uint64_t>
                values;

            size_t nonZero = 0;

            for (const auto& snap :
                 snapshots)
            {
                uint64_t value =
                    V39ReadUnsignedWidth(
                        snap.bytes,
                        off,
                        width
                    );

                if (!value)
                    continue;

                ++nonZero;
                values.insert(
                    value
                );
            }

            if (
                snapshots.empty() ||
                nonZero * 100 <
                    snapshots.size() *
                    65 ||
                values.size() < 2
            )
            {
                continue;
            }

            IdCandidate id{};
            id.offset =
                off;
            id.width =
                width;
            id.nonZero =
                nonZero;
            id.distinct =
                values.size();

            long long distance =
                std::llabs(
                    static_cast<long long>(
                        off
                    ) -
                    static_cast<long long>(
                        count.offset
                    )
                );

            id.score =
                static_cast<int>(
                    nonZero * 18 +
                    values.size() * 22
                ) +
                static_cast<int>(
                    std::max<long long>(
                        0,
                        220 -
                        distance * 10
                    )
                );

            if (width == 2)
                id.score += 40;

            ids.push_back(
                id
            );
        }
    }

    std::sort(
        ids.begin(),
        ids.end(),
        [](
            const IdCandidate& a,
            const IdCandidate& b)
        {
            if (a.score !=
                b.score)
                return a.score > b.score;

            if (a.distinct !=
                b.distinct)
                return a.distinct > b.distinct;

            if (a.width !=
                b.width)
                return a.width < b.width;

            return a.offset < b.offset;
        }
    );

    std::cout
        << "\n[ITEM ID CANDIDATES - EVIDENCE ONLY]\n";

    for (size_t i = 0;
         i < ids.size() &&
         i < 10;
         ++i)
    {
        std::cout
            << "#"
            << i
            << " off=+"
            << HexU64(
                ids[i].offset
            )
            << " width="
            << ids[i].width
            << " nonZero="
            << ids[i].nonZero
            << " distinct="
            << ids[i].distinct
            << " score="
            << ids[i].score
            << "\n";
    }

    std::cout
        << "[ITEM ID] Candidatos estruturais encontrados; iniciando prova semantica V4.7 NORMAL.\n";

    if (V47ConfirmItemIdNormal(
            profile))
    {
        return true;
    }

    profile.itemIdOffset =
        0;

    profile.itemLayoutStatus =
        "partial_count_confirmed_container_slot_id_pending";

    return false;
}


bool V38DiscoverItemLayoutGuided(
    DbProfile& profile,
    uintptr_t localPlayer)
{
    std::vector<uintptr_t>
        items =
            V38CollectInventoryItemPointers(
                profile,
                localPlayer
            );

    auto containers =
        V38FindContainersLinkedToConfirmedOwner(
            profile
        );

    auto containerItems =
        V38CollectContainerItems(
            profile,
            containers
        );

    items.insert(
        items.end(),
        containerItems.begin(),
        containerItems.end()
    );

    std::sort(
        items.begin(),
        items.end()
    );

    items.erase(
        std::unique(
            items.begin(),
            items.end()
        ),
        items.end()
    );

    if (items.size() < 2)
        return false;

    std::cout
        << "\\n============================================================\\n"
        << "           V3.8 ITEM COUNT / ID GUIDED RESOLVER\\n"
        << "============================================================\\n"
        << "[MODE] READ-ONLY\\n"
        << "Item objects available: "
        << items.size()
        << "\\n";

    if (!AskYesNo(
            "Existe uma PILHA com quantidade >=2 que voce consegue alterar em EXATAMENTE 1 unidade agora? [S/N]: "))
    {
        return false;
    }

    auto before =
        V38CaptureItemSnapshots(
            items
        );

    std::cout
        << "\\n[ACTION - ITEM STACK]\\n"
        << "Escolha UMA pilha existente.\\n"
        << "Adicione OU retire UMA unidade (ex.: 36 -> 35; NAO 36 -> 1).\\n"
        << "Nao troque o tipo do item e, se possivel, mantenha a pilha no mesmo lugar.\\n";

    WaitEnter(
        "Depois da quantidade mudar em exatamente 1, pressione ENTER..."
    );

    struct CountCandidate
    {
        uintptr_t offset = 0;
        size_t deltaOne = 0;
        size_t otherChanges = 0;
        int score = 0;
    };

    std::vector<CountCandidate>
        countCandidates;

    for (uintptr_t off = 0x10;
         off + sizeof(uint16_t) <= 0xA0;
         off += 2)
    {
        CountCandidate c{};
        c.offset = off;

        for (const auto& snap :
             before)
        {
            if (!IsReadableMonitorRange(
                    snap.pointer,
                    0xA0))
            {
                continue;
            }

            uint16_t oldValue = 0;
            uint16_t newValue = 0;

            std::memcpy(
                &oldValue,
                snap.bytes.data() + off,
                sizeof(oldValue)
            );

            SafeRead(
                snap.pointer + off,
                newValue
            );

            if (oldValue ==
                newValue)
            {
                continue;
            }

            int delta =
                static_cast<int>(
                    newValue) -
                static_cast<int>(
                    oldValue);

            if (
                std::abs(
                    delta) == 1 &&
                oldValue <= 10000 &&
                newValue <= 10000
            )
            {
                ++c.deltaOne;
            }
            else
            {
                ++c.otherChanges;
            }
        }

        if (!c.deltaOne)
            continue;

        c.score =
            static_cast<int>(
                c.deltaOne * 300
            ) -
            static_cast<int>(
                c.otherChanges * 400
            );

        if ((off & 3) == 0)
            c.score += 30;

        countCandidates.push_back(
            c
        );
    }

    std::sort(
        countCandidates.begin(),
        countCandidates.end(),
        [](
            const CountCandidate& a,
            const CountCandidate& b)
        {
            if (a.score !=
                b.score)
            {
                return
                    a.score >
                    b.score;
            }

            return
                a.offset <
                b.offset;
        }
    );

    std::cout
        << "\\n[ITEM COUNT CANDIDATES]\\n";

    for (size_t i = 0;
         i < countCandidates.size() &&
         i < 12;
         ++i)
    {
        std::cout
            << "#"
            << i
            << " off=+"
            << HexU64(
                countCandidates[i].offset
            )
            << " deltaOne="
            << countCandidates[i].deltaOne
            << " other="
            << countCandidates[i].otherChanges
            << " score="
            << countCandidates[i].score
            << "\\n";
    }

    if (countCandidates.empty() ||
        countCandidates[0].score <= 0)
    {
        return false;
    }

    if (countCandidates.size() > 1 &&
        countCandidates[0].score ==
            countCandidates[1].score)
    {
        return false;
    }

    uintptr_t countOffset =
        countCandidates[0].offset;

    struct IdCandidate
    {
        uintptr_t offset = 0;
        size_t nonZero = 0;
        size_t distinct = 0;
        int score = 0;
    };

    std::vector<IdCandidate>
        ids;

    const intptr_t deltas[] =
    {
        -8,
        -6,
        -4,
        -2,
        2,
        4,
        6,
        8
    };

    for (intptr_t delta :
         deltas)
    {
        intptr_t signedOff =
            static_cast<intptr_t>(
                countOffset) +
            delta;

        if (signedOff < 0x10 ||
            signedOff + 2 >
                0xA0)
        {
            continue;
        }

        uintptr_t off =
            static_cast<uintptr_t>(
                signedOff
            );

        std::set<uint16_t>
            values;

        size_t nonZero = 0;

        for (const auto& snap :
             before)
        {
            uint16_t value = 0;

            std::memcpy(
                &value,
                snap.bytes.data() + off,
                sizeof(value)
            );

            if (value)
            {
                ++nonZero;
                values.insert(
                    value
                );
            }
        }

        if (nonZero * 100 <
                before.size() * 80 ||
            values.empty())
        {
            continue;
        }

        IdCandidate c{};
        c.offset = off;
        c.nonZero = nonZero;
        c.distinct = values.size();

        c.score =
            static_cast<int>(
                nonZero * 20 +
                values.size() * 12
            );

        if (delta == -4)
            c.score += 120;

        if ((off & 1) == 0)
            c.score += 10;

        ids.push_back(
            c
        );
    }

    std::sort(
        ids.begin(),
        ids.end(),
        [](
            const IdCandidate& a,
            const IdCandidate& b)
        {
            if (a.score !=
                b.score)
            {
                return
                    a.score >
                    b.score;
            }

            return
                a.offset <
                b.offset;
        }
    );

    std::cout
        << "\\n[ITEM ID NEIGHBOR CANDIDATES]\\n";

    for (size_t i = 0;
         i < ids.size() &&
         i < 8;
         ++i)
    {
        std::cout
            << "#"
            << i
            << " off=+"
            << HexU64(
                ids[i].offset
            )
            << " nonZero="
            << ids[i].nonZero
            << " distinct="
            << ids[i].distinct
            << " score="
            << ids[i].score
            << "\\n";
    }

    if (ids.empty())
        return false;

    if (ids.size() > 1 &&
        ids[0].score ==
            ids[1].score)
    {
        return false;
    }

    profile.itemCountOffset =
        countOffset;

    profile.itemIdOffset =
        ids[0].offset;

    profile.itemLayoutStatus =
        "confirmed_runtime_stack_transition_id_neighbor";

    std::cout
        << "\\n[ITEM LAYOUT CONFIRMED]\\n"
        << "Item ID offset       : +"
        << HexU64(
            profile.itemIdOffset
        )
        << "\\n"
        << "Count/Subtype offset : +"
        << HexU64(
            profile.itemCountOffset
        )
        << "\\n"
        << "Evidence             : exact +/-1 stack transition + structural neighbor\\n";

    return true;
}


bool EnsureBuildMigratorDataCompletion(
    DbProfile& profile,
    std::vector<DbProfile>& database,
    int profileIndex,
    const std::string& databasePath)
{
    std::cout
        << "\n============================================================\n"
        << "       BUILDMIGRATOR V4.7 NORMAL - NPC / ITEM / CONTAINERS\n"
        << "============================================================\n"
        << "[MODE] READ-ONLY\n"
        << "[NO CALL] nenhuma funcao interna sera chamada\n";

    // V4.6 migration safety:
    // The old all-to-all relocated Item pairing could produce a false Count/ID
    // confirmation.  Never consume that legacy status as authoritative.
    if (
        profile.itemLayoutStatus ==
            "confirmed_runtime_exact_visible_count_and_structural_id"
    )
    {
        std::cout
            << "[ITEM MIGRATION] Legacy all-to-all Count/ID confirmation invalidated; "
            << "recalibrating with container-slot provenance.\n";

        profile.itemIdOffset = 0;
        profile.itemCountOffset = 0;
        profile.itemCountWidth = 0;
        profile.itemLayoutStatus =
            "pending_container_slot_provenance";
    }

    uintptr_t localPlayer =
        WaitForDiscoveryLocalPlayer(
            profile,
            "BUILDMIGRATOR V4.6.1 - FINAL DATA"
        );

    if (!localPlayer)
        return false;

    if (!WaitForTileWorldReady(
            profile,
            localPlayer))
    {
        return false;
    }

    if (profile.npcStatus.find(
            "confirmed_") != 0)
    {
        if (!BMDiscoverNpcFromCurrentWorld(
                profile,
                localPlayer,
                true))
        {
            std::cout
                << "\n[NPC] Nenhum NPC semanticamente unico esta visivel agora.\n";

            if (AskYesNo(
                    "Ir para perto de um NPC visivel e tentar agora? [S/N]: "))
            {
                WaitEnter(
                    "Com o NPC visivel e voce parado, pressione ENTER..."
                );

                WaitForTileWorldReady(
                    profile,
                    localPlayer
                );

                if (!BMDiscoverNpcFromCurrentWorld(
                        profile,
                        localPlayer,
                        true))
                {
                    profile.npcStatus =
                        "pending_npc_not_uniquely_visible";
                }
            }
            else
            {
                profile.npcStatus =
                    "pending_user_skipped_npc";
            }
        }
    }

    if (!BMDiscoverInventory(
            profile,
            localPlayer))
    {
        std::cout
            << "\n[INVENTORY] Ainda nao ficou unico.\n";

        if (AskYesNo(
                "Deixar Backpack/equipamentos ocupando pelo menos 2 slots e tentar novamente? [S/N]: "))
        {
            WaitEnter(
                "Depois de ajustar os equipamentos, pressione ENTER..."
            );

            if (!BMDiscoverInventory(
                    profile,
                    localPlayer))
            {
                profile.inventoryStatus =
                    "pending_inventory_ambiguous";
            }
        }
        else
        {
            profile.inventoryStatus =
                "pending_user_skipped_inventory";
        }
    }

    const bool countConfirmedByContainerSlot =
        profile.itemLayoutStatus.find(
            "partial_count_confirmed_container_slot") == 0;

    if (
        profile.itemLayoutStatus.find(
            "confirmed_") != 0 &&
        !countConfirmedByContainerSlot
    )
    {
        if (!BMValidateReferenceItemLayout(
                profile,
                localPlayer))
        {
            profile.itemLayoutStatus =
                "candidate_reference_offsets_need_container_crosscheck";
        }
    }

    if (
        profile.containersStatus !=
            "confirmed_runtime_open_container_tree_and_items" &&
        profile.containersStatus !=
            "confirmed_runtime_container_owner_and_layout"
    )
    {
        if (!BMDiscoverContainers(
                profile,
                localPlayer))
        {
            std::cout
                << "\n[CONTAINER] Layout legado nao validou nesta build.\n";

            if (!profile.gameContainersOffset)
            {
                if (AskYesNo(
                        "Executar reconhecimento RTTI por transicao fechar/abrir Backpack? [S/N]: "))
                {
                    if (!V36ContainerTransitionRecon(
                            profile))
                    {
                        profile.containersStatus =
                            "pending_container_rtti_transition_no_object";
                    }
                }
                else
                {
                    profile.containersStatus =
                        "pending_user_skipped_containers";
                }
            }

            if (
                profile.gameContainersOffset &&
                profile.containersStatus !=
                    "confirmed_runtime_container_owner_and_layout"
            )
            {
                std::cout
                    << "\n[CONTAINER] Owner conhecido. Tentando aprender tree/deque semanticamente...\n";

                if (!V38DiscoverSemanticContainerLayout(
                        profile))
                {
                    profile.containersStatus =
                        "candidate_container_owner_confirmed_layout_pending";
                }
            }
        }
    }

    if (
        profile.itemLayoutStatus.find(
            "confirmed_") != 0 &&
        profile.inventoryStatus.find(
            "confirmed_") == 0)
    {
        if (!V39DiscoverItemLayoutGuided(
                profile,
                localPlayer))
        {
            std::cout
                << "[ITEM] Layout ID/Count continua pending; nenhum offset foi adivinhado.\n";
        }
    }

    if (profileIndex >= 0 &&
        profileIndex <
            static_cast<int>(
                database.size()))
    {
        database[
            static_cast<size_t>(
                profileIndex)
        ] = profile;

        SaveProfileDatabase(
            databasePath,
            database
        );
    }

    std::cout
        << "\n[DATA COMPLETION]\n"
        << "NPC        : "
        << profile.npcStatus
        << "\n"
        << "Inventory  : "
        << profile.inventoryStatus
        << "\n"
        << "Item       : "
        << profile.itemLayoutStatus
        << "\n"
        << "Containers : "
        << profile.containersStatus
        << "\n";

    return true;
}


// ============================================================
// BUILDMIGRATOR V4.6.1 - STATIC FUNCTION SIGNATURES
// Current exact OpenGL build captures reference signatures.
// Other builds search those signatures in .text.
// Strict read-only.
// ============================================================

std::string BMMakeMaskedSignature(
    uintptr_t address,
    size_t length)
{
    if (!address ||
        address < g_textBegin ||
        address + length > g_textEnd)
    {
        return {};
    }

    std::vector<uint8_t>
        bytes(
            length
        );

    std::memcpy(
        bytes.data(),
        reinterpret_cast<const void*>(
            address),
        length
    );

    std::vector<uint8_t>
        literal(
            length,
            1
        );

    for (size_t i = 0;
         i < length;
         ++i)
    {
        uint8_t op =
            bytes[i];

        if ((op == 0xE8 ||
             op == 0xE9) &&
            i + 4 < length)
        {
            for (size_t j = 1;
                 j <= 4;
                 ++j)
            {
                literal[
                    i + j
                ] = 0;
            }

            i += 4;
            continue;
        }

        if (op == 0x0F &&
            i + 5 < length &&
            bytes[i + 1] >= 0x80 &&
            bytes[i + 1] <= 0x8F)
        {
            for (size_t j = 2;
                 j <= 5;
                 ++j)
            {
                literal[
                    i + j
                ] = 0;
            }

            i += 5;
            continue;
        }

        if (op >= 0x40 &&
            op <= 0x4F &&
            i + 2 < length)
        {
            uint8_t opcode =
                bytes[
                    i + 1
                ];

            if ((opcode == 0x8B ||
                 opcode == 0x8D ||
                 opcode == 0x89 ||
                 opcode == 0x39 ||
                 opcode == 0x3B) &&
                i + 6 < length)
            {
                uint8_t modrm =
                    bytes[
                        i + 2
                    ];

                if ((modrm & 0xC7) ==
                    0x05)
                {
                    for (size_t j = 3;
                         j <= 6;
                         ++j)
                    {
                        literal[
                            i + j
                        ] = 0;
                    }
                }
            }

            if (opcode >= 0xB8 &&
                opcode <= 0xBF &&
                i + 9 < length)
            {
                for (size_t j = 2;
                     j <= 9;
                     ++j)
                {
                    literal[
                        i + j
                    ] = 0;
                }
            }
        }
        else if ((op == 0x8B ||
                  op == 0x8D ||
                  op == 0x89 ||
                  op == 0x39 ||
                  op == 0x3B) &&
                 i + 5 < length)
        {
            uint8_t modrm =
                bytes[
                    i + 1
                ];

            if ((modrm & 0xC7) ==
                0x05)
            {
                for (size_t j = 2;
                     j <= 5;
                     ++j)
                {
                    literal[
                        i + j
                    ] = 0;
                }
            }
        }
    }

    std::ostringstream out;

    out
        << std::uppercase
        << std::hex
        << std::setfill('0');

    for (size_t i = 0;
         i < length;
         ++i)
    {
        if (i)
            out << ' ';

        if (!literal[i])
        {
            out << "??";
        }
        else
        {
            out
                << std::setw(2)
                << static_cast<unsigned>(
                    bytes[i]
                );
        }
    }

    return out.str();
}

bool BMParseSignature(
    const std::string& text,
    std::vector<int>& pattern)
{
    pattern.clear();

    std::istringstream in(
        text
    );

    std::string token;

    while (in >> token)
    {
        if (token == "??")
        {
            pattern.push_back(
                -1
            );

            continue;
        }

        if (token.size() != 2)
            return false;

        unsigned value = 0;

        std::istringstream hex(
            token
        );

        hex
            >> std::hex
            >> value;

        if (!hex)
            return false;

        pattern.push_back(
            static_cast<int>(
                value & 0xFF
            )
        );
    }

    return
        pattern.size() >= 24;
}

uintptr_t BMScanUniqueSignature(
    const std::string& signature,
    size_t* outMatches)
{
    if (outMatches)
        *outMatches = 0;

    std::vector<int>
        pattern;

    if (!BMParseSignature(
            signature,
            pattern))
    {
        return 0;
    }

    size_t textSize =
        static_cast<size_t>(
            g_textEnd -
            g_textBegin
        );

    if (textSize <
        pattern.size())
    {
        return 0;
    }

    std::vector<uint8_t>
        textBytes(
            textSize
        );

    std::memcpy(
        textBytes.data(),
        reinterpret_cast<const void*>(
            g_textBegin),
        textSize
    );

    size_t bestRunStart = 0;
    size_t bestRunLength = 0;

    size_t currentStart = 0;
    size_t currentLength = 0;

    for (size_t i = 0;
         i < pattern.size();
         ++i)
    {
        if (pattern[i] >= 0)
        {
            if (!currentLength)
                currentStart = i;

            ++currentLength;

            if (currentLength >
                bestRunLength)
            {
                bestRunLength =
                    currentLength;

                bestRunStart =
                    currentStart;
            }
        }
        else
        {
            currentLength = 0;
        }
    }

    if (bestRunLength < 6)
        return 0;

    std::vector<uint8_t>
        anchor;

    anchor.reserve(
        bestRunLength
    );

    for (size_t i = 0;
         i < bestRunLength;
         ++i)
    {
        anchor.push_back(
            static_cast<uint8_t>(
                pattern[
                    bestRunStart +
                    i
                ]
            )
        );
    }

    size_t matches = 0;
    uintptr_t unique = 0;

    auto it =
        textBytes.begin();

    while (it !=
           textBytes.end())
    {
        it =
            std::search(
                it,
                textBytes.end(),
                anchor.begin(),
                anchor.end()
            );

        if (it ==
            textBytes.end())
        {
            break;
        }

        size_t anchorPos =
            static_cast<size_t>(
                it -
                textBytes.begin()
            );

        if (anchorPos >=
            bestRunStart)
        {
            size_t start =
                anchorPos -
                bestRunStart;

            if (start +
                    pattern.size() <=
                textBytes.size())
            {
                bool ok = true;

                for (size_t j = 0;
                     j < pattern.size();
                     ++j)
                {
                    if (pattern[j] >= 0 &&
                        textBytes[
                            start + j
                        ] !=
                            static_cast<uint8_t>(
                                pattern[j]))
                    {
                        ok = false;
                        break;
                    }
                }

                if (ok)
                {
                    ++matches;

                    unique =
                        g_textBegin +
                        start;

                    if (matches > 1)
                    {
                        if (outMatches)
                            *outMatches =
                                matches;

                        return 0;
                    }
                }
            }
        }

        ++it;
    }

    if (outMatches)
        *outMatches =
            matches;

    return
        matches == 1
            ? unique
            : 0;
}

struct BMFunctionSpec
{
    const char* name;

    uintptr_t DbProfile::* rvaField;
    std::string DbProfile::* sigField;

    uintptr_t goldenRva;
};

std::vector<BMFunctionSpec>
BMFunctionSpecs()
{
    return
    {
        {
            "Game::autoWalk",
            &DbProfile::fnGameAutoWalk,
            &DbProfile::sigGameAutoWalk,
            0x162200
        },
        {
            "LocalPlayer::autoWalk",
            &DbProfile::fnLocalPlayerAutoWalk,
            &DbProfile::sigLocalPlayerAutoWalk,
            0x1805C0
        },
        {
            "Game::attack",
            &DbProfile::fnGameAttack,
            &DbProfile::sigGameAttack,
            0x165410
        },
        {
            "Game::follow",
            &DbProfile::fnGameFollow,
            &DbProfile::sigGameFollow,
            0x1656E0
        },
        {
            "Game::look",
            &DbProfile::fnGameLook,
            &DbProfile::sigGameLook,
            0x163790
        },
        {
            "Game::detailedLook",
            &DbProfile::fnGameDetailedLook,
            &DbProfile::sigGameDetailedLook,
            0x163B10
        },
        {
            "Game::move",
            &DbProfile::fnGameMove,
            &DbProfile::sigGameMove,
            0x163E20
        },
        {
            "Game::use",
            &DbProfile::fnGameUse,
            &DbProfile::sigGameUse,
            0x164570
        },
        {
            "Game::useWith",
            &DbProfile::fnGameUseWith,
            &DbProfile::sigGameUseWith,
            0x164A50
        },
        {
            "Game::talk",
            &DbProfile::fnGameTalk,
            &DbProfile::sigGameTalk,
            0x165D40
        },
        {
            "Map::getTile",
            &DbProfile::fnMapGetTile,
            &DbProfile::sigMapGetTile,
            0x22D9A0
        },
        {
            "Map::getCreatureById",
            &DbProfile::fnMapGetCreatureById,
            &DbProfile::sigMapGetCreatureById,
            0x22E5A0
        },
        {
            "Map::getCreatureByName",
            &DbProfile::fnMapGetCreatureByName,
            &DbProfile::sigMapGetCreatureByName,
            0x14E910
        },
        {
            "Container::getItem",
            &DbProfile::fnContainerGetItem,
            &DbProfile::sigContainerGetItem,
            0x13A1E0
        }
    };
}

const DbProfile* BMFindGoldenSignatureProfile(
    const std::vector<DbProfile>& database)
{
    for (const auto& p :
         database)
    {
        if (BMIsGoldenOpenGlBuild(
                p) &&
            p.functionsStatus ==
                "golden_signatures_captured")
        {
            return &p;
        }
    }

    return nullptr;
}

bool BMCaptureGoldenFunctionSignatures(
    DbProfile& profile)
{
    auto specs =
        BMFunctionSpecs();

    size_t captured = 0;

    for (const auto& spec :
         specs)
    {
        uintptr_t address =
            g_exeBase +
            spec.goldenRva;

        if (address <
                g_textBegin ||
            address + 64 >
                g_textEnd)
        {
            continue;
        }

        profile.*(
            spec.rvaField
        ) =
            spec.goldenRva;

        profile.*(
            spec.sigField
        ) =
            BMMakeMaskedSignature(
                address,
                64
            );

        if (!(profile.*(
                  spec.sigField
              )).empty())
        {
            ++captured;

            g_functionResolutionMethod[
                spec.name
            ] = "golden_reference";

            g_functionResolutionScore[
                spec.name
            ] = 1.0;
        }
    }

    profile.localPlayerAutoWalkVtableSlot =
        0xA8;

    if (captured ==
        specs.size())
    {
        profile.functionsStatus =
            "golden_signatures_captured";

        return true;
    }

    profile.functionsStatus =
        "golden_signature_capture_partial";

    return false;
}


double BMSignatureSimilarityAt(
    const std::string& signature,
    uintptr_t address,
    size_t* outLiteralCount = nullptr,
    size_t* outMatchedCount = nullptr)
{
    if (outLiteralCount)
        *outLiteralCount = 0;

    if (outMatchedCount)
        *outMatchedCount = 0;

    std::vector<int> pattern;

    if (!BMParseSignature(
            signature,
            pattern))
    {
        return 0.0;
    }

    if (!address ||
        address < g_textBegin ||
        address + pattern.size() >
            g_textEnd)
    {
        return 0.0;
    }

    size_t literals = 0;
    size_t matched = 0;

    for (size_t i = 0;
         i < pattern.size();
         ++i)
    {
        if (pattern[i] < 0)
            continue;

        ++literals;

        uint8_t current =
            *reinterpret_cast<const uint8_t*>(
                address + i
            );

        if (current ==
            static_cast<uint8_t>(
                pattern[i]))
        {
            ++matched;
        }
    }

    if (outLiteralCount)
        *outLiteralCount =
            literals;

    if (outMatchedCount)
        *outMatchedCount =
            matched;

    if (!literals)
        return 0.0;

    return
        static_cast<double>(
            matched) /
        static_cast<double>(
            literals);
}


uintptr_t BMScanAnchoredFuzzySignature(
    const std::string& signature,
    double* outBestScore,
    double* outSecondScore,
    size_t* outCandidateCount)
{
    if (outBestScore)
        *outBestScore = 0.0;

    if (outSecondScore)
        *outSecondScore = 0.0;

    if (outCandidateCount)
        *outCandidateCount = 0;

    std::vector<int>
        pattern;

    if (!BMParseSignature(
            signature,
            pattern))
    {
        return 0;
    }

    struct LiteralRun
    {
        size_t start = 0;
        size_t length = 0;
    };

    std::vector<LiteralRun>
        runs;

    size_t i = 0;

    while (i <
           pattern.size())
    {
        if (pattern[i] < 0)
        {
            ++i;
            continue;
        }

        size_t start =
            i;

        while (i <
               pattern.size() &&
               pattern[i] >= 0)
        {
            ++i;
        }

        size_t length =
            i - start;

        if (length >= 5)
        {
            LiteralRun run{};
            run.start = start;
            run.length =
                std::min<size_t>(
                    length,
                    10
                );

            runs.push_back(
                run
            );
        }
    }

    if (runs.empty())
        return 0;

    std::sort(
        runs.begin(),
        runs.end(),
        [](
            const LiteralRun& a,
            const LiteralRun& b)
        {
            return
                a.length >
                b.length;
        }
    );

    if (runs.size() > 8)
        runs.resize(8);

    const size_t textSize =
        static_cast<size_t>(
            g_textEnd -
            g_textBegin
        );

    const uint8_t* text =
        reinterpret_cast<const uint8_t*>(
            g_textBegin
        );

    std::unordered_map<uintptr_t, double>
        candidates;

    for (const auto& run :
         runs)
    {
        std::vector<uint8_t>
            anchor;

        for (size_t k = 0;
             k < run.length;
             ++k)
        {
            anchor.push_back(
                static_cast<uint8_t>(
                    pattern[
                        run.start +
                        k
                    ]
                )
            );
        }

        const uint8_t* begin =
            text;

        const uint8_t* end =
            text +
            textSize;

        const uint8_t* cursor =
            begin;

        size_t anchorHits = 0;

        while (cursor <
               end)
        {
            const uint8_t* hit =
                std::search(
                    cursor,
                    end,
                    anchor.begin(),
                    anchor.end()
                );

            if (hit ==
                end)
            {
                break;
            }

            ++anchorHits;

            if (anchorHits > 4096)
                break;

            size_t hitOffset =
                static_cast<size_t>(
                    hit -
                    begin
                );

            if (hitOffset >=
                run.start)
            {
                intptr_t nominal =
                    static_cast<intptr_t>(
                        hitOffset -
                        run.start
                    );

                for (intptr_t shift = -12;
                     shift <= 12;
                     ++shift)
                {
                    intptr_t startSigned =
                        nominal +
                        shift;

                    if (startSigned < 0)
                        continue;

                    size_t start =
                        static_cast<size_t>(
                            startSigned
                        );

                    if (start +
                            pattern.size() >
                        textSize)
                    {
                        continue;
                    }

                    uintptr_t address =
                        g_textBegin +
                        start;

                    size_t literals = 0;
                    size_t matched = 0;

                    double score =
                        BMSignatureSimilarityAt(
                            signature,
                            address,
                            &literals,
                            &matched
                        );

                    if (literals < 24)
                        continue;

                    auto it =
                        candidates.find(
                            address
                        );

                    if (it ==
                            candidates.end() ||
                        score >
                            it->second)
                    {
                        candidates[
                            address
                        ] =
                            score;
                    }
                }
            }

            cursor =
                hit + 1;
        }
    }

    if (outCandidateCount)
    {
        *outCandidateCount =
            candidates.size();
    }

    if (candidates.empty())
        return 0;

    uintptr_t bestAddress = 0;
    double bestScore = 0.0;
    double secondScore = 0.0;

    for (const auto& kv :
         candidates)
    {
        if (kv.second >
            bestScore)
        {
            secondScore =
                bestScore;

            bestScore =
                kv.second;

            bestAddress =
                kv.first;
        }
        else if (kv.second >
                 secondScore)
        {
            secondScore =
                kv.second;
        }
    }

    if (outBestScore)
        *outBestScore =
            bestScore;

    if (outSecondScore)
        *outSecondScore =
            secondScore;

    const double gap =
        bestScore -
        secondScore;

    const bool strong =
        (
            bestScore >= 0.88 &&
            gap >= 0.03
        ) ||
        (
            bestScore >= 0.80 &&
            gap >= 0.07
        );

    return
        strong
            ? bestAddress
            : 0;
}


bool BMResolveByFamilyDeltaFuzzy(
    DbProfile& profile,
    const DbProfile& golden,
    const std::vector<BMFunctionSpec>& specs,
    size_t& resolved)
{
    std::unordered_map<long long, size_t>
        deltaCounts;

    for (const auto& spec :
         specs)
    {
        std::string name =
            spec.name;

        if (name.rfind(
                "Game::",
                0) != 0)
        {
            continue;
        }

        uintptr_t current =
            profile.*(
                spec.rvaField
            );

        if (!current)
            continue;

        long long delta =
            static_cast<long long>(
                current) -
            static_cast<long long>(
                spec.goldenRva);

        ++deltaCounts[
            delta
        ];
    }

    if (deltaCounts.empty())
        return false;

    long long dominantDelta = 0;
    size_t dominantCount = 0;

    for (const auto& kv :
         deltaCounts)
    {
        if (kv.second >
            dominantCount)
        {
            dominantDelta =
                kv.first;

            dominantCount =
                kv.second;
        }
    }

    if (dominantCount < 5)
        return false;

    std::cout
        << "\n[FAMILY DELTA] Game::* dominant delta = "
        << (
            dominantDelta >= 0
                ? "+"
                : "-"
        )
        << HexU64(
            static_cast<uintptr_t>(
                dominantDelta >= 0
                    ? dominantDelta
                    : -dominantDelta
            )
        )
        << " from "
        << dominantCount
        << " resolved sibling functions.\n";

    bool addedAny = false;

    for (const auto& spec :
         specs)
    {
        std::string name =
            spec.name;

        if (name.rfind(
                "Game::",
                0) != 0)
        {
            continue;
        }

        if (profile.*(
                spec.rvaField))
        {
            continue;
        }

        const std::string& signature =
            golden.*(
                spec.sigField
            );

        if (signature.empty())
            continue;

        long long predictedSigned =
            static_cast<long long>(
                spec.goldenRva) +
            dominantDelta;

        if (predictedSigned <= 0)
            continue;

        uintptr_t predictedRva =
            static_cast<uintptr_t>(
                predictedSigned
            );

        uintptr_t predicted =
            g_exeBase +
            predictedRva;

        // First trust the very strong sibling-delta prediction only if
        // the masked bytes still substantially resemble the Golden function.
        size_t literalCount = 0;
        size_t matchedCount = 0;

        double predictedScore =
            BMSignatureSimilarityAt(
                signature,
                predicted,
                &literalCount,
                &matchedCount
            );

        uintptr_t bestAddress =
            predicted;

        double bestScore =
            predictedScore;

        double secondScore =
            0.0;

        // If the exact predicted boundary changed slightly, search a narrow
        // neighborhood only. This is intentionally NOT a whole-image fuzzy scan.
        const intptr_t radius =
            0x80;

        for (intptr_t d =
                 -radius;
             d <= radius;
             ++d)
        {
            uintptr_t candidate =
                static_cast<uintptr_t>(
                    static_cast<intptr_t>(
                        predicted) +
                    d
                );

            size_t localLiteral = 0;
            size_t localMatched = 0;

            double score =
                BMSignatureSimilarityAt(
                    signature,
                    candidate,
                    &localLiteral,
                    &localMatched
                );

            if (localLiteral <
                24)
            {
                continue;
            }

            if (score >
                bestScore)
            {
                secondScore =
                    bestScore;

                bestScore =
                    score;

                bestAddress =
                    candidate;
            }
            else if (score >
                     secondScore &&
                     candidate !=
                         bestAddress)
            {
                secondScore =
                    score;
            }
        }

        const bool strongExact =
            bestAddress ==
                predicted &&
            bestScore >= 0.72 &&
            literalCount >= 24;

        const bool strongNearby =
            bestAddress !=
                predicted &&
            bestScore >= 0.82 &&
            (
                bestScore -
                secondScore
            ) >= 0.05;

        if (!strongExact &&
            !strongNearby)
        {
            std::cout
                << spec.name
                << " : FAMILY DELTA candidate "
                << HexU64(
                    predictedRva
                )
                << " fuzzy="
                << std::fixed
                << std::setprecision(2)
                << bestScore
                << " -> NOT PROMOTED\n";

            continue;
        }

        uintptr_t rva =
            bestAddress -
            g_exeBase;

        profile.*(
            spec.rvaField
        ) =
            rva;

        profile.*(
            spec.sigField
        ) =
            BMMakeMaskedSignature(
                bestAddress,
                64
            );

        ++resolved;
        addedAny = true;

        g_functionResolutionMethod[
            spec.name
        ] = "family_delta_fuzzy";

        g_functionResolutionScore[
            spec.name
        ] = bestScore;

        std::cout
            << spec.name
            << " : RVA "
            << HexU64(
                rva
            )
            << " [FAMILY DELTA + FUZZY "
            << std::fixed
            << std::setprecision(2)
            << bestScore
            << "]\n";
    }

    return addedAny;
}



std::string V42LuaBindingToken(
    const std::string& semanticName)
{
    if (semanticName == "Game::autoWalk")
        return "autoWalk";

    if (semanticName == "LocalPlayer::autoWalk")
        return "autoWalk";

    if (semanticName == "Game::attack")
        return "attack";

    if (semanticName == "Game::follow")
        return "follow";

    if (semanticName == "Game::look")
        return "look";

    // detailedLook is fork-specific in several clients. Do not invent
    // a public binding token unless a stable token is observed.
    if (semanticName == "Game::detailedLook")
        return {};

    if (semanticName == "Game::move")
        return "move";

    if (semanticName == "Game::use")
        return "use";

    if (semanticName == "Game::useWith")
        return "useWith";

    if (semanticName == "Game::talk")
        return "talk";

    if (semanticName == "Map::getTile")
        return "getTile";

    if (semanticName == "Map::getCreatureById")
        return "getCreatureById";

    if (semanticName == "Map::getCreatureByName")
        return "getCreatureByName";

    if (semanticName == "Container::getItem")
        return "getItem";

    return {};
}

std::vector<uintptr_t>
V42FindModuleCStringOccurrences(
    const std::string& value,
    size_t maxResults = 64)
{
    std::vector<uintptr_t> out;

    if (value.empty() ||
        !g_exeBase ||
        !g_imageEnd ||
        g_imageEnd <= g_exeBase)
    {
        return out;
    }

    std::vector<uint8_t> pattern(
        value.begin(),
        value.end()
    );

    pattern.push_back(0);

    constexpr size_t CHUNK =
        1024 * 1024;

    std::vector<uint8_t> buffer(
        CHUNK +
        256
    );

    uintptr_t cursor =
        g_exeBase;

    const size_t overlap =
        pattern.size() > 1
            ? pattern.size() - 1
            : 0;

    while (cursor <
           g_imageEnd)
    {
        size_t want =
            static_cast<size_t>(
                std::min<uintptr_t>(
                    CHUNK,
                    g_imageEnd -
                    cursor
                )
            );

        size_t got = 0;

        if (!ReadProcessChunk(
                cursor,
                buffer.data(),
                want,
                got))
        {
            cursor +=
                std::max<size_t>(
                    want,
                    0x1000
                );

            continue;
        }

        if (got <
            pattern.size())
        {
            cursor += got;
            continue;
        }

        auto begin =
            buffer.begin();

        auto end =
            buffer.begin() +
            got;

        auto it =
            begin;

        while (it != end)
        {
            it =
                std::search(
                    it,
                    end,
                    pattern.begin(),
                    pattern.end()
                );

            if (it == end)
                break;

            size_t local =
                static_cast<size_t>(
                    it -
                    begin
                );

            uintptr_t address =
                cursor +
                local;

            // Prefer exact C strings, not suffixes inside longer words.
            bool leftBoundary =
                local == 0 ||
                buffer[
                    local - 1
                ] == 0 ||
                buffer[
                    local - 1
                ] < 0x20;

            if (leftBoundary)
            {
                out.push_back(
                    address
                );

                if (out.size() >=
                    maxResults)
                {
                    break;
                }
            }

            ++it;
        }

        if (out.size() >=
            maxResults)
        {
            break;
        }

        if (got <= overlap)
            break;

        cursor +=
            got -
            overlap;
    }

    std::sort(
        out.begin(),
        out.end()
    );

    out.erase(
        std::unique(
            out.begin(),
            out.end()
        ),
        out.end()
    );

    return out;
}

std::vector<uintptr_t>
V42FindRipRefsToAddress(
    uintptr_t target,
    size_t maxResults = 256)
{
    std::vector<uintptr_t> out;

    if (!target ||
        !g_textBegin ||
        !g_textEnd ||
        g_textEnd <=
            g_textBegin)
    {
        return out;
    }

    const uint8_t* text =
        reinterpret_cast<const uint8_t*>(
            g_textBegin
        );

    const size_t size =
        static_cast<size_t>(
            g_textEnd -
            g_textBegin
        );

    for (size_t i = 0;
         i + 7 <= size;
         ++i)
    {
        const uint8_t rex =
            text[i];

        if ((rex & 0xF0) != 0x40)
            continue;

        const uint8_t opcode =
            text[
                i + 1
            ];

        if (opcode != 0x8D &&
            opcode != 0x8B)
        {
            continue;
        }

        const uint8_t modrm =
            text[
                i + 2
            ];

        if ((modrm & 0xC7) !=
            0x05)
        {
            continue;
        }

        int32_t disp = 0;

        std::memcpy(
            &disp,
            text + i + 3,
            sizeof(disp)
        );

        uintptr_t address =
            g_textBegin +
            i;

        uintptr_t destination =
            address +
            7 +
            static_cast<intptr_t>(
                disp
            );

        if (destination ==
            target)
        {
            out.push_back(
                address
            );

            if (out.size() >=
                maxResults)
            {
                break;
            }
        }
    }

    return out;
}

std::vector<uintptr_t>
V42CollectNearbyLeaTextTargets(
    uintptr_t center,
    size_t radius = 0x180)
{
    std::vector<uintptr_t> out;

    if (!center)
        return out;

    uintptr_t begin =
        center > radius
            ? center - radius
            : g_textBegin;

    if (begin <
        g_textBegin)
    {
        begin =
            g_textBegin;
    }

    uintptr_t end =
        std::min<uintptr_t>(
            g_textEnd,
            center +
            radius
        );

    if (end <= begin ||
        end - begin < 7)
    {
        return out;
    }

    const uint8_t* bytes =
        reinterpret_cast<const uint8_t*>(
            begin
        );

    const size_t size =
        static_cast<size_t>(
            end -
            begin
        );

    for (size_t i = 0;
         i + 7 <= size;
         ++i)
    {
        const uint8_t rex =
            bytes[i];

        if ((rex & 0xF0) != 0x40)
            continue;

        // Function pointers used by Lua binding templates are commonly
        // materialized with LEA reg,[rip+function].
        if (bytes[
                i + 1
            ] != 0x8D)
        {
            continue;
        }

        const uint8_t modrm =
            bytes[
                i + 2
            ];

        if ((modrm & 0xC7) !=
            0x05)
        {
            continue;
        }

        int32_t disp = 0;

        std::memcpy(
            &disp,
            bytes + i + 3,
            sizeof(disp)
        );

        uintptr_t instruction =
            begin +
            i;

        uintptr_t destination =
            instruction +
            7 +
            static_cast<intptr_t>(
                disp
            );

        if (destination >=
                g_textBegin &&
            destination <
                g_textEnd)
        {
            out.push_back(
                destination
            );
        }
    }

    std::sort(
        out.begin(),
        out.end()
    );

    out.erase(
        std::unique(
            out.begin(),
            out.end()
        ),
        out.end()
    );

    return out;
}


// V4.3.1: forward declaration because the callgraph resolver is defined
// before the native-contract helper implementation below.
size_t V41CountDirectCallXrefs(
    uintptr_t target);


// V4.4.1: forward declaration required by the PDATA resolver.
std::string BMFunctionMethod(
    const char* name,
    const DbProfile& p);

struct V44FunctionRange
{
    uintptr_t begin = 0;
    uintptr_t end = 0;
    uint32_t unwindRva = 0;

    bool valid() const
    {
        return
            begin >= g_textBegin &&
            end > begin &&
            end <= g_textEnd;
    }

    size_t size() const
    {
        return
            valid()
                ? static_cast<size_t>(
                    end - begin)
                : 0;
    }
};

struct V44RuntimeFunctionRaw
{
    uint32_t beginRva = 0;
    uint32_t endRva = 0;
    uint32_t unwindRva = 0;
};

bool V44GetFunctionRange(
    uintptr_t address,
    V44FunctionRange& out)
{
    out = {};

    if (
        !address ||
        address < g_textBegin ||
        address >= g_textEnd
    )
    {
        return false;
    }

    IMAGE_DOS_HEADER dos{};

    if (!SafeRead(
            g_exeBase,
            dos) ||
        dos.e_magic != IMAGE_DOS_SIGNATURE)
    {
        return false;
    }

    uintptr_t ntAddress =
        g_exeBase +
        static_cast<uintptr_t>(
            dos.e_lfanew
        );

    IMAGE_NT_HEADERS64 nt{};

    if (!SafeRead(
            ntAddress,
            nt) ||
        nt.Signature !=
            IMAGE_NT_SIGNATURE)
    {
        return false;
    }

    const auto& directory =
        nt.OptionalHeader
            .DataDirectory[
                IMAGE_DIRECTORY_ENTRY_EXCEPTION
            ];

    if (
        !directory.VirtualAddress ||
        directory.Size <
            sizeof(
                V44RuntimeFunctionRaw)
    )
    {
        return false;
    }

    uintptr_t table =
        g_exeBase +
        directory.VirtualAddress;

    size_t count =
        directory.Size /
        sizeof(
            V44RuntimeFunctionRaw);

    uint32_t targetRva =
        static_cast<uint32_t>(
            address -
            g_exeBase
        );

    // .pdata is sorted by BeginAddress on normal x64 PE images.
    size_t lo = 0;
    size_t hi = count;

    while (lo < hi)
    {
        size_t mid =
            lo +
            (hi - lo) / 2;

        V44RuntimeFunctionRaw entry{};

        if (!SafeRead(
                table +
                    mid *
                    sizeof(entry),
                entry))
        {
            return false;
        }

        if (targetRva <
            entry.beginRva)
        {
            hi = mid;
            continue;
        }

        if (targetRva >=
            entry.endRva)
        {
            lo = mid + 1;
            continue;
        }

        out.begin =
            g_exeBase +
            entry.beginRva;

        out.end =
            g_exeBase +
            entry.endRva;

        out.unwindRva =
            entry.unwindRva;

        return
            out.valid();
    }

    return false;
}

struct V44BranchTarget
{
    uintptr_t address = 0;
    std::string kind;
};

std::vector<V44BranchTarget>
V44CollectBranchesInFunction(
    uintptr_t anyAddress,
    size_t maxResults = 256)
{
    std::vector<V44BranchTarget>
        out;

    V44FunctionRange range{};

    if (!V44GetFunctionRange(
            anyAddress,
            range))
    {
        return out;
    }

    const uint8_t* bytes =
        reinterpret_cast<const uint8_t*>(
            range.begin
        );

    const size_t size =
        range.size();

    auto addTarget =
        [&](uintptr_t target,
            const char* kind)
        {
            if (
                target < g_textBegin ||
                target >= g_textEnd
            )
            {
                return;
            }

            for (const auto& existing :
                 out)
            {
                if (
                    existing.address ==
                        target &&
                    existing.kind ==
                        kind
                )
                {
                    return;
                }
            }

            V44BranchTarget b{};
            b.address = target;
            b.kind = kind;

            out.push_back(
                b
            );
        };

    for (size_t i = 0;
         i < size;
         ++i)
    {
        // CALL rel32
        if (
            bytes[i] == 0xE8 &&
            i + 5 <= size
        )
        {
            int32_t rel = 0;

            std::memcpy(
                &rel,
                bytes + i + 1,
                sizeof(rel)
            );

            uintptr_t instruction =
                range.begin +
                i;

            uintptr_t target =
                instruction +
                5 +
                static_cast<intptr_t>(
                    rel
                );

            addTarget(
                target,
                "call_rel32"
            );

            if (out.size() >=
                maxResults)
            {
                break;
            }

            continue;
        }

        // JMP rel32 - important for thin binding wrappers / tailcalls.
        if (
            bytes[i] == 0xE9 &&
            i + 5 <= size
        )
        {
            int32_t rel = 0;

            std::memcpy(
                &rel,
                bytes + i + 1,
                sizeof(rel)
            );

            uintptr_t instruction =
                range.begin +
                i;

            uintptr_t target =
                instruction +
                5 +
                static_cast<intptr_t>(
                    rel
                );

            // Internal control-flow branches are not callgraph edges.
            if (
                target < range.begin ||
                target >= range.end
            )
            {
                addTarget(
                    target,
                    "tail_jmp_rel32"
                );
            }

            if (out.size() >=
                maxResults)
            {
                break;
            }

            continue;
        }

        // CALL/JMP qword ptr [RIP+disp32].
        // If the slot already points back into .text, it is a useful
        // indirect edge. Imports outside .text are ignored.
        if (
            bytes[i] == 0xFF &&
            i + 6 <= size &&
            (
                bytes[
                    i + 1
                ] == 0x15 ||
                bytes[
                    i + 1
                ] == 0x25
            )
        )
        {
            int32_t disp = 0;

            std::memcpy(
                &disp,
                bytes + i + 2,
                sizeof(disp)
            );

            uintptr_t instruction =
                range.begin +
                i;

            uintptr_t slot =
                instruction +
                6 +
                static_cast<intptr_t>(
                    disp
                );

            uintptr_t target =
                ReadPtr(
                    slot
                );

            addTarget(
                target,
                bytes[
                    i + 1
                ] == 0x15
                    ? "call_rip_indirect"
                    : "jmp_rip_indirect"
            );

            if (out.size() >=
                maxResults)
            {
                break;
            }
        }
    }

    return out;
}

struct V44PdataCallgraphCandidate
{
    uintptr_t address = 0;
    uintptr_t functionBegin = 0;
    size_t functionSize = 0;
    size_t depth = 0;
    size_t pathVotes = 0;
    size_t directCallsites = 0;
    size_t tailVotes = 0;
    size_t indirectVotes = 0;
    double similarity = 0.0;
    double confidence = 0.0;
};

std::vector<V44PdataCallgraphCandidate>
V44CollectPdataBoundedCandidates(
    const std::string& semanticName,
    const std::string& signature)
{
    std::vector<V44PdataCallgraphCandidate>
        out;

    const std::string token =
        V42LuaBindingToken(
            semanticName
        );

    if (
        token.empty() ||
        signature.empty()
    )
    {
        return out;
    }

    auto strings =
        V42FindModuleCStringOccurrences(
            token
        );

    struct Vote
    {
        uintptr_t seed = 0;
        size_t minDepth = 99;
        size_t votes = 0;
        size_t tailVotes = 0;
        size_t indirectVotes = 0;
    };

    std::map<uintptr_t, Vote>
        votes;

    auto add =
        [&](uintptr_t address,
            uintptr_t seed,
            size_t depth,
            const std::string& kind)
        {
            V44FunctionRange range{};

            if (!V44GetFunctionRange(
                    address,
                    range))
            {
                return;
            }

            uintptr_t canonical =
                range.begin;

            Vote& v =
                votes[
                    canonical
                ];

            v.seed =
                seed;

            v.minDepth =
                std::min<size_t>(
                    v.minDepth,
                    depth
                );

            ++v.votes;

            if (kind.find(
                    "tail_jmp") !=
                std::string::npos)
            {
                ++v.tailVotes;
            }

            if (kind.find(
                    "indirect") !=
                std::string::npos)
            {
                ++v.indirectVotes;
            }
        };

    for (uintptr_t str :
         strings)
    {
        auto xrefs =
            V42FindRipRefsToAddress(
                str
            );

        for (uintptr_t xref :
             xrefs)
        {
            V44FunctionRange registration{};

            if (V44GetFunctionRange(
                    xref,
                    registration))
            {
                auto registrationEdges =
                    V44CollectBranchesInFunction(
                        registration.begin
                    );

                for (const auto& edge :
                     registrationEdges)
                {
                    add(
                        edge.address,
                        registration.begin,
                        1,
                        edge.kind
                    );
                }
            }

            auto seeds =
                V42CollectNearbyLeaTextTargets(
                    xref,
                    0x280
                );

            for (uintptr_t seed :
                 seeds)
            {
                V44FunctionRange seedRange{};

                if (!V44GetFunctionRange(
                        seed,
                        seedRange))
                {
                    continue;
                }

                add(
                    seedRange.begin,
                    seedRange.begin,
                    0,
                    "binding_seed"
                );

                auto depth1 =
                    V44CollectBranchesInFunction(
                        seedRange.begin
                    );

                for (const auto& edge1 :
                     depth1)
                {
                    add(
                        edge1.address,
                        seedRange.begin,
                        1,
                        edge1.kind
                    );

                    V44FunctionRange d1Range{};

                    if (!V44GetFunctionRange(
                            edge1.address,
                            d1Range))
                    {
                        continue;
                    }

                    auto depth2 =
                        V44CollectBranchesInFunction(
                            d1Range.begin
                        );

                    for (const auto& edge2 :
                         depth2)
                    {
                        add(
                            edge2.address,
                            seedRange.begin,
                            2,
                            edge2.kind
                        );
                    }
                }
            }
        }
    }

    for (const auto& kv :
         votes)
    {
        V44FunctionRange range{};

        if (!V44GetFunctionRange(
                kv.first,
                range))
        {
            continue;
        }

        size_t literals = 0;
        size_t matched = 0;

        double similarity =
            BMSignatureSimilarityAt(
                signature,
                range.begin,
                &literals,
                &matched
            );

        if (
            literals < 24 ||
            similarity < 0.32
        )
        {
            continue;
        }

        V44PdataCallgraphCandidate c{};

        c.address =
            range.begin;

        c.functionBegin =
            range.begin;

        c.functionSize =
            range.size();

        c.depth =
            kv.second.minDepth == 99
                ? 0
                : kv.second.minDepth;

        c.pathVotes =
            kv.second.votes;

        c.tailVotes =
            kv.second.tailVotes;

        c.indirectVotes =
            kv.second.indirectVotes;

        c.directCallsites =
            V41CountDirectCallXrefs(
                range.begin
            );

        c.similarity =
            similarity;

        c.confidence =
            similarity;

        if (c.depth == 0)
        {
            c.confidence -= 0.14;
        }
        else
        {
            c.confidence +=
                c.depth == 1
                    ? 0.13
                    : 0.07;
        }

        c.confidence +=
            std::min<size_t>(
                c.pathVotes,
                4
            ) *
            0.02;

        if (c.tailVotes)
            c.confidence += 0.05;

        if (c.indirectVotes)
            c.confidence += 0.03;

        if (
            c.directCallsites >= 1 &&
            c.directCallsites <= 48
        )
        {
            c.confidence += 0.04;
        }
        else if (
            c.directCallsites > 128
        )
        {
            c.confidence -= 0.22;
        }
        else if (
            c.directCallsites > 64
        )
        {
            c.confidence -= 0.12;
        }

        if (
            c.functionSize >= 8 &&
            c.functionSize <= 0x900
        )
        {
            c.confidence += 0.03;
        }
        else if (
            c.functionSize > 0x2000
        )
        {
            c.confidence -= 0.10;
        }

        c.confidence =
            std::max(
                0.0,
                std::min(
                    0.99,
                    c.confidence
                )
            );

        out.push_back(
            c
        );
    }

    std::sort(
        out.begin(),
        out.end(),
        [](
            const V44PdataCallgraphCandidate& a,
            const V44PdataCallgraphCandidate& b)
        {
            if (
                a.confidence !=
                b.confidence
            )
            {
                return
                    a.confidence >
                    b.confidence;
            }

            if (
                a.similarity !=
                b.similarity
            )
            {
                return
                    a.similarity >
                    b.similarity;
            }

            if (
                a.depth !=
                b.depth
            )
            {
                return
                    a.depth >
                    b.depth;
            }

            return
                a.address <
                b.address;
        }
    );

    return out;
}

bool V44ResolveByPdataBoundedCallgraph(
    DbProfile& profile,
    const DbProfile& golden,
    const std::vector<BMFunctionSpec>& specs,
    size_t& resolved)
{
    bool changed = false;

    std::cout
        << "\n============================================================\n"
        << "             PDATA-BOUNDED LUA CALLGRAPH\n"
        << "============================================================\n"
        << "[MODE] READ-ONLY PE .pdata + branch graph\n"
        << "Function ranges come from x64 unwind metadata; fixed 0x300-byte windows are not used.\n";

    for (const auto& spec :
         specs)
    {
        const std::string& signature =
            golden.*(
                spec.sigField
            );

        if (signature.empty())
            continue;

        uintptr_t existingRva =
            profile.*(
                spec.rvaField
            );

        const std::string existingMethod =
            BMFunctionMethod(
                spec.name,
                profile
            );

        // Keep functions already resolved by stronger non-binding evidence.
        if (
            existingRva &&
            existingMethod !=
                "binding_wrapper_demoted_native_pending" &&
            existingMethod !=
                "lua_binding_string_anchor_fuzzy"
        )
        {
            continue;
        }

        auto candidates =
            V44CollectPdataBoundedCandidates(
                spec.name,
                signature
            );

        const double best =
            candidates.empty()
                ? 0.0
                : candidates[0].confidence;

        const double second =
            candidates.size() > 1
                ? candidates[1].confidence
                : 0.0;

        std::cout
            << spec.name
            << " : existing="
            << (
                existingRva
                    ? HexU64(
                        existingRva)
                    : std::string(
                        "pending")
            )
            << " candidates="
            << candidates.size()
            << " best="
            << std::fixed
            << std::setprecision(2)
            << best
            << " gap="
            << (
                best -
                second
            );

        if (candidates.empty())
        {
            std::cout
                << " -> PENDING\n";
            continue;
        }

        std::cout
            << "\n    [PDATA TOP CANDIDATES]\n";

        for (size_t candidateIndex = 0;
             candidateIndex < candidates.size() &&
             candidateIndex < 6;
             ++candidateIndex)
        {
            const auto& c =
                candidates[
                    candidateIndex
                ];

            std::cout
                << "      #"
                << candidateIndex
                << " rva="
                << HexU64(
                    c.address -
                    g_exeBase
                )
                << " conf="
                << std::fixed
                << std::setprecision(2)
                << c.confidence
                << " sim="
                << c.similarity
                << " depth="
                << c.depth
                << " size="
                << c.functionSize
                << " votes="
                << c.pathVotes
                << " tail="
                << c.tailVotes
                << " indirect="
                << c.indirectVotes
                << " callsites="
                << c.directCallsites
                << "\n";
        }

        const auto& winner =
            candidates[0];

        std::cout
            << " depth="
            << winner.depth
            << " sim="
            << winner.similarity
            << " size="
            << winner.functionSize
            << " votes="
            << winner.pathVotes
            << " tail="
            << winner.tailVotes
            << " indirect="
            << winner.indirectVotes
            << " callsites="
            << winner.directCallsites;

        const bool strong =
            winner.depth >= 1 &&
            winner.similarity >= 0.45 &&
            winner.confidence >= 0.74 &&
            (
                candidates.size() == 1 ||
                winner.confidence -
                    second >=
                    0.05
            );

        if (!strong)
        {
            std::cout
                << " -> NOT PROMOTED\n";
            continue;
        }

        uintptr_t rva =
            winner.address -
            g_exeBase;

        const bool wasEmpty =
            existingRva == 0;

        profile.*(
            spec.rvaField
        ) =
            rva;

        (
            profile.*(
                spec.sigField
            )
        ) =
            BMMakeMaskedSignature(
                winner.address,
                64
            );

        g_functionResolutionMethod[
            spec.name
        ] =
            "pdata_bounded_lua_callgraph_native";

        g_functionResolutionScore[
            spec.name
        ] =
            winner.confidence;

        if (wasEmpty)
            ++resolved;

        changed = true;

        std::cout
            << " -> RVA "
            << HexU64(
                rva
            )
            << " [PDATA CALLGRAPH NATIVE]\n";
    }

    return changed;
}


std::vector<uintptr_t>
V43CollectDirectCallTargets(
    uintptr_t begin,
    size_t length,
    size_t maxResults = 256)
{
    std::vector<uintptr_t> out;

    if (!begin ||
        begin < g_textBegin ||
        begin >= g_textEnd ||
        length < 5)
    {
        return out;
    }

    uintptr_t end =
        std::min<uintptr_t>(
            g_textEnd,
            begin +
            length
        );

    const uint8_t* bytes =
        reinterpret_cast<const uint8_t*>(
            begin
        );

    const size_t size =
        static_cast<size_t>(
            end -
            begin
        );

    for (size_t i = 0;
         i + 5 <= size;
         ++i)
    {
        if (bytes[i] != 0xE8)
            continue;

        int32_t rel = 0;

        std::memcpy(
            &rel,
            bytes + i + 1,
            sizeof(rel)
        );

        uintptr_t callAddress =
            begin +
            i;

        uintptr_t destination =
            callAddress +
            5 +
            static_cast<intptr_t>(
                rel
            );

        if (
            destination >= g_textBegin &&
            destination < g_textEnd
        )
        {
            out.push_back(
                destination
            );

            if (out.size() >=
                maxResults)
            {
                break;
            }
        }
    }

    std::sort(
        out.begin(),
        out.end()
    );

    out.erase(
        std::unique(
            out.begin(),
            out.end()
        ),
        out.end()
    );

    return out;
}

bool V43AddressIsDirectLuaBindingTarget(
    const std::string& semanticName,
    uintptr_t address)
{
    if (!address)
        return false;

    const std::string token =
        V42LuaBindingToken(
            semanticName
        );

    if (token.empty())
        return false;

    auto strings =
        V42FindModuleCStringOccurrences(
            token
        );

    for (uintptr_t str :
         strings)
    {
        auto xrefs =
            V42FindRipRefsToAddress(
                str
            );

        for (uintptr_t xref :
             xrefs)
        {
            auto targets =
                V42CollectNearbyLeaTextTargets(
                    xref,
                    0x220
                );

            if (std::find(
                    targets.begin(),
                    targets.end(),
                    address) !=
                targets.end())
            {
                return true;
            }
        }
    }

    return false;
}

struct V43LuaCallgraphCandidate
{
    uintptr_t address = 0;
    uintptr_t bindingSeed = 0;
    size_t depth = 0;
    size_t pathVotes = 0;
    size_t directCallsites = 0;
    double similarity = 0.0;
    double confidence = 0.0;
};

std::vector<V43LuaCallgraphCandidate>
V43CollectLuaCallgraphCandidates(
    const std::string& semanticName,
    const std::string& signature)
{
    std::vector<V43LuaCallgraphCandidate>
        out;

    const std::string token =
        V42LuaBindingToken(
            semanticName
        );

    if (token.empty() ||
        signature.empty())
    {
        return out;
    }

    auto strings =
        V42FindModuleCStringOccurrences(
            token
        );

    struct Vote
    {
        uintptr_t seed = 0;
        size_t minDepth = 99;
        size_t votes = 0;
    };

    std::map<uintptr_t, Vote>
        votes;

    for (uintptr_t str :
         strings)
    {
        auto xrefs =
            V42FindRipRefsToAddress(
                str
            );

        for (uintptr_t xref :
             xrefs)
        {
            // 1) Function pointers materialized around the Lua registration.
            auto bindingSeeds =
                V42CollectNearbyLeaTextTargets(
                    xref,
                    0x280
                );

            // 2) Calls made by the registration/wrapper region itself.
            uintptr_t xrefWindow =
                xref > 0x100
                    ? xref - 0x100
                    : g_textBegin;

            if (xrefWindow <
                g_textBegin)
            {
                xrefWindow =
                    g_textBegin;
            }

            auto registrationCalls =
                V43CollectDirectCallTargets(
                    xrefWindow,
                    0x300
                );

            for (uintptr_t callTarget :
                 registrationCalls)
            {
                Vote& v =
                    votes[
                        callTarget
                    ];

                v.seed =
                    xref;

                v.minDepth =
                    std::min<size_t>(
                        v.minDepth,
                        1
                    );

                ++v.votes;
            }

            for (uintptr_t seed :
                 bindingSeeds)
            {
                {
                    Vote& v =
                        votes[
                            seed
                        ];

                    v.seed =
                        seed;

                    v.minDepth =
                        std::min<size_t>(
                            v.minDepth,
                            0
                        );

                    ++v.votes;
                }

                // Lua binding targets are often wrappers/thunks. Follow
                // their direct calls instead of assuming the wrapper itself
                // is Game::attack/Game::talk/etc.
                auto depth1 =
                    V43CollectDirectCallTargets(
                        seed,
                        0x300
                    );

                for (uintptr_t d1 :
                     depth1)
                {
                    Vote& v1 =
                        votes[
                            d1
                        ];

                    v1.seed =
                        seed;

                    v1.minDepth =
                        std::min<size_t>(
                            v1.minDepth,
                            1
                        );

                    ++v1.votes;

                    // One extra hop is enough to traverse a small template
                    // thunk while remaining conservative.
                    auto depth2 =
                        V43CollectDirectCallTargets(
                            d1,
                            0x240
                        );

                    for (uintptr_t d2 :
                         depth2)
                    {
                        Vote& v2 =
                            votes[
                                d2
                            ];

                        v2.seed =
                            seed;

                        v2.minDepth =
                            std::min<size_t>(
                                v2.minDepth,
                                2
                            );

                        ++v2.votes;
                    }
                }
            }
        }
    }

    for (const auto& kv :
         votes)
    {
        size_t literals = 0;
        size_t matched = 0;

        double similarity =
            BMSignatureSimilarityAt(
                signature,
                kv.first,
                &literals,
                &matched
            );

        if (
            literals < 24 ||
            similarity < 0.35
        )
        {
            continue;
        }

        V43LuaCallgraphCandidate c{};
        c.address =
            kv.first;

        c.bindingSeed =
            kv.second.seed;

        c.depth =
            kv.second.minDepth == 99
                ? 0
                : kv.second.minDepth;

        c.pathVotes =
            kv.second.votes;

        c.directCallsites =
            V41CountDirectCallXrefs(
                kv.first
            );

        c.similarity =
            similarity;

        c.confidence =
            similarity;

        // Depth 0 is a binding target and may just be a Lua wrapper.
        if (c.depth == 0)
        {
            c.confidence -= 0.12;

            if (c.directCallsites == 0)
            {
                c.confidence -= 0.08;
            }
        }
        else
        {
            c.confidence +=
                c.depth == 1
                    ? 0.12
                    : 0.06;

            if (c.directCallsites)
            {
                c.confidence += 0.05;
            }
        }

        c.confidence +=
            std::min<size_t>(
                c.pathVotes,
                4
            ) *
            0.025;

        c.confidence =
            std::max(
                0.0,
                std::min(
                    0.99,
                    c.confidence
                )
            );

        out.push_back(
            c
        );
    }

    std::sort(
        out.begin(),
        out.end(),
        [](
            const V43LuaCallgraphCandidate& a,
            const V43LuaCallgraphCandidate& b)
        {
            if (a.confidence !=
                b.confidence)
            {
                return
                    a.confidence >
                    b.confidence;
            }

            if (a.depth !=
                b.depth)
            {
                return
                    a.depth >
                    b.depth;
            }

            if (a.pathVotes !=
                b.pathVotes)
            {
                return
                    a.pathVotes >
                    b.pathVotes;
            }

            return
                a.address <
                b.address;
        }
    );

    return out;
}

bool V43ResolveByLuaWrapperCallgraph(
    DbProfile& profile,
    const DbProfile& golden,
    const std::vector<BMFunctionSpec>& specs,
    size_t& resolved)
{
    bool addedAny = false;

    std::cout
        << "\n============================================================\n"
        << "           LUA WRAPPER -> NATIVE CALLGRAPH MIGRATION\n"
        << "============================================================\n"
        << "[MODE] READ-ONLY code/string/callgraph scan\n"
        << "Binding targets are treated as possible wrappers, not native functions.\n";

    for (const auto& spec :
         specs)
    {
        const std::string& signature =
            golden.*(
                spec.sigField
            );

        if (signature.empty())
            continue;

        uintptr_t existingRva =
            profile.*(
                spec.rvaField
            );

        uintptr_t existingAddress =
            existingRva
                ? g_exeBase +
                    existingRva
                : 0;

        // A prior V4.2 Lua binding target can be a wrapper. Re-evaluate it
        // when it is a direct binding target with no normal CALL xrefs.
        bool existingLooksLikeWrapper =
            existingAddress &&
            V43AddressIsDirectLuaBindingTarget(
                spec.name,
                existingAddress
            ) &&
            V41CountDirectCallXrefs(
                existingAddress
            ) == 0;

        if (
            existingRva &&
            !existingLooksLikeWrapper
        )
        {
            continue;
        }

        auto candidates =
            V43CollectLuaCallgraphCandidates(
                spec.name,
                signature
            );

        const double best =
            candidates.empty()
                ? 0.0
                : candidates[0].confidence;

        const double second =
            candidates.size() > 1
                ? candidates[1].confidence
                : 0.0;

        std::cout
            << spec.name
            << " : existing="
            << (
                existingRva
                    ? HexU64(
                        existingRva)
                    : std::string(
                        "pending")
            )
            << " wrapperLike="
            << (
                existingLooksLikeWrapper
                    ? "YES"
                    : "NO"
            )
            << " candidates="
            << candidates.size()
            << " best="
            << std::fixed
            << std::setprecision(2)
            << best
            << " gap="
            << (
                best -
                second
            );

        if (candidates.empty())
        {
            if (existingLooksLikeWrapper)
            {
                profile.*(
                    spec.rvaField
                ) =
                    0;

                (
                    profile.*(
                        spec.sigField
                    )
                ).clear();

                g_functionResolutionMethod[
                    spec.name
                ] =
                    "binding_wrapper_demoted_native_pending";

                g_functionResolutionScore[
                    spec.name
                ] =
                    0.0;

                std::cout
                    << " -> DEMOTED WRAPPER; NATIVE PENDING\n";
            }
            else
            {
                std::cout
                    << " -> PENDING\n";
            }

            continue;
        }

        const auto& winner =
            candidates[0];

        std::cout
            << " depth="
            << winner.depth
            << " sim="
            << winner.similarity
            << " votes="
            << winner.pathVotes
            << " callsites="
            << winner.directCallsites;

        // Native promotion requires a callgraph hop. Depth 0 remains a
        // binding-wrapper candidate even with good byte similarity.
        const bool strongNative =
            winner.depth >= 1 &&
            winner.confidence >= 0.78 &&
            (
                candidates.size() == 1 ||
                winner.confidence -
                    second >=
                    0.06
            ) &&
            winner.similarity >= 0.52;

        if (!strongNative)
        {
            if (existingLooksLikeWrapper)
            {
                profile.*(
                    spec.rvaField
                ) =
                    0;

                (
                    profile.*(
                        spec.sigField
                    )
                ).clear();

                g_functionResolutionMethod[
                    spec.name
                ] =
                    "binding_wrapper_demoted_native_pending";

                g_functionResolutionScore[
                    spec.name
                ] =
                    0.0;

                std::cout
                    << " -> DEMOTED WRAPPER; NO STRONG NATIVE\n";
            }
            else
            {
                std::cout
                    << " -> NOT PROMOTED\n";
            }

            continue;
        }

        uintptr_t newRva =
            winner.address -
            g_exeBase;

        const bool replacing =
            existingRva != 0 &&
            existingRva !=
                newRva;

        profile.*(
            spec.rvaField
        ) =
            newRva;

        profile.*(
            spec.sigField
        ) =
            BMMakeMaskedSignature(
                winner.address,
                64
            );

        g_functionResolutionMethod[
            spec.name
        ] =
            "lua_wrapper_callgraph_native";

        g_functionResolutionScore[
            spec.name
        ] =
            winner.confidence;

        if (!existingRva)
            ++resolved;

        addedAny = true;

        std::cout
            << " -> RVA "
            << HexU64(
                newRva
            )
            << (
                replacing
                    ? " [REPLACED BINDING WRAPPER]"
                    : " [CALLGRAPH NATIVE]"
            )
            << "\n";
    }

    return addedAny;
}


bool BMResolveByLuaBindingAnchors(
    DbProfile& profile,
    const DbProfile& golden,
    const std::vector<BMFunctionSpec>& specs,
    size_t& resolved)
{
    bool addedAny = false;

    std::set<uintptr_t>
        alreadyUsed;

    for (const auto& s :
         specs)
    {
        uintptr_t rva =
            profile.*(
                s.rvaField
            );

        if (rva)
        {
            alreadyUsed.insert(
                g_exeBase +
                rva
            );
        }
    }

    std::cout
        << "\n============================================================\n"
        << "          LUA BINDING STRING ANCHOR MIGRATION\n"
        << "============================================================\n"
        << "[MODE] READ-ONLY module/string/xref scan\n"
        << "Only unique semantic anchors with signature similarity are promoted.\n";

    for (const auto& spec :
         specs)
    {
        if (profile.*(
                spec.rvaField))
        {
            continue;
        }

        const std::string token =
            V42LuaBindingToken(
                spec.name
            );

        const std::string& signature =
            golden.*(
                spec.sigField
            );

        if (token.empty() ||
            signature.empty())
        {
            continue;
        }

        auto strings =
            V42FindModuleCStringOccurrences(
                token
            );

        std::map<uintptr_t, size_t>
            votes;

        size_t xrefCount = 0;

        for (uintptr_t str :
             strings)
        {
            auto xrefs =
                V42FindRipRefsToAddress(
                    str
                );

            xrefCount +=
                xrefs.size();

            for (uintptr_t xref :
                 xrefs)
            {
                auto candidates =
                    V42CollectNearbyLeaTextTargets(
                        xref
                    );

                for (uintptr_t candidate :
                     candidates)
                {
                    if (alreadyUsed.find(
                            candidate) !=
                        alreadyUsed.end())
                    {
                        continue;
                    }

                    ++votes[
                        candidate
                    ];
                }
            }
        }

        struct Candidate
        {
            uintptr_t address = 0;
            size_t votes = 0;
            double similarity = 0.0;
            double confidence = 0.0;
        };

        std::vector<Candidate>
            candidates;

        for (const auto& kv :
             votes)
        {
            size_t literals = 0;
            size_t matched = 0;

            double similarity =
                BMSignatureSimilarityAt(
                    signature,
                    kv.first,
                    &literals,
                    &matched
                );

            if (literals < 24 ||
                similarity < 0.40)
            {
                continue;
            }

            Candidate c{};
            c.address = kv.first;
            c.votes = kv.second;
            c.similarity = similarity;

            c.confidence =
                std::min(
                    0.99,
                    similarity +
                    std::min<size_t>(
                        kv.second,
                        4
                    ) *
                    0.05
                );

            candidates.push_back(
                c
            );
        }

        std::sort(
            candidates.begin(),
            candidates.end(),
            [](
                const Candidate& a,
                const Candidate& b)
            {
                if (a.confidence !=
                    b.confidence)
                {
                    return
                        a.confidence >
                        b.confidence;
                }

                if (a.votes !=
                    b.votes)
                {
                    return
                        a.votes >
                        b.votes;
                }

                return
                    a.address <
                    b.address;
            }
        );

        const double best =
            candidates.empty()
                ? 0.0
                : candidates[0].confidence;

        const double second =
            candidates.size() > 1
                ? candidates[1].confidence
                : 0.0;

        std::cout
            << spec.name
            << " : token=\""
            << token
            << "\" strings="
            << strings.size()
            << " xrefs="
            << xrefCount
            << " candidates="
            << candidates.size()
            << " best="
            << std::fixed
            << std::setprecision(2)
            << best
            << " gap="
            << (
                best -
                second
            );

        if (candidates.empty())
        {
            std::cout
                << " -> PENDING\n";
            continue;
        }

        const Candidate& winner =
            candidates[0];

        const bool strong =
            (
                winner.confidence >=
                    0.78 &&
                (
                    candidates.size() == 1 ||
                    winner.confidence -
                        second >=
                        0.06
                )
            ) ||
            (
                winner.similarity >=
                    0.68 &&
                winner.votes >= 2 &&
                (
                    candidates.size() == 1 ||
                    winner.confidence -
                        second >=
                        0.04
                )
            );

        if (!strong)
        {
            std::cout
                << " -> NOT PROMOTED\n";
            continue;
        }

        uintptr_t rva =
            winner.address -
            g_exeBase;

        profile.*(
            spec.rvaField
        ) =
            rva;

        profile.*(
            spec.sigField
        ) =
            BMMakeMaskedSignature(
                winner.address,
                64
            );

        g_functionResolutionMethod[
            spec.name
        ] =
            "lua_binding_string_anchor_fuzzy";

        g_functionResolutionScore[
            spec.name
        ] =
            winner.confidence;

        alreadyUsed.insert(
            winner.address
        );

        ++resolved;
        addedAny = true;

        std::cout
            << " -> RVA "
            << HexU64(
                rva
            )
            << " [LUA BIND ANCHOR]\n";
    }

    return addedAny;
}



struct V45ClusterCandidate
{
    const BMFunctionSpec* spec = nullptr;
    uintptr_t targetRva = 0;
    uintptr_t goldenRva = 0;
    long long delta = 0;
    double similarity = 0.0;
    double localConfidence = 0.0;
    size_t depth = 0;
    size_t callsites = 0;
};

bool V45IsGameClusterFunction(
    const std::string& name)
{
    return
        name == "Game::autoWalk" ||
        name == "Game::attack" ||
        name == "Game::follow" ||
        name == "Game::look" ||
        name == "Game::detailedLook" ||
        name == "Game::move" ||
        name == "Game::use" ||
        name == "Game::useWith" ||
        name == "Game::talk";
}

bool V45ResolveGameClusterConsensus(
    DbProfile& profile,
    const DbProfile& golden,
    const std::vector<BMFunctionSpec>& specs,
    size_t& resolved)
{
    std::vector<V45ClusterCandidate>
        all;

    std::map<
        std::string,
        std::vector<V45ClusterCandidate>>
        byFunction;

    for (const auto& spec :
         specs)
    {
        if (!V45IsGameClusterFunction(
                spec.name))
        {
            continue;
        }

        uintptr_t goldenRva =
            golden.*(
                spec.rvaField
            );

        const std::string& signature =
            golden.*(
                spec.sigField
            );

        if (
            !goldenRva ||
            signature.empty()
        )
        {
            continue;
        }

        uintptr_t existingRva =
            profile.*(
                spec.rvaField
            );

        const std::string method =
            BMFunctionMethod(
                spec.name,
                profile
            );

        // Keep addresses learned through stronger native evidence.
        if (
            existingRva &&
            method !=
                "binding_wrapper_demoted_native_pending" &&
            method !=
                "lua_binding_string_anchor_fuzzy"
        )
        {
            continue;
        }

        auto candidates =
            V44CollectPdataBoundedCandidates(
                spec.name,
                signature
            );

        size_t acceptedForFunction = 0;

        for (const auto& c :
             candidates)
        {
            // Depth 0 remains a binding/wrapper candidate, not native.
            if (c.depth < 1)
                continue;

            // Extremely common helpers are poor semantic anchors.
            if (c.directCallsites > 128)
                continue;

            if (c.similarity < 0.30)
                continue;

            V45ClusterCandidate cc{};
            cc.spec =
                &spec;

            cc.targetRva =
                c.address -
                g_exeBase;

            cc.goldenRva =
                goldenRva;

            cc.delta =
                static_cast<long long>(
                    cc.targetRva) -
                static_cast<long long>(
                    cc.goldenRva);

            cc.similarity =
                c.similarity;

            cc.localConfidence =
                c.confidence;

            cc.depth =
                c.depth;

            cc.callsites =
                c.directCallsites;

            all.push_back(
                cc
            );

            byFunction[
                spec.name
            ].push_back(
                cc
            );

            ++acceptedForFunction;

            // A small candidate list is enough for relative-layout voting.
            if (acceptedForFunction >= 8)
                break;
        }
    }

    if (all.size() < 3)
        return false;

    struct Hypothesis
    {
        long long centerDelta = 0;
        size_t support = 0;
        long long maxError = 0;
        long long totalError = 0;
        double averageSimilarity = 0.0;
        std::map<std::string, V45ClusterCandidate>
            selected;
    };

    Hypothesis best{};

    // Same-source OTClient families often preserve Game method ordering and
    // relative spacing even when the whole cluster moves.  Test every
    // candidate delta as a possible translation and require convergence
    // across several DISTINCT semantic methods.
    for (const auto& seed :
         all)
    {
        Hypothesis h{};
        h.centerDelta =
            seed.delta;

        for (auto& kv :
             byFunction)
        {
            const auto& functionCandidates =
                kv.second;

            bool found = false;
            V45ClusterCandidate selected{};
            long long selectedError =
                0x7FFFFFFFFFFFFFFFLL;

            for (const auto& c :
                 functionCandidates)
            {
                long long error =
                    std::llabs(
                        c.delta -
                        h.centerDelta
                    );

                // Tolerate small local code-size drift while still demanding
                // a coherent cluster translation.
                if (error > 0x100)
                    continue;

                if (
                    !found ||
                    error <
                        selectedError ||
                    (
                        error ==
                            selectedError &&
                        c.localConfidence >
                            selected.localConfidence
                    )
                )
                {
                    found = true;
                    selected = c;
                    selectedError =
                        error;
                }
            }

            if (!found)
                continue;

            h.selected[
                kv.first
            ] =
                selected;

            ++h.support;

            h.maxError =
                std::max<long long>(
                    h.maxError,
                    selectedError
                );

            h.totalError +=
                selectedError;

            h.averageSimilarity +=
                selected.similarity;
        }

        if (h.support)
        {
            h.averageSimilarity /=
                static_cast<double>(
                    h.support
                );
        }

        bool better =
            h.support >
                best.support ||
            (
                h.support ==
                    best.support &&
                h.maxError <
                    best.maxError
            ) ||
            (
                h.support ==
                    best.support &&
                h.maxError ==
                    best.maxError &&
                h.totalError <
                    best.totalError
            ) ||
            (
                h.support ==
                    best.support &&
                h.maxError ==
                    best.maxError &&
                h.totalError ==
                    best.totalError &&
                h.averageSimilarity >
                    best.averageSimilarity
            );

        if (better)
        {
            best =
                h;
        }
    }

    std::cout
        << "\n============================================================\n"
        << "             GOLDEN GAME CLUSTER CONSENSUS\n"
        << "============================================================\n"
        << "[MODE] READ-ONLY relative-layout evidence\n"
        << "Support       : "
        << best.support
        << "\n"
        << "Center delta  : "
        << (
            best.centerDelta >= 0
                ? "+"
                : "-"
        )
        << HexU64(
            static_cast<uintptr_t>(
                std::llabs(
                    best.centerDelta
                )
            )
        )
        << "\n"
        << "Max drift     : "
        << HexU64(
            static_cast<uintptr_t>(
                best.maxError
            )
        )
        << "\n"
        << "Total drift   : "
        << HexU64(
            static_cast<uintptr_t>(
                best.totalError
            )
        )
        << "\n"
        << "Avg similarity: "
        << std::fixed
        << std::setprecision(2)
        << best.averageSimilarity
        << "\n";

    for (const auto& kv :
         best.selected)
    {
        const auto& c =
            kv.second;

        long long error =
            std::llabs(
                c.delta -
                best.centerDelta
            );

        std::cout
            << "  "
            << kv.first
            << " golden="
            << HexU64(
                c.goldenRva
            )
            << " target="
            << HexU64(
                c.targetRva
            )
            << " delta="
            << (
                c.delta >= 0
                    ? "+"
                    : "-"
            )
            << HexU64(
                static_cast<uintptr_t>(
                    std::llabs(
                        c.delta
                    )
                )
            )
            << " drift="
            << HexU64(
                static_cast<uintptr_t>(
                    error
                )
            )
            << " sim="
            << c.similarity
            << " depth="
            << c.depth
            << " callsites="
            << c.callsites
            << "\n";
    }

    // Two promotion modes:
    //  A) 4+ distinct methods with <=0x80 drift.
    //  B) 3+ methods with extremely tight <=0x20 drift.
    const bool strongCluster =
        (
            best.support >= 4 &&
            best.maxError <= 0x80 &&
            best.averageSimilarity >= 0.36
        ) ||
        (
            best.support >= 3 &&
            best.maxError <= 0x20 &&
            best.averageSimilarity >= 0.34
        );

    if (!strongCluster)
    {
        std::cout
            << "[CLUSTER] Evidence insuficiente; nenhuma RVA promovida.\n";

        return false;
    }

    size_t promoted = 0;

    for (const auto& kv :
         best.selected)
    {
        const auto& c =
            kv.second;

        long long error =
            std::llabs(
                c.delta -
                best.centerDelta
            );

        if (error >
            (
                best.support >= 4
                    ? 0x80
                    : 0x20
            ))
        {
            continue;
        }

        uintptr_t& current =
            profile.*(
                c.spec->rvaField
            );

        const std::string currentMethod =
            BMFunctionMethod(
                c.spec->name,
                profile
            );

        if (
            current &&
            currentMethod !=
                "binding_wrapper_demoted_native_pending" &&
            currentMethod !=
                "lua_binding_string_anchor_fuzzy"
        )
        {
            continue;
        }

        const bool wasEmpty =
            current == 0;

        current =
            c.targetRva;

        (
            profile.*(
                c.spec->sigField
            )
        ) =
            BMMakeMaskedSignature(
                g_exeBase +
                    c.targetRva,
                64
            );

        double relationStrength =
            1.0 -
            std::min<double>(
                1.0,
                static_cast<double>(
                    error
                ) /
                256.0
            );

        double confidence =
            0.58 +
            std::min<size_t>(
                best.support,
                6
            ) *
            0.055 +
            c.similarity *
            0.12 +
            relationStrength *
            0.08;

        confidence =
            std::min(
                0.97,
                confidence
            );

        g_functionResolutionMethod[
            c.spec->name
        ] =
            "golden_game_cluster_delta_consensus";

        g_functionResolutionScore[
            c.spec->name
        ] =
            confidence;

        if (wasEmpty)
            ++resolved;

        ++promoted;

        std::cout
            << "[CLUSTER PROMOTE] "
            << c.spec->name
            << " -> "
            << HexU64(
                c.targetRva
            )
            << " confidence="
            << std::fixed
            << std::setprecision(2)
            << confidence
            << "\n";
    }

    std::cout
        << "[CLUSTER] Promoted "
        << promoted
        << " function(s).\n";

    return
        promoted != 0;
}



// ============================================================
// BUILDMIGRATOR V4.9 - OTC-STYLE DIRECT LUA BIND RESOLVER
//
// Ported strategy (not offsets): resolve the client from its own Lua
// registration metadata. The external otc-api profile is NOT consulted here.
//
// Evidence chain:
//   exact C-string token -> RIP-relative xref -> nearby RIP materialized
//   object/function pointer -> exact x64 .pdata function boundary.
//
// Sibling filters mirror the working otc-api resolver strategy:
//   attack != cancelAttack
//   follow != cancelFollow
//   move != moveRaw / moveToParentContainer
//   use != useWith
//   autoWalk separates Game::autoWalk from LocalPlayer::autoWalk by g_game.
// ============================================================

struct V49RipTarget
{
    uintptr_t instruction = 0;
    uintptr_t target = 0;
    uint8_t opcode = 0;
};

struct V49BindHit
{
    uintptr_t fn = 0;
    uintptr_t object = 0;
    uintptr_t xref = 0;
    size_t fnDist = std::numeric_limits<size_t>::max();
    size_t objectDist = std::numeric_limits<size_t>::max();
    bool sawObjectHint = false;
};

struct V49DirectState
{
    uintptr_t gameObjectBaseRva = 0;
    uintptr_t talkChannelRva = 0;
    uintptr_t topUseThingRva = 0;
    uintptr_t mapObjectRva = 0;
};

V49DirectState g_v49DirectState;

const ModuleSection* V49SectionForAddress(
    const std::vector<ModuleSection>& sections,
    uintptr_t address)
{
    for (const auto& s : sections)
    {
        if (address >= s.begin && address < s.end)
            return &s;
    }
    return nullptr;
}

bool V49IsWritableModuleAddress(
    const std::vector<ModuleSection>& sections,
    uintptr_t address)
{
    const ModuleSection* s =
        V49SectionForAddress(sections, address);

    return s && s->readable() && s->writable() && !s->executable();
}

uintptr_t V49CanonicalFunctionStart(uintptr_t address)
{
    V44FunctionRange range{};
    if (!V44GetFunctionRange(address, range))
        return 0;
    return range.begin;
}

std::vector<V49RipTarget> V49CollectNearbyRipTargets(
    uintptr_t center,
    size_t before = 0x10,
    size_t after = 0x60)
{
    std::vector<V49RipTarget> out;

    if (!center || !g_textBegin || !g_textEnd)
        return out;

    uintptr_t begin = center > before ? center - before : g_textBegin;
    if (begin < g_textBegin)
        begin = g_textBegin;

    uintptr_t end = std::min<uintptr_t>(g_textEnd, center + after);
    if (end <= begin || end - begin < 7)
        return out;

    const uint8_t* bytes = reinterpret_cast<const uint8_t*>(begin);
    const size_t size = static_cast<size_t>(end - begin);

    for (size_t i = 0; i + 7 <= size; ++i)
    {
        const uint8_t rex = bytes[i];
        if (rex != 0x48 && rex != 0x4C)
            continue;

        const uint8_t opcode = bytes[i + 1];
        if (opcode != 0x8D)
            continue;

        const uint8_t modrm = bytes[i + 2];
        if ((modrm & 0xC7) != 0x05)
            continue;

        int32_t disp = 0;
        std::memcpy(&disp, bytes + i + 3, sizeof(disp));

        const uintptr_t instruction = begin + i;
        const uintptr_t target =
            instruction + 7 + static_cast<intptr_t>(disp);

        if (target < g_exeBase || target >= g_imageEnd)
            continue;

        out.push_back({instruction, target, opcode});
    }

    std::sort(out.begin(), out.end(), [](const V49RipTarget& a, const V49RipTarget& b)
    {
        if (a.instruction != b.instruction)
            return a.instruction < b.instruction;
        return a.target < b.target;
    });

    out.erase(std::unique(out.begin(), out.end(), [](const V49RipTarget& a, const V49RipTarget& b)
    {
        return a.instruction == b.instruction && a.target == b.target;
    }), out.end());

    return out;
}

std::vector<uintptr_t> V49FindRipLeaRefsToAddress(
    uintptr_t target,
    size_t maxResults = 256)
{
    std::vector<uintptr_t> out;
    if (!target || !g_textBegin || !g_textEnd || g_textEnd <= g_textBegin)
        return out;

    const auto* bytes = reinterpret_cast<const uint8_t*>(g_textBegin);
    const size_t len = static_cast<size_t>(g_textEnd - g_textBegin);

    for (size_t i = 0; i + 7 <= len && out.size() < maxResults; ++i)
    {
        const uint8_t rex = bytes[i];
        const uint8_t op = bytes[i + 1];
        const uint8_t modrm = bytes[i + 2];
        if ((rex != 0x48 && rex != 0x4C) || op != 0x8D || (modrm & 0xC7) != 0x05)
            continue;

        int32_t disp = 0;
        std::memcpy(&disp, bytes + i + 3, sizeof(disp));
        const uintptr_t p = g_textBegin + i;
        if (p + 7 + static_cast<intptr_t>(disp) == target)
            out.push_back(p);
    }

    return out;
}

std::vector<V49BindHit> V49CollectBinds(
    const std::string& token,
    uintptr_t objectHint = 0)
{
    std::vector<V49BindHit> out;
    if (token.empty())
        return out;

    const auto sections = GetModuleSections();
    const auto strings = V42FindModuleCStringOccurrences(token, 64);

    for (uintptr_t str : strings)
    {
        const auto xrefs = V49FindRipLeaRefsToAddress(str, 256);

        for (uintptr_t xref : xrefs)
        {
            V49BindHit hit{};
            hit.xref = xref;

            const auto targets = V49CollectNearbyRipTargets(xref);

            for (const auto& t : targets)
            {
                if (objectHint && t.target == objectHint)
                    hit.sawObjectHint = true;

                const size_t d =
                    t.instruction >= xref
                        ? static_cast<size_t>(t.instruction - xref)
                        : static_cast<size_t>(xref - t.instruction) + 0x1000;

                const uintptr_t fn = V49CanonicalFunctionStart(t.target);
                if (fn && t.instruction >= xref && d < hit.fnDist)
                {
                    hit.fnDist = d;
                    hit.fn = fn;
                }

                if (V49IsWritableModuleAddress(sections, t.target) &&
                    d < hit.objectDist)
                {
                    hit.objectDist = d;
                    hit.object = t.target;
                }
            }

            if (hit.fn)
                out.push_back(hit);
        }
    }

    return out;
}

uintptr_t V49FirstFunctionForToken(
    const std::string& token,
    uintptr_t objectHint,
    const std::set<uintptr_t>& reject,
    int* outScore = nullptr,
    uintptr_t* outXref = nullptr)
{
    const auto hits = V49CollectBinds(token, objectHint);
    uintptr_t best = 0;
    uintptr_t bestXref = 0;
    int bestScore = std::numeric_limits<int>::min();

    for (const auto& h : hits)
    {
        if (!h.fn || reject.count(h.fn))
            continue;

        int score = 2;
        if (h.fnDist < 80)
            score += 4;
        if (objectHint && (h.sawObjectHint || h.object == objectHint))
            score += 8;
        if (h.fnDist < 32)
            score += 2;

        if (score > bestScore)
        {
            bestScore = score;
            best = h.fn;
            bestXref = h.xref;
        }
    }

    if (outScore)
        *outScore = best ? bestScore : 0;
    if (outXref)
        *outXref = bestXref;
    return best;
}

const BMFunctionSpec* V49FindSpecByName(
    const std::vector<BMFunctionSpec>& specs,
    const char* name)
{
    if (!name)
        return nullptr;
    for (const auto& spec : specs)
        if (std::string(spec.name) == name)
            return &spec;
    return nullptr;
}

bool V49Promote(
    DbProfile& profile,
    const std::vector<BMFunctionSpec>& specs,
    const char* semanticName,
    uintptr_t address,
    const char* method,
    double confidence)
{
    if (!semanticName || !address)
        return false;

    V44FunctionRange range{};
    if (!V44GetFunctionRange(address, range) || range.begin != address)
        return false;

    const BMFunctionSpec* spec = V49FindSpecByName(specs, semanticName);
    if (!spec)
        return false;

    const uintptr_t rva = address - g_exeBase;
    const uintptr_t previous = profile.*(spec->rvaField);

    profile.*(spec->rvaField) = rva;
    profile.*(spec->sigField) = BMMakeMaskedSignature(address, 64);

    g_functionResolutionMethod[semanticName] = method ? method : "otc_style_direct_bind";
    g_functionResolutionScore[semanticName] = confidence;

    std::cout
        << semanticName
        << " : RVA "
        << HexU64(rva)
        << " [OTC-STYLE DIRECT BIND]"
        << (previous && previous != rva ? " [REPLACED WEAKER CANDIDATE]" : "")
        << " confidence="
        << std::fixed << std::setprecision(2) << confidence
        << "\n";

    return previous != rva;
}

bool V49DiscoverTalkAndGame(
    const DbProfile& profile,
    uintptr_t& gameBase,
    uintptr_t& talkChannel)
{
    gameBase = 0;
    talkChannel = 0;

    const auto hits = V49CollectBinds("talkChannel", 0);
    if (hits.empty())
        return false;

    const auto sections = GetModuleSections();
    const uintptr_t learnedAnchor =
        profile.gameRva ? g_exeBase + profile.gameRva : 0;

    int bestScore = std::numeric_limits<int>::min();

    for (const auto& h : hits)
    {
        if (!h.fn)
            continue;

        int score = 4;
        if (h.fnDist < 80)
            score += 4;
        if (h.object && V49IsWritableModuleAddress(sections, h.object))
            score += 6;

        if (learnedAnchor && h.object)
        {
            const uintptr_t delta =
                learnedAnchor > h.object
                    ? learnedAnchor - h.object
                    : h.object - learnedAnchor;

            if (delta <= 0x40)
                score += 14;
            if (h.object <= learnedAnchor && learnedAnchor - h.object <= 0x40)
                score += 4;
        }

        if (score > bestScore)
        {
            bestScore = score;
            talkChannel = h.fn;
            gameBase = h.object;
        }
    }

    if (!talkChannel || !gameBase)
        return false;

    g_v49DirectState.gameObjectBaseRva = gameBase - g_exeBase;
    g_v49DirectState.talkChannelRva = talkChannel - g_exeBase;

    std::cout
        << "Game object base : " << HexU64(g_v49DirectState.gameObjectBaseRva)
        << " [talkChannel bind]\n"
        << "Game::talkChannel: " << HexU64(g_v49DirectState.talkChannelRva)
        << " [DIRECT LUA BIND]\n";

    if (learnedAnchor)
    {
        const intptr_t delta =
            static_cast<intptr_t>(learnedAnchor) - static_cast<intptr_t>(gameBase);
        std::cout
            << "OTCLab learned Game/LP anchor delta from object base: "
            << (delta >= 0 ? "+" : "-")
            << HexU64(static_cast<uintptr_t>(delta >= 0 ? delta : -delta))
            << "\n";
    }

    return true;
}

bool V49ResolveOtcStyleDirectBindings(
    DbProfile& profile,
    const std::vector<BMFunctionSpec>& specs)
{
    std::cout
        << "\n============================================================\n"
        << "          V4.9 OTC-STYLE DIRECT LUA BIND RESOLVER\n"
        << "============================================================\n"
        << "[MODE] READ-ONLY / NO EXTERNAL RVA ORACLE\n"
        << "[METHOD] token -> RIP xref -> nearby function/object -> .pdata start\n";

    bool changed = false;
    uintptr_t gameBase = 0;
    uintptr_t talkChannel = 0;

    V49DiscoverTalkAndGame(profile, gameBase, talkChannel);

    if (!gameBase)
    {
        // Conservative fallback: use the previously learned Game anchor only as
        // a neighborhood hint. Never hardcode the known -8 relationship.
        if (profile.gameRva)
        {
            const uintptr_t anchor = g_exeBase + profile.gameRva;
            const auto hits = V49CollectBinds("attack", 0);
            int bestScore = std::numeric_limits<int>::min();
            for (const auto& h : hits)
            {
                if (!h.object)
                    continue;
                const uintptr_t delta =
                    anchor > h.object ? anchor - h.object : h.object - anchor;
                if (delta > 0x80)
                    continue;
                const int score = static_cast<int>(0x80 - delta);
                if (score > bestScore)
                {
                    bestScore = score;
                    gameBase = h.object;
                }
            }
        }
    }

    if (!gameBase)
    {
        std::cout << "[V4.9] g_game nao foi fechado pelos binds; Game methods ficam pendentes.\n";
    }
    else
    {
        // autoWalk: same token registers Game::autoWalk and LocalPlayer::autoWalk.
        const auto autoHits = V49CollectBinds("autoWalk", gameBase);
        uintptr_t gameAuto = 0;
        uintptr_t localAuto = 0;
        size_t localDist = std::numeric_limits<size_t>::max();
        size_t gameDist = std::numeric_limits<size_t>::max();

        for (const auto& h : autoHits)
        {
            if (!h.fn)
                continue;
            const bool gameBound = h.sawObjectHint || h.object == gameBase;
            if (gameBound)
            {
                if (h.fnDist < gameDist)
                {
                    gameDist = h.fnDist;
                    gameAuto = h.fn;
                }
            }
            else if (h.fnDist < localDist)
            {
                localDist = h.fnDist;
                localAuto = h.fn;
            }
        }

        if (gameAuto)
            changed |= V49Promote(profile, specs, "Game::autoWalk", gameAuto,
                                  "otc_style_direct_bind_game_object", 0.98);
        if (localAuto && localAuto != gameAuto)
            changed |= V49Promote(profile, specs, "LocalPlayer::autoWalk", localAuto,
                                  "otc_style_direct_bind_localplayer", 1.00);

        // attack != cancelAttack
        const uintptr_t cancelAttack =
            V49FirstFunctionForToken("cancelAttack", gameBase, {});
        const uintptr_t attack =
            V49FirstFunctionForToken("attack", gameBase, {cancelAttack});
        if (attack)
            changed |= V49Promote(profile, specs, "Game::attack", attack,
                                  "otc_style_direct_bind_sibling_filtered", 0.98);

        // follow != cancelFollow
        const uintptr_t cancelFollow =
            V49FirstFunctionForToken("cancelFollow", gameBase, {});
        const uintptr_t follow =
            V49FirstFunctionForToken("follow", gameBase, {cancelFollow});
        if (follow)
            changed |= V49Promote(profile, specs, "Game::follow", follow,
                                  "otc_style_direct_bind_sibling_filtered", 0.98);

        const uintptr_t look =
            V49FirstFunctionForToken("look", gameBase, {});
        if (look)
            changed |= V49Promote(profile, specs, "Game::look", look,
                                  "otc_style_direct_bind", 0.98);

        const uintptr_t detailedLook =
            V49FirstFunctionForToken("detailedLook", gameBase, {});
        if (detailedLook)
            changed |= V49Promote(profile, specs, "Game::detailedLook", detailedLook,
                                  "otc_style_direct_bind", 0.96);

        // move != moveRaw / moveToParentContainer
        const uintptr_t moveRaw =
            V49FirstFunctionForToken("moveRaw", gameBase, {});
        const uintptr_t moveParent =
            V49FirstFunctionForToken("moveToParentContainer", gameBase, {});
        const uintptr_t move =
            V49FirstFunctionForToken("move", gameBase, {moveRaw, moveParent});
        if (move)
            changed |= V49Promote(profile, specs, "Game::move", move,
                                  "otc_style_direct_bind_sibling_filtered", 0.98);

        // useWith first; plain use cannot alias it.
        uintptr_t useWithXref = 0;
        const uintptr_t useWith =
            V49FirstFunctionForToken("useWith", gameBase, {}, nullptr, &useWithXref);
        if (useWith)
            changed |= V49Promote(profile, specs, "Game::useWith", useWith,
                                  "otc_style_direct_bind", 0.98);

        const auto useHits = V49CollectBinds("use", gameBase);
        uintptr_t bestUse = 0;
        int bestUseScore = std::numeric_limits<int>::min();
        for (const auto& h : useHits)
        {
            if (!h.fn || (useWith && h.fn == useWith))
                continue;

            int score = 2;
            if (h.fnDist < 80)
                score += 4;
            if (h.sawObjectHint || h.object == gameBase)
                score += 8;

            if (useWithXref)
            {
                const uintptr_t d =
                    h.xref > useWithXref ? h.xref - useWithXref : useWithXref - h.xref;
                if (d < 64) score += 20;
                else if (d < 256) score += 12;
                else if (d < 1024) score += 4;
            }

            if (score > bestUseScore)
            {
                bestUseScore = score;
                bestUse = h.fn;
            }
        }

        if (bestUse)
            changed |= V49Promote(profile, specs, "Game::use", bestUse,
                                  "otc_style_direct_bind_use_pair", 0.98);
    }

    // Map bindings are independent of g_game.
    const uintptr_t mapHint =
        profile.mapRva ? g_exeBase + profile.mapRva : 0;

    const auto tileHits = V49CollectBinds("getTile", mapHint);
    uintptr_t getTile = 0;
    uintptr_t mapObject = 0;
    int tileScore = std::numeric_limits<int>::min();

    for (const auto& h : tileHits)
    {
        if (!h.fn)
            continue;
        int score = 1;
        if (h.fnDist < 80)
            score += 4;
        if (mapHint && (h.sawObjectHint || h.object == mapHint))
            score += 12;
        else if (h.object)
            score += 3;

        if (score > tileScore)
        {
            tileScore = score;
            getTile = h.fn;
            mapObject = h.object;
        }
    }

    if (getTile)
        changed |= V49Promote(profile, specs, "Map::getTile", getTile,
                              "otc_style_direct_bind_map", 1.00);

    if (mapObject)
        g_v49DirectState.mapObjectRva = mapObject - g_exeBase;

    const uintptr_t effectiveMap = mapObject ? mapObject : mapHint;

    const uintptr_t getCreatureById =
        V49FirstFunctionForToken("getCreatureById", effectiveMap, {});
    if (getCreatureById)
        changed |= V49Promote(profile, specs, "Map::getCreatureById", getCreatureById,
                              "otc_style_direct_bind_map", 0.98);

    const uintptr_t getCreatureByName =
        V49FirstFunctionForToken("getCreatureByName", effectiveMap, {});
    if (getCreatureByName)
        changed |= V49Promote(profile, specs, "Map::getCreatureByName", getCreatureByName,
                              "otc_style_direct_bind_map", 0.98);

    const uintptr_t topUse =
        V49FirstFunctionForToken("getTopUseThing", 0, {});
    if (topUse)
    {
        g_v49DirectState.topUseThingRva = topUse - g_exeBase;
        std::cout << "Tile::getTopUseThing : "
                  << HexU64(g_v49DirectState.topUseThingRva)
                  << " [DIRECT LUA BIND / diagnostic]\n";
    }

    // Container::getItem: only promote if the exact token converges to one
    // canonical function start; there is no stable container object singleton.
    const auto getItemHits = V49CollectBinds("getItem", 0);
    std::set<uintptr_t> uniqueGetItem;
    for (const auto& h : getItemHits)
        if (h.fn) uniqueGetItem.insert(h.fn);
    if (uniqueGetItem.size() == 1)
        changed |= V49Promote(profile, specs, "Container::getItem", *uniqueGetItem.begin(),
                              "otc_style_direct_bind_unique_token", 0.95);

    std::cout
        << "\n[V4.9 DIRECT STATE]\n"
        << "  Game object base : " << HexU64(g_v49DirectState.gameObjectBaseRva) << "\n"
        << "  talkChannel      : " << HexU64(g_v49DirectState.talkChannelRva) << "\n"
        << "  Map object       : " << HexU64(g_v49DirectState.mapObjectRva) << "\n"
        << "  getTopUseThing   : " << HexU64(g_v49DirectState.topUseThingRva) << "\n";

    return changed;
}

bool V49CoreActionSetReady(const DbProfile& p)
{
    return
        g_v49DirectState.gameObjectBaseRva != 0 &&
        g_v49DirectState.talkChannelRva != 0 &&
        p.fnLocalPlayerAutoWalk != 0 &&
        p.fnGameAttack != 0 &&
        p.fnGameLook != 0 &&
        p.fnGameMove != 0 &&
        p.fnGameUse != 0 &&
        p.fnGameUseWith != 0 &&
        p.fnMapGetTile != 0;
}


bool BMResolveFunctionsFromGolden(
    DbProfile& profile,
    const DbProfile& golden)
{
    auto specs =
        BMFunctionSpecs();

    size_t resolved = 0;

    std::cout
        << "\n============================================================\n"
        << "             STATIC FUNCTION MIGRATION\n"
        << "============================================================\n"
        << "[MODE] READ-ONLY .text signature scan\n";

    for (const auto& spec :
         specs)
    {
        const std::string& signature =
            golden.*(
                spec.sigField
            );

        if (signature.empty())
        {
            std::cout
                << spec.name
                << " : NO REFERENCE SIGNATURE\n";

            continue;
        }

        size_t matches = 0;

        uintptr_t address =
            BMScanUniqueSignature(
                signature,
                &matches
            );

        if (!address)
        {
            double bestFuzzy = 0.0;
            double secondFuzzy = 0.0;
            size_t fuzzyCandidates = 0;

            uintptr_t fuzzyAddress =
                BMScanAnchoredFuzzySignature(
                    signature,
                    &bestFuzzy,
                    &secondFuzzy,
                    &fuzzyCandidates
                );

            if (!fuzzyAddress)
            {
                std::cout
                    << spec.name
                    << " : CHECK matches="
                    << matches
                    << " fuzzy="
                    << std::fixed
                    << std::setprecision(2)
                    << bestFuzzy
                    << " gap="
                    << (
                        bestFuzzy -
                        secondFuzzy
                    )
                    << " candidates="
                    << fuzzyCandidates
                    << "\n";

                continue;
            }

            address =
                fuzzyAddress;

            g_functionResolutionMethod[
                spec.name
            ] = "global_anchor_fuzzy";

            g_functionResolutionScore[
                spec.name
            ] = bestFuzzy;

            std::cout
                << spec.name
                << " : FUZZY UNIQUE score="
                << std::fixed
                << std::setprecision(2)
                << bestFuzzy
                << " gap="
                << (
                    bestFuzzy -
                    secondFuzzy
                )
                << "\n";
        }

        uintptr_t rva =
            address -
            g_exeBase;

        profile.*(
            spec.rvaField
        ) =
            rva;

        profile.*(
            spec.sigField
        ) =
            BMMakeMaskedSignature(
                address,
                64
            );

        ++resolved;

        if (
            g_functionResolutionMethod.find(
                spec.name) ==
            g_functionResolutionMethod.end()
        )
        {
            g_functionResolutionMethod[
                spec.name
            ] = "unique_masked_signature";

            g_functionResolutionScore[
                spec.name
            ] = 1.0;
        }

        std::cout
            << spec.name
            << " : RVA "
            << HexU64(
                rva
            )
            << " [UNIQUE SIGNATURE]\n";
    }

    // If one Game::* signature drifted but its sibling functions moved
    // together, use the dominant family delta plus a narrow fuzzy check.
    BMResolveByFamilyDeltaFuzzy(
        profile,
        golden,
        specs,
        resolved
    );

    // V4.2 semantic fallback:
    // Lua binding names such as "attack", "useWith" and "getTile" are
    // stable source-level anchors in OTClient families. We resolve only
    // when the nearby function-pointer candidate also resembles the
    // golden masked function signature.
    BMResolveByLuaBindingAnchors(
        profile,
        golden,
        specs,
        resolved
    );

    // V4.3 correction:
    // a Lua registration target can be a wrapper/thunk rather than the
    // native Game/Map/Container method. Follow direct CALL edges from the
    // binding target and only promote a deeper target when it also matches
    // the golden native signature. Previous wrapper-like addresses with zero
    // normal callsites are demoted if no native child is proven.
    V43ResolveByLuaWrapperCallgraph(
        profile,
        golden,
        specs,
        resolved
    );

    // V4.4: use the PE x64 exception table (.pdata) to obtain exact
    // function boundaries, then follow direct/tail/indirect branch edges
    // only inside those functions. This removes the common-helper noise
    // observed with fixed-size wrapper windows.
    V44ResolveByPdataBoundedCallgraph(
        profile,
        golden,
        specs,
        resolved
    );

    // V4.5: correlate several Game methods against the Golden build at once.
    // No single weak fuzzy candidate is enough; multiple DISTINCT methods
    // must agree on the same relative code-cluster translation.
    V45ResolveGameClusterConsensus(
        profile,
        golden,
        specs,
        resolved
    );

    // V4.9: external same-build RVAs are intentionally NOT used as an oracle.
    // Resolve from this binary's own Lua registration metadata, mirroring the
    // working otc-api discovery method. This runs after legacy diagnostics so
    // direct semantic binds replace weaker/demoted candidates deterministically.
    V49ResolveOtcStyleDirectBindings(
        profile,
        specs
    );

    // Independent structural fallback for LocalPlayer::autoWalk.
    if (!profile.fnLocalPlayerAutoWalk &&
        profile.vtableRva)
    {
        uintptr_t vt =
            g_exeBase +
            profile.vtableRva;

        uintptr_t fn =
            ReadPtr(
                vt +
                0xA8
            );

        if (fn >= g_textBegin &&
            fn < g_textEnd)
        {
            profile.fnLocalPlayerAutoWalk =
                fn -
                g_exeBase;

            profile.localPlayerAutoWalkVtableSlot =
                0xA8;

            ++resolved;

            g_functionResolutionMethod[
                "LocalPlayer::autoWalk"
            ] = "vtable_slot_fallback";

            g_functionResolutionScore[
                "LocalPlayer::autoWalk"
            ] = 0.90;

            std::cout
                << "LocalPlayer::autoWalk : RVA "
                << HexU64(
                    profile.fnLocalPlayerAutoWalk
                )
                << " [VTABLE +0xA8 CANDIDATE]\n";
        }
    }

    size_t present = 0;

    for (const auto& spec :
         specs)
    {
        if (profile.*(
                spec.rvaField))
        {
            ++present;
        }
    }

    if (present ==
        specs.size())
    {
        profile.functionsStatus =
            "confirmed_static_migration";

        return true;
    }

    if (V49CoreActionSetReady(profile))
    {
        profile.functionsStatus =
            "confirmed_otc_style_core_optional_pending";

        std::cout
            << "[FUNCTIONS] OTC-STYLE CORE READY. Resolved "
            << present
            << "/"
            << specs.size()
            << ". Legacy/optional contracts may remain pending without blocking the action core.\n";

        return true;
    }

    profile.functionsStatus =
        "partial_otc_style_direct_bind_migration";

    std::cout
        << "[FUNCTIONS] Resolved "
        << present
        << "/"
        << specs.size()
        << ". OTC-style core is not complete yet; unresolved entries remain pending.\n";

    return false;
}

bool EnsureBuildMigratorFunctionStage(
    DbProfile& profile,
    std::vector<DbProfile>& database,
    int profileIndex,
    const std::string& databasePath)
{
    bool ok = false;

    if (BMIsGoldenOpenGlBuild(
            profile))
    {
        ok =
            BMCaptureGoldenFunctionSignatures(
                profile
            );

        std::cout
            << "\n[FUNCTION GOLDEN] "
            << profile.functionsStatus
            << "\n";
    }
    else
    {
        const DbProfile* golden =
            BMFindGoldenSignatureProfile(
                database
            );

        if (!golden)
        {
            // V4.9 no longer requires a Golden build to discover the action core.
            // An empty reference profile simply disables the legacy signature stages;
            // the direct Lua-bind resolver still runs against the current executable.
            DbProfile emptyGolden{};

            std::cout
                << "\n[FUNCTIONS V4.9] Golden OpenGL ausente. Continuando pelo resolver direto de binds do proprio cliente.\n";

            ok =
                BMResolveFunctionsFromGolden(
                    profile,
                    emptyGolden
                );
        }
        else
        {
            ok =
                BMResolveFunctionsFromGolden(
                    profile,
                    *golden
                );
        }
    }

    if (profileIndex >= 0 &&
        profileIndex <
            static_cast<int>(
                database.size()))
    {
        database[
            static_cast<size_t>(
                profileIndex)
        ] = profile;

        SaveProfileDatabase(
            databasePath,
            database
        );
    }

    return ok;
}



void V39PopulateKnownCreatureReferenceFields(
    DbProfile& p)
{
    if (!BMIsGoldenOpenGlBuild(
            p))
    {
        return;
    }

    // Golden OpenGL reference values already runtime-validated in the
    // established reference profile. Other builds stay pending until
    // independent discovery confirms the same semantics.
    p.creatureName = 0x40;
    p.creatureWalkDirection = 0x68;
    p.creatureSpeed = 0xEC;
    p.creatureSkull = 0xFC;
    p.creatureParty = 0xFD;
    p.creatureRemoved = 0x1A6;
    p.creatureWalking = 0x330;
    p.creatureStates = 0x648;
}

std::string V39FieldStatus(
    uintptr_t offset,
    const std::string& fallback = "pending")
{
    return
        offset
            ? "confirmed"
            : fallback;
}

void V39WriteOffsetField(
    std::ostringstream& j,
    const char* name,
    uintptr_t offset,
    const char* type,
    const char* method,
    double confidence,
    bool comma,
    int indent = 8)
{
    std::string pad(
        static_cast<size_t>(indent),
        ' '
    );

    j
        << pad
        << "\""
        << name
        << "\": {\n"
        << pad
        << "  \"offset\": \""
        << HexU64(offset)
        << "\",\n"
        << pad
        << "  \"type\": \""
        << type
        << "\",\n"
        << pad
        << "  \"status\": \""
        << V39FieldStatus(offset)
        << "\",\n"
        << pad
        << "  \"method\": \""
        << (
            offset
                ? method
                : "pending_discovery"
        )
        << "\",\n"
        << pad
        << "  \"confidence\": "
        << std::fixed
        << std::setprecision(2)
        << (
            offset
                ? confidence
                : 0.0
        )
        << "\n"
        << pad
        << "}"
        << (
            comma
                ? ","
                : ""
        )
        << "\n";
}

struct V41NativeArg
{
    const char* name = "";
    const char* type = "unknown";
    const char* passing = "unknown";
};

struct V41NativeContract
{
    const char* owner = "unknown";
    const char* returnType = "unknown";

    // Semantic prototype source model.  This is deliberately separate from
    // the machine ABI proof needed for direct native invocation.
    const char* prototypeStatus =
        "pending_reverse_engineering";

    const char* referenceSource =
        "none";

    const char* threadRequired =
        "unknown";

    const char* threadStatus =
        "pending_validation";

    bool sourceModelKnown = false;
    bool mutatingAction = false;

    std::vector<V41NativeArg> args;
};

V41NativeContract V41ContractFor(
    const char* semanticName)
{
    const std::string name =
        semanticName;

    // The semantic signatures below mirror the public OTClient source model
    // for these exact symbols. They are useful knowledge, but they do NOT by
    // themselves prove the binary-level layout of non-trivial C++ objects.
    // Therefore callable remains false until machine ABI + runtime thread
    // validation are completed.

    if (name == "Game::autoWalk")
    {
        return {
            "Game*",
            "void",
            "reference_source_model",
            "OTClient::Game::autoWalk",
            "game",
            "reference_source_expected_runtime_pending",
            true,
            true,
            {
                {
                    "dirs",
                    "std::vector<Otc::Direction>",
                    "by_value_nontrivial"
                }
            }
        };
    }

    if (name == "LocalPlayer::autoWalk")
    {
        return {
            "LocalPlayer*",
            "bool",
            "reference_source_model",
            "OTClient::LocalPlayer::autoWalk",
            "game",
            "reference_source_expected_runtime_pending",
            true,
            true,
            {
                {
                    "destination",
                    "const Position&",
                    "const_reference"
                }
            }
        };
    }

    if (name == "Game::attack")
    {
        return {
            "Game*",
            "void",
            "reference_source_model",
            "OTClient::Game::attack",
            "game",
            "reference_source_expected_runtime_pending",
            true,
            true,
            {
                {
                    "creature",
                    "CreaturePtr",
                    "by_value_nontrivial"
                }
            }
        };
    }

    if (name == "Game::follow")
    {
        return {
            "Game*",
            "void",
            "reference_source_model",
            "OTClient::Game::follow",
            "game",
            "reference_source_expected_runtime_pending",
            true,
            true,
            {
                {
                    "creature",
                    "CreaturePtr",
                    "by_value_nontrivial"
                }
            }
        };
    }

    if (name == "Game::look")
    {
        return {
            "Game*",
            "void",
            "reference_source_model",
            "OTClient::Game::look",
            "game",
            "reference_source_expected_runtime_pending",
            true,
            true,
            {
                {
                    "thing",
                    "const ThingPtr&",
                    "const_reference"
                },
                {
                    "isBattleList",
                    "bool",
                    "value"
                }
            }
        };
    }

    if (name == "Game::move")
    {
        return {
            "Game*",
            "void",
            "reference_source_model",
            "OTClient::Game::move",
            "game",
            "reference_source_expected_runtime_pending",
            true,
            true,
            {
                {
                    "thing",
                    "const ThingPtr&",
                    "const_reference"
                },
                {
                    "toPos",
                    "const Position&",
                    "const_reference"
                },
                {
                    "count",
                    "int",
                    "value"
                }
            }
        };
    }

    if (name == "Game::use")
    {
        return {
            "Game*",
            "void",
            "reference_source_model",
            "OTClient::Game::use",
            "game",
            "reference_source_expected_runtime_pending",
            true,
            true,
            {
                {
                    "thing",
                    "const ThingPtr&",
                    "const_reference"
                }
            }
        };
    }

    if (name == "Game::useWith")
    {
        return {
            "Game*",
            "void",
            "reference_source_model",
            "OTClient::Game::useWith",
            "game",
            "reference_source_expected_runtime_pending",
            true,
            true,
            {
                {
                    "item",
                    "const ItemPtr&",
                    "const_reference"
                },
                {
                    "toThing",
                    "const ThingPtr&",
                    "const_reference"
                }
            }
        };
    }

    if (name == "Game::talk")
    {
        return {
            "Game*",
            "void",
            "reference_source_model",
            "OTClient::Game::talk",
            "game",
            "reference_source_expected_runtime_pending",
            true,
            true,
            {
                {
                    "message",
                    "const std::string&",
                    "const_reference"
                }
            }
        };
    }

    if (name == "Map::getTile")
    {
        return {
            "Map*",
            "const TilePtr&",
            "reference_source_model",
            "OTClient::Map::getTile",
            "game",
            "reference_source_expected_runtime_pending",
            true,
            false,
            {
                {
                    "pos",
                    "const Position&",
                    "const_reference"
                }
            }
        };
    }

    if (name == "Map::getCreatureById")
    {
        return {
            "Map*",
            "CreaturePtr",
            "reference_source_model",
            "OTClient::Map::getCreatureById",
            "game",
            "reference_source_expected_runtime_pending",
            true,
            false,
            {
                {
                    "id",
                    "uint32",
                    "value"
                }
            }
        };
    }

    if (name == "Container::getItem")
    {
        return {
            "Container*",
            "ItemPtr",
            "reference_source_model",
            "OTClient::Container::getItem",
            "game",
            "reference_source_expected_runtime_pending",
            true,
            false,
            {
                {
                    "slot",
                    "int",
                    "value"
                }
            }
        };
    }

    // Game::detailedLook and Map::getCreatureByName differ across forks.
    // Keep them explicit but unresolved rather than assigning a prototype
    // from a different class/version.
    if (name.rfind("Game::", 0) == 0)
    {
        V41NativeContract c{};
        c.owner = "Game*";
        c.threadRequired = "game";
        c.mutatingAction = true;
        return c;
    }

    if (name.rfind("LocalPlayer::", 0) == 0)
    {
        V41NativeContract c{};
        c.owner = "LocalPlayer*";
        c.threadRequired = "game";
        c.mutatingAction = true;
        return c;
    }

    if (name.rfind("Map::", 0) == 0)
    {
        V41NativeContract c{};
        c.owner = "Map*";
        c.threadRequired = "game";
        return c;
    }

    if (name.rfind("Container::", 0) == 0)
    {
        V41NativeContract c{};
        c.owner = "Container*";
        c.threadRequired = "game";
        return c;
    }

    return {};
}

size_t V41CountDirectCallXrefs(
    uintptr_t target)
{
    if (
        !target ||
        target < g_textBegin ||
        target >= g_textEnd
    )
    {
        return 0;
    }

    size_t count = 0;

    const uint8_t* text =
        reinterpret_cast<const uint8_t*>(
            g_textBegin
        );

    const size_t size =
        static_cast<size_t>(
            g_textEnd -
            g_textBegin
        );

    for (size_t i = 0;
         i + 5 <= size;
         ++i)
    {
        if (text[i] != 0xE8)
            continue;

        int32_t rel = 0;

        std::memcpy(
            &rel,
            text + i + 1,
            sizeof(rel)
        );

        uintptr_t callAddress =
            g_textBegin +
            i;

        uintptr_t destination =
            callAddress +
            5 +
            static_cast<intptr_t>(
                rel
            );

        if (destination == target)
            ++count;
    }

    return count;
}

// ============================================================
// BUILDMIGRATOR V4.6.1 - COMPLETE PROFILE EXPORT
// ============================================================

struct BMFloorHeaderModel
{
    bool confirmed = false;
    long long base = 0;
    long long stride = 0;
    std::vector<std::pair<unsigned, uintptr_t>> observations;
};

BMFloorHeaderModel BMBuildFloorHeaderModel(
    const DbProfile& profile)
{
    BMFloorHeaderModel model{};

    for (const auto& kv :
         g_floorHeaderObservations)
    {
        model.observations.push_back(
            kv
        );
    }

    // The Stage 5B profile stores one confirmed header even when this
    // particular run did not revisit that floor. Do not invent its Z.
    // It remains available separately as lastConfirmedOffset.

    if (model.observations.size() < 2)
        return model;

    std::sort(
        model.observations.begin(),
        model.observations.end(),
        [](
            const auto& a,
            const auto& b)
        {
            return a.first < b.first;
        }
    );

    const auto& a =
        model.observations[0];

    const auto& b =
        model.observations[1];

    long long dz =
        static_cast<long long>(
            b.first) -
        static_cast<long long>(
            a.first);

    if (!dz)
        return model;

    long long doff =
        static_cast<long long>(
            b.second) -
        static_cast<long long>(
            a.second);

    if (doff % dz != 0)
        return model;

    long long stride =
        doff / dz;

    long long base =
        static_cast<long long>(
            a.second) -
        static_cast<long long>(
            a.first) *
        stride;

    for (const auto& kv :
         model.observations)
    {
        long long expected =
            base +
            static_cast<long long>(
                kv.first) *
            stride;

        if (expected !=
            static_cast<long long>(
                kv.second))
        {
            return model;
        }
    }

    model.confirmed = true;
    model.base = base;
    model.stride = stride;

    return model;
}

std::string BMRendererHint(
    const std::string& exePath)
{
    std::string lower =
        exePath;

    std::transform(
        lower.begin(),
        lower.end(),
        lower.begin(),
        [](
            unsigned char c)
        {
            return
                static_cast<char>(
                    std::tolower(c));
        }
    );

    if (lower.find(
            "dx9") !=
        std::string::npos)
    {
        return "dx9";
    }

    if (lower.find(
            "opengl") !=
        std::string::npos)
    {
        return "opengl";
    }

    return "unknown";
}

bool BMConsumerProfileReady(
    const DbProfile& p)
{
    const bool player =
        p.vtableRva &&
        p.directGlobalRva &&
        p.x &&
        p.y &&
        p.z &&
        p.health &&
        p.maxHealth &&
        p.mana &&
        p.maxMana;

    const bool game =
        p.gameRva &&
        p.gameAttackTarget &&
        p.gameFollowTarget &&
        p.gameContainersOffset;

    const bool map =
        p.mapRva &&
        p.mapCenterX &&
        p.mapCenterY &&
        p.mapCenterZ &&
        p.mapNorth &&
        p.mapEast &&
        p.mapSouth &&
        p.mapWest;

    const bool tile =
        p.tileThingsBegin &&
        p.tileThingsEnd &&
        p.tileThingsCap &&
        p.tileVtableRva &&
        p.mapTilePathDepth &&
        p.mapTilePathMapOffset &&
        p.mapTileStorageStride;

    const bool classes =
        p.itemVtableRva &&
        p.playerVtableRva &&
        p.monsterVtableRva &&
        p.npcVtableRva &&
        (
            p.classificationStatus ==
                "confirmed_runtime_four_class_static_bool" ||
            p.classificationStatus ==
                "confirmed_semantic_vtables_slots_pending"
        );

    const bool itemContainer =
        p.inventoryBaseOffset &&
        p.itemIdOffset &&
        p.itemCountOffset &&
        p.containerItemCountOffset;

    size_t functionCount = 0;

    for (const auto& spec :
         BMFunctionSpecs())
    {
        if (p.*(
                spec.rvaField))
        {
            ++functionCount;
        }
    }

    const bool functions =
        functionCount ==
            BMFunctionSpecs().size();

    return
        player &&
        game &&
        map &&
        tile &&
        classes &&
        itemContainer &&
        functions;
}

std::string BMFunctionMethod(
    const char* name,
    const DbProfile& p)
{
    auto it =
        g_functionResolutionMethod.find(
            name
        );

    if (it !=
        g_functionResolutionMethod.end())
    {
        return
            it->second;
    }

    if (BMIsGoldenOpenGlBuild(
            p))
    {
        return
            "golden_reference";
    }

    return
        "confirmed_static_migration";
}

double BMFunctionScore(
    const char* name)
{
    auto it =
        g_functionResolutionScore.find(
            name
        );

    if (it !=
        g_functionResolutionScore.end())
    {
        return
            it->second;
    }

    return 1.0;
}

void BMWriteFunctionJson(
    std::ostringstream& j,
    const char* jsonName,
    const char* semanticName,
    uintptr_t rva,
    const DbProfile& p,
    bool comma)
{
    const V41NativeContract contract =
        V41ContractFor(
            semanticName
        );

    const std::string method =
        BMFunctionMethod(
            semanticName,
            p
        );

    const double score =
        BMFunctionScore(
            semanticName
        );

    const size_t callsiteCount =
        rva
            ? V41CountDirectCallXrefs(
                g_exeBase +
                rva
              )
            : 0;

    const bool bindingTargetLike =
        rva &&
        V43AddressIsDirectLuaBindingTarget(
            semanticName,
            g_exeBase +
                rva
        );

    const bool nativeCallgraphMethod =
        method ==
            "lua_wrapper_callgraph_native" ||
        method ==
            "pdata_bounded_lua_callgraph_native" ||
        method ==
            "golden_game_cluster_delta_consensus";

    const bool wrapperDemoted =
        method ==
            "binding_wrapper_demoted_native_pending";

    const bool addressConfirmed =
        rva != 0 &&
        !wrapperDemoted &&
        (
            !bindingTargetLike ||
            nativeCallgraphMethod ||
            callsiteCount > 0
        );

    const bool prototypeKnown =
        contract.sourceModelKnown;

    // Windows x64 fixes the platform calling convention, but C++ non-trivial
    // parameter lowering (shared_ptr/vector/string) still needs binary-level
    // validation before a direct wrapper is safe.
    const bool machineAbiValidated =
        false;

    const bool runtimeThreadValidated =
        false;

    const bool callable =
        addressConfirmed &&
        prototypeKnown &&
        machineAbiValidated &&
        runtimeThreadValidated;

    j
        << "      \""
        << jsonName
        << "\": {\n"
        << "        \"semanticName\": \""
        << semanticName
        << "\",\n"
        << "        \"address\": {\n"
        << "          \"rva\": \""
        << HexU64(rva)
        << "\",\n"
        << "          \"status\": \""
        << (
            addressConfirmed
                ? "confirmed"
                : "pending"
        )
        << "\",\n"
        << "          \"method\": \""
        << EscapeJson(method)
        << "\",\n"
        << "          \"confidence\": "
        << std::fixed
        << std::setprecision(2)
        << (
            addressConfirmed
                ? score
                : 0.0
        )
        << ",\n"
        << "          \"directCallsiteCount\": "
        << callsiteCount
        << ",\n"
        << "          \"bindingTargetLike\": "
        << (
            bindingTargetLike
                ? "true"
                : "false"
        )
        << ",\n"
        << "          \"role\": \""
        << (
            wrapperDemoted
                ? "binding_wrapper_demoted"
                : (
                    nativeCallgraphMethod
                        ? "native_via_wrapper_callgraph"
                        : (
                            bindingTargetLike &&
                            callsiteCount == 0
                                ? "binding_target_candidate"
                                : (
                                    addressConfirmed
                                        ? "native_candidate"
                                        : "pending"
                                  )
                          )
                  )
        )
        << "\"\n"
        << "        },\n"
        << "        \"abi\": {\n"
        << "          \"callingConvention\": \"msvc_x64\",\n"
        << "          \"platformStatus\": \"confirmed_windows_x64\",\n"
        << "          \"thisRegister\": \"RCX\",\n"
        << "          \"machineParameterLayoutStatus\": \"pending_binary_validation\",\n"
        << "          \"note\": \"non-trivial C++ arguments may lower to hidden/reference ABI forms\"\n"
        << "        },\n"
        << "        \"prototype\": {\n"
        << "          \"returnType\": \""
        << EscapeJson(contract.returnType)
        << "\",\n"
        << "          \"arguments\": [\n"
        << "            {\"name\": \"this\", \"type\": \""
        << contract.owner
        << "\", \"passing\": \"pointer\"}";

    for (const auto& arg :
         contract.args)
    {
        j
            << ",\n"
            << "            {\"name\": \""
            << EscapeJson(arg.name)
            << "\", \"type\": \""
            << EscapeJson(arg.type)
            << "\", \"passing\": \""
            << EscapeJson(arg.passing)
            << "\"}";
    }

    j
        << "\n"
        << "          ],\n"
        << "          \"status\": \""
        << contract.prototypeStatus
        << "\",\n"
        << "          \"referenceSource\": \""
        << EscapeJson(contract.referenceSource)
        << "\",\n"
        << "          \"binaryValidationStatus\": \""
        << (
            addressConfirmed &&
            prototypeKnown
                ? "semantic_source_model_plus_address_confirmed_machine_abi_pending"
                : "pending"
        )
        << "\"\n"
        << "        },\n"
        << "        \"thread\": {\n"
        << "          \"required\": \""
        << contract.threadRequired
        << "\",\n"
        << "          \"status\": \""
        << contract.threadStatus
        << "\",\n"
        << "          \"runtimeValidationStatus\": \"pending\"\n"
        << "        },\n"
        << "        \"runtimeValidation\": {\n"
        << "          \"status\": \"pending\",\n"
        << "          \"mode\": \"manual_game_action_plus_read_only_state_observation\",\n"
        << "          \"nativeFunctionInvokedByMigrator\": false\n"
        << "        },\n"
        << "        \"callability\": {\n"
        << "          \"addressConfirmed\": "
        << (addressConfirmed ? "true" : "false")
        << ",\n"
        << "          \"semanticPrototypeKnown\": "
        << (prototypeKnown ? "true" : "false")
        << ",\n"
        << "          \"machineAbiValidated\": "
        << (machineAbiValidated ? "true" : "false")
        << ",\n"
        << "          \"threadValidated\": "
        << (runtimeThreadValidated ? "true" : "false")
        << "\n"
        << "        },\n"
        << "        \"callable\": "
        << (
            callable
                ? "true"
                : "false"
        )
        << "\n"
        << "      }"
        << (
            comma
                ? ","
                : ""
        )
        << "\n";
}


void V42PrintNativeContractSummary(
    const DbProfile& p)
{
    const auto specs =
        BMFunctionSpecs();

    std::cout
        << "\n============================================================\n"
        << "                NATIVE CONTRACT SUMMARY\n"
        << "============================================================\n"
        << "Semantic prototypes are source-model evidence.\n"
        << "callable stays NO until machine ABI + runtime thread validation are complete.\n";

    for (const auto& spec :
         specs)
    {
        const V41NativeContract contract =
            V41ContractFor(
                spec.name
            );

        const uintptr_t rva =
            p.*(
                spec.rvaField
            );

        const std::string method =
            BMFunctionMethod(
                spec.name,
                p
            );

        const double score =
            BMFunctionScore(
                spec.name
            );

        const size_t callsites =
            rva
                ? V41CountDirectCallXrefs(
                    g_exeBase +
                    rva
                  )
                : 0;

        const bool bindingTargetLike =
            rva &&
            V43AddressIsDirectLuaBindingTarget(
                spec.name,
                g_exeBase +
                    rva
            );

        std::cout
            << spec.name
            << "\n"
            << "  RVA          : "
            << (
                rva
                    ? HexU64(rva)
                    : std::string("pending")
            )
            << "\n"
            << "  RVA method   : "
            << method
            << "\n"
            << "  RVA conf     : "
            << std::fixed
            << std::setprecision(2)
            << (
                rva
                    ? score
                    : 0.0
            )
            << "\n"
            << "  callsites    : "
            << callsites
            << "\n"
            << "  bindingTarget: "
            << (
                bindingTargetLike
                    ? "YES"
                    : "NO"
            )
            << "\n"
            << "  address role : "
            << (
                method ==
                    "lua_wrapper_callgraph_native"
                    ? "native_via_wrapper_callgraph"
                    : (
                        bindingTargetLike &&
                        callsites == 0
                            ? "binding_target_candidate"
                            : (
                                rva
                                    ? "native_candidate"
                                    : "pending"
                              )
                      )
            )
            << "\n"
            << "  return       : "
            << contract.returnType
            << "\n"
            << "  prototype    : "
            << contract.prototypeStatus
            << "\n"
            << "  thread       : "
            << contract.threadRequired
            << " ["
            << contract.threadStatus
            << "]\n"
            << "  machine ABI  : pending_binary_validation\n"
            << "  callable     : NO\n";
    }
}


void V39WriteMigratorState(
    std::ostringstream& j,
    const DbProfile& p)
{
    auto W =
        [&](const char* name,
            uintptr_t value,
            bool comma = true)
        {
            j
                << "    \""
                << name
                << "\": \""
                << HexU64(value)
                << "\""
                << (
                    comma
                        ? ","
                        : ""
                )
                << "\n";
        };

    auto WS =
        [&](const char* name,
            const std::string& value,
            bool comma = true)
        {
            j
                << "    \""
                << name
                << "\": \""
                << EscapeJson(value)
                << "\""
                << (
                    comma
                        ? ","
                        : ""
                )
                << "\n";
        };

    j << "  \"migratorState\": {\n";

    WS("name", p.name);
    WS("status", p.status);
    W("timestamp", static_cast<uintptr_t>(p.timestamp));
    W("sizeOfImage", static_cast<uintptr_t>(p.sizeOfImage));
    W("textHashFNV1A64", static_cast<uintptr_t>(p.textHash));
    W("vtableRva", p.vtableRva);
    W("directGlobalRva", p.directGlobalRva);
    W("indirectGlobalRva", p.indirectGlobalRva);
    W("ownerOffset", p.ownerOffset);
    W("x", p.x); W("y", p.y); W("z", p.z);
    W("id", p.id); W("hpPercent", p.hpPercent); W("direction", p.direction);
    W("creatureName", p.creatureName);
    W("creatureWalkDirection", p.creatureWalkDirection);
    W("creatureSpeed", p.creatureSpeed);
    W("creatureSkull", p.creatureSkull);
    W("creatureParty", p.creatureParty);
    W("creatureRemoved", p.creatureRemoved);
    W("creatureWalking", p.creatureWalking);
    W("creatureStates", p.creatureStates);
    W("health", p.health); W("maxHealth", p.maxHealth); W("capacity", p.capacity);
    W("experience", p.experience); W("level", p.level); W("mana", p.mana); W("maxMana", p.maxMana);
    W("gameRva", p.gameRva); W("gameLocalPlayer", p.gameLocalPlayer);
    W("gameAttackTarget", p.gameAttackTarget); W("gameFollowTarget", p.gameFollowTarget);
    WS("gameStatus", p.gameStatus); WS("followStatus", p.followStatus);
    W("mapRva", p.mapRva); W("mapCenterX", p.mapCenterX); W("mapCenterY", p.mapCenterY); W("mapCenterZ", p.mapCenterZ);
    W("mapNorth", p.mapNorth); W("mapEast", p.mapEast); W("mapSouth", p.mapSouth); W("mapWest", p.mapWest);
    WS("mapStatus", p.mapStatus);
    W("tileThingsBegin", p.tileThingsBegin); W("tileThingsEnd", p.tileThingsEnd); W("tileThingsCap", p.tileThingsCap);
    W("tileVtableRva", p.tileVtableRva); WS("tileRttiName", p.tileRttiName);
    W("thingStorageStride", p.thingStorageStride); WS("thingStorageMode", p.thingStorageMode); WS("tileThingsStatus", p.tileThingsStatus);
    W("mapTilePathDepth", p.mapTilePathDepth); W("mapTilePathMapOffset", p.mapTilePathMapOffset);
    W("mapTilePathChildOffset", p.mapTilePathChildOffset); W("mapTilePathHeaderOffset", p.mapTilePathHeaderOffset);
    W("mapTileStorageStride", p.mapTileStorageStride); WS("mapTileStorageMode", p.mapTileStorageMode); WS("mapTilePathStatus", p.mapTilePathStatus);
    W("monsterVtableRva", p.monsterVtableRva); WS("monsterVtableStatus", p.monsterVtableStatus);
    W("itemVtableRva", p.itemVtableRva); WS("itemVtableStatus", p.itemVtableStatus);
    W("playerVtableRva", p.playerVtableRva); WS("playerVtableStatus", p.playerVtableStatus);
    W("slotIsItem", p.slotIsItem); W("slotIsCreature", p.slotIsCreature); W("slotIsMonster", p.slotIsMonster);
    W("slotIsPlayer", p.slotIsPlayer); W("slotIsLocalPlayer", p.slotIsLocalPlayer); WS("classificationStatus", p.classificationStatus);
    W("npcVtableRva", p.npcVtableRva); W("slotIsNpc", p.slotIsNpc); WS("npcStatus", p.npcStatus);
    W("inventoryBaseOffset", p.inventoryBaseOffset); W("inventorySlotStride", p.inventorySlotStride);
    WS("inventoryStorageMode", p.inventoryStorageMode); WS("inventoryStatus", p.inventoryStatus);
    W("itemIdOffset", p.itemIdOffset); W("itemCountOffset", p.itemCountOffset); W("itemCountWidth", p.itemCountWidth); WS("itemLayoutStatus", p.itemLayoutStatus);
    W("gameContainersOffset", p.gameContainersOffset);
    W("containerMapHeaderOffset", p.containerMapHeaderOffset); W("containerMapSizeOffset", p.containerMapSizeOffset);
    W("containerNodeLeftOffset", p.containerNodeLeftOffset); W("containerNodeRightOffset", p.containerNodeRightOffset);
    W("containerNodeNilOffset", p.containerNodeNilOffset); W("containerNodeKeyOffset", p.containerNodeKeyOffset); W("containerNodeValueOffset", p.containerNodeValueOffset);
    W("containerIdOffset", p.containerIdOffset); W("containerCapacityOffset", p.containerCapacityOffset); W("containerItemOffset", p.containerItemOffset);
    W("containerNameOffset", p.containerNameOffset); W("containerHasParentOffset", p.containerHasParentOffset); W("containerClosedOffset", p.containerClosedOffset);
    W("containerUnlockedOffset", p.containerUnlockedOffset); W("containerPagesOffset", p.containerPagesOffset); W("containerSizeOffset", p.containerSizeOffset);
    W("containerFirstIndexOffset", p.containerFirstIndexOffset); W("containerDequeMapOffset", p.containerDequeMapOffset);
    W("containerDequeMapSizeOffset", p.containerDequeMapSizeOffset); W("containerDequeOffsetOffset", p.containerDequeOffsetOffset);
    W("containerItemCountOffset", p.containerItemCountOffset); W("containerItemElementStride", p.containerItemElementStride);
    WS("containerItemStorageMode", p.containerItemStorageMode); WS("containersStatus", p.containersStatus);
    W("fnGameAutoWalk", p.fnGameAutoWalk); W("fnLocalPlayerAutoWalk", p.fnLocalPlayerAutoWalk);
    W("fnGameAttack", p.fnGameAttack); W("fnGameFollow", p.fnGameFollow); W("fnGameLook", p.fnGameLook); W("fnGameDetailedLook", p.fnGameDetailedLook);
    W("fnGameMove", p.fnGameMove); W("fnGameUse", p.fnGameUse); W("fnGameUseWith", p.fnGameUseWith); W("fnGameTalk", p.fnGameTalk);
    W("fnMapGetTile", p.fnMapGetTile); W("fnMapGetCreatureById", p.fnMapGetCreatureById); W("fnMapGetCreatureByName", p.fnMapGetCreatureByName);
    W("fnContainerGetItem", p.fnContainerGetItem); W("localPlayerAutoWalkVtableSlot", p.localPlayerAutoWalkVtableSlot);
    WS("sigGameAutoWalk", p.sigGameAutoWalk); WS("sigLocalPlayerAutoWalk", p.sigLocalPlayerAutoWalk);
    WS("sigGameAttack", p.sigGameAttack); WS("sigGameFollow", p.sigGameFollow); WS("sigGameLook", p.sigGameLook); WS("sigGameDetailedLook", p.sigGameDetailedLook);
    WS("sigGameMove", p.sigGameMove); WS("sigGameUse", p.sigGameUse); WS("sigGameUseWith", p.sigGameUseWith); WS("sigGameTalk", p.sigGameTalk);
    WS("sigMapGetTile", p.sigMapGetTile); WS("sigMapGetCreatureById", p.sigMapGetCreatureById); WS("sigMapGetCreatureByName", p.sigMapGetCreatureByName);
    WS("sigContainerGetItem", p.sigContainerGetItem); WS("functionsStatus", p.functionsStatus);

    WS("lookFeatureStatus", p.lookFeatureStatus);
    WS("lookHookFunction", p.lookHookFunction);
    W("lookHookRva", p.lookHookRva);
    WS("lookHookArgument", p.lookHookArgument);
    W("lookThingIndirection", p.lookThingIndirection);
    W("lookItemIdOffset", p.lookItemIdOffset);
    WS("lookItemIdType", p.lookItemIdType);
    W("lookPositionXOffset", p.lookPositionXOffset);
    W("lookPositionYOffset", p.lookPositionYOffset);
    W("lookPositionZOffset", p.lookPositionZOffset);
    W("lookContainerSentinelX", p.lookContainerSentinelX);
    WS("lookContextStatus", p.lookContextStatus);
    WS("hackLightStatus", p.hackLightStatus);
    W("lightIntensityOffset", p.lightIntensityOffset);
    WS("lightIntensityType", p.lightIntensityType);
    WS("lightCalibrationMethod", p.lightCalibrationMethod, false);

    j << "  },\n";
}

bool BMSaveCompleteProfile(
    const BuildInfo& build,
    const DbProfile& sourceProfile,
    const std::string& directory)
{
    DbProfile p =
        sourceProfile;

    V39PopulateKnownCreatureReferenceFields(
        p
    );

    BMRefreshLookFeatureContract(build, p);
    BMApplyKnownLightEvidence(build, p);

    const bool strictReady =
        BMConsumerProfileReady(
            p
        );

    const bool readOnlyReady =
        p.vtableRva &&
        p.directGlobalRva &&
        p.x &&
        p.y &&
        p.z &&
        p.health &&
        p.maxHealth &&
        p.mana &&
        p.maxMana &&
        p.gameRva &&
        p.mapRva &&
        p.tileVtableRva &&
        p.mapTilePathMapOffset;

    BMFloorHeaderModel floorModel =
        BMBuildFloorHeaderModel(
            p
        );

    std::ostringstream canonicalPath;

    canonicalPath
        << directory
        << "\\OTCLab_BuildProfile_"
        << std::hex
        << std::uppercase
        << build.timestamp
        << "_"
        << build.textHash
        << ".json";

    std::ostringstream j;

    j
        << "{\n"
        << "  \"schema\": \"otclab-build-profile-v2\",\n"
        << "  \"schemaVersion\": 2,\n"
        << "  \"storagePolicy\": {\n"
        << "    \"sourceOfTruth\": \"this_file\",\n"
        << "    \"oneOfficialProfilePerBuild\": true,\n"
        << "    \"legacyAliasesGenerated\": false\n"
        << "  },\n"
        << "  \"capabilities\": {\n"
        << "    \"readOnlyCoreReady\": "
        << (
            readOnlyReady
                ? "true"
                : "false"
        )
        << ",\n"
        << "    \"strictConsumerReady\": "
        << (
            strictReady
                ? "true"
                : "false"
        )
        << ",\n"
        << "    \"nativeActionsReady\": false,\n"
        << "    \"lookCaptureReady\": "
        << (p.lookFeatureStatus == "confirmed_runtime" ? "true" : "false")
        << ",\n"
        << "    \"hackLightReady\": "
        << (p.hackLightStatus == "confirmed_runtime_write" && p.lightWriteValidated ? "true" : "false")
        << "\n"
        << "  },\n"
        << "  \"profileName\": \""
        << EscapeJson(p.name)
        << "\",\n"
        << "  \"profileStatus\": \""
        << (
            strictReady
                ? "complete"
                : "partial"
        )
        << "\",\n";

    V39WriteMigratorState(
        j,
        p
    );

    j
        << "  \"build\": {\n"
        << "    \"exe\": \""
        << EscapeJson(build.exePath)
        << "\",\n"
        << "    \"architecture\": \"x64\",\n"
        << "    \"pointerSize\": 8,\n"
        << "    \"rendererHint\": \""
        << BMRendererHint(
            build.exePath
        )
        << "\",\n"
        << "    \"fingerprint\": {\n"
        << "      \"timestamp\": \""
        << HexU64(build.timestamp)
        << "\",\n"
        << "      \"sizeOfImage\": \""
        << HexU64(build.sizeOfImage)
        << "\",\n"
        << "      \"entryPointRva\": \""
        << HexU64(build.entryPointRva)
        << "\",\n"
        << "      \"textRva\": \""
        << HexU64(build.textRva)
        << "\",\n"
        << "      \"textSize\": \""
        << HexU64(build.textSize)
        << "\",\n"
        << "      \"textHashFNV1A64\": \""
        << HexU64(build.textHash)
        << "\"\n"
        << "    }\n"
        << "  },\n"
        << "  \"values\": {\n"
        << "    \"localPlayer\": {\n"
        << "      \"vtableRva\": \""
        << HexU64(p.vtableRva)
        << "\",\n"
        << "      \"directGlobalRva\": \""
        << HexU64(p.directGlobalRva)
        << "\",\n"
        << "      \"indirectGlobalRva\": \""
        << HexU64(p.indirectGlobalRva)
        << "\",\n"
        << "      \"indirectOwnerOffset\": \""
        << HexU64(p.ownerOffset)
        << "\",\n"
        << "      \"fields\": {\n";

    V39WriteOffsetField(j, "x", p.x, "u32", "position_transition", 1.0, true, 8);
    V39WriteOffsetField(j, "y", p.y, "u32", "position_transition", 1.0, true, 8);
    V39WriteOffsetField(j, "z", p.z, "u8", "xyz_structural_continuity", 1.0, true, 8);
    V39WriteOffsetField(j, "direction", p.direction, "u32", "turn_transition", 1.0, true, 8);
    V39WriteOffsetField(j, "health", p.health, "double", "value_transition", 0.98, true, 8);
    V39WriteOffsetField(j, "maxHealth", p.maxHealth, "double", "value_pair", 0.98, true, 8);
    V39WriteOffsetField(j, "mana", p.mana, "double", "value_transition", 0.98, true, 8);
    V39WriteOffsetField(j, "maxMana", p.maxMana, "double", "value_pair", 0.98, true, 8);
    V39WriteOffsetField(j, "capacity", p.capacity, "double", "before_after_transition", 1.0, true, 8);
    V39WriteOffsetField(j, "experience", p.experience, "double", "local_value_match", 0.95, true, 8);
    V39WriteOffsetField(j, "level", p.level, "double", "local_value_match", 0.95, false, 8);

    j
        << "      }\n"
        << "    },\n"
        << "    \"creature\": {\n"
        << "      \"fields\": {\n";

    // X/Y/Z/direction are validated behaviorally on Creature-like targets.
    V39WriteOffsetField(j, "x", p.x, "u32", "creature_position_shape", 0.95, true, 8);
    V39WriteOffsetField(j, "y", p.y, "u32", "creature_position_shape", 0.95, true, 8);
    V39WriteOffsetField(j, "z", p.z, "u8", "creature_position_shape", 0.95, true, 8);
    V39WriteOffsetField(j, "id", BMIsGoldenOpenGlBuild(p) ? 0x38 : 0, "u32", "golden_reference_only", 1.0, true, 8);
    V39WriteOffsetField(j, "name", p.creatureName, "msvc_string", "runtime_reference", 1.0, true, 8);
    V39WriteOffsetField(j, "hpPercent", BMIsGoldenOpenGlBuild(p) ? 0x60 : 0, "u8", "golden_reference_only", 1.0, true, 8);
    V39WriteOffsetField(j, "direction", p.direction, "u32", "creature_direction_shape", 0.95, true, 8);
    V39WriteOffsetField(j, "walkDirection", p.creatureWalkDirection, "u32", "runtime_reference", 1.0, true, 8);
    V39WriteOffsetField(j, "speed", p.creatureSpeed, "u32", "runtime_reference", 1.0, true, 8);
    V39WriteOffsetField(j, "skull", p.creatureSkull, "u8", "runtime_reference", 1.0, true, 8);
    V39WriteOffsetField(j, "party", p.creatureParty, "u8", "runtime_reference", 1.0, true, 8);
    V39WriteOffsetField(j, "removed", p.creatureRemoved, "bool", "runtime_reference", 1.0, true, 8);
    V39WriteOffsetField(j, "walking", p.creatureWalking, "bool", "runtime_reference", 1.0, true, 8);
    V39WriteOffsetField(j, "states", p.creatureStates, "u32", "runtime_reference", 1.0, false, 8);

    j
        << "      }\n"
        << "    },\n"
        << "    \"game\": {\n"
        << "      \"rva\": \""
        << HexU64(p.gameRva)
        << "\",\n"
        << "      \"localPlayer\": \""
        << HexU64(p.gameLocalPlayer)
        << "\",\n"
        << "      \"attackTarget\": \""
        << HexU64(p.gameAttackTarget)
        << "\",\n"
        << "      \"followTarget\": \""
        << HexU64(p.gameFollowTarget)
        << "\",\n"
        << "      \"containers\": \""
        << HexU64(p.gameContainersOffset)
        << "\"\n"
        << "    },\n"
        << "    \"map\": {\n"
        << "      \"rva\": \""
        << HexU64(p.mapRva)
        << "\",\n"
        << "      \"center\": {\"x\": \""
        << HexU64(p.mapCenterX)
        << "\", \"y\": \""
        << HexU64(p.mapCenterY)
        << "\", \"z\": \""
        << HexU64(p.mapCenterZ)
        << "\"},\n"
        << "      \"aware\": {\"north\": \""
        << HexU64(p.mapNorth)
        << "\", \"east\": \""
        << HexU64(p.mapEast)
        << "\", \"south\": \""
        << HexU64(p.mapSouth)
        << "\", \"west\": \""
        << HexU64(p.mapWest)
        << "\"}\n"
        << "    },\n"
        << "    \"tile\": {\n"
        << "      \"vtableRva\": \""
        << HexU64(p.tileVtableRva)
        << "\",\n"
        << "      \"rtti\": \""
        << EscapeJson(p.tileRttiName)
        << "\",\n"
        << "      \"things\": {\"begin\": \""
        << HexU64(p.tileThingsBegin)
        << "\", \"end\": \""
        << HexU64(p.tileThingsEnd)
        << "\", \"capacity\": \""
        << HexU64(p.tileThingsCap)
        << "\", \"mode\": \""
        << EscapeJson(p.thingStorageMode)
        << "\", \"stride\": "
        << p.thingStorageStride
        << "}\n"
        << "    },\n"
        << "    \"classification\": {\n"
        << "      \"itemVtableRva\": \""
        << HexU64(p.itemVtableRva)
        << "\",\n"
        << "      \"localPlayerVtableRva\": \""
        << HexU64(p.vtableRva)
        << "\",\n"
        << "      \"playerVtableRva\": \""
        << HexU64(p.playerVtableRva)
        << "\",\n"
        << "      \"monsterVtableRva\": \""
        << HexU64(p.monsterVtableRva)
        << "\",\n"
        << "      \"npcVtableRva\": \""
        << HexU64(p.npcVtableRva)
        << "\"\n"
        << "    },\n"
        << "    \"inventory\": {\n"
        << "      \"baseOffset\": \""
        << HexU64(p.inventoryBaseOffset)
        << "\",\n"
        << "      \"storageMode\": \""
        << EscapeJson(p.inventoryStorageMode)
        << "\",\n"
        << "      \"slotStride\": "
        << p.inventorySlotStride
        << "\n"
        << "    },\n"
        << "    \"item\": {\n"
        << "      \"idOffset\": \""
        << HexU64(p.itemIdOffset)
        << "\",\n"
        << "      \"countSubtypeOffset\": \""
        << HexU64(p.itemCountOffset)
        << "\",\n"
        << "      \"countSubtypeWidth\": "
        << p.itemCountWidth
        << "\n"
        << "    },\n"
        << "    \"containers\": {\n"
        << "      \"ownerOffset\": \""
        << HexU64(p.gameContainersOffset)
        << "\",\n"
        << "      \"tree\": {\"header\": \""
        << HexU64(p.containerMapHeaderOffset)
        << "\", \"size\": \""
        << HexU64(p.containerMapSizeOffset)
        << "\", \"left\": \""
        << HexU64(p.containerNodeLeftOffset)
        << "\", \"right\": \""
        << HexU64(p.containerNodeRightOffset)
        << "\", \"value\": \""
        << HexU64(p.containerNodeValueOffset)
        << "\"},\n"
        << "      \"object\": {\"name\": \""
        << HexU64(p.containerNameOffset)
        << "\", \"dequeMap\": \""
        << HexU64(p.containerDequeMapOffset)
        << "\", \"dequeMapSize\": \""
        << HexU64(p.containerDequeMapSizeOffset)
        << "\", \"dequeOffset\": \""
        << HexU64(p.containerDequeOffsetOffset)
        << "\", \"itemCount\": \""
        << HexU64(p.containerItemCountOffset)
        << "\", \"itemStorageMode\": \""
        << EscapeJson(p.containerItemStorageMode)
        << "\", \"itemElementStride\": "
        << p.containerItemElementStride
        << "}\n"
        << "    }\n"
        << "  },\n"
        << "  \"resolvers\": {\n"
        << "    \"localPlayer\": {\n"
        << "      \"preferred\": \"direct_global\",\n"
        << "      \"directGlobalRva\": \""
        << HexU64(p.directGlobalRva)
        << "\",\n"
        << "      \"indirect\": {\"globalRva\": \""
        << HexU64(p.indirectGlobalRva)
        << "\", \"ownerOffset\": \""
        << HexU64(p.ownerOffset)
        << "\"}\n"
        << "    },\n"
        << "    \"currentFloorTileStorage\": {\n"
        << "      \"mode\": \"runtime_resolve\",\n"
        << "      \"neverUseLastConfirmedOffsetAsFixed\": true,\n"
        << "      \"path\": {\"depth\": "
        << p.mapTilePathDepth
        << ", \"mapOffset\": \""
        << HexU64(p.mapTilePathMapOffset)
        << "\", \"childOffset\": \""
        << HexU64(p.mapTilePathChildOffset)
        << "\"},\n"
        << "      \"storage\": {\"mode\": \""
        << EscapeJson(p.mapTileStorageMode)
        << "\", \"elementStride\": "
        << p.mapTileStorageStride
        << "},\n"
        << "      \"lastConfirmedOffsetEvidenceOnly\": \""
        << HexU64(p.mapTilePathHeaderOffset)
        << "\",\n"
        << "      \"linearModel\": {\n"
        << "        \"status\": \""
        << (
            floorModel.confirmed
                ? "confirmed_from_runtime_observations"
                : "insufficient_observations"
        )
        << "\",\n"
        << "        \"base\": \""
        << HexU64(
            floorModel.confirmed &&
            floorModel.base >= 0
                ? static_cast<uintptr_t>(
                    floorModel.base)
                : 0
        )
        << "\",\n"
        << "        \"stride\": \""
        << HexU64(
            floorModel.confirmed &&
            floorModel.stride >= 0
                ? static_cast<uintptr_t>(
                    floorModel.stride)
                : 0
        )
        << "\"\n"
        << "      },\n"
        << "      \"observations\": [";

    for (size_t i = 0;
         i < floorModel.observations.size();
         ++i)
    {
        if (i)
            j << ",";

        j
            << "{\"z\": "
            << floorModel.observations[i].first
            << ", \"headerOffset\": \""
            << HexU64(
                floorModel.observations[i].second
            )
            << "\"}";
    }

    j
        << "]\n"
        << "    },\n"
        << "    \"inventory\": {\n"
        << "      \"mode\": \"semantic_item_array_then_logical_slot_transition\",\n"
        << "      \"status\": \""
        << EscapeJson(p.inventoryStatus)
        << "\"\n"
        << "    },\n"
        << "    \"containers\": {\n"
        << "      \"mode\": \"rtti_transition_then_collection_provenance_then_layout\",\n"
        << "      \"status\": \""
        << EscapeJson(p.containersStatus)
        << "\"\n"
        << "    },\n"
        << "    \"functions\": {\n"
        << "      \"policy\": \"otc_style_direct_lua_bind_primary_with_legacy_diagnostics\",\n"
        << "      \"status\": \""
        << EscapeJson(p.functionsStatus)
        << "\"\n"
        << "    },\n"
        << "    \"directBindResolver\": {\n"
        << "      \"gameObjectBaseRva\": \"" << HexU64(g_v49DirectState.gameObjectBaseRva) << "\",\n"
        << "      \"talkChannelRva\": \"" << HexU64(g_v49DirectState.talkChannelRva) << "\",\n"
        << "      \"mapObjectRva\": \"" << HexU64(g_v49DirectState.mapObjectRva) << "\",\n"
        << "      \"topUseThingRva\": \"" << HexU64(g_v49DirectState.topUseThingRva) << "\"\n"
        << "    }\n"
        << "  },\n"
        << "  \"contracts\": {\n"
        << "    \"nativeFunctions\": {\n";

    BMWriteFunctionJson(j, "gameAutoWalk", "Game::autoWalk", p.fnGameAutoWalk, p, true);
    BMWriteFunctionJson(j, "localPlayerAutoWalk", "LocalPlayer::autoWalk", p.fnLocalPlayerAutoWalk, p, true);
    BMWriteFunctionJson(j, "gameAttack", "Game::attack", p.fnGameAttack, p, true);
    BMWriteFunctionJson(j, "gameFollow", "Game::follow", p.fnGameFollow, p, true);
    BMWriteFunctionJson(j, "gameLook", "Game::look", p.fnGameLook, p, true);
    BMWriteFunctionJson(j, "gameDetailedLook", "Game::detailedLook", p.fnGameDetailedLook, p, true);
    BMWriteFunctionJson(j, "gameMove", "Game::move", p.fnGameMove, p, true);
    BMWriteFunctionJson(j, "gameUse", "Game::use", p.fnGameUse, p, true);
    BMWriteFunctionJson(j, "gameUseWith", "Game::useWith", p.fnGameUseWith, p, true);
    BMWriteFunctionJson(j, "gameTalk", "Game::talk", p.fnGameTalk, p, true);
    BMWriteFunctionJson(j, "mapGetTile", "Map::getTile", p.fnMapGetTile, p, true);
    BMWriteFunctionJson(j, "mapGetCreatureById", "Map::getCreatureById", p.fnMapGetCreatureById, p, true);
    BMWriteFunctionJson(j, "mapGetCreatureByName", "Map::getCreatureByName", p.fnMapGetCreatureByName, p, true);
    BMWriteFunctionJson(j, "containerGetItem", "Container::getItem", p.fnContainerGetItem, p, false);

    j
        << "    }\n"
        << "  },\n"
        << "  \"features\": {\n"
        << "    \"look\": {\n"
        << "      \"status\": \"" << EscapeJson(p.lookFeatureStatus) << "\",\n"
        << "      \"architecture\": \"x64\",\n"
        << "      \"hookFunction\": \"" << EscapeJson(p.lookHookFunction) << "\",\n"
        << "      \"hookRva\": \"" << HexU64(p.lookHookRva) << "\",\n"
        << "      \"hookArgument\": \"" << EscapeJson(p.lookHookArgument) << "\",\n"
        << "      \"thingIndirection\": " << p.lookThingIndirection << ",\n"
        << "      \"itemIdOffset\": \"" << HexU64(p.lookItemIdOffset) << "\",\n"
        << "      \"itemIdType\": \"" << EscapeJson(p.lookItemIdType) << "\",\n"
        << "      \"positionOffsets\": {\"x\": \"" << HexU64(p.lookPositionXOffset)
        << "\", \"y\": \"" << HexU64(p.lookPositionYOffset)
        << "\", \"z\": \"" << HexU64(p.lookPositionZOffset) << "\"},\n"
        << "      \"containerSentinel\": {\"enabled\": " << (p.lookContainerSentinelEnabled ? "true" : "false")
        << ", \"x\": \"" << HexU64(p.lookContainerSentinelX) << "\"},\n"
        << "      \"contextStatus\": \"" << EscapeJson(p.lookContextStatus) << "\"\n"
        << "    },\n"
        << "    \"hackLight\": {\n"
        << "      \"status\": \"" << EscapeJson(p.hackLightStatus) << "\",\n"
        << "      \"architecture\": \"x64\",\n"
        << "      \"storage\": \"local_player_field\",\n"
        << "      \"intensityOffset\": \"" << HexU64(p.lightIntensityOffset) << "\",\n"
        << "      \"type\": \"" << EscapeJson(p.lightIntensityType) << "\",\n"
        << "      \"observedValues\": {\"baseline\": " << p.lightObservedBaseline
        << ", \"torch\": " << p.lightObservedTorch
        << ", \"utevoLux\": " << p.lightObservedLux
        << ", \"utevoGranLux\": " << p.lightObservedGranLux << "},\n"
        << "      \"hackValue\": " << p.lightHackValue << ",\n"
        << "      \"restorePolicy\": \"snapshot_original\",\n"
        << "      \"calibrationMethod\": \"" << EscapeJson(p.lightCalibrationMethod) << "\",\n"
        << "      \"writeValidated\": " << (p.lightWriteValidated ? "true" : "false") << "\n"
        << "    }\n"
        << "  },\n"
        << "  \"x64FeatureDocumentation\": {\n"
        << "    \"version\": \"1.1\",\n"
        << "    \"pointerSize\": 8,\n"
        << "    \"lookRule\": \"Known build hooks are temporary and prologue-validated; new builds stay candidate until ABI is proven.\",\n"
        << "    \"lightRule\": \"Calibrate LocalPlayer u8, then require explicit write+restore validation before current-session PASS.\",\n"
        << "    \"writeRule\": \"Always snapshot and restore original light byte; do not copy a light offset across builds.\"\n"
        << "  },\n"
        << "  \"evidence\": {\n"
        << "    \"itemLayout\": \""
        << EscapeJson(p.itemLayoutStatus)
        << "\",\n"
        << "    \"inventory\": \""
        << EscapeJson(p.inventoryStatus)
        << "\",\n"
        << "    \"containers\": \""
        << EscapeJson(p.containersStatus)
        << "\",\n"
        << "    \"classification\": \""
        << EscapeJson(p.classificationStatus)
        << "\"\n"
        << "  },\n"
        << "  \"validation\": {\n"
        << "    \"fields\": {\n"
        << "      \"game.localPlayer\": {\"status\": \""
        << (p.gameLocalPlayer || p.gameRva ? "confirmed" : "pending")
        << "\", \"method\": \""
        << EscapeJson(p.gameStatus)
        << "\"},\n"
        << "      \"game.attackTarget\": {\"status\": \""
        << (p.gameAttackTarget ? "confirmed" : "pending")
        << "\", \"method\": \""
        << EscapeJson(p.gameStatus)
        << "\"},\n"
        << "      \"game.followTarget\": {\"status\": \""
        << (p.gameFollowTarget ? "confirmed" : "pending")
        << "\", \"method\": \""
        << EscapeJson(p.followStatus)
        << "\"},\n"
        << "      \"map.center\": {\"status\": \""
        << (p.mapCenterX && p.mapCenterY && p.mapCenterZ ? "confirmed" : "pending")
        << "\", \"method\": \""
        << EscapeJson(p.mapStatus)
        << "\"},\n"
        << "      \"tile.things\": {\"status\": \""
        << (p.tileThingsBegin && p.tileThingsEnd && p.tileThingsCap ? "confirmed" : "pending")
        << "\", \"method\": \""
        << EscapeJson(p.tileThingsStatus)
        << "\"},\n"
        << "      \"inventory.baseOffset\": {\"status\": \""
        << (p.inventoryBaseOffset && p.inventoryStatus.find("confirmed_") == 0 ? "confirmed" : "pending")
        << "\", \"method\": \""
        << EscapeJson(p.inventoryStatus)
        << "\"},\n"
        << "      \"item.idOffset\": {\"status\": \""
        << (p.itemIdOffset && p.itemLayoutStatus.find("confirmed_") == 0 ? "confirmed" : "pending")
        << "\", \"method\": \""
        << EscapeJson(p.itemLayoutStatus)
        << "\"},\n"
        << "      \"item.countSubtypeOffset\": {\"status\": \""
        << (
            p.itemCountOffset &&
            (
                p.itemLayoutStatus.find("confirmed_") == 0 ||
                p.itemLayoutStatus.find("partial_count_confirmed") == 0
            )
                ? "confirmed"
                : "pending"
        )
        << "\", \"method\": \""
        << EscapeJson(p.itemLayoutStatus)
        << "\"},\n"
        << "      \"containers.ownerOffset\": {\"status\": \""
        << (p.gameContainersOffset ? "confirmed" : "pending")
        << "\", \"method\": \""
        << EscapeJson(p.containersStatus)
        << "\"},\n"
        << "      \"containers.itemStorage\": {\"status\": \""
        << (p.containerDequeMapOffset && p.containerItemCountOffset ? "confirmed" : "pending")
        << "\", \"method\": \""
        << EscapeJson(p.containersStatus)
        << "\"}\n"
        << "    },\n"
        << "    \"modules\": {\n"
        << "      \"player\": \""
        << EscapeJson(p.status)
        << "\",\n"
        << "    \"game\": \""
        << EscapeJson(p.gameStatus)
        << "\",\n"
        << "    \"follow\": \""
        << EscapeJson(p.followStatus)
        << "\",\n"
        << "    \"map\": \""
        << EscapeJson(p.mapStatus)
        << "\",\n"
        << "    \"tileThings\": \""
        << EscapeJson(p.tileThingsStatus)
        << "\",\n"
        << "    \"mapTilePath\": \""
        << EscapeJson(p.mapTilePathStatus)
        << "\",\n"
        << "    \"monster\": \""
        << EscapeJson(p.monsterVtableStatus)
        << "\",\n"
        << "    \"itemClass\": \""
        << EscapeJson(p.itemVtableStatus)
        << "\",\n"
        << "    \"playerClass\": \""
        << EscapeJson(p.playerVtableStatus)
        << "\",\n"
        << "    \"classification\": \""
        << EscapeJson(p.classificationStatus)
        << "\",\n"
        << "    \"npc\": \""
        << EscapeJson(p.npcStatus)
        << "\",\n"
        << "    \"inventory\": \""
        << EscapeJson(p.inventoryStatus)
        << "\",\n"
        << "    \"itemLayout\": \""
        << EscapeJson(p.itemLayoutStatus)
        << "\",\n"
        << "    \"containers\": \""
        << EscapeJson(p.containersStatus)
        << "\",\n"
        << "      \"functions\": \""
        << EscapeJson(p.functionsStatus)
        << "\"\n"
        << "    }\n"
        << "  }\n"
        << "}\n";

    std::ofstream f(
        canonicalPath.str(),
        std::ios::out |
        std::ios::trunc
    );

    if (!f)
        return false;

    f << j.str();

    std::cout
        << "\n[SAVE] CANONICAL BUILDPROFILE V2:\n"
        << canonicalPath.str()
        << "\n"
        << "[SOURCE OF TRUTH] Este e o unico profile oficial desta build.\n"
        << "[READ-ONLY READY] "
        << (
            readOnlyReady
                ? "YES"
                : "NO"
        )
        << "\n"
        << "[STRICT READY] "
        << (
            strictReady
                ? "YES"
                : "NO - partial profile"
        )
        << "\n"
        << "[NATIVE ACTIONS READY] NO - semantic prototypes podem estar preenchidos; machine ABI/thread runtime ainda precisam validacao.\n";

    return true;
}

// ============================================================
// V1.5 - RUNTIME MONITOR
// ============================================================

const char* MonitorPresenceName(
    MonitorPresence state)
{
    switch (state)
    {
        case MonitorPresence::LoggedOut:
            return "LOGGED_OUT";

        case MonitorPresence::LoggedIn:
            return "LOGGED_IN";

        case MonitorPresence::Inconsistent:
            return "INCONSISTENT";
    }

    return "UNKNOWN";
}

bool IsReadableMonitorRange(
    uintptr_t address,
    size_t size)
{
    if (!address ||
        !size)
    {
        return false;
    }

    MEMORY_BASIC_INFORMATION mbi{};

    if (!VirtualQuery(
            reinterpret_cast<void*>(
                address
            ),
            &mbi,
            sizeof(mbi)))
    {
        return false;
    }

    if (mbi.State !=
            MEM_COMMIT ||
        !IsReadableProtection(
            mbi.Protect))
    {
        return false;
    }

    uintptr_t begin =
        reinterpret_cast<uintptr_t>(
            mbi.BaseAddress
        );

    uintptr_t end =
        begin +
        mbi.RegionSize;

    return
        address >= begin &&
        address + size <= end;
}

double MonitorReadDouble(
    uintptr_t address)
{
    double value = 0.0;

    SafeRead(
        address,
        value
    );

    return value;
}

bool ValidateMonitorLocalPlayer(
    uintptr_t localPlayer,
    const DbProfile& p,
    MonitorSample* out)
{
    if (!localPlayer)
        return false;

    if (!IsReadableMonitorRange(
            localPlayer,
            0x700))
    {
        return false;
    }

    uintptr_t vtable =
        ReadPtr(
            localPlayer
        );

    uintptr_t expectedVtable =
        g_exeBase +
        p.vtableRva;

    if (vtable !=
        expectedVtable)
    {
        return false;
    }

    uint32_t x =
        ReadU32(
            localPlayer +
            p.x
        );

    uint32_t y =
        ReadU32(
            localPlayer +
            p.y
        );

    uint8_t z =
        ReadU8(
            localPlayer +
            p.z
        );

    if (!PositionPlausible(
            x,
            y,
            z))
    {
        return false;
    }

    if (out)
    {
        out->vtableRva =
            vtable -
            g_exeBase;

        out->x = x;
        out->y = y;
        out->z = z;

        if (p.id)
        {
            out->id =
                ReadU32(
                    localPlayer +
                    p.id
                );
        }

        if (p.hpPercent)
        {
            out->hpPercent =
                ReadU8(
                    localPlayer +
                    p.hpPercent
                );
        }

        if (p.direction)
        {
            out->direction =
                ReadU32(
                    localPlayer +
                    p.direction
                );
        }

        if (p.health)
        {
            out->health =
                MonitorReadDouble(
                    localPlayer +
                    p.health
                );
        }

        if (p.maxHealth)
        {
            out->maxHealth =
                MonitorReadDouble(
                    localPlayer +
                    p.maxHealth
                );
        }

        if (p.capacity)
        {
            out->capacity =
                MonitorReadDouble(
                    localPlayer +
                    p.capacity
                );
        }

        if (p.experience)
        {
            out->experience =
                MonitorReadDouble(
                    localPlayer +
                    p.experience
                );
        }

        if (p.level)
        {
            out->level =
                MonitorReadDouble(
                    localPlayer +
                    p.level
                );
        }

        if (p.mana)
        {
            out->mana =
                MonitorReadDouble(
                    localPlayer +
                    p.mana
                );
        }

        if (p.maxMana)
        {
            out->maxMana =
                MonitorReadDouble(
                    localPlayer +
                    p.maxMana
                );
        }
    }

    return true;
}

void CopyMonitorDetails(
    MonitorSample& dst,
    const MonitorSample& src)
{
    dst.vtableRva =
        src.vtableRva;

    dst.x =
        src.x;

    dst.y =
        src.y;

    dst.z =
        src.z;

    dst.id =
        src.id;

    dst.hpPercent =
        src.hpPercent;

    dst.direction =
        src.direction;

    dst.health =
        src.health;

    dst.maxHealth =
        src.maxHealth;

    dst.capacity =
        src.capacity;

    dst.experience =
        src.experience;

    dst.level =
        src.level;

    dst.mana =
        src.mana;

    dst.maxMana =
        src.maxMana;
}

MonitorSample TakeMonitorSample(
    const DbProfile& p)
{
    MonitorSample sample{};

    sample.tick =
        GetTickCount64();

    if (p.directGlobalRva)
    {
        sample.directRaw =
            ReadPtr(
                g_exeBase +
                p.directGlobalRva
            );
    }

    if (p.indirectGlobalRva &&
        p.ownerOffset)
    {
        sample.indirectOwner =
            ReadPtr(
                g_exeBase +
                p.indirectGlobalRva
            );

        if (sample.indirectOwner)
        {
            sample.indirectRaw =
                ReadPtr(
                    sample.indirectOwner +
                    p.ownerOffset
                );
        }
    }

    MonitorSample directDetails{};
    MonitorSample indirectDetails{};

    if (p.directGlobalRva)
    {
        sample.directValid =
            ValidateMonitorLocalPlayer(
                sample.directRaw,
                p,
                &directDetails
            );
    }

    if (p.indirectGlobalRva &&
        p.ownerOffset)
    {
        sample.indirectValid =
            ValidateMonitorLocalPlayer(
                sample.indirectRaw,
                p,
                &indirectDetails
            );
    }

    bool hasDirect =
        p.directGlobalRva != 0;

    bool hasIndirect =
        p.indirectGlobalRva != 0 &&
        p.ownerOffset != 0;

    sample.pathsAgree =
        hasDirect &&
        hasIndirect &&
        sample.directValid &&
        sample.indirectValid &&
        sample.directRaw ==
            sample.indirectRaw;

    if (sample.pathsAgree)
    {
        sample.localPlayer =
            sample.directRaw;

        CopyMonitorDetails(
            sample,
            directDetails
        );

        sample.state =
            MonitorPresence::LoggedIn;

        return sample;
    }

    if (sample.directValid &&
        !sample.indirectValid)
    {
        sample.localPlayer =
            sample.directRaw;

        CopyMonitorDetails(
            sample,
            directDetails
        );

        sample.state =
            MonitorPresence::LoggedIn;

        return sample;
    }

    if (!sample.directValid &&
        sample.indirectValid)
    {
        sample.localPlayer =
            sample.indirectRaw;

        CopyMonitorDetails(
            sample,
            indirectDetails
        );

        sample.state =
            MonitorPresence::LoggedIn;

        return sample;
    }

    if (sample.directValid &&
        sample.indirectValid &&
        sample.directRaw !=
            sample.indirectRaw)
    {
        sample.state =
            MonitorPresence::Inconsistent;

        return sample;
    }

    sample.state =
        MonitorPresence::LoggedOut;

    return sample;
}

void PrintMonitorSnapshot(
    const MonitorSample& sample)
{
    std::cout
        << "\n============================================================\n"
        << "                      RUNTIME SNAPSHOT\n"
        << "============================================================\n"
        << "State           : "
        << MonitorPresenceName(
            sample.state
        )
        << "\n"
        << "Direct raw      : "
        << HexPtr(
            sample.directRaw
        )
        << "  valid="
        << (
            sample.directValid
                ? "YES"
                : "NO"
        )
        << "\n"
        << "Indirect owner  : "
        << HexPtr(
            sample.indirectOwner
        )
        << "\n"
        << "Indirect raw    : "
        << HexPtr(
            sample.indirectRaw
        )
        << "  valid="
        << (
            sample.indirectValid
                ? "YES"
                : "NO"
        )
        << "\n"
        << "Paths agree     : "
        << (
            sample.pathsAgree
                ? "YES"
                : "NO"
        )
        << "\n";

    if (sample.state ==
        MonitorPresence::LoggedIn)
    {
        std::cout
            << "LocalPlayer     : "
            << HexPtr(
                sample.localPlayer
            )
            << "\n"
            << "VTable RVA      : "
            << HexU64(
                sample.vtableRva
            )
            << "\n"
            << "Position        : "
            << sample.x
            << ","
            << sample.y
            << ","
            << static_cast<unsigned>(
                sample.z
            )
            << "\n"
            << "ID              : "
            << sample.id
            << "\n"
            << "HP%             : "
            << static_cast<unsigned>(
                sample.hpPercent
            )
            << "\n"
            << "Direction       : "
            << sample.direction
            << "\n"
            << "Health          : "
            << sample.health
            << " / "
            << sample.maxHealth
            << "\n"
            << "Mana            : "
            << sample.mana
            << " / "
            << sample.maxMana
            << "\n"
            << "Capacity        : "
            << sample.capacity
            << "\n"
            << "Experience      : "
            << sample.experience
            << "\n"
            << "Level           : "
            << sample.level
            << "\n";
    }
}

void UpdateMonitorStats(
    MonitorStats& stats,
    const MonitorSample& sample)
{
    ++stats.samples;

    if (sample.state ==
        MonitorPresence::LoggedOut)
    {
        ++stats.loggedOutSamples;
    }
    else if (sample.state ==
             MonitorPresence::LoggedIn)
    {
        ++stats.loggedInSamples;
    }
    else
    {
        ++stats.inconsistentSamples;
    }

    if (sample.directValid)
        ++stats.directValidSamples;

    if (sample.indirectValid)
        ++stats.indirectValidSamples;

    if (sample.pathsAgree)
        ++stats.agreementSamples;

    if (sample.directValid &&
        sample.indirectValid &&
        !sample.pathsAgree)
    {
        ++stats.mismatchSamples;
    }
}

void AddMonitorEvent(
    MonitorStats& stats,
    const char* type,
    const MonitorSample& sample)
{
    MonitorEvent event{};

    event.type =
        type;

    event.tick =
        sample.tick;

    event.localPlayer =
        sample.localPlayer;

    event.pathsAgree =
        sample.pathsAgree;

    event.vtableRva =
        sample.vtableRva;

    event.x =
        sample.x;

    event.y =
        sample.y;

    event.z =
        sample.z;

    event.id =
        sample.id;

    stats.events.push_back(
        std::move(event)
    );
}

bool MonitorHotkeyPressed(
    int vk)
{
    return
        (
            GetAsyncKeyState(
                vk
            ) &
            1
        ) != 0;
}

bool IsMultiSessionValidated(
    const DbProfile& profile,
    const MonitorStats& stats)
{
    bool pathEvidence = false;

    if (profile.directGlobalRva &&
        profile.indirectGlobalRva &&
        profile.ownerOffset)
    {
        pathEvidence =
            stats.agreementSamples > 0 &&
            stats.mismatchSamples == 0;
    }
    else
    {
        pathEvidence =
            stats.loggedInSamples > 0;
    }

    return
        stats.loginEvents >= 2 &&
        stats.logoutEvents >= 1 &&
        pathEvidence;
}

bool SaveRuntimeValidationReport(
    const BuildInfo& build,
    const DbProfile& profile,
    const MonitorStats& stats,
    const MonitorSample& lastSample,
    const std::string& directory)
{
    std::ostringstream filename;

    filename
        << directory
        << "\\otclab_runtime_v15_"
        << std::hex
        << std::uppercase
        << build.timestamp
        << "_"
        << build.textHash
        << ".json";

    std::ofstream f(
        filename.str(),
        std::ios::out |
        std::ios::trunc
    );

    if (!f)
        return false;

    bool validated =
        IsMultiSessionValidated(
            profile,
            stats
        );

    f
        << "{\n"
        << "  \"format\": \"otclab-runtime-validation-v1.5\",\n"
        << "  \"profile\": \""
        << EscapeJson(
            profile.name
        )
        << "\",\n"
        << "  \"profileStatus\": \""
        << EscapeJson(
            profile.status
        )
        << "\",\n"
        << "  \"timestamp\": \""
        << HexU64(
            build.timestamp
        )
        << "\",\n"
        << "  \"textHashFNV1A64\": \""
        << HexU64(
            build.textHash
        )
        << "\",\n"
        << "  \"multiSessionValidated\": "
        << (
            validated
                ? "true"
                : "false"
        )
        << ",\n"
        << "  \"samples\": "
        << stats.samples
        << ",\n"
        << "  \"loginEvents\": "
        << stats.loginEvents
        << ",\n"
        << "  \"logoutEvents\": "
        << stats.logoutEvents
        << ",\n"
        << "  \"pointerChangeEvents\": "
        << stats.pointerChangeEvents
        << ",\n"
        << "  \"agreementSamples\": "
        << stats.agreementSamples
        << ",\n"
        << "  \"mismatchSamples\": "
        << stats.mismatchSamples
        << ",\n"
        << "  \"lastState\": \""
        << MonitorPresenceName(
            lastSample.state
        )
        << "\",\n"
        << "  \"lastLocalPlayer\": \""
        << HexPtr(
            lastSample.localPlayer
        )
        << "\",\n"
        << "  \"events\": [\n";

    for (size_t i = 0;
         i < stats.events.size();
         ++i)
    {
        const auto& event =
            stats.events[i];

        f
            << "    {\n"
            << "      \"type\": \""
            << EscapeJson(
                event.type
            )
            << "\",\n"
            << "      \"tick\": "
            << event.tick
            << ",\n"
            << "      \"localPlayer\": \""
            << HexPtr(
                event.localPlayer
            )
            << "\",\n"
            << "      \"pathsAgree\": "
            << (
                event.pathsAgree
                    ? "true"
                    : "false"
            )
            << ",\n"
            << "      \"vtableRva\": \""
            << HexU64(
                event.vtableRva
            )
            << "\",\n"
            << "      \"x\": "
            << event.x
            << ",\n"
            << "      \"y\": "
            << event.y
            << ",\n"
            << "      \"z\": "
            << static_cast<unsigned>(
                event.z
            )
            << ",\n"
            << "      \"id\": "
            << event.id
            << "\n"
            << "    }";

        if (i + 1 <
            stats.events.size())
        {
            f << ",";
        }

        f << "\n";
    }

    f
        << "  ]\n"
        << "}\n";

    std::cout
        << "\n[SAVE] Runtime validation:\n"
        << filename.str()
        << "\n";

    return true;
}

void RunRuntimeMonitor(
    const BuildInfo& build,
    DbProfile& profile,
    std::vector<DbProfile>& database,
    int profileIndex,
    const std::string& databasePath,
    const std::string& dllDirectory)
{
    PrintDbProfile(
        profile
    );

    std::cout
        << "\n[DISCOVERY STATUS]\n"
        << "  [FEITO] Build fingerprint\n"
        << "  [FEITO] LocalPlayer + Player layout\n"
        << "  [FEITO] Game + AttackTarget\n"
        << "  ["
        << (
            (
                profile.followStatus ==
                    "discovered_runtime_selfcheck_pass" ||
                profile.followStatus ==
                    "confirmed_runtime_follow_cycle"
            )
                ? "FEITO"
                : "CHECK"
        )
        << "] FollowTarget\n"
        << "  ["
        << (
            (
                profile.mapStatus ==
                    "discovered_runtime_selfcheck_pass" ||
                profile.mapStatus ==
                    "confirmed_runtime_position_transitions"
            )
                ? "FEITO"
                : "CHECK"
        )
        << "] Map\n"
        << "  ["
        << (
            (
                profile.tileThingsStatus ==
                    "discovered_runtime_selfcheck_pass" ||
                profile.tileThingsStatus ==
                    "confirmed_runtime_localplayer_two_tiles"
            )
                ? "FEITO"
                : "CHECK"
        )
        << "] Tile::things\n"
        << "  ["
        << (
            profile.mapTilePathStatus ==
                "confirmed_runtime_two_positions"
                ? "FEITO"
                : "CHECK"
        )
        << "] Map -> Tile path\n"
        << "  ["
        << (
            profile.monsterVtableStatus.find(
                "confirmed_") == 0
                ? "FEITO"
                : "CHECK"
        )
        << "] Monster VTable\n"
        << "  ["
        << (
            profile.classificationStatus.find(
                "confirmed_") == 0
                ? "FEITO"
                : (
                    profile.classificationStatus.find(
                        "partial_") == 0
                        ? "PARCIAL"
                        : "CHECK"
                )
        )
        << "] Classification core\n";

    if (!DbProfileMonitorReady(
            profile))
    {
        std::cout
            << "\n[MONITOR] Profile salvo, mas ainda nao possui dados\n"
            << "suficientes para monitor automatico.\n";

        return;
    }

    std::cout
        << "\n============================================================\n"
        << "                     RUNTIME WATCH\n"
        << "============================================================\n"
        << "A partir daqui nao precisa digitar stats.\n\n"
        << "Teste recomendado:\n"
        << "  1. fique logado ou faca login\n"
        << "  2. faca logout\n"
        << "  3. faca login novamente\n\n"
        << "F6  = snapshot manual\n"
        << "F7  = salvar relatorio\n"
        << "END = salvar e descarregar\n"
        << "============================================================\n";

    MonitorStats stats{};

    MonitorSample last =
        TakeMonitorSample(
            profile
        );

    UpdateMonitorStats(
        stats,
        last
    );

    MonitorPresence stableState =
        last.state;

    MonitorPresence pendingState =
        stableState;

    int pendingCount = 0;

    uintptr_t stablePointer =
        last.state ==
                MonitorPresence::LoggedIn
            ? last.localPlayer
            : 0;

    uintptr_t previousSessionPointer =
        stablePointer;

    std::cout
        << "[START] State = "
        << MonitorPresenceName(
            stableState
        )
        << "\n";

    if (stableState ==
        MonitorPresence::LoggedIn)
    {
        ++stats.loginEvents;

        AddMonitorEvent(
            stats,
            "initial_logged_in",
            last
        );

        PrintMonitorSnapshot(
            last
        );
    }

    for (;;)
    {
        Sleep(250);

        MonitorSample sample =
            TakeMonitorSample(
                profile
            );

        UpdateMonitorStats(
            stats,
            sample
        );

        if (sample.state !=
            stableState)
        {
            if (sample.state ==
                pendingState)
            {
                ++pendingCount;
            }
            else
            {
                pendingState =
                    sample.state;

                pendingCount =
                    1;
            }

            if (pendingCount >= 3)
            {
                stableState =
                    pendingState;

                pendingCount =
                    0;

                if (stableState ==
                    MonitorPresence::LoggedIn)
                {
                    ++stats.loginEvents;

                    if (previousSessionPointer &&
                        sample.localPlayer &&
                        previousSessionPointer !=
                            sample.localPlayer)
                    {
                        ++stats.pointerChangeEvents;

                        AddMonitorEvent(
                            stats,
                            "localplayer_pointer_changed",
                            sample
                        );

                        std::cout
                            << "\n[POINTER CHANGED]\n"
                            << "Old LocalPlayer : "
                            << HexPtr(
                                previousSessionPointer
                            )
                            << "\n"
                            << "New LocalPlayer : "
                            << HexPtr(
                                sample.localPlayer
                            )
                            << "\n";
                    }

                    previousSessionPointer =
                        sample.localPlayer;

                    stablePointer =
                        sample.localPlayer;

                    AddMonitorEvent(
                        stats,
                        "login_detected",
                        sample
                    );

                    std::cout
                        << "\n============================================================\n"
                        << "                     LOGIN DETECTED\n"
                        << "============================================================\n";

                    PrintMonitorSnapshot(
                        sample
                    );
                }
                else if (stableState ==
                         MonitorPresence::LoggedOut)
                {
                    ++stats.logoutEvents;

                    stablePointer =
                        0;

                    AddMonitorEvent(
                        stats,
                        "logout_detected",
                        sample
                    );

                    std::cout
                        << "\n============================================================\n"
                        << "                    LOGOUT DETECTED\n"
                        << "============================================================\n"
                        << "Direct raw   : "
                        << HexPtr(
                            sample.directRaw
                        )
                        << "\n"
                        << "Indirect raw : "
                        << HexPtr(
                            sample.indirectRaw
                        )
                        << "\n";
                }
                else
                {
                    AddMonitorEvent(
                        stats,
                        "inconsistent_paths",
                        sample
                    );

                    std::cout
                        << "\n[WARNING] DIRECT/INDIRECT inconsistentes.\n";

                    PrintMonitorSnapshot(
                        sample
                    );
                }
            }
        }
        else
        {
            pendingCount = 0;

            pendingState =
                stableState;
        }

        if (stableState ==
                MonitorPresence::LoggedIn &&
            sample.state ==
                MonitorPresence::LoggedIn &&
            stablePointer &&
            sample.localPlayer &&
            stablePointer !=
                sample.localPlayer)
        {
            uintptr_t old =
                stablePointer;

            stablePointer =
                sample.localPlayer;

            previousSessionPointer =
                sample.localPlayer;

            ++stats.pointerChangeEvents;

            AddMonitorEvent(
                stats,
                "localplayer_pointer_changed_while_logged_in",
                sample
            );

            std::cout
                << "\n[POINTER CHANGED WHILE LOGGED IN]\n"
                << "Old : "
                << HexPtr(
                    old
                )
                << "\n"
                << "New : "
                << HexPtr(
                    stablePointer
                )
                << "\n";
        }

        last =
            sample;

        if (MonitorHotkeyPressed(
                VK_F6))
        {
            PrintMonitorSnapshot(
                sample
            );
        }

        if (MonitorHotkeyPressed(
                VK_F7))
        {
            if (IsMultiSessionValidated(
                    profile,
                    stats))
            {
                profile.status =
                    "confirmed_runtime_multi_session";

                if (profileIndex >= 0 &&
                    profileIndex <
                        static_cast<int>(
                            database.size()
                        ))
                {
                    database[
                        profileIndex
                    ] = profile;

                    SaveProfileDatabase(
                        databasePath,
                        database
                    );
                }
            }

            SaveRuntimeValidationReport(
                build,
                profile,
                stats,
                sample,
                dllDirectory
            );
        }

        if (MonitorHotkeyPressed(
                VK_END))
        {
            if (IsMultiSessionValidated(
                    profile,
                    stats))
            {
                profile.status =
                    "confirmed_runtime_multi_session";

                if (profileIndex >= 0 &&
                    profileIndex <
                        static_cast<int>(
                            database.size()
                        ))
                {
                    database[
                        profileIndex
                    ] = profile;

                    SaveProfileDatabase(
                        databasePath,
                        database
                    );
                }
            }

            SaveRuntimeValidationReport(
                build,
                profile,
                stats,
                sample,
                dllDirectory
            );

            std::cout
                << "\n============================================================\n"
                << "                       FINAL STATS\n"
                << "============================================================\n"
                << "Login events      : "
                << stats.loginEvents
                << "\n"
                << "Logout events     : "
                << stats.logoutEvents
                << "\n"
                << "Pointer changes   : "
                << stats.pointerChangeEvents
                << "\n"
                << "Agreement samples : "
                << stats.agreementSamples
                << "\n"
                << "Mismatch samples  : "
                << stats.mismatchSamples
                << "\n"
                << "Profile status    : "
                << profile.status
                << "\n";

            break;
        }
    }
}


// ============================================================
// BUILDMIGRATOR V2 - ASSISTED CALIBRATION ORCHESTRATOR
//
// Policy:
//   PASS      -> continue automatically.
//   CALIBRATE -> user can repeat the same guided test.
//   SKIP      -> preserve everything already learned and continue where safe.
//   STOP      -> save the partial profile and leave the wizard.
//
// Raw runtime pointers are NOT compared across sessions. The checks are
// based on fingerprint, RVAs, offsets, object shape and semantic transitions.
// ============================================================

enum class BMGuidedChoice
{
    Retry,
    Skip,
    Stop
};

BMGuidedChoice BMAskGuidedChoice(
    const std::string& moduleName)
{
    while (true)
    {
        std::cout
            << "\n[CALIBRATE] "
            << moduleName
            << " ainda nao fechou com evidencia suficiente.\n"
            << "  R = repetir/calibrar este modulo\n"
            << "  S = pular por enquanto e salvar como pending\n"
            << "  Q = salvar o que ja foi encontrado e encerrar wizard\n"
            << "Escolha [R/S/Q]: ";

        std::string line;

        std::getline(
            std::cin,
            line
        );

        if (line.empty())
            continue;

        char c =
            static_cast<char>(
                std::toupper(
                    static_cast<unsigned char>(
                        line[0]
                    )
                )
            );

        if (c == 'R')
            return BMGuidedChoice::Retry;

        if (c == 'S')
            return BMGuidedChoice::Skip;

        if (c == 'Q')
            return BMGuidedChoice::Stop;
    }
}

bool BMRunGuidedModule(
    const std::string& moduleName,
    const std::function<bool()>& action,
    bool& stopRequested)
{
    size_t attempt = 0;

    while (!stopRequested)
    {
        ++attempt;

        std::cout
            << "\n============================================================\n"
            << "                  MODULE: "
            << moduleName
            << "\n"
            << "============================================================\n"
            << "Attempt              : "
            << attempt
            << "\n";

        bool ok =
            action();

        if (ok)
        {
            std::cout
                << "[PASS] "
                << moduleName
                << "\n";

            return true;
        }

        BMGuidedChoice choice =
            BMAskGuidedChoice(
                moduleName
            );

        if (choice ==
            BMGuidedChoice::Retry)
        {
            std::cout
                << "[RETRY] Mantendo candidatos/evidencias ja coletados quando aplicavel.\n";

            continue;
        }

        if (choice ==
            BMGuidedChoice::Skip)
        {
            std::cout
                << "[SKIP] "
                << moduleName
                << " ficou pendente.\n";

            return false;
        }

        stopRequested = true;

        std::cout
            << "[STOP] Wizard sera encerrado depois de salvar o profile parcial.\n";

        return false;
    }

    return false;
}

void BMCopyPlayerDiscovery(
    DbProfile& target,
    const DbProfile& learned)
{
    target.vtableRva =
        learned.vtableRva;

    target.directGlobalRva =
        learned.directGlobalRva;

    target.indirectGlobalRva =
        learned.indirectGlobalRva;

    target.ownerOffset =
        learned.ownerOffset;

    target.x =
        learned.x;

    target.y =
        learned.y;

    target.z =
        learned.z;

    target.id =
        learned.id;

    target.hpPercent =
        learned.hpPercent;

    target.direction =
        learned.direction;

    target.health =
        learned.health;

    target.maxHealth =
        learned.maxHealth;

    target.capacity =
        learned.capacity;

    target.experience =
        learned.experience;

    target.level =
        learned.level;

    target.mana =
        learned.mana;

    target.maxMana =
        learned.maxMana;

    target.status =
        "guided_player_recalibrated";

    // Anything downstream must be revalidated after changing the player anchor.
    target.gameStatus =
        "needs_revalidate";

    target.followStatus =
        "needs_revalidate";

    target.mapStatus =
        "needs_revalidate";

    target.tileThingsStatus =
        "needs_revalidate";

    target.mapTilePathStatus =
        "needs_revalidate";

    target.monsterVtableStatus =
        "needs_revalidate";

    target.itemVtableStatus =
        "needs_revalidate";

    target.playerVtableStatus =
        "needs_revalidate";

    target.classificationStatus =
        "needs_revalidate";

    target.npcStatus =
        "needs_revalidate";

    target.inventoryStatus =
        "needs_revalidate";

    target.itemLayoutStatus =
        "needs_revalidate";

    target.containersStatus =
        "needs_revalidate";

    target.functionsStatus =
        "needs_revalidate";
}

bool BMRecalibratePlayer(
    const BuildInfo& build,
    DbProfile& profile,
    std::vector<DbProfile>& database,
    int profileIndex,
    const std::string& databasePath)
{
    std::cout
        << "\n============================================================\n"
        << "              PLAYER GUIDED RECALIBRATION\n"
        << "============================================================\n"
        << "Digite os valores atuais. Se algum campo ficar ambiguo,\n"
        << "o calibrador antigo de transicoes sera usado novamente.\n";

    BulkInput input =
        AskBulkInput();

    Candidate bestCandidate{};
    BaseHypothesis bestBase{};

    if (!DiscoverLocalPlayer(
            input,
            bestCandidate,
            bestBase))
    {
        std::cout
            << "[PLAYER] Nenhuma base segura encontrada nesta tentativa.\n";

        return false;
    }

    if (bestBase.score < 12)
    {
        std::cout
            << "[PLAYER] Base score baixo: "
            << bestBase.score
            << "\n";

        return false;
    }

    ProfileFields fields =
        ResolveBulkLocally(
            bestBase.base,
            input
        );

    PrintFields(
        fields
    );

    std::cout
        << "\n[PLAYER] SMART RETRY / VALUE TRANSITIONS\n";

    RetryPendingFields(
        bestBase.base,
        fields
    );

    PositionCalibration position =
        CalibratePositionAndDirection(
            bestBase.base
        );

    PointerDiscovery pointers =
        DiscoverPointerPath(
            bestBase.base
        );

    DbProfile learned =
        BuildDatabaseProfile(
            build,
            bestBase,
            fields,
            position,
            pointers
        );

    if (!DbProfileMonitorReady(
            learned))
    {
        std::cout
            << "[PLAYER] Recalibracao ainda nao produziu um profile monitoravel.\n";

        return false;
    }

    BMCopyPlayerDiscovery(
        profile,
        learned
    );

    if (profileIndex >= 0 &&
        profileIndex <
            static_cast<int>(
                database.size()))
    {
        database[
            static_cast<size_t>(
                profileIndex)
        ] = profile;

        SaveProfileDatabase(
            databasePath,
            database
        );
    }

    std::cout
        << "\n[PASS] PLAYER RECALIBRATED\n"
        << "VTable RVA           : "
        << HexU64(profile.vtableRva)
        << "\n"
        << "Direct Global RVA    : "
        << HexU64(profile.directGlobalRva)
        << "\n"
        << "Indirect Global RVA  : "
        << HexU64(profile.indirectGlobalRva)
        << "\n";

    return true;
}

bool BMFastValidateKnownPlayer(
    DbProfile& profile)
{
    uintptr_t localPlayer =
        ResolveProfileLocalPlayerForDiscovery(
            profile
        );

    if (!localPlayer)
        return false;

    MonitorSample sample =
        TakeMonitorSample(
            profile
        );

    if (sample.state !=
            MonitorPresence::LoggedIn ||
        !sample.localPlayer)
    {
        return false;
    }

    const bool hasIndirect =
        profile.indirectGlobalRva != 0 &&
        profile.ownerOffset != 0;

    const bool pathCheck =
        hasIndirect
            ? sample.pathsAgree
            : sample.directValid;

    return
        pathCheck &&
        sample.vtableRva ==
            profile.vtableRva &&
        PositionPlausible(
            sample.x,
            sample.y,
            sample.z
        );
}

bool BMEnsureKnownPlayer(
    const BuildInfo& build,
    DbProfile& profile,
    std::vector<DbProfile>& database,
    int profileIndex,
    const std::string& databasePath,
    bool& stopRequested)
{
    while (!stopRequested)
    {
        std::cout
            << "\n============================================================\n"
            << "                 PLAYER FAST CHECK\n"
            << "============================================================\n"
            << "Entre no personagem e deixe HP/Mana/XP/Cap visiveis.\n";

        WaitEnter(
            "Quando estiver logado e parado, pressione ENTER..."
        );

        // A short settling window avoids classifying the login transition
        // itself as profile drift.
        for (int i = 0;
             i < 20;
             ++i)
        {
            if (BMFastValidateKnownPlayer(
                    profile))
            {
                std::cout
                    << "[PASS] PLAYER / LOCALPLAYER\n";

                return true;
            }

            Sleep(250);
        }

        std::cout
            << "[CHECK] O Player salvo nao validou nesta sessao/build.\n"
            << "Isso pode ser login incompleto ou drift de RVA/offset.\n";

        BMGuidedChoice choice =
            BMAskGuidedChoice(
                "PLAYER / LOCALPLAYER"
            );

        if (choice ==
            BMGuidedChoice::Retry)
        {
            if (AskYesNo(
                    "Refazer agora a calibracao completa com HP/Mana/XP/Cap? [S/N]: "))
            {
                if (BMRecalibratePlayer(
                        build,
                        profile,
                        database,
                        profileIndex,
                        databasePath))
                {
                    return true;
                }

                std::cout
                    << "[PLAYER] Recalibracao nao fechou. Podemos tentar novamente.\n";
            }

            continue;
        }

        if (choice ==
            BMGuidedChoice::Skip)
        {
            return false;
        }

        stopRequested = true;
        return false;
    }

    return false;
}

bool BMDataCompletionReady(
    const DbProfile& profile)
{
    const bool npc =
        profile.npcVtableRva != 0 &&
        profile.npcStatus.find(
            "confirmed_") == 0;

    const bool inventory =
        profile.inventoryBaseOffset != 0 &&
        profile.inventoryStatus.find(
            "confirmed_") == 0;

    const bool item =
        profile.itemVtableRva != 0 &&
        profile.itemIdOffset != 0 &&
        profile.itemCountOffset != 0 &&
        profile.itemLayoutStatus.find(
            "confirmed_") == 0;

    const bool containers =
        profile.gameContainersOffset != 0 &&
        (
            profile.containersStatus ==
                "confirmed_runtime_open_container_tree_and_items" ||
            profile.containersStatus ==
                "confirmed_runtime_container_owner_and_layout"
        );

    return
        npc &&
        inventory &&
        item &&
        containers;
}


// ============================================================
// V4.6 - CROME x64 FEATURES: LOOK CONTRACT + PLAYER LIGHT
// ============================================================

struct BMLightCandidate
{
    uintptr_t offset = 0;
    uint8_t base = 0;
    uint8_t active = 0;
    uint8_t returned = 0;
    int score = 0;
};

bool BMCaptureLocalPlayerBytes(
    uintptr_t localPlayer,
    std::vector<uint8_t>& out)
{
    out.assign(
        FEATURE_LIGHT_SCAN_END -
        FEATURE_LIGHT_SCAN_BEGIN,
        0
    );

    for (uintptr_t off = FEATURE_LIGHT_SCAN_BEGIN;
         off < FEATURE_LIGHT_SCAN_END;
         ++off)
    {
        uint8_t value = 0;

        if (!SafeRead(
                localPlayer + off,
                value))
        {
            return false;
        }

        out[off - FEATURE_LIGHT_SCAN_BEGIN] = value;
    }

    return true;
}

std::vector<BMLightCandidate> BMRankLightCandidates(
    const std::vector<uint8_t>& base,
    const std::vector<uint8_t>& active,
    const std::vector<uint8_t>& returned)
{
    std::vector<BMLightCandidate> out;

    if (base.size() != active.size() ||
        base.size() != returned.size())
    {
        return out;
    }

    for (size_t i = 0; i < base.size(); ++i)
    {
        const uint8_t a = base[i];
        const uint8_t b = active[i];
        const uint8_t c = returned[i];

        if (a == b)
            continue;

        BMLightCandidate candidate{};
        candidate.offset =
            FEATURE_LIGHT_SCAN_BEGIN + i;
        candidate.base = a;
        candidate.active = b;
        candidate.returned = c;

        // Exact A -> B -> A transition is the strongest signal.
        if (c == a)
            candidate.score += 160;

        // Creature light intensity is normally a small byte.
        if (a <= 32 && b <= 32)
            candidate.score += 55;

        // Prefer a meaningful intensity increase, but do not require it.
        if (b > a)
            candidate.score += 35;

        // Creature base fields commonly live before the large stat block.
        if (candidate.offset < 0x300)
            candidate.score += 25;

        // Avoid volatile pointer bytes / obviously huge byte noise when possible.
        if (a <= 64 && b <= 64 && c <= 64)
            candidate.score += 15;

        out.push_back(candidate);
    }

    std::sort(
        out.begin(),
        out.end(),
        [](const BMLightCandidate& lhs,
           const BMLightCandidate& rhs)
        {
            if (lhs.score != rhs.score)
                return lhs.score > rhs.score;

            return lhs.offset < rhs.offset;
        }
    );

    return out;
}

void BMPrintLightCandidates(
    const char* label,
    const std::vector<BMLightCandidate>& candidates)
{
    std::cout
        << "\n[LIGHT][" << label << "] candidatos u8:\n";

    const size_t count =
        std::min<size_t>(
            candidates.size(),
            12
        );

    if (!count)
    {
        std::cout
            << "  nenhum candidato A -> B -> A no LocalPlayer.\n";
        return;
    }

    for (size_t i = 0; i < count; ++i)
    {
        const auto& c = candidates[i];

        std::cout
            << "  #" << std::setw(2) << std::setfill('0')
            << (i + 1)
            << std::setfill(' ')
            << " off=+" << HexU64(c.offset)
            << "  " << static_cast<unsigned>(c.base)
            << " -> " << static_cast<unsigned>(c.active)
            << " -> " << static_cast<unsigned>(c.returned)
            << "  score=" << c.score
            << (c.returned == c.base ? " RETURNED" : "")
            << "\n";
    }
}

bool BMIsClassicFeatureReferenceBuild(
    const BuildInfo& build)
{
    return
        build.timestamp == 0x6AA3019AUL &&
        build.sizeOfImage == 0x14C1000UL &&
        build.textHash == 0x602E746BAE706D6CULL;
}

bool BMIsOldersFeatureReferenceBuild(
    const BuildInfo& build)
{
    return
        build.timestamp == 0x6AA9FA57UL &&
        build.sizeOfImage == 0x17BF000UL &&
        build.textHash == 0x89D3D35243890EA2ULL;
}

void BMRefreshLookFeatureContract(
    const BuildInfo& build,
    DbProfile& p)
{
    // These two fingerprints were runtime-tested with isolated probes.
    if (BMIsClassicFeatureReferenceBuild(build))
    {
        p.lookFeatureStatus = "confirmed_runtime";
        p.lookHookFunction = "gameLook";
        p.lookHookRva = 0x164090;
        p.lookHookArgument = "RDX";
        p.lookThingIndirection = 1;
        p.lookItemIdOffset = 0x40;
        p.lookItemIdType = "u32";
        p.lookPositionXOffset = 0;
        p.lookPositionYOffset = 0;
        p.lookPositionZOffset = 0;
        p.lookContainerSentinelEnabled = false;
        p.lookContainerSentinelX = 0;
        p.lookContextStatus = "item_id_confirmed_context_pending";
        return;
    }

    if (BMIsOldersFeatureReferenceBuild(build))
    {
        p.lookFeatureStatus = "confirmed_runtime";
        p.lookHookFunction = "gameDetailedLook";
        p.lookHookRva = 0x163B10;
        p.lookHookArgument = "RDX";
        p.lookThingIndirection = 1;
        p.lookItemIdOffset = 0x38;
        p.lookItemIdType = "u32";
        p.lookPositionXOffset = 0x18;
        p.lookPositionYOffset = 0x1C;
        p.lookPositionZOffset = 0x20;
        p.lookContainerSentinelEnabled = true;
        p.lookContainerSentinelX = 0xFFFF;
        p.lookContextStatus = "confirmed_ground_and_container_runtime";
        return;
    }

    // A previously auto-discovered contract belongs to this exact fingerprint/profile.
    // Preserve it across reruns; do not demote it back to a static candidate.
    if (p.lookFeatureStatus == "confirmed_runtime" &&
        p.lookHookRva &&
        !p.lookHookArgument.empty() &&
        p.lookHookArgument != "pending" &&
        p.lookHookArgument != "pending_runtime_abi" &&
        p.lookItemIdOffset)
    {
        return;
    }

    // For a new build, static discovery only prepares the runtime test.
    // Never copy RDX/indirection assumptions from another build.
    uintptr_t candidateRva =
        p.fnGameDetailedLook
            ? p.fnGameDetailedLook
            : p.fnGameLook;

    if (candidateRva && p.itemIdOffset)
    {
        p.lookFeatureStatus =
            "candidate_static_requires_runtime_probe";
        p.lookHookFunction =
            p.fnGameDetailedLook
                ? "gameDetailedLook"
                : "gameLook";
        p.lookHookRva = candidateRva;
        p.lookHookArgument = "pending_runtime_abi";
        p.lookThingIndirection = 0;
        p.lookItemIdOffset = p.itemIdOffset;
        p.lookItemIdType = "u32";
        p.lookContextStatus = "pending_runtime_probe";
    }
    else
    {
        p.lookFeatureStatus = "pending";
        p.lookHookFunction = "pending";
        p.lookHookRva = 0;
        p.lookHookArgument = "pending";
        p.lookThingIndirection = 0;
        p.lookItemIdOffset = p.itemIdOffset;
        p.lookItemIdType = "u32";
        p.lookContextStatus = "pending";
    }
}

void BMApplyKnownLightEvidence(
    const BuildInfo& build,
    DbProfile& p)
{
    if (BMIsClassicFeatureReferenceBuild(build))
    {
        p.hackLightStatus = "confirmed_runtime_write";
        p.lightIntensityOffset = 0xF1;
        p.lightIntensityType = "u8";
        p.lightObservedBaseline = 0;
        p.lightObservedTorch = -1;
        p.lightObservedLux = 6;
        p.lightObservedGranLux = 8;
        p.lightHackValue = 15;
        p.lightCalibrationMethod =
            "localplayer_u8_transition_lux_gran_and_write_restore";
        p.lightWriteValidated = true;
        return;
    }

    if (p.hackLightStatus.empty() ||
        p.hackLightStatus == "unknown")
    {
        p.hackLightStatus = "pending";
    }

    if (p.lightIntensityType.empty() ||
        p.lightIntensityType == "unknown")
    {
        p.lightIntensityType = "u8";
    }

    if (p.lightCalibrationMethod.empty() ||
        p.lightCalibrationMethod == "unknown")
    {
        p.lightCalibrationMethod = "pending_runtime_transition";
    }
}

bool BMCalibratePlayerLightReadOnly(
    const BuildInfo& build,
    DbProfile& p)
{
    BMApplyKnownLightEvidence(build, p);

    if (p.hackLightStatus == "confirmed_runtime_write")
    {
        std::cout
            << "[PASS] HACKLIGHT ja confirmado por runtime+write nesta build: LocalPlayer+"
            << HexU64(p.lightIntensityOffset)
            << " (" << p.lightIntensityType << ")\n";
        return true;
    }

    uintptr_t localPlayer =
        ResolveProfileLocalPlayerForDiscovery(p);

    if (!localPlayer)
    {
        std::cout
            << "[LIGHT][PENDING] LocalPlayer nao esta valido agora.\n";
        p.hackLightStatus = "pending_player_not_ready";
        return false;
    }

    std::cout
        << "\n============================================================\n"
        << "             PLAYER LIGHT CALIBRATION (READ-ONLY)\n"
        << "============================================================\n"
        << "Este teste procura um BYTE de intensidade dentro do LocalPlayer.\n"
        << "Nao precisa utevo gran lux.\n"
        << "Personagem lvl baixo pode tentar TOCHA primeiro.\n"
        << "Se a tocha for luz do Item e nao do Player, nenhum campo sera promovido.\n"
        << "LocalPlayer: 0x" << std::hex << std::uppercase << localPlayer
        << std::dec << "\n";

    std::vector<uint8_t> base;
    std::vector<uint8_t> torch;
    std::vector<uint8_t> torchReturn;
    std::vector<uint8_t> lux;
    std::vector<uint8_t> luxReturn;

    WaitEnter(
        "BASE: deixe SEM tocha e SEM magia de luz; pressione ENTER..."
    );

    if (!BMCaptureLocalPlayerBytes(localPlayer, base))
    {
        std::cout << "[LIGHT][FAIL] Nao consegui capturar BASE.\n";
        p.hackLightStatus = "pending_capture_failed";
        return false;
    }

    std::vector<BMLightCandidate> torchCandidates;
    std::vector<BMLightCandidate> luxCandidates;

    if (AskYesNo(
            "Testar agora com TOCHA (ideal para personagem lvl baixo)? [S/N]: "))
    {
        WaitEnter(
            "TOCHA ON: equipe/acenda a tocha e confirme visualmente a luz; pressione ENTER..."
        );

        if (BMCaptureLocalPlayerBytes(localPlayer, torch))
        {
            WaitEnter(
                "TOCHA OFF: remova/apague a tocha e espere voltar; pressione ENTER..."
            );

            if (BMCaptureLocalPlayerBytes(localPlayer, torchReturn))
            {
                torchCandidates =
                    BMRankLightCandidates(
                        base,
                        torch,
                        torchReturn
                    );

                BMPrintLightCandidates(
                    "TORCH",
                    torchCandidates
                );
            }
        }
    }

    const bool canLux =
        AskYesNo(
            "Seu personagem ja pode usar 'utevo lux'? [S/N]: "
        );

    if (canLux)
    {
        // Re-capture clean base because a torch test may have changed state.
        WaitEnter(
            "LUX BASE: deixe a luz normal/sem tocha; pressione ENTER..."
        );

        BMCaptureLocalPlayerBytes(
            localPlayer,
            base
        );

        WaitEnter(
            "Agora fale 'utevo lux'. Enquanto a luz estiver ativa pressione ENTER..."
        );

        if (BMCaptureLocalPlayerBytes(localPlayer, lux))
        {
            WaitEnter(
                "Espere a luz de utevo lux terminar/voltar ao normal; pressione ENTER..."
            );

            if (BMCaptureLocalPlayerBytes(localPlayer, luxReturn))
            {
                luxCandidates =
                    BMRankLightCandidates(
                        base,
                        lux,
                        luxReturn
                    );

                BMPrintLightCandidates(
                    "UTEVO_LUX",
                    luxCandidates
                );
            }
        }
    }

    const BMLightCandidate* chosen = nullptr;
    std::string method;

    // Prefer the spell transition when available: it is known to represent
    // Creature/LocalPlayer light in the tested x64 family.
    if (!luxCandidates.empty())
    {
        chosen = &luxCandidates.front();
        method = "localplayer_u8_base_utevo_lux_return";
    }
    else if (!torchCandidates.empty())
    {
        chosen = &torchCandidates.front();
        method = "localplayer_u8_base_torch_return";
    }

    if (!chosen)
    {
        std::cout
            << "[LIGHT][PENDING] Nenhuma transicao forte dentro do LocalPlayer.\n"
            << "Isto e aceitavel: a tocha pode emitir luz pelo Item.\n"
            << "Repita quando 'utevo lux' estiver disponivel.\n";

        p.hackLightStatus =
            canLux
                ? "pending_no_localplayer_light_transition"
                : "pending_torch_no_localplayer_transition_retry_with_lux";
        p.lightCalibrationMethod =
            canLux
                ? "utevo_lux_no_candidate"
                : "torch_only_no_candidate";
        return false;
    }

    // Require a strong return-to-base signal before saving the offset.
    if (chosen->score < 200 ||
        chosen->returned != chosen->base)
    {
        std::cout
            << "[LIGHT][PENDING] Melhor candidato ainda fraco. Nao vou promover offset.\n";
        p.hackLightStatus = "candidate_weak_runtime_transition";
        p.lightCalibrationMethod = method;
        return false;
    }

    std::cout
        << "\n[LIGHT][CANDIDATE] LocalPlayer+"
        << HexU64(chosen->offset)
        << " u8: "
        << static_cast<unsigned>(chosen->base)
        << " -> "
        << static_cast<unsigned>(chosen->active)
        << " -> "
        << static_cast<unsigned>(chosen->returned)
        << "\n";

    if (!AskYesNo(
            "A mudanca visual de luz coincidiu EXATAMENTE com este teste? Salvar candidato? [S/N]: "))
    {
        p.hackLightStatus = "candidate_rejected_by_user";
        p.lightCalibrationMethod = method;
        return false;
    }

    p.lightIntensityOffset = chosen->offset;
    p.lightIntensityType = "u8";
    p.lightObservedBaseline = chosen->base;

    if (method.find("torch") != std::string::npos)
        p.lightObservedTorch = chosen->active;

    if (method.find("utevo_lux") != std::string::npos)
        p.lightObservedLux = chosen->active;

    p.lightHackValue = FEATURE_LIGHT_DEFAULT_HACK_VALUE;
    p.lightCalibrationMethod = method;
    p.lightWriteValidated = false;

    // Read-only BuildExplorer must not claim write validation.
    p.hackLightStatus =
        method.find("utevo_lux") != std::string::npos
            ? "confirmed_runtime_transition_write_test_pending"
            : "candidate_runtime_torch_transition_write_test_pending";

    std::cout
        << "[LIGHT][SAVED] Offset candidato salvo no BuildProfile.\n"
        << "[LIGHT][NEXT] O Crome so deve habilitar escrita quando status for confirmed_runtime_write.\n";

    return true;
}


// ============================================================
// V4.6.2 - OPTIONAL ACTIVE FEATURE VALIDATION
//
// The discovery core above remains read-only.  This block is entered only
// after explicit user opt-in and is intentionally limited to contracts that
// already have enough runtime evidence to be tested safely.
//
// LOOK:
//   - installs a temporary, reversible x64 entry hook;
//   - only uses exact prologues from the two reference-tested builds;
//   - reads Thing* from *(RDX) and prints the observed item id;
//   - always restores the original bytes before leaving the test.
//
// PLAYER LIGHT:
//   - snapshots the original LocalPlayer u8 intensity;
//   - continuously forces the configured hack value for a few seconds;
//   - restores the snapshot even when validation fails;
//   - promotes a candidate to confirmed_runtime_write only after the user
//     confirms the visual transition and the restore succeeds.
// ============================================================

struct BMActiveLookHookState
{
    uintptr_t target = 0;
    size_t patchLen = 0;
    uint8_t saved[32]{};
    void* trampoline = nullptr;
    bool installed = false;
    DbProfile* profile = nullptr;
    bool oldersContext = false;
};

BMActiveLookHookState g_bmActiveLook{};
volatile LONG64 g_bmActiveLookCalls = 0;
volatile LONG g_bmActiveLookLastId = 0;
bool g_bmActiveLookSessionValidated = false;
bool g_bmActiveLightSessionValidated = false;

using BMActiveLookFn =
    uintptr_t(*)(void*, void*, void*, void*);

BMActiveLookFn g_bmActiveLookOriginal = nullptr;

bool BMActiveReadable(
    uintptr_t address,
    size_t size)
{
    if (!address || !size)
        return false;

    MEMORY_BASIC_INFORMATION mbi{};

    if (!VirtualQuery(
            reinterpret_cast<void*>(address),
            &mbi,
            sizeof(mbi)))
    {
        return false;
    }

    if (mbi.State != MEM_COMMIT ||
        (mbi.Protect & (PAGE_NOACCESS | PAGE_GUARD)))
    {
        return false;
    }

    const uintptr_t begin =
        reinterpret_cast<uintptr_t>(
            mbi.BaseAddress
        );

    const uintptr_t end =
        begin +
        mbi.RegionSize;

    return
        address >= begin &&
        address + size >= address &&
        address + size <= end;
}

bool BMActiveExecutable(
    uintptr_t address)
{
    if (!address)
        return false;

    MEMORY_BASIC_INFORMATION mbi{};

    if (!VirtualQuery(
            reinterpret_cast<void*>(address),
            &mbi,
            sizeof(mbi)))
    {
        return false;
    }

    if (mbi.State != MEM_COMMIT ||
        (mbi.Protect & (PAGE_NOACCESS | PAGE_GUARD)))
    {
        return false;
    }

    const DWORD protection =
        mbi.Protect & 0xFF;

    return
        protection == PAGE_EXECUTE ||
        protection == PAGE_EXECUTE_READ ||
        protection == PAGE_EXECUTE_READWRITE ||
        protection == PAGE_EXECUTE_WRITECOPY;
}

void BMActiveMakeAbsJump(
    uint8_t* out,
    uintptr_t target)
{
    out[0] = 0x48;
    out[1] = 0xB8;

    std::memcpy(
        out + 2,
        &target,
        sizeof(target)
    );

    out[10] = 0xFF;
    out[11] = 0xE0;
}

bool BMActiveWriteByte(
    uintptr_t address,
    uint8_t value)
{
    if (!BMActiveReadable(
            address,
            1))
    {
        return false;
    }

    DWORD oldProtection = 0;

    if (!VirtualProtect(
            reinterpret_cast<void*>(address),
            1,
            PAGE_READWRITE,
            &oldProtection))
    {
        return false;
    }

    *reinterpret_cast<volatile uint8_t*>(
        address
    ) = value;

    DWORD ignored = 0;

    VirtualProtect(
        reinterpret_cast<void*>(address),
        1,
        oldProtection,
        &ignored
    );

    return true;
}

uintptr_t BMActiveLookDetour(
    void* a1,
    void* a2,
    void* a3,
    void* a4)
{
    InterlockedIncrement64(
        &g_bmActiveLookCalls
    );

    DbProfile* p =
        g_bmActiveLook.profile;

    const uintptr_t rdx =
        reinterpret_cast<uintptr_t>(
            a2
        );

    uintptr_t thing = 0;

    if (rdx && p)
    {
        thing =
            ReadPtr(
                rdx
            );
    }

    uint32_t id = 0;

    if (thing &&
        p &&
        p->lookItemIdOffset)
    {
        SafeRead(
            thing +
                p->lookItemIdOffset,
            id
        );
    }

    if (id > 0 &&
        id < 1000000)
    {
        InterlockedExchange(
            &g_bmActiveLookLastId,
            static_cast<LONG>(
                id
            )
        );

        std::cout
            << "\n[LOOK][ACTIVE] id="
            << id;

        if (g_bmActiveLook.oldersContext &&
            p->lookPositionXOffset &&
            p->lookPositionYOffset &&
            p->lookPositionZOffset)
        {
            uint32_t x = 0;
            uint32_t y = 0;
            uint8_t z = 0;

            SafeRead(
                thing +
                    p->lookPositionXOffset,
                x
            );

            SafeRead(
                thing +
                    p->lookPositionYOffset,
                y
            );

            SafeRead(
                thing +
                    p->lookPositionZOffset,
                z
            );

            if (p->lookContainerSentinelEnabled &&
                x == p->lookContainerSentinelX)
            {
                std::cout
                    << " container/inventory";
            }
            else
            {
                std::cout
                    << " ground pos="
                    << x
                    << ","
                    << y
                    << ","
                    << static_cast<unsigned>(z);
            }
        }
        else
        {
            // Classico Item does not expose Creature XYZ at +30/+34/+38.
            // Do not print a fake position.  ID capture itself is confirmed.
            std::cout
                << " context=pending";
        }

        std::cout
            << " Thing="
            << HexPtr(thing)
            << "\n";

        std::cout.flush();
    }

    return
        g_bmActiveLookOriginal
            ? g_bmActiveLookOriginal(
                a1,
                a2,
                a3,
                a4)
            : 0;
}

bool BMInstallActiveLookHook(
    const BuildInfo& build,
    DbProfile& p)
{
    // Refuse to patch a new/unverified ABI.  The reference builds below have
    // already been proven with isolated probes and exact clean prologues.
    const bool isClassic =
        BMIsClassicFeatureReferenceBuild(
            build
        );

    const bool isOlders =
        BMIsOldersFeatureReferenceBuild(
            build
        );

    if (!isClassic &&
        !isOlders)
    {
        std::cout
            << "[LOOK][ACTIVE][SKIP] Esta build ainda nao possui contrato de hook runtime confirmado.\n"
            << "[LOOK][ACTIVE][SKIP] Mantendo candidate_static_requires_runtime_probe.\n";
        return false;
    }

    const uint8_t classicExpected[] = {
        0x48,0x89,0x5C,0x24,0x18,
        0x48,0x89,0x74,0x24,0x20,
        0x57,
        0x48,0x81,0xEC,0x90,0x00,0x00,0x00
    };

    const uint8_t oldersExpected[] = {
        0x48,0x89,0x5C,0x24,0x18,
        0x55,0x56,0x57,
        0x48,0x81,0xEC,0xB0,0x00,0x00,0x00
    };

    const uint8_t* expected =
        isClassic
            ? classicExpected
            : oldersExpected;

    const size_t patchLen =
        isClassic
            ? sizeof(classicExpected)
            : sizeof(oldersExpected);

    if (!p.lookHookRva)
    {
        std::cout
            << "[LOOK][ACTIVE][FAIL] Hook RVA ausente.\n";
        return false;
    }

    const uintptr_t target =
        g_exeBase +
        p.lookHookRva;

    if (!BMActiveReadable(
            target,
            patchLen) ||
        !BMActiveExecutable(
            target))
    {
        std::cout
            << "[LOOK][ACTIVE][FAIL] Endereco de hook nao esta executavel/legivel: "
            << HexPtr(target)
            << "\n";
        return false;
    }

    if (std::memcmp(
            reinterpret_cast<const void*>(target),
            expected,
            patchLen) != 0)
    {
        std::cout
            << "[LOOK][ACTIVE][FAIL] Prologo nao corresponde ao probe confirmado. Nenhum patch aplicado.\n"
            << "  Target: "
            << HexPtr(target)
            << "\n";
        return false;
    }

    g_bmActiveLook = {};
    g_bmActiveLook.target = target;
    g_bmActiveLook.patchLen = patchLen;
    g_bmActiveLook.profile = &p;
    g_bmActiveLook.oldersContext = isOlders;

    std::memcpy(
        g_bmActiveLook.saved,
        reinterpret_cast<const void*>(target),
        patchLen
    );

    auto* trampoline =
        reinterpret_cast<uint8_t*>(
            VirtualAlloc(
                nullptr,
                patchLen + 16,
                MEM_COMMIT | MEM_RESERVE,
                PAGE_EXECUTE_READWRITE
            )
        );

    if (!trampoline)
    {
        std::cout
            << "[LOOK][ACTIVE][FAIL] VirtualAlloc do trampoline falhou.\n";
        return false;
    }

    std::memcpy(
        trampoline,
        g_bmActiveLook.saved,
        patchLen
    );

    BMActiveMakeAbsJump(
        trampoline + patchLen,
        target + patchLen
    );

    for (size_t i = patchLen + 12;
         i < patchLen + 16;
         ++i)
    {
        trampoline[i] = 0x90;
    }

    FlushInstructionCache(
        GetCurrentProcess(),
        trampoline,
        patchLen + 16
    );

    g_bmActiveLook.trampoline =
        trampoline;

    g_bmActiveLookOriginal =
        reinterpret_cast<BMActiveLookFn>(
            trampoline
        );

    uint8_t patch[32]{};

    std::memset(
        patch,
        0x90,
        patchLen
    );

    BMActiveMakeAbsJump(
        patch,
        reinterpret_cast<uintptr_t>(
            &BMActiveLookDetour
        )
    );

    DWORD oldProtection = 0;

    if (!VirtualProtect(
            reinterpret_cast<void*>(target),
            patchLen,
            PAGE_EXECUTE_READWRITE,
            &oldProtection))
    {
        VirtualFree(
            trampoline,
            0,
            MEM_RELEASE
        );

        g_bmActiveLook = {};
        g_bmActiveLookOriginal = nullptr;
        return false;
    }

    std::memcpy(
        reinterpret_cast<void*>(target),
        patch,
        patchLen
    );

    FlushInstructionCache(
        GetCurrentProcess(),
        reinterpret_cast<void*>(target),
        patchLen
    );

    DWORD ignored = 0;

    VirtualProtect(
        reinterpret_cast<void*>(target),
        patchLen,
        oldProtection,
        &ignored
    );

    InterlockedExchange64(
        &g_bmActiveLookCalls,
        0
    );

    InterlockedExchange(
        &g_bmActiveLookLastId,
        0
    );

    g_bmActiveLook.installed = true;

    std::cout
        << "[LOOK][ACTIVE][OK] Hook temporario instalado em "
        << p.lookHookFunction
        << " @ "
        << HexU64(p.lookHookRva)
        << ".\n";

    return true;
}

void BMUninstallActiveLookHook()
{
    if (g_bmActiveLook.installed &&
        g_bmActiveLook.target &&
        g_bmActiveLook.patchLen)
    {
        DWORD oldProtection = 0;

        if (VirtualProtect(
                reinterpret_cast<void*>(
                    g_bmActiveLook.target
                ),
                g_bmActiveLook.patchLen,
                PAGE_EXECUTE_READWRITE,
                &oldProtection))
        {
            std::memcpy(
                reinterpret_cast<void*>(
                    g_bmActiveLook.target
                ),
                g_bmActiveLook.saved,
                g_bmActiveLook.patchLen
            );

            FlushInstructionCache(
                GetCurrentProcess(),
                reinterpret_cast<void*>(
                    g_bmActiveLook.target
                ),
                g_bmActiveLook.patchLen
            );

            DWORD ignored = 0;

            VirtualProtect(
                reinterpret_cast<void*>(
                    g_bmActiveLook.target
                ),
                g_bmActiveLook.patchLen,
                oldProtection,
                &ignored
            );
        }
    }

    if (g_bmActiveLook.trampoline)
    {
        VirtualFree(
            g_bmActiveLook.trampoline,
            0,
            MEM_RELEASE
        );
    }

    g_bmActiveLook = {};
    g_bmActiveLookOriginal = nullptr;
}

// ============================================================
// V4.9.3 - PLAYER FOLLOW REBIND FIX + GENERIC LOOK AUTO DISCOVERY
//
// Uses a one-byte INT3 + vectored exception handler instead of copying an
// unknown function prologue into a trampoline.  This lets a new build prove
// the x64 argument/indirection contract without assuming another build's ABI.
// The original byte is restored before the module leaves the test.
// ============================================================

constexpr size_t BM_LOOK_AUTO_MAX_CAPTURES = 64;
constexpr uint32_t BM_LOOK_DEFAULT_ITEM_A = 3031;
constexpr uint32_t BM_LOOK_DEFAULT_ITEM_B = 3552;

struct BMLookAutoRegObservation
{
    uintptr_t raw = 0;
    uintptr_t directThing = 0;
    uintptr_t indirectThing = 0;
    uint32_t directId = 0;
    uint32_t indirectId = 0;
    bool directValid = false;
    bool indirectValid = false;
};

struct BMLookAutoCapture
{
    DWORD threadId = 0;
    BMLookAutoRegObservation regs[4]{};
};

struct BMLookAutoBreakpointState
{
    uintptr_t target = 0;
    uint8_t originalByte = 0;
    uintptr_t itemIdOffset = 0;
    uintptr_t expectedItemVtable = 0;
    PVOID vehHandle = nullptr;
    volatile LONG installed = 0;
    volatile LONG armed = 0;
    volatile LONG rearmThreadId = 0;
    volatile LONG captureCount = 0;
    BMLookAutoCapture captures[BM_LOOK_AUTO_MAX_CAPTURES]{};
};

BMLookAutoBreakpointState g_bmLookAuto{};

bool BMRawPatchOneByte(
    uintptr_t address,
    uint8_t value)
{
    if (!address)
        return false;

    DWORD oldProtection = 0;

    if (!VirtualProtect(
            reinterpret_cast<void*>(address),
            1,
            PAGE_EXECUTE_READWRITE,
            &oldProtection))
    {
        return false;
    }

    *reinterpret_cast<volatile uint8_t*>(address) = value;

    FlushInstructionCache(
        GetCurrentProcess(),
        reinterpret_cast<void*>(address),
        1
    );

    DWORD ignored = 0;
    VirtualProtect(
        reinterpret_cast<void*>(address),
        1,
        oldProtection,
        &ignored
    );

    return true;
}

bool BMLookAutoReadItem(
    uintptr_t thing,
    uint32_t& id)
{
    id = 0;

    if (!thing ||
        !g_bmLookAuto.itemIdOffset)
    {
        return false;
    }

    if (g_bmLookAuto.expectedItemVtable)
    {
        uintptr_t vtable = 0;

        if (!SafeRead(thing, vtable) ||
            vtable != g_bmLookAuto.expectedItemVtable)
        {
            return false;
        }
    }

    uint32_t value = 0;

    if (!SafeRead(
            thing + g_bmLookAuto.itemIdOffset,
            value))
    {
        return false;
    }

    if (!value || value >= 1000000)
        return false;

    id = value;
    return true;
}

LONG CALLBACK BMLookAutoVeh(
    PEXCEPTION_POINTERS info)
{
    if (!info ||
        !info->ExceptionRecord ||
        !info->ContextRecord ||
        !InterlockedCompareExchange(
            &g_bmLookAuto.installed,
            0,
            0))
    {
        return EXCEPTION_CONTINUE_SEARCH;
    }

    const DWORD code =
        info->ExceptionRecord->ExceptionCode;

    CONTEXT* ctx =
        info->ContextRecord;

    const DWORD currentThread =
        GetCurrentThreadId();

    if (code == EXCEPTION_BREAKPOINT &&
        reinterpret_cast<uintptr_t>(
            info->ExceptionRecord->ExceptionAddress
        ) == g_bmLookAuto.target)
    {
        const LONG slot =
            InterlockedIncrement(
                &g_bmLookAuto.captureCount
            ) - 1;

        if (slot >= 0 &&
            slot < static_cast<LONG>(BM_LOOK_AUTO_MAX_CAPTURES))
        {
            BMLookAutoCapture& capture =
                g_bmLookAuto.captures[
                    static_cast<size_t>(slot)
                ];

            capture = {};
            capture.threadId = currentThread;

            const uintptr_t values[4] = {
                static_cast<uintptr_t>(ctx->Rcx),
                static_cast<uintptr_t>(ctx->Rdx),
                static_cast<uintptr_t>(ctx->R8),
                static_cast<uintptr_t>(ctx->R9)
            };

            for (size_t i = 0; i < 4; ++i)
            {
                auto& obs = capture.regs[i];
                obs.raw = values[i];
                obs.directThing = values[i];

                obs.directValid =
                    BMLookAutoReadItem(
                        obs.directThing,
                        obs.directId
                    );

                uintptr_t indirect = 0;

                if (values[i] &&
                    SafeRead(values[i], indirect))
                {
                    obs.indirectThing = indirect;
                    obs.indirectValid =
                        BMLookAutoReadItem(
                            indirect,
                            obs.indirectId
                        );
                }
            }
        }

        // Execute the original first instruction once, then re-arm INT3 from
        // EXCEPTION_SINGLE_STEP. No unknown-length trampoline is required.
        BMRawPatchOneByte(
            g_bmLookAuto.target,
            g_bmLookAuto.originalByte
        );

        InterlockedExchange(
            &g_bmLookAuto.armed,
            0
        );

        InterlockedExchange(
            &g_bmLookAuto.rearmThreadId,
            static_cast<LONG>(currentThread)
        );

        ctx->Rip =
            static_cast<DWORD64>(
                g_bmLookAuto.target
            );

        ctx->EFlags |= 0x100u;

        return EXCEPTION_CONTINUE_EXECUTION;
    }

    if (code == EXCEPTION_SINGLE_STEP &&
        static_cast<DWORD>(
            InterlockedCompareExchange(
                &g_bmLookAuto.rearmThreadId,
                0,
                0
            )
        ) == currentThread)
    {
        BMRawPatchOneByte(
            g_bmLookAuto.target,
            0xCC
        );

        InterlockedExchange(
            &g_bmLookAuto.armed,
            1
        );

        InterlockedExchange(
            &g_bmLookAuto.rearmThreadId,
            0
        );

        ctx->EFlags &= ~0x100u;

        return EXCEPTION_CONTINUE_EXECUTION;
    }

    return EXCEPTION_CONTINUE_SEARCH;
}

void BMLookAutoClearCaptures()
{
    InterlockedExchange(
        &g_bmLookAuto.captureCount,
        0
    );

    std::memset(
        g_bmLookAuto.captures,
        0,
        sizeof(g_bmLookAuto.captures)
    );
}

bool BMInstallLookAutoBreakpoint(
    uintptr_t target,
    const DbProfile& p)
{
    if (!target ||
        !BMActiveReadable(target, 1) ||
        !BMActiveExecutable(target))
    {
        return false;
    }

    uint8_t original = 0;

    if (!SafeRead(target, original))
        return false;

    g_bmLookAuto = {};
    g_bmLookAuto.target = target;
    g_bmLookAuto.originalByte = original;
    g_bmLookAuto.itemIdOffset =
        p.lookItemIdOffset
            ? p.lookItemIdOffset
            : p.itemIdOffset;

    if (p.itemVtableRva)
    {
        g_bmLookAuto.expectedItemVtable =
            g_exeBase + p.itemVtableRva;
    }

    g_bmLookAuto.vehHandle =
        AddVectoredExceptionHandler(
            1,
            &BMLookAutoVeh
        );

    if (!g_bmLookAuto.vehHandle)
    {
        g_bmLookAuto = {};
        return false;
    }

    InterlockedExchange(
        &g_bmLookAuto.installed,
        1
    );

    if (!BMRawPatchOneByte(
            target,
            0xCC))
    {
        InterlockedExchange(
            &g_bmLookAuto.installed,
            0
        );

        RemoveVectoredExceptionHandler(
            g_bmLookAuto.vehHandle
        );

        g_bmLookAuto = {};
        return false;
    }

    InterlockedExchange(
        &g_bmLookAuto.armed,
        1
    );

    BMLookAutoClearCaptures();
    return true;
}

void BMUninstallLookAutoBreakpoint()
{
    if (InterlockedCompareExchange(
            &g_bmLookAuto.installed,
            0,
            0))
    {
        // Restore regardless of whether INT3 is currently armed. If a single
        // step is in flight, the handler remains installed until after restore.
        BMRawPatchOneByte(
            g_bmLookAuto.target,
            g_bmLookAuto.originalByte
        );
    }

    InterlockedExchange(
        &g_bmLookAuto.installed,
        0
    );

    if (g_bmLookAuto.vehHandle)
    {
        RemoveVectoredExceptionHandler(
            g_bmLookAuto.vehHandle
        );
    }

    g_bmLookAuto = {};
}

const char* BMLookAutoRegisterName(
    int index)
{
    switch (index)
    {
        case 0: return "RCX";
        case 1: return "RDX";
        case 2: return "R8";
        case 3: return "R9";
    }

    return "?";
}

std::string BMLookAutoPathName(
    int key)
{
    const int reg = key / 2;
    const int indirection = key % 2;

    std::ostringstream ss;

    if (indirection)
        ss << "*(";

    ss << BMLookAutoRegisterName(reg);

    if (indirection)
        ss << ")";

    return ss.str();
}

std::set<int> BMLookAutoMatches(
    uint32_t expectedId)
{
    std::set<int> matches;

    LONG count =
        InterlockedCompareExchange(
            &g_bmLookAuto.captureCount,
            0,
            0
        );

    if (count < 0)
        count = 0;

    if (count > static_cast<LONG>(BM_LOOK_AUTO_MAX_CAPTURES))
    {
        count = static_cast<LONG>(BM_LOOK_AUTO_MAX_CAPTURES);
    }

    for (LONG i = 0; i < count; ++i)
    {
        const auto& capture =
            g_bmLookAuto.captures[
                static_cast<size_t>(i)
            ];

        for (int r = 0; r < 4; ++r)
        {
            const auto& obs = capture.regs[r];

            if (obs.directValid &&
                obs.directId == expectedId)
            {
                matches.insert(r * 2);
            }

            if (obs.indirectValid &&
                obs.indirectId == expectedId)
            {
                matches.insert(r * 2 + 1);
            }
        }
    }

    return matches;
}

void BMLookAutoPrintObservedIds()
{
    std::set<std::string> lines;

    LONG count =
        InterlockedCompareExchange(
            &g_bmLookAuto.captureCount,
            0,
            0
        );

    if (count < 0)
        count = 0;

    if (count > static_cast<LONG>(BM_LOOK_AUTO_MAX_CAPTURES))
    {
        count = static_cast<LONG>(BM_LOOK_AUTO_MAX_CAPTURES);
    }

    for (LONG i = 0; i < count; ++i)
    {
        const auto& capture =
            g_bmLookAuto.captures[
                static_cast<size_t>(i)
            ];

        for (int r = 0; r < 4; ++r)
        {
            const auto& obs = capture.regs[r];

            if (obs.directValid)
            {
                std::ostringstream ss;
                ss << BMLookAutoRegisterName(r)
                   << " direct -> id="
                   << obs.directId;
                lines.insert(ss.str());
            }

            if (obs.indirectValid)
            {
                std::ostringstream ss;
                ss << "*(" << BMLookAutoRegisterName(r)
                   << ") -> id="
                   << obs.indirectId;
                lines.insert(ss.str());
            }
        }
    }

    for (const auto& line : lines)
    {
        std::cout
            << "    "
            << line
            << "\n";
    }
}

uint32_t BMAskLookReferenceId(
    const char* label,
    uint32_t defaultId)
{
    for (;;)
    {
        std::cout
            << label
            << " [default "
            << defaultId
            << "]: ";

        std::string input;
        std::getline(std::cin, input);

        if (input.empty())
            return defaultId;

        try
        {
            unsigned long value =
                std::stoul(
                    input,
                    nullptr,
                    0
                );

            if (value > 0 &&
                value < 1000000)
            {
                return static_cast<uint32_t>(value);
            }
        }
        catch (...)
        {
        }

        std::cout
            << "[INPUT] ID invalido. Tente novamente.\n";
    }
}

void BMChooseLookReferenceIds(
    uint32_t& itemA,
    uint32_t& itemB,
    bool firstTime)
{
    if (firstTime)
    {
        std::cout
            << "\n[LOOK AUTO] IDs sugeridos pelos testes atuais:\n"
            << "  Item A = 3031\n"
            << "  Item B = 3552\n"
            << "Eles NAO sao universais entre OTs. Confirme ou troque para esta build.\n";

        if (AskYesNo(
                "Usar A=3031 e B=3552 nesta calibracao? [S/N]: "))
        {
            itemA = BM_LOOK_DEFAULT_ITEM_A;
            itemB = BM_LOOK_DEFAULT_ITEM_B;
            return;
        }
    }
    else
    {
        std::ostringstream prompt;
        prompt
            << "Manter IDs A="
            << itemA
            << " e B="
            << itemB
            << "? [S/N]: ";

        if (AskYesNo(prompt.str().c_str()))
            return;
    }

    itemA =
        BMAskLookReferenceId(
            "ID conhecido do Item A",
            itemA ? itemA : BM_LOOK_DEFAULT_ITEM_A
        );

    do
    {
        itemB =
            BMAskLookReferenceId(
                "ID conhecido do Item B",
                itemB ? itemB : BM_LOOK_DEFAULT_ITEM_B
            );

        if (itemA == itemB)
        {
            std::cout
                << "[LOOK AUTO] Item B precisa ter ID diferente do Item A.\n";
        }
    }
    while (itemA == itemB);
}

std::vector<std::pair<uintptr_t, std::string>>
BMLookAutoFunctionCandidates(
    const DbProfile& p)
{
    std::vector<std::pair<uintptr_t, std::string>> out;

    auto add =
        [&](uintptr_t rva, const char* name)
        {
            if (!rva)
                return;

            for (const auto& entry : out)
            {
                if (entry.first == rva)
                    return;
            }

            out.emplace_back(rva, name);
        };

    add(
        p.lookHookRva,
        p.lookHookFunction.empty()
            ? "lookCandidate"
            : p.lookHookFunction.c_str()
    );

    add(p.fnGameDetailedLook, "gameDetailedLook");
    add(p.fnGameLook, "gameLook");

    return out;
}

bool BMRunLookAutoDiscovery(
    const BuildInfo& build,
    DbProfile& p)
{
    (void)build;

    const uintptr_t idOffset =
        p.lookItemIdOffset
            ? p.lookItemIdOffset
            : p.itemIdOffset;

    if (!idOffset)
    {
        std::cout
            << "[LOOK AUTO][FAIL] Item ID offset ainda nao foi descoberto.\n";
        return false;
    }

    auto functionCandidates =
        BMLookAutoFunctionCandidates(p);

    if (functionCandidates.empty())
    {
        std::cout
            << "[LOOK AUTO][FAIL] Nenhum Game::look/detailedLook candidato disponivel.\n";
        return false;
    }

    uint32_t itemA = BM_LOOK_DEFAULT_ITEM_A;
    uint32_t itemB = BM_LOOK_DEFAULT_ITEM_B;

    BMChooseLookReferenceIds(
        itemA,
        itemB,
        true
    );

    std::cout
        << "\n============================================================\n"
        << "              LOOK AUTO DISCOVERY X64\n"
        << "============================================================\n"
        << "A DLL vai testar ate 3 ciclos antes de devolver R/S/Q.\n"
        << "Registros testados: RCX, RDX, R8, R9 e uma indirecao *(REG).\n"
        << "Item ID offset: +"
        << HexU64(idOffset)
        << "\n";

    for (int attempt = 1;
         attempt <= 3;
         ++attempt)
    {
        std::cout
            << "\n[LOOK AUTO] CICLO "
            << attempt
            << "/3\n";

        bool anyFunctionCalled = false;

        for (const auto& candidate :
             functionCandidates)
        {
            const uintptr_t rva = candidate.first;
            const std::string& functionName = candidate.second;
            const uintptr_t target = g_exeBase + rva;

            std::cout
                << "\n[LOOK AUTO] Testando "
                << functionName
                << " @ "
                << HexU64(rva)
                << "\n";

            p.lookItemIdOffset = idOffset;

            if (!BMInstallLookAutoBreakpoint(
                    target,
                    p))
            {
                std::cout
                    << "[LOOK AUTO] Nao foi possivel instalar breakpoint temporario neste candidato.\n";
                continue;
            }

            BMLookAutoClearCaptures();

            {
                std::ostringstream prompt;
                prompt
                    << "De LOOK no Item A de ID conhecido "
                    << itemA
                    << " e depois pressione ENTER...";
                WaitEnter(prompt.str().c_str());
            }

            LONG callsA =
                InterlockedCompareExchange(
                    &g_bmLookAuto.captureCount,
                    0,
                    0
                );

            auto matchesA =
                BMLookAutoMatches(itemA);

            if (callsA > 0)
            {
                anyFunctionCalled = true;
            }

            std::cout
                << "[LOOK AUTO][A] calls="
                << callsA
                << " expected="
                << itemA
                << " matches="
                << matchesA.size()
                << "\n";

            if (matchesA.empty())
            {
                BMLookAutoPrintObservedIds();
                BMUninstallLookAutoBreakpoint();

                if (callsA == 0)
                {
                    std::cout
                        << "[LOOK AUTO] Este candidato nao disparou com o Look; tentando o proximo.\n";
                }
                else
                {
                    std::cout
                        << "[LOOK AUTO] Funcao disparou, mas nenhum caminho produziu o ID A esperado.\n";
                }

                continue;
            }

            for (int key : matchesA)
            {
                std::cout
                    << "    A MATCH: "
                    << BMLookAutoPathName(key)
                    << " + "
                    << HexU64(idOffset)
                    << " = "
                    << itemA
                    << "\n";
            }

            BMLookAutoClearCaptures();

            {
                std::ostringstream prompt;
                prompt
                    << "Agora de LOOK no Item B de ID conhecido "
                    << itemB
                    << " e depois pressione ENTER...";
                WaitEnter(prompt.str().c_str());
            }

            LONG callsB =
                InterlockedCompareExchange(
                    &g_bmLookAuto.captureCount,
                    0,
                    0
                );

            auto matchesB =
                BMLookAutoMatches(itemB);

            std::set<int> common;

            std::set_intersection(
                matchesA.begin(),
                matchesA.end(),
                matchesB.begin(),
                matchesB.end(),
                std::inserter(
                    common,
                    common.end()
                )
            );

            std::cout
                << "[LOOK AUTO][B] calls="
                << callsB
                << " expected="
                << itemB
                << " matches="
                << matchesB.size()
                << " common="
                << common.size()
                << "\n";

            if (common.size() == 1)
            {
                const int key = *common.begin();
                const int regIndex = key / 2;
                const int indirection = key % 2;

                BMUninstallLookAutoBreakpoint();

                p.lookFeatureStatus =
                    "confirmed_runtime";
                p.lookHookFunction =
                    functionName;
                p.lookHookRva = rva;
                p.lookHookArgument =
                    BMLookAutoRegisterName(
                        regIndex
                    );
                p.lookThingIndirection =
                    static_cast<uintptr_t>(
                        indirection
                    );
                p.lookItemIdOffset = idOffset;
                p.lookItemIdType = "u32";
                p.lookContextStatus =
                    "item_id_confirmed_context_pending";

                g_bmActiveLookSessionValidated = true;

                std::cout
                    << "\n============================================================\n"
                    << "               LOOK ABI CONFIRMED\n"
                    << "============================================================\n"
                    << "Function       : "
                    << p.lookHookFunction
                    << "\n"
                    << "Hook RVA       : "
                    << HexU64(p.lookHookRva)
                    << "\n"
                    << "Argument       : "
                    << p.lookHookArgument
                    << "\n"
                    << "Indirection    : "
                    << p.lookThingIndirection
                    << "\n"
                    << "Item ID offset : +"
                    << HexU64(p.lookItemIdOffset)
                    << "\n"
                    << "Samples        : "
                    << itemA
                    << " / "
                    << itemB
                    << "\n"
                    << "Status         : confirmed_runtime\n";

                return true;
            }

            if (!matchesB.empty())
            {
                for (int key : matchesB)
                {
                    std::cout
                        << "    B MATCH: "
                        << BMLookAutoPathName(key)
                        << " + "
                        << HexU64(idOffset)
                        << " = "
                        << itemB
                        << "\n";
                }
            }
            else
            {
                BMLookAutoPrintObservedIds();
            }

            BMUninstallLookAutoBreakpoint();

            if (common.empty())
            {
                std::cout
                    << "[LOOK AUTO] A e B nao confirmaram o mesmo caminho de ABI.\n";
            }
            else
            {
                std::cout
                    << "[LOOK AUTO] Ainda existem multiplos caminhos equivalentes; repetindo para desempatar.\n";
            }
        }

        if (!anyFunctionCalled)
        {
            std::cout
                << "[LOOK AUTO] Nenhum candidato disparou neste ciclo.\n";
        }

        if (attempt < 3)
        {
            std::cout
                << "[LOOK AUTO] Ciclo nao fechou. Vamos repetir.\n";
        }
    }

    std::cout
        << "\n[LOOK AUTO][FAIL] 3 ciclos concluidos sem prova suficiente.\n"
        << "O modulo externo exibira R/S/Q.\n";

    // Preserve candidate/static evidence. Do not invent an ABI.
    if (p.lookFeatureStatus != "confirmed_runtime")
    {
        p.lookFeatureStatus =
            "candidate_static_requires_runtime_probe";
        p.lookHookArgument =
            "pending_runtime_abi";
        p.lookThingIndirection = 0;
        p.lookContextStatus =
            "pending_runtime_probe";
    }

    return false;
}

bool BMRunActiveLookValidation(
    const BuildInfo& build,
    DbProfile& p)
{
    // Reference builds keep the exact prologue-validated trampoline test that
    // has already been proven. New builds use the generic one-byte breakpoint
    // discovery above so ABI/patch length no longer needs a separate probe.
    if (BMIsClassicFeatureReferenceBuild(build) ||
        BMIsOldersFeatureReferenceBuild(build))
    {
        if (!AskYesNo(
                "Executar teste ATIVO do Look agora? Ele instala um hook temporario e reversivel. [S/N]: "))
        {
            return
                p.lookFeatureStatus == "confirmed_runtime";
        }

        if (!BMInstallActiveLookHook(
                build,
                p))
        {
            return false;
        }

        std::cout
            << "\n[LOOK][ACTIVE] No jogo, de LOOK em pelo menos DOIS itens agora.\n"
            << "  - um item/objeto no chao\n"
            << "  - um item na backpack, se possivel\n"
            << "Cada evento valido deve imprimir [LOOK][ACTIVE] id=...\n";

        WaitEnter(
            "Depois dos LOOKs, pressione ENTER para remover o hook e validar..."
        );

        const LONG64 calls =
            InterlockedCompareExchange64(
                &g_bmActiveLookCalls,
                0,
                0
            );

        const LONG lastId =
            InterlockedCompareExchange(
                &g_bmActiveLookLastId,
                0,
                0
            );

        BMUninstallActiveLookHook();

        std::cout
            << "[LOOK][ACTIVE] Hook removido; bytes originais restaurados. calls="
            << calls
            << " lastId="
            << lastId
            << "\n";

        if (calls > 0 &&
            lastId > 0)
        {
            p.lookFeatureStatus =
                "confirmed_runtime";

            if (BMIsClassicFeatureReferenceBuild(build))
            {
                p.lookContextStatus =
                    "item_id_confirmed_context_pending";
            }
            else
            {
                p.lookContextStatus =
                    "confirmed_ground_and_container_runtime";
            }

            g_bmActiveLookSessionValidated = true;

            std::cout
                << "[LOOK][ACTIVE][PASS] Game Look disparou e Item ID foi lido ao vivo nesta sessao.\n";
            return true;
        }

        std::cout
            << "[LOOK][ACTIVE][FAIL] Nenhum Item ID valido foi capturado nesta sessao.\n"
            << "[LOOK][ACTIVE][INFO] Evidencia historica do profile nao sera apagada automaticamente.\n";

        return false;
    }

    if (!AskYesNo(
            "Executar LOOK AUTO DISCOVERY nesta nova build agora? [S/N]: "))
    {
        return
            p.lookFeatureStatus == "confirmed_runtime";
    }

    return BMRunLookAutoDiscovery(
        build,
        p
    );
}

bool BMRunActivePlayerLightValidation(
    const BuildInfo& build,
    DbProfile& p)
{
    (void)build;

    if (!p.lightIntensityOffset)
    {
        std::cout
            << "[LIGHT][ACTIVE][SKIP] Ainda nao existe offset de intensidade para testar.\n";
        return false;
    }

    if (!AskYesNo(
            "Executar teste ATIVO de Player Light agora? Ele escreve temporariamente e RESTAURA o byte original. [S/N]: "))
    {
        return false;
    }

    uintptr_t localPlayer =
        ResolveProfileLocalPlayerForDiscovery(
            p
        );

    if (!localPlayer)
    {
        std::cout
            << "[LIGHT][ACTIVE][FAIL] LocalPlayer nao esta valido.\n";
        return false;
    }

    const uintptr_t lightAddress =
        localPlayer +
        p.lightIntensityOffset;

    uint8_t original = 0;

    if (!SafeRead(
            lightAddress,
            original))
    {
        std::cout
            << "[LIGHT][ACTIVE][FAIL] Nao consegui ler o byte original.\n";
        return false;
    }

    int requested =
        p.lightHackValue;

    if (requested <= 0 ||
        requested > 255)
    {
        requested =
            FEATURE_LIGHT_DEFAULT_HACK_VALUE;
    }

    const uint8_t hackValue =
        static_cast<uint8_t>(
            requested
        );

    std::cout
        << "[LIGHT][ACTIVE] LocalPlayer="
        << HexPtr(localPlayer)
        << " offset=+"
        << HexU64(p.lightIntensityOffset)
        << " original="
        << static_cast<unsigned>(original)
        << " test="
        << static_cast<unsigned>(hackValue)
        << "\n"
        << "[LIGHT][ACTIVE] Forcando este valor por ~4 segundos. Observe a iluminacao do personagem.\n";

    bool writeOk = true;

    const DWORD start =
        GetTickCount();

    while (GetTickCount() - start < 4000)
    {
        if (!BMActiveWriteByte(
                lightAddress,
                hackValue))
        {
            writeOk = false;
            break;
        }

        Sleep(50);
    }

    const bool restoreOk =
        BMActiveWriteByte(
            lightAddress,
            original
        );

    std::cout
        << "[LIGHT][ACTIVE] Restore="
        << (restoreOk ? "OK" : "FAIL")
        << " valor="
        << static_cast<unsigned>(original)
        << "\n";

    if (!writeOk ||
        !restoreOk)
    {
        std::cout
            << "[LIGHT][ACTIVE][FAIL] Escrita/restore nao fechou com seguranca.\n";
        return false;
    }

    if (!AskYesNo(
            "A iluminacao ficou visivelmente mais forte durante os ~4 segundos e voltou ao normal depois? [S/N]: "))
    {
        std::cout
            << "[LIGHT][ACTIVE][FAIL] Usuario nao confirmou a transicao visual.\n"
            << "[LIGHT][ACTIVE][INFO] Offset preservado como evidencia; status anterior nao sera apagado automaticamente.\n";
        return false;
    }

    p.lightObservedBaseline =
        original;

    p.lightHackValue =
        hackValue;

    p.lightWriteValidated =
        true;

    p.hackLightStatus =
        "confirmed_runtime_write";

    if (p.lightCalibrationMethod.empty() ||
        p.lightCalibrationMethod == "unknown" ||
        p.lightCalibrationMethod == "pending_runtime_transition")
    {
        p.lightCalibrationMethod =
            "active_write_restore_user_visual_confirmed";
    }
    else if (p.lightCalibrationMethod.find(
                 "active_reverified") ==
             std::string::npos)
    {
        p.lightCalibrationMethod +=
            "_active_reverified";
    }

    g_bmActiveLightSessionValidated = true;

    std::cout
        << "[LIGHT][ACTIVE][PASS] Write + force + restore confirmados nesta sessao.\n";

    return true;
}

bool BMRunX64FeatureStage(
    const BuildInfo& build,
    DbProfile& p)
{
    g_bmActiveLookSessionValidated = false;
    g_bmActiveLightSessionValidated = false;

    BMRefreshLookFeatureContract(build, p);
    BMApplyKnownLightEvidence(build, p);

    std::cout
        << "\n============================================================\n"
        << "              X64 FEATURES - LOOK + HACKLIGHT\n"
        << "============================================================\n"
        << "Look status : " << p.lookFeatureStatus << "  [profile/reference evidence]\n"
        << "Look RVA    : " << HexU64(p.lookHookRva) << "\n"
        << "Item ID off : " << HexU64(p.lookItemIdOffset) << "\n"
        << "Light status: " << p.hackLightStatus << "  [profile/reference evidence]\n"
        << "Session test: NOT RUN YET - os blocos abaixo validam ao vivo.\n";

    std::cout
        << "\n============================================================\n"
        << "            OPTIONAL ACTIVE FEATURE VALIDATION\n"
        << "============================================================\n"
        << "O core do BuildExplorer continua READ-ONLY.\n"
        << "Somente com confirmacao explicita este modulo pode:\n"
        << "  - usar breakpoint/hook temporario e reversivel para Look;\n"
        << "  - escrever/restaurar o byte de Player Light para validar o hack.\n"
        << "Nada fica patchado ao terminar cada teste.\n";

    const bool lookOk =
        BMRunActiveLookValidation(
            build,
            p
        );

    // New/unknown builds calibrate Player Light by real transitions:
    // BASE -> TORCH -> BASE and/or BASE -> utevo lux -> BASE.
    if (p.hackLightStatus != "confirmed_runtime_write" &&
        !p.lightWriteValidated)
    {
        if (AskYesNo(
                "Executar calibracao READ-ONLY de Player Light agora? [S/N]: "))
        {
            BMCalibratePlayerLightReadOnly(
                build,
                p
            );
        }
    }

    BMRunActivePlayerLightValidation(
        build,
        p
    );

    std::cout
        << "\n[X64 FEATURES][FINAL]\n"
        << "  Look      : "
        << p.lookFeatureStatus
        << "\n"
        << "  HackLight : "
        << p.hackLightStatus
        << " offset="
        << HexU64(p.lightIntensityOffset)
        << " writeValidated="
        << (p.lightWriteValidated ? "YES" : "NO")
        << "\n"
        << "  Session Look ACTIVE : "
        << (g_bmActiveLookSessionValidated ? "PASS" : "NOT_RUN_OR_FAIL")
        << "\n"
        << "  Session Light ACTIVE: "
        << (g_bmActiveLightSessionValidated ? "PASS" : "NOT_RUN_OR_FAIL")
        << "\n";

    // Look is the mandatory x64 feature contract for this stage.  A new build
    // that exhausted its three auto-discovery cycles returns false so the
    // existing guided orchestrator immediately offers R / S / Q.
    if (!lookOk &&
        p.lookFeatureStatus != "confirmed_runtime")
    {
        return false;
    }

    return
        p.lookFeatureStatus == "confirmed_runtime" ||
        p.hackLightStatus != "pending";
}


void BMPrintWizardSummary(
    const DbProfile& p)
{
    auto status =
        [](
            bool value)
        {
            return
                value
                    ? "PASS"
                    : "PENDING";
        };

    auto semanticStatus =
        [](
            const std::string& value)
        {
            if (
                value.find(
                    "layout_pending") !=
                    std::string::npos ||
                value.find(
                    "owner_confirmed_layout_pending") !=
                    std::string::npos
            )
            {
                return "PARTIAL";
            }

            if (value.find(
                    "confirmed_") == 0)
            {
                return "PASS";
            }

            if (value.find(
                    "partial_") == 0)
            {
                return "PARTIAL";
            }

            return "PENDING";
        };

    std::cout
        << "\n============================================================\n"
        << "                  MIGRATION SUMMARY\n"
        << "============================================================\n"
        << "Player              : "
        << status(
            p.vtableRva &&
            p.directGlobalRva)
        << "\n"
        << "Game/Attack         : "
        << status(
            p.gameRva &&
            p.gameAttackTarget)
        << "\n"
        << "Follow              : "
        << status(
            p.gameFollowTarget)
        << "\n"
        << "Map                 : "
        << status(
            p.mapRva &&
            p.mapCenterX)
        << "\n"
        << "Tile::things        : "
        << status(
            p.tileThingsBegin &&
            p.tileThingsEnd &&
            p.tileThingsCap)
        << "\n"
        << "Map->Tile           : "
        << status(
            p.mapTilePathDepth &&
            p.mapTilePathMapOffset)
        << "\n"
        << "Monster             : "
        << semanticStatus(
            p.monsterVtableStatus)
        << "\n"
        << "Classification      : "
        << semanticStatus(
            p.classificationStatus)
        << "\n"
        << "NPC                 : "
        << semanticStatus(
            p.npcStatus)
        << "\n"
        << "Inventory           : "
        << semanticStatus(
            p.inventoryStatus)
        << "\n"
        << "Item layout         : "
        << semanticStatus(
            p.itemLayoutStatus)
        << "\n"
        << "Containers          : "
        << semanticStatus(
            p.containersStatus)
        << "\n"
        << "Functions           : "
        << p.functionsStatus
        << "\n"
        << "Look ID feature     : "
        << p.lookFeatureStatus
        << "\n"
        << "HackLight feature   : "
        << p.hackLightStatus
        << " (offset="
        << HexU64(p.lightIntensityOffset)
        << ")\n";
}

bool BMRunGuidedPipeline(
    const BuildInfo& build,
    DbProfile& profile,
    std::vector<DbProfile>& database,
    int profileIndex,
    const std::string& databasePath,
    const std::string& dllDirectory)
{
    bool stopRequested = false;

    bool stage2Ok =
        BMRunGuidedModule(
            "GAME + ATTACKTARGET",
            [&]()
            {
                return
                    EnsureGameDiscovery(
                        profile,
                        database,
                        profileIndex,
                        databasePath
                    );
            },
            stopRequested
        );

    bool stage3Ok = false;

    if (stage2Ok &&
        !stopRequested)
    {
        stage3Ok =
            BMRunGuidedModule(
                "FOLLOWTARGET",
                [&]()
                {
                    return
                        EnsureFollowDiscovery(
                            profile,
                            database,
                            profileIndex,
                            databasePath
                        );
                },
                stopRequested
            );
    }
    else
    {
        std::cout
            << "[BLOCKED] FOLLOWTARGET depende de GAME.\n";
    }

    bool stage4Ok = false;

    if (stage2Ok &&
        stage3Ok &&
        !stopRequested)
    {
        stage4Ok =
            BMRunGuidedModule(
                "MAP / CENTER / AWARE",
                [&]()
                {
                    return
                        EnsureMapDiscovery(
                            profile,
                            database,
                            profileIndex,
                            databasePath
                        );
                },
                stopRequested
            );
    }
    else
    {
        std::cout
            << "[BLOCKED] MAP depende de GAME + FOLLOW.\n";
    }

    bool stage5aOk = false;

    if (stage4Ok &&
        !stopRequested)
    {
        stage5aOk =
            BMRunGuidedModule(
                "TILE::THINGS",
                [&]()
                {
                    return
                        EnsureTileThingsDiscovery(
                            profile,
                            database,
                            profileIndex,
                            databasePath
                        );
                },
                stopRequested
            );
    }
    else
    {
        std::cout
            << "[BLOCKED] TILE::THINGS depende de MAP.\n";
    }

    bool stage5bOk = false;

    if (stage5aOk &&
        !stopRequested)
    {
        stage5bOk =
            BMRunGuidedModule(
                "MAP -> TILE STORAGE",
                [&]()
                {
                    return
                        EnsureMapTilePathDiscovery(
                            profile,
                            database,
                            profileIndex,
                            databasePath
                        );
                },
                stopRequested
            );
    }
    else
    {
        std::cout
            << "[BLOCKED] MAP->TILE depende de TILE::THINGS.\n";
    }

    bool stage6aOk = false;

    if (stage5bOk &&
        !stopRequested)
    {
        stage6aOk =
            BMRunGuidedModule(
                "MONSTER / CREATURE",
                [&]()
                {
                    return
                        EnsureStage6AMonsterDiscovery(
                            profile,
                            database,
                            profileIndex,
                            databasePath
                        );
                },
                stopRequested
            );
    }
    else
    {
        std::cout
            << "[BLOCKED] MONSTER depende do WORLD TILE STORAGE.\n";
    }

    bool stage6bOk = false;

    if (stage6aOk &&
        !stopRequested)
    {
        stage6bOk =
            BMRunGuidedModule(
                "ITEM / PLAYER / CLASSIFICATION",
                [&]()
                {
                    return
                        EnsureStage6BClassification(
                            profile,
                            database,
                            profileIndex,
                            databasePath
                        );
                },
                stopRequested
            );
    }
    else
    {
        std::cout
            << "[BLOCKED] CLASSIFICATION depende de MONSTER.\n";
    }

    bool dataOk = false;

    const bool classificationAllowsData =
        stage6bOk ||
        profile.classificationStatus ==
            "partial_semantic_item_monster_player_pending";

    if (classificationAllowsData &&
        !stopRequested)
    {
        dataOk =
            BMRunGuidedModule(
                "NPC / INVENTORY / ITEM / CONTAINERS",
                [&]()
                {
                    EnsureBuildMigratorDataCompletion(
                        profile,
                        database,
                        profileIndex,
                        databasePath
                    );

                    return
                        BMDataCompletionReady(
                            profile
                        );
                },
                stopRequested
            );
    }
    else
    {
        std::cout
            << "[BLOCKED] FINAL DATA depende de Item/Monster semantic anchors.\n";
    }

    bool functionsOk = false;

    if (!stopRequested)
    {
        functionsOk =
            BMRunGuidedModule(
                "STATIC FUNCTION RVAS",
                [&]()
                {
                    return
                        EnsureBuildMigratorFunctionStage(
                            profile,
                            database,
                            profileIndex,
                            databasePath
                        );
                },
                stopRequested
            );
    }

    V42PrintNativeContractSummary(
        profile
    );

    bool featuresOk = false;

    if (!stopRequested)
    {
        featuresOk =
            BMRunGuidedModule(
                "X64 LOOK ID + PLAYER LIGHT",
                [&]()
                {
                    return BMRunX64FeatureStage(
                        build,
                        profile
                    );
                },
                stopRequested
            );
    }

    std::cout
        << "[FEATURE STAGE] "
        << (featuresOk ? "PASS/KNOWN" : "SKIPPED/PENDING")
        << "\n";

    if (profileIndex >= 0 &&
        profileIndex <
            static_cast<int>(
                database.size()))
    {
        database[
            static_cast<size_t>(
                profileIndex)
        ] = profile;

        SaveProfileDatabase(
            databasePath,
            database
        );
    }

    BMSaveCompleteProfile(
        build,
        profile,
        dllDirectory
    );

    BMPrintWizardSummary(
        profile
    );

    return
        stage2Ok &&
        stage3Ok &&
        stage4Ok &&
        stage5aOk &&
        stage5bOk &&
        stage6aOk &&
        stage6bOk &&
        dataOk &&
        functionsOk;
}

// ============================================================
// MAIN
// ============================================================

DWORD WINAPI MainThread(
    LPVOID)
{
    OpenConsole();

    SetConsoleTitleA(
        "OTCLab BuildMigrator V4.9.3 DIRECT BIND + Player Rebind + Look/Light Auto Discovery"
    );

    std::cout
        << "============================================================\n"
        << "               OTCLab BuildMigrator V4.9.3 DIRECT BIND + Player Rebind + Look/Light Auto Discovery\n"
        << "          CANONICAL PROFILE V2 / X64 / CONTAINER-SLOT ITEM PROVENANCE\n"
        << "============================================================\n"
        << "[CORE MODE] READ-ONLY\n"
        << "[CORE MODE] Nenhuma escrita/hook/chamada interna durante discovery\n"
        << "[FEATURE VERIFY] Opcional: hook Look temporario + write/restore Player Light\n"
        << "[FEATURE VERIFY] Sempre pede confirmacao antes de modificar memoria\n"
        << "============================================================\n";

    BuildInfo build{};

    if (!ResolveBuild(
            build))
    {
        std::cout
            << "\n[FATAL] Nao foi possivel resolver o PE x64.\n";

        WaitEnter(
            "Pressione ENTER para descarregar..."
        );

        FreeConsole();

        FreeLibraryAndExitThread(
            g_dllModule,
            0
        );

        return 0;
    }

    PrintBuild(
        build
    );

    char dllPath[MAX_PATH]{};

    GetModuleFileNameA(
        g_dllModule,
        dllPath,
        MAX_PATH
    );

    std::string dllDirectory =
        DirectoryOf(
            dllPath
        );

    // V3.9: no aggregate profile database is generated anymore.
    // The in-memory working set is rebuilt from the canonical V2 files.
    std::string databasePath;

    std::vector<DbProfile> database =
        V39LoadCanonicalProfileDirectory(
            dllDirectory
        );

    if (database.empty())
    {
        // One-time read-only compatibility import from the old aggregate
        // database. It is never rewritten by V3.9.
        std::string legacyDatabasePath =
            dllDirectory +
            "\\otclab_build_profiles.json";

        database =
            LoadProfileDatabase(
                legacyDatabasePath
            );

        if (!database.empty())
        {
            std::cout
                << "\n[MIGRATE] Perfis legados carregados apenas para conversao em BuildProfile V2.\n";
        }
    }

    std::cout
        << "\n[CANONICAL PROFILES] Perfis V2/legados em memoria: "
        << database.size()
        << "\n";

    int profileIndex =
        FindProfileIndex(
            build,
            database
        );

    // ========================================================
    // KNOWN BUILD
    // ========================================================

    if (profileIndex >= 0)
    {
        std::cout
            << "\n[KNOWN BUILD] Profile encontrado.\n"
            << "V4.6 faz FAST CHECK primeiro e so pede calibracao se necessario.\n";

        DbProfile& profile =
            database[
                profileIndex
            ];

        bool stopRequested = false;

        bool playerOk =
            BMEnsureKnownPlayer(
                build,
                profile,
                database,
                profileIndex,
                databasePath,
                stopRequested
            );

        if (playerOk &&
            !stopRequested)
        {
            BMRunGuidedPipeline(
                build,
                profile,
                database,
                profileIndex,
                databasePath,
                dllDirectory
            );
        }
        else
        {
            if (profileIndex >= 0 &&
                profileIndex <
                    static_cast<int>(
                        database.size()))
            {
                database[
                    static_cast<size_t>(
                        profileIndex)
                ] = profile;

                SaveProfileDatabase(
                    databasePath,
                    database
                );
            }

            BMSaveCompleteProfile(
                build,
                profile,
                dllDirectory
            );

            BMPrintWizardSummary(
                profile
            );
        }

        if (!stopRequested &&
            DbProfileMonitorReady(
                profile))
        {
            RunRuntimeMonitor(
                build,
                profile,
                database,
                profileIndex,
                databasePath,
                dllDirectory
            );
        }

        FreeConsole();

        FreeLibraryAndExitThread(
            g_dllModule,
            0
        );

        return 0;
    }

    // ========================================================
    // UNKNOWN BUILD -> SELF DISCOVERY
    // ========================================================

    std::cout
        << "\n============================================================\n"
        << "                    UNKNOWN BUILD\n"
        << "============================================================\n"
        << "Este fingerprint ainda nao existe no banco.\n"
        << "O BuildMigrator V4.6.1 vai aprender esta build agora.\n\n"
        << "Timestamp : "
        << HexU64(
            build.timestamp
        )
        << "\n"
        << "SizeImage : "
        << HexU64(
            build.sizeOfImage
        )
        << "\n"
        << "TextHash  : "
        << HexU64(
            build.textHash
        )
        << "\n";

    std::cout
        << "\n============================================================\n"
        << "                        WAIT LOGIN\n"
        << "============================================================\n"
        << "1. Faca login normalmente.\n"
        << "2. Entre no personagem.\n"
        << "3. Espere HP/Mana/XP/Cap aparecerem.\n";

    WaitEnter(
        "Quando estiver LOGADO, pressione ENTER..."
    );

    BulkInput input =
        AskBulkInput();

    Candidate bestCandidate{};
    BaseHypothesis bestBase{};

    if (!DiscoverLocalPlayer(
            input,
            bestCandidate,
            bestBase))
    {
        std::cout
            << "\n[STOP] Nao consegui localizar LocalPlayer.\n"
            << "Nenhum profile oficial foi alterado; nenhum RVA foi inventado.\n";

        WaitEnter(
            "Pressione ENTER para descarregar..."
        );

        FreeConsole();

        FreeLibraryAndExitThread(
            g_dllModule,
            0
        );

        return 0;
    }

    if (bestBase.score < 12)
    {
        std::cout
            << "\n[WARNING] Base score baixo: "
            << bestBase.score
            << "\n";

        if (!AskYesNo(
                "Continuar mesmo assim? [S/N]: "))
        {
            FreeConsole();

            FreeLibraryAndExitThread(
                g_dllModule,
                0
            );

            return 0;
        }
    }

    ProfileFields fields =
        ResolveBulkLocally(
            bestBase.base,
            input
        );

    PrintFields(
        fields
    );

    std::cout
        << "\n============================================================\n"
        << "                     SMART RETRY\n"
        << "============================================================\n"
        << "Somente campos pendentes serao repetidos; novas transicoes podem reduzir candidatos.\n";

    RetryPendingFields(
        bestBase.base,
        fields
    );

    PositionCalibration position =
        CalibratePositionAndDirection(
            bestBase.base
        );

    PointerDiscovery pointers =
        DiscoverPointerPath(
            bestBase.base
        );

    PrintFields(
        fields
    );

    // V3.9: nenhum JSON de discovery separado. O unico profile oficial
    // por build e o BuildProfile V2 canonico.

    DbProfile learned =
        BuildDatabaseProfile(
            build,
            bestBase,
            fields,
            position,
            pointers
        );

    database.push_back(
        learned
    );

    profileIndex =
        static_cast<int>(
            database.size() -
            1
        );

    BMSaveCompleteProfile(
        build,
        learned,
        dllDirectory
    );

    std::cout
        << "\n============================================================\n"
        << "                    PROFILE CREATED\n"
        << "============================================================\n"
        << "BuildProfile V2 canonico criado para esta build.\n";

    DbProfile& profile =
        database[
            profileIndex
        ];

    PrintDbProfile(
        profile
    );

    if (!DbProfileMonitorReady(
            profile))
    {
        std::cout
            << "\n[STOP] O profile foi salvo, mas faltou pelo menos um\n"
            << "elemento essencial para o monitor automatico.\n"
            << "Revise o BuildProfile V2 canonico salvo para esta build.\n";

        WaitEnter(
            "Pressione ENTER para descarregar..."
        );

        FreeConsole();

        FreeLibraryAndExitThread(
            g_dllModule,
            0
        );

        return 0;
    }

    BMRunGuidedPipeline(
        build,
        profile,
        database,
        profileIndex,
        databasePath,
        dllDirectory
    );

    PrintDbProfile(
        profile
    );

    if (DbProfileMonitorReady(
            profile))
    {
        std::cout
            << "\n============================================================\n"
            << "                SWITCHING TO RUNTIME WATCH\n"
            << "============================================================\n"
            << "A build foi aprendida/salva.\n"
            << "O core de Player esta monitoravel nesta sessao.\n";

        RunRuntimeMonitor(
            build,
            profile,
            database,
            profileIndex,
            databasePath,
            dllDirectory
        );
    }
    else
    {
        std::cout
            << "\n[PARTIAL PROFILE] Wizard terminou sem core suficiente para Runtime Watch.\n";
    }

    FreeConsole();

    FreeLibraryAndExitThread(
        g_dllModule,
        0
    );

    return 0;
}

} // namespace

// ============================================================
// DLL ENTRY
// ============================================================

BOOL APIENTRY DllMain(
    HMODULE hModule,
    DWORD reason,
    LPVOID)
{
    if (reason ==
        DLL_PROCESS_ATTACH)
    {
        g_dllModule =
            hModule;

        DisableThreadLibraryCalls(
            hModule
        );

        HANDLE thread =
            CreateThread(
                nullptr,
                0,
                MainThread,
                nullptr,
                0,
                nullptr
            );

        if (thread)
        {
            CloseHandle(
                thread
            );
        }
    }

    return TRUE;
}
